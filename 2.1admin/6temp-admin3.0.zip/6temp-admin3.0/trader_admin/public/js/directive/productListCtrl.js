app.controller("productListCtrl", function ($scope, localStorageService,$rootScope) {
    $(".productList-ajax").select2({
        ajax: {
            type: "GET",
            url: $rootScope.baseUrl + 'c/up/symbol/query/all',
            dataType: 'json',
            contentType: "application/x-www-form-urlencoded",
            delay: 200,
            data: function (params) {
                var query = {};
                return query
            },
            processResults: function (data, params) {
                console.log(data);
                var results=data.list;
                var itemUserList = [];
                for (var i = 0, r = results.length; i < r; i++) {
                    var tmpObject = {};
                    tmpObject.id = results[i].key;
                    // tmpObject.orgNum = results[i].organize.orgNum;
                    tmpObject.text = results[i].market+"-"+results[i].commodity+"-"+results[i].contract;
                    itemUserList.push(tmpObject);
                }
                console.log(itemUserList)
                return {
                    results: itemUserList
                };
            },
            cache: true
        },
        placeholder: '请选择',
        width:150,
        allowClear: true,
        // minimumInputLength:1,
        escapeMarkup: function (markup) {
            return markup;
        },  //字符转义处理
        templateResult: formatRepo,  //将返回结果的text显示到下拉框里
        templateSelection: formatRepoSelection  //定义selected的外观,将值写入input框
    });
    function formatRepo(repo) {
        // console.log(repo)
        var markup = '<div class="clearfix">' +
            '<sapn>' + repo.text + '</sapn>' +
            '</div>';
        return markup;
    }
    function formatRepoSelection(repo) {
        console.log(repo)
        $scope.directiveProductId=repo.id;//传值
        repo.selected = true;
        return repo.text;

    }
});