app.controller("upOrganizeCtrl", function ($scope, localStorageService,$rootScope) {
    $(".up-organize-example-ajax").select2({
        ajax: {
            type: "post",
            url: $rootScope.baseUrl + '/organize/query/as/page',
            dataType: 'json',
            contentType: "application/x-www-form-urlencoded",
            delay: 250,
            data: function (params) {
                var query = {
                    page: (params.page)?params.page:1,
                    rows: 20,
                    search_A_EQ_state: 1,
                    search_B_LIKE_orgName: params.term || '',
                    search_B_LIKE_orgNum: params.term || '',
                     group_B: 'OR'
                };
                return query
            },
            processResults: function (data, params) {
                var parseResult=JSON.parse(data.content);
                var results = parseResult.content;
                console.log(results);
                var itemList = [];
                for (var i = 0, r = results.length; i < r; i++) {
                    var tmp = {};
                    tmp.code = results[i].orgCode;
                    tmp.orgNum = results[i].orgNum;
                    tmp.id = results[i].orgId;
                    tmp.name = results[i].orgName;
                    tmp.text = results[i].orgName + ' (' + results[i].orgCode + ')';
                    itemList.push(tmp);
                }
                params.page = params.page || 1;
                return {
                    results: itemList,
                    pagination: {
                        more: (params.page * 10) < parseResult.totalElements
                    }
                };
            },
            cache: true
        },
        placeholder: '请选择',
        width:250,
        allowClear: true,
        escapeMarkup: function (markup) {
            return markup;
        },  //字符转义处理
        templateResult: formatRepo,  //将返回结果的text显示到下拉框里
        templateSelection: formatRepoSelection  //定义selected的外观,将值写入input框
    });
    function formatRepo(repo) {
        if (repo.loading) return repo.text;
        var markup = '<div class="clearfix">' +
            '<sapn>' + repo.name + '</sapn>' +
            '<span >' +'('+repo.orgNum+')'+ '</span>' +
            '</div>';
        return markup;
    }
    function formatRepoSelection(repo) {
        console.log(repo);
        $scope.upOrgCode=repo.code;
        $scope.upOrgId=repo.id;
        repo.selected = true;
        localStorageService.update('oldOrgId',repo.id);
        localStorageService.update('oldOrgCode',repo.code);
        if(repo.orgNum){
            return repo.name + '(' + repo.orgNum + ')';
        }else{
            return repo.name
        }
    }
});