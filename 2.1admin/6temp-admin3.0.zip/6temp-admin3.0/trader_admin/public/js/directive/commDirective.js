app
    .directive("alertBar", [function () {
        return {
            restrict: 'EA',
            templateUrl: '../views/tpl/alertBar.html',
            scope: {
                message: "=",
                type: "="
            },
            link: function (scope, element, attrs) {
                scope.hideAlert = function () {
                    scope.message = null;
                    scope.type = null;
                };
            }
        }
    }])
    .directive("confirmBar", [function () {
        return {
            restrict: 'EA',
            templateUrl: '../views/tpl/confirmBar.html'
        }
    }])
    .directive("organizeCode", [function () {
        return {
            restrict: 'EA',
            templateUrl: '../views/tpl/organizeCode.html',
            controller:"organizeCodeCtrl"
        }
    }])
    .directive("upOrganize", [function () {
        return {
            restrict: 'EA',
            templateUrl: '../views/tpl/upOrganize.html',
            controller:"upOrganizeCtrl"
        }
    }])
    .directive("userList", [function () {
        return {
            restrict: 'EA',
            templateUrl: '../views/tpl/userList.html',
            controller:"userListCtrl"
        }
    }])
    .directive("loginName", [function () {
        return {
            restrict: 'EA',
            templateUrl: '../views/tpl/loginName.html',
            controller:"loginNameCtrl"
        }
    }])
    .directive("fpCode", [function () {
        return {
            restrict: 'EA',
            templateUrl: '../views/tpl/fpCode.html',
            controller:"fpCodeCtrl"
        }
    }])
    .directive("productList", [function () {
        return {
            restrict: 'EA',
            templateUrl: '../views/tpl/productList.html',
            controller:"productListCtrl"
        }
    }])
    .directive("OrgIdlist", [function () {
        return {
            restrict: 'EA',
            templateUrl: '../views/tpl/OrgIdlist.html',
            controller:"OrgIdlistCtrl"
        }
    }])
    .directive("newOrganize", [function () {
        return {
            restrict: 'EA',
            templateUrl: '../views/tpl/newOrganize.html',
            controller:"newOrganizeCtrl"
        }
    }]);