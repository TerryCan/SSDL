app.controller("userListCtrl", function ($scope, localStorageService,$rootScope) {
    $(".userList-ajax").select2({
        ajax: {
            type: "post",
            url: $rootScope.baseUrl + '/user/query/customer/as/page',
            dataType: 'json',
            contentType: "application/x-www-form-urlencoded",
            delay: 200,
            data: function (params) {
                var query = {
                    page: (params.page)?params.page:1,
                    rows: 20,
                    search_A_NOTEQ_state: -1,
                    search_B_LIKE_loginName: params.term || '',
                    search_B_LIKE_email: params.term || '',
                    search_B_LIKE_phone: params.term || '',
                    'search_B_LIKE_sysOrganizeRelation.orgName': params.term || '',
                    'search_B_LIKE_sysOrganizeRelation.orgNum': params.term || '',
                    group_B:'OR'

            };
                return query
            },
            processResults: function (data, params) {
                var parseResult=JSON.parse(data.content);
                var results = parseResult.content;
                // console.log(results);
                var itemUserList = [];
                for (var i = 0, r = results.length; i < r; i++) {
                    var tmpObject = {};
                    tmpObject.id = results[i].userId;
                    tmpObject.orgNum = results[i].organize.orgNum;
                    tmpObject.text = results[i].loginName;
                    itemUserList.push(tmpObject);
                }
                // console.log(itemUserList)
                params.page = params.page || 1;
                return {
                    results: itemUserList,
                    pagination: {
                        more: (params.page * 10) < parseResult.totalElements
                    }
                };
            },
            cache: true
        },
        placeholder: '请选择',
        width:150,
        allowClear: true,
        // minimumInputLength:1,
        escapeMarkup: function (markup) {
            return markup;
        },  //字符转义处理
        templateResult: formatRepo,  //将返回结果的text显示到下拉框里
        templateSelection: formatRepoSelection  //定义selected的外观,将值写入input框
    });
    function formatRepo(repo) {
        // console.log(repo)
        var markup = '<div class="clearfix">' +
            '<sapn>' + repo.text + '</sapn>' +
            '<span >' +'('+repo.orgNum+')'+ '</span>' +
            '</div>';
        return markup;
    }
    function formatRepoSelection(repo) {
        // console.log(repo)
        $scope.directiveUserId=repo.id;//传值
        repo.selected = true;
        if(repo.orgNum){
            return repo.text + '(' + repo.orgNum + ')';
        }else{
            return repo.text
        }
    }
});