var app = angular.module('traderApp', ["login_page", "ui.router"]);
app.controller('AppController', ['$scope', 'tipService', 'confirmService', '$state', '$rootScope', function ($scope, tipService, confirmService, $state, $rootScope) {
    $rootScope.tipService = tipService;
    $rootScope.confirmService = confirmService;
    $rootScope.confirmShow = false;
    $rootScope.confirmImplement = function () {
    };
    $scope.changeState = function (name, opt) {
        $state.go(name, opt);
    };
}]);
app.run(["$rootScope", "$state", "dataSer", "localStorageService", function ($rootScope, $state, dataSer, localStorageService) {
    // window.localStorage.clear();
    $rootScope.$state = $state;
    $rootScope.version = "2.0";
    dataSer.initLine();
    var url = localStorageService.get("line");
    var nowUrl = localStorageService.get("baseUrl");
    if (!nowUrl && url) {
        $rootScope.baseUrl = url[0].value;
    } else {
        $rootScope.baseUrl = nowUrl;
    }
    $rootScope.checkLogin = function (bool) {
        if (!bool) {
            if (window.sessionStorage.getItem('isLogin') == null) {
                $state.go('login');
                return;
            }
        } else {
            $state.go('tabs.home');
        }
    };
}]);
app.config(['$stateProvider', '$urlRouterProvider', '$httpProvider', '$compileProvider', function ($stateProvider, $urlRouterProvider, $httpProvider, $compileProvider) {
    $httpProvider.defaults.headers.common = {
        'X-Requested-With': 'XMLHttpRequest'
    };
    $compileProvider.imgSrcSanitizationWhitelist(/^\s*(https?|local|data|chrome-extension):/);
    $urlRouterProvider.when('', "login");
    $stateProvider
        .state("login", {
            url: "/login",
            templateUrl: "../views/login.html",
            controller: "loginCtrl"
        })
        .state("onlineAddUser", {
            url: "/onlineAddUser",
            templateUrl: "../views/tpl/onlineAddUser.html",
            controller: "onlineAddUserCtrl"
        })
        .state("forgot_password", {
            url: "/forgot_password",
            templateUrl: "../views/forgot_password.html",
            controller: "forgot_passwordCtrl"
        })
        .state("tabs", {
            url: "/trader",
            templateUrl: "../views/trader.html"
        })
        .state("tabs.home", { //首页
            url: "/home",
            templateUrl: "../views/tpl/home.html",
            controller: "homePage"
        })
        .state("tabs.notice", { //公告
            url: "/notice",
            templateUrl: "../views/tpl/Notice.html",
            controller: "NoticeCtrl"
        })
        // 账户明细
        .state("tabs.tradeAccountManage", {
            url: "/tradeAccountManage",
            templateUrl: "../views/tpl/moneyManage/tradeAccountManage.html",
            controller: "tradeAccountManageCtrl"
        })
        .state("tabs.dependencyAccountManage", {
            url: "/dependencyAccountManage",
            templateUrl: "../views/tpl/moneyManage/dependencyAccountManage.html",
            controller: "dependencyAccountManageCtrl"
        })

        // 客户管理
        .state("tabs.customerManage", {
            url: "/customerManage",
            templateUrl: "../views/tpl/usermanage/customerManage.html",
            controller: "customerManageCtrl"
        })
        .state("tabs.memberManage", {
            url: "/memberManage",
            templateUrl: "../views/tpl/usermanage/memberManage.html",
            controller: "memberManageCtrl"
        })
        .state("tabs.memberManageAdd", {
            url: "/memberManageAdd",
            templateUrl: "../views/tpl/usermanage/memberManageAdd.html",
            controller: "memberManageAddCtrl"
        })
        .state("tabs.memberManageEdit", {
            url: "/memberManageEdit",
            templateUrl: "../views/tpl/usermanage/memberManageEdit.html",
            controller: "memberManageEditCtrl"
        })

        // 上手管理
        .state("tabs.prevSourceAgreementManage", {
            url: "/prevSourceAgreementManage",
            templateUrl: "../views/tpl/prevSourceManage/prevSourceAgreementManage.html",
            controller: "prevSourceAgreementManageCtrl"
        })
        .state("tabs.prevSourceAccountManage", {
            url: "/prevSourceAccountManage",
            templateUrl: "../views/tpl/prevSourceManage/prevSourceAccountManage.html",
            controller: "prevSourceAccountManageCtrl"
        })
        .state("tabs.prevSourceDeposit", {
            url: "/prevSourceDeposit",
            templateUrl: "../views/tpl/prevSourceManage/prevSourceDeposit.html",
            controller: "prevSourceDepositCtrl"
        })
        .state("tabs.prevSourceProductManage", {
            url: "/prevSourceProductManage",
            templateUrl: "../views/tpl/prevSourceManage/prevSourceProductManage.html",
            controller: "prevSourceProductManageCtrl"
        })
        .state("tabs.prevSourceTradeProduct", {
            url: "/prevSourceTradeProduct",
            templateUrl: "../views/tpl/prevSourceManage/prevSourceTradeProduct.html",
            controller: "prevSourceTradeProductCtrl"
        })
        .state("tabs.prevSourceFee", {
            url: "/prevSourceFee",
            templateUrl: "../views/tpl/prevSourceManage/prevSourceFee.html",
            controller: "prevSourceFeeCtrl"
        })
        .state("tabs.prevSourceCapitalManage", {
            url: "/prevSourceCapitalManage",
            templateUrl: "../views/tpl/prevSourceManage/prevSourceCapitalManage.html",
            controller: "prevSourceCapitalManageCtrl"
        })

        .state("tabs.prevSourceFundingapproval", {
            url: "/prevSourceFundingapproval",
            templateUrl: "../views/tpl/prevSourceManage/prevSourceFundingapproval.html",
            controller: "prevSourceFundingapprovalCtrl"
        })
        .state("tabs.prevSourceRealtimefunds", {
            url: "/prevSourceRealtimefunds",
            templateUrl: "../views/tpl/prevSourceManage/prevSourceRealtimefunds.html",
            controller: "prevSourceRealtimefundsCtrl"
        })
        .state("tabs.prevSourcePipelinequery", {
            url: "/prevSourcePipelinequery",
            templateUrl: "../views/tpl/prevSourceManage/prevSourcePipelinequery.html",
            controller: "prevSourcePipelinequeryCtrl"
        })
        .state("tabs.prevSourceStatisticalquery", {
            url: "/prevSourceStatisticalquery",
            templateUrl: "../views/tpl/prevSourceManage/prevSourceStatisticalquery.html",
            controller: "prevSourceStatisticalqueryCtrl"
        })

        .state("tabs.prevSourcePositionsManage", {
            url: "/prevSourcePositionsManage",
            templateUrl: "../views/tpl/prevSourceManage/prevSourcePositionsManage.html",
            controller: "prevSourcePositionsManageCtrl"
        })
        .state("tabs.prevSourceRouteManage", {
            url: "/prevSourceRouteManage",
            templateUrl: "../views/tpl/prevSourceManage/prevSourceRouteManage.html",
            controller: "prevSourceRouteManageCtrl"
        })
        .state("tabs.prevSourceRouteManageRule", {
            url: "/prevSourceRouteManageRule",
            templateUrl: "../views/tpl/prevSourceManage/prevSourceRouteManageRule.html",
            controller: "prevSourceRouteManageRuleCtrl"
        })
        .state("tabs.prevSourceOptionalopponentmechanism", {
            url: "/prevSourceOptionalopponentmechanism",
            templateUrl: "../views/tpl/prevSourceManage/prevSourceOptionalopponentmechanism.html",
            controller: "prevSourceOptionalopponentmechanismCtrl"
        })
        .state("tabs.Marketsourcecommodity", {
            url: "/Marketsourcecommodity",
            templateUrl: "../views/tpl/prevSourceManage/Marketsourcecommodity.html",
            controller: "MarketsourcecommodityCtrl"
        })

        // 行情源管理
        .state("tabs.marketAgreementManage", { //行情协议管理
            url: "/marketAgreementManage",
            templateUrl: "../views/tpl/marketSourceManage/marketAgreementManage.html",
            controller: "marketAgreementManageCtrl"
        })
        .state("tabs.marketSourceManage", { //行情源管理
            url: "/marketSourceManage",
            templateUrl: "../views/tpl/marketSourceManage/marketSourceManage.html",
            controller: "marketSourceManageCtrl"
        })
        .state("tabs.marketSourceProductManage", { //行情源商品管理
            url: "/marketSourceProductManage",
            templateUrl: "../views/tpl/marketSourceManage/marketSourceProductManage.html",
            controller: "marketSourceProductManageCtrl"
        })
        .state("tabs.marketAccountgood", { //行情源可采用商品管理
            url: "/marketAccountgood",
            templateUrl: "../views/tpl/marketSourceManage/marketAccountgood.html",
            controller: "marketAccountgoodCtrl"
        })
        .state("tabs.marketMakeup", { //行情源历史补录
            url: "/marketMakeup",
            templateUrl: "../views/tpl/marketSourceManage/marketMakeup.html",
            controller: "marketMakeupCtrl"
        })

        // 系统管理
        .state("tabs.adminManage", {
            url: "/adminManage",
            templateUrl: "../views/tpl/systemManage/adminManage.html",
            controller: "administratorsManageCtrl"
        })
        .state("tabs.adminManageAdd", {
            url: "/adminManageAdd",
            templateUrl: "../views/tpl/systemManage/adminManageAdd.html",
            controller: "adminManageAddCtrl"
        })
        .state("tabs.adminManageEdit", {
            url: "/adminManageEdit",
            templateUrl: "../views/tpl/systemManage/adminManageEdit.html",
            controller: "adminManageEditCtrl"
        })
        .state("tabs.userManage", {
            url: "/userManage",
            templateUrl: "../views/tpl/systemManage/userManage.html",
            controller: "userManageCtrl"
        })
        .state("tabs.editCustomerUser", {
            url: "/editCustomerUser",
            templateUrl: "../views/tpl/usermanage/editCustomerUser.html",
            controller: "editCustomerUserCtrl"
        })
        //公告
        .state("tabs.Noticequery", { //公告查询
            url: "/Noticequery",
            templateUrl: "../views/tpl/systemManage/Noticequery.html",
            controller: "NoticequeryCtrl"
        })
        .state("tabs.NoticenewAdd", { //公告新增
            url: "/NoticenewAdd",
            templateUrl: "../views/tpl/systemManage/NoticenewAdd.html",
            controller: "NoticenewAddCtrl"
        })
        .state("tabs.Noticemodify", { //公告修改
            url: "/Noticemodify",
            templateUrl: "../views/tpl/systemManage/Noticemodify.html",
            controller: "NoticemodifyCtrl"
        })
        .state("tabs.PersonalizedOrganization", { //机构个性化配置
            url: "/PersonalizedOrganization",
            templateUrl: "../views/tpl/systemManage/PersonalizedOrganization.html",
            controller: "PersonalizedOrganizationCtrl"
        })
        .state("tabs.PersonalizedOrganizationAdd", { //机构个性化配置保存
            url: "/PersonalizedOrganizationAdd",
            templateUrl: "../views/tpl/systemManage/PersonalizedOrganizationAdd.html",
            controller: "PersonalizedOrganizationAddCtrl"
        })
        .state("tabs.PersonalizedOrganizationEdit", { //机构个性化配置保存
            url: "/PersonalizedOrganizationEdit",
            templateUrl: "../views/tpl/systemManage/PersonalizedOrganizationEdit.html",
            controller: "PersonalizedOrganizationEditCtrl"
        })
        .state("tabs.MailSettings", { //邮箱配置
            url: "/MailSettings",
            templateUrl: "../views/tpl/systemManage/MailSettings.html",
            controller: "MailSettingsCtrl"
        })
        .state("tabs.Mailtemplatesettings", { //邮箱模板配置
            url: "/Mailtemplatesettings",
            templateUrl: "../views/tpl/systemManage/Mailtemplatesettings.html",
            controller: "MailtemplatesettingsCtrl"
        })
        .state("tabs.MailtemplatesettingsAdd", { //邮箱模板新增配置
            url: "/MailtemplatesettingsAdd",
            templateUrl: "../views/tpl/systemManage/MailtemplatesettingsAdd.html",
            controller: "MailtemplatesettingsAddCtrl"
        })
        .state("tabs.MailtemplatesettingsEdit", { //邮箱模板修改配置
            url: "/MailtemplatesettingsEdit",
            templateUrl: "../views/tpl/systemManage/MailtemplatesettingsEdit.html",
            controller: "MailtemplatesettingsEditCtrl"
        })
        .state("tabs.Twodimensionalcodequery", { //二维码设置
            url: "/Twodimensionalcodequery",
            templateUrl: "../views/tpl/systemManage/Twodimensionalcodequery.html",
            controller: "TwodimensionalcodequeryCtrl"
        })
        .state("tabs.TwodimensionalcodeAdd", { //二维码设置
            url: "/TwodimensionalcodeAdd",
            templateUrl: "../views/tpl/systemManage/TwodimensionalcodeAdd.html",
            controller: "TwodimensionalcodeAddCtrl"
        })
        .state("tabs.TwodimensionalcodeEdit", { //二维码设置
            url: "/TwodimensionalcodeEdit",
            templateUrl: "../views/tpl/systemManage/TwodimensionalcodeEdit.html",
            controller: "TwodimensionalcodeEditCtrl"
        })
        .state("tabs.Operationlog", { //操作日志
            url: "/Operationlog",
            templateUrl: "../views/tpl/systemManage/Operationlog.html",
            controller: "OperationlogCtrl"
        })

        // 资金管理
        // 交易账户
        .state("tabs.exchangeMoney", {
            url: "/exchangeMoney",
            templateUrl: "../views/tpl/moneyManage/exchangeMoney.html",
            controller: "exchangeMoneyCtrl"
        })
        .state("tabs.bankAdjust", {
            url: "/bankAdjust",
            templateUrl: "../views/tpl/moneyManage/bankAdjust.html",
            controller: "bankAdjustCtrl"
        })
        .state("tabs.currentCapital", {
            url: "/currentCapital",
            templateUrl: "../views/tpl/moneyManage/currentCapital.html",
            controller: "currentCapitalCtrl"
        })
        .state("tabs.tradeProcess", {
            url: "/tradeProcess",
            templateUrl: "../views/tpl/moneyManage/tradeProcess.html",
            controller: "tradeProcessCtrl"
        })
        .state("tabs.runSearch", {
            url: "/runSearch",
            templateUrl: "../views/tpl/moneyManage/runSearch.html",
            controller: "runSearchCtrl"
        })
        .state("tabs.accountUnusualManage", {
            url: "/accountUnusualManage",
            templateUrl: "../views/tpl/moneyManage/accountUnusualManage.html",
            controller: "accountUnusualManageCtrl"
        })
        .state("tabs.statisticSearch", {
            url: "/statisticSearch",
            templateUrl: "../views/tpl/moneyManage/statisticSearch.html",
            controller: "statisticSearchCtrl"
        })
        // 附属账户
        .state("tabs.accountManage", {
            url: "/accountManage",
            templateUrl: "../views/tpl/moneyManage/accountManage.html",
            controller: "accountManageCtrl"
        })
        .state("tabs.accountCurrentCapital", {
            url: "/accountCurrentCapital",
            templateUrl: "../views/tpl/moneyManage/accountCurrentCapital.html",
            controller: "accountCurrentCapitalCtrl"
        })
        .state("tabs.accountRunSearch", {
            url: "/accountRunSearch",
            templateUrl: "../views/tpl/moneyManage/accountRunSearch.html",
            controller: "accountRunSearchCtrl"
        })
        .state("tabs.accountStatisticSearch", {
            url: "/accountStatisticSearch",
            templateUrl: "../views/tpl/moneyManage/accountStatisticSearch.html",
            controller: "accountStatisticSearchCtrl"
        })

        // 支付通道
        .state("tabs.accessManage", {
            url: "/accessManage",
            templateUrl: "../views/tpl/moneyManage/accessManage.html",
            controller: "accessManageCtrl"
        })
        .state("tabs.merchantManage", {
            url: "/merchantManage",
            templateUrl: "../views/tpl/moneyManage/merchantManage.html",
            controller: "merchantManageCtrl"
        })
        .state("tabs.merchantManageAdd", {
            url: "/merchantManageAdd",
            templateUrl: "../views/tpl/moneyManage/merchantManageAdd.html",
            controller: "merchantManageAddCtrl"
        })
        .state("tabs.merchantManageEdit", {
            url: "/merchantManageEdit",
            templateUrl: "../views/tpl/moneyManage/merchantManageEdit.html",
            controller: "merchantManageEditCtrl"
        })

        .state("tabs.payRunSearch", {
            url: "/payRunSearch",
            templateUrl: "../views/tpl/moneyManage/payRunSearch.html",
            controller: "payRunSearchCtrl"
        })
        .state("tabs.payUnusualManage", {
            url: "/payUnusualManage",
            templateUrl: "../views/tpl/moneyManage/payUnusualManage.html",
            controller: "payUnusualManageCtrl"
        })

        // 参数配置
        /*.state("tabs.commissionSplit", {
         url: "/commissionSplit",
         templateUrl: "../views/tpl/argumentsConfigure/commissionSplit.html",
         controller: "commissionSplitCtrl"
         })*/
        .state("tabs.commissionSplitBatchsetup", {
            url: "/commissionSplitBatchsetup",
            templateUrl: "../views/tpl/argumentsConfigure/commissionSplitBatchsetup.html",
            controller: "commissionSplitBatchsetupCtrl"
        })

        .state("tabs.CommissionallocationAdd", {
            url: "/CommissionallocationAdd",
            templateUrl: "../views/tpl/argumentsConfigure/CommissionallocationAdd.html",
            controller: "CommissionallocationAddCtrl"
        })
        .state("tabs.CommissionallocationEdit", {
            url: "/CommissionallocationEdit",
            templateUrl: "../views/tpl/argumentsConfigure/CommissionallocationEdit.html",
            controller: "CommissionallocationEditCtrl"
        })
        //机构配置
        .state("tabs.orginConfig", {
            url: "/orginConfig",
            templateUrl: "../views/tpl/argumentsConfigure/orginConfig.html",
            controller: "orginConfigCtrl"
        })
        //开闭市时间
        .state("tabs.OpenCloseTime", {
            url: "/OpenCloseTime",
            templateUrl: "../views/tpl/argumentsConfigure/OpenCloseTime.html",
            controller: "OpenCloseTimeCtrl"
        })
        .state("tabs.OpenCloseTimeAdd", {
            url: "/OpenCloseTimeAdd",
            templateUrl: "../views/tpl/argumentsConfigure/OpenCloseTimeAdd.html",
            controller: "OpenCloseTimeAddCtrl"
        })
        .state("tabs.OpenCloseTimeEdit", {
            url: "/OpenCloseTimeEdit",
            templateUrl: "../views/tpl/argumentsConfigure/OpenCloseTimeEdit.html",
            controller: "OpenCloseTimeEditCtrl"
        })
        //币种组
        .state("tabs.Currencygroup", {
            url: "/Currencygroup",
            templateUrl: "../views/tpl/argumentsConfigure/Currencygroup.html",
            controller: "CurrencygroupCtrl"
        })
        //上手账号映射
        .state("tabs.upaccountmap", {
            url: "/upaccountmap",
            templateUrl: "../views/tpl/argumentsConfigure/upaccountmap.html",
            controller: "upaccountmapCtrl"
        })

        // 风控
        .state("tabs.riskRegulation", {
            url: "/riskRegulation",
            templateUrl: "../views/tpl/riskManagement/riskRegulation.html",
            controller: "riskRegulationCtrl"
        })
        .state("tabs.riskRegulationAppoint", {
            url: "/riskRegulationAppoint",
            templateUrl: "../views/tpl/riskManagement/riskRegulationAppoint.html",
            controller: "riskRegulationAppointCtrl"
        })
        .state("tabs.tradeRegulation", {
            url: "/tradeRegulation",
            templateUrl: "../views/tpl/riskManagement/tradeRegulation.html",
            controller: "tradeRegulationCtrl"
        })
        .state("tabs.tradeRegulationAppoint", {
            url: "/tradeRegulationAppoint",
            templateUrl: "../views/tpl/riskManagement/tradeRegulationAppoint.html",
            controller: "tradeRegulationAppointCtrl"
        })
        .state("tabs.riskKyohei", {
            url: "/riskKyohei",
            templateUrl: "../views/tpl/riskManagement/riskKyohei.html",
            controller: "riskKyoheiCtrl"
        })

        //客户管理
        .state("tabs.CustomerEntrust", {
            url: "/CustomerEntrust",
            templateUrl: "../views/tpl/transaction/CustomerEntrust.html",
            controller: "CustomerEntrustCtrl"
        })
        .state("tabs.CustomerDeal", {
            url: "/CustomerDeal",
            templateUrl: "../views/tpl/transaction/CustomerDeal.html",
            controller: "CustomerDealCtrl"
        })
        .state("tabs.CustomerPosition", {
            url: "/CustomerPosition",
            templateUrl: "../views/tpl/transaction/CustomerPosition.html",
            controller: "CustomerPositionCtrl"
        })
        .state("tabs.memberManagedetails", {
            url: "/memberManagedetails",
            templateUrl: "../views/tpl/transaction/memberManagedetails.html",
            controller: "memberManagedetailsCtrl"
        })
        .state("tabs.CustomerPositionDetail", {
            url: "/CustomerPositionDetail",
            templateUrl: "../views/tpl/transaction/CustomerPositionDetail.html",
            controller: "CustomerPositionDetailCtrl"
        })
        .state("tabs.Singlemakeup", {
            url: "/Singlemakeup",
            templateUrl: "../views/tpl/transaction/Singlemakeup.html",
            controller: "SinglemakeupCtrl"
        })
        .state("tabs.Singlemakeupdetails", {
            url: "/Singlemakeupdetails",
            templateUrl: "../views/tpl/transaction/Singlemakeupdetails.html",
            controller: "SinglemakeupdetailsCtrl"
        })
        .state("tabs.SinglemakeupEntrust", {
            url: "/SinglemakeupEntrust",
            templateUrl: "../views/tpl/transaction/SinglemakeupEntrust.html",
            controller: "SinglemakeupEntrustCtrl"
        })
        .state("tabs.SinglemakeupDeal", {
            url: "/SinglemakeupDeal",
            templateUrl: "../views/tpl/transaction/SinglemakeupDeal.html",
            controller: "SinglemakeupDealCtrl"
        })
        .state("tabs.SinglemakeupEntrustEdit", {
            url: "/SinglemakeupEntrustEdit",
            templateUrl: "../views/tpl/transaction/SinglemakeupEntrustEdit.html",
            controller: "SinglemakeupEntrustEditCtrl"
        })
        .state("tabs.SinglemakeupDealEdit", {
            url: "/SinglemakeupDealEdit",
            templateUrl: "../views/tpl/transaction/SinglemakeupDealEdit.html",
            controller: "SinglemakeupDealEditCtrl"
        })
        .state("tabs.Entrustedstatistics", {
            url: "/Entrustedstatistics",
            templateUrl: "../views/tpl/transaction/Entrustedstatistics.html",
            controller: "EntrustedstatisticsCtrl"
        })
        .state("tabs.Transactionstatistics", {
            url: "/Transactionstatistics",
            templateUrl: "../views/tpl/transaction/Transactionstatistics.html",
            controller: "TransactionstatisticsCtrl"
        })
        .state("tabs.Dealstatistics", {
            url: "/Dealstatistics",
            templateUrl: "../views/tpl/transaction/Dealstatistics.html",
            controller: "DealstatisticsCtrl"
        })


        //上手管理
        .state("tabs.PreviousEntrust", {
            url: "/PreviousEntrust",
            templateUrl: "../views/tpl/transaction/PreviousEntrust.html",
            controller: "PreviousEntrustCtrl"
        })
        .state("tabs.PreviousDeal", {
            url: "/PreviousDeal",
            templateUrl: "../views/tpl/transaction/PreviousDeal.html",
            controller: "PreviousDealCtrl"
        })
        .state("tabs.PreviousPosition", {
            url: "/PreviousPosition",
            templateUrl: "../views/tpl/transaction/PreviousPosition.html",
            controller: "PreviousPositionCtrl"
        })
        //机构户
        .state("tabs.OrganizeDeal", {
            url: "/OrganizeDeal",
            templateUrl: "../views/tpl/transaction/OrganizeDeal.html",
            controller: "OrganizeDealCtrl"
        })
        .state("tabs.OrganizeHold", {
            url: "/OrganizeHold",
            templateUrl: "../views/tpl/transaction/OrganizeHold.html",
            controller: "OrganizeHoldCtrl"
        })
        .state("tabs.OrganizePositionstatistics", {
            url: "/OrganizePositionstatistics",
            templateUrl: "../views/tpl/transaction/OrganizePositionstatistics.html",
            controller: "OrganizePositionstatisticsCtrl"
        })
        .state("tabs.OrganizeDealstatistics", {
            url: "/OrganizeDealstatistics",
            templateUrl: "../views/tpl/transaction/OrganizeDealstatistics.html",
            controller: "OrganizeDealstatisticsCtrl"
        })

        //产品管理
        .state("tabs.productClassification", { //产品管理
            url: "/productClassification",
            templateUrl: "../views/tpl/productMmanagement/productClassification.html",
            controller: "productClassificationCtrl"
        })
        .state("tabs.productClassificationAdd", { //产品管理新增
            url: "/productClassificationAdd",
            templateUrl: "../views/tpl/productMmanagement/productClassificationAdd.html",
            controller: "productClassificationAddCtrl"
        })
        .state("tabs.productClassificationEdit", { //产品管理编辑
            url: "/productClassificationEdit",
            templateUrl: "../views/tpl/productMmanagement/productClassificationEdit.html",
            controller: "productClassificationEditCtrl"
        })
        .state("tabs.productConfiguration", { //产品配置
            url: "/productConfiguration",
            templateUrl: "../views/tpl/productMmanagement/productConfiguration.html",
            controller: "productConfigurationCtrl"
        })
        .state("tabs.productConfigurationAdd", { //产品个性化配置
            url: "/productConfigurationAdd",
            templateUrl: "../views/tpl/productMmanagement/productConfigurationAdd.html",
            controller: "productConfigurationAddCtrl"
        })
        .state("tabs.productConfigurationEdit", { //产品个性化配置
            url: "/productConfigurationEdit",
            templateUrl: "../views/tpl/productMmanagement/productConfigurationEdit.html",
            controller: "productConfigurationEditCtrl"
        })
        .state("tabs.marketMapping", { //行情映射
            url: "/marketMapping",
            templateUrl: "../views/tpl/productMmanagement/marketMapping.html",
            controller: "marketMappingCtrl"
        })
        .state("tabs.marketMappingAdd", { //行情映射新增
            url: "/marketMappingAdd",
            templateUrl: "../views/tpl/productMmanagement/marketMappingAdd.html",
            controller: "marketMappingAddCtrl"
        })
        .state("tabs.transactionMapping", { //交易映射
            url: "/transactionMapping",
            templateUrl: "../views/tpl/productMmanagement/transactionMapping.html",
            controller: "transactionMappingCtrl"
        })
        .state("tabs.userManageAll", { //角色批量管理
            url: "/userManageAll",
            templateUrl: "../views/tpl/systemManage/userManageAll.html",
            controller: "userManageAllCtrl"
        })
        //品种分类
        .state("tabs.VarietyClassification", {
            url: "/VarietyClassification",
            templateUrl: "../views/tpl/argumentsConfigure/VarietyClassification.html",
            controller: "VarietyClassificationCtrl"
        })
        //品种
        .state("tabs.Varieties", {
            url: "/Varieties",
            templateUrl: "../views/tpl/argumentsConfigure/Varieties.html",
            controller: "VarietiesCtrl"
        })
        //合约
        .state("tabs.contract", {
            url: "/contract",
            templateUrl: "../views/tpl/argumentsConfigure/contract.html",
            controller: "contractCtrl"
        })
        //市场管理
        .state("tabs.MarketManagement", {
            url: "/MarketManagement",
            templateUrl: "../views/tpl/argumentsConfigure/MarketManagement.html",
            controller: "MarketManagementCtrl"
        })
        //币种
        .state("tabs.currencyManagement", {
            url: "/currencyManagement",
            templateUrl: "../views/tpl/argumentsConfigure/currencyManagement.html",
            controller: "currencyManagementCtrl"
        })
        //个性化组
        .state("tabs.Personalizationgroup", {
            url: "/Personalizationgroup",
            templateUrl: "../views/tpl/argumentsConfigure/Personalizationgroup.html",
            controller: "PersonalizationgroupCtrl"
        })
        //黑名单
        .state("tabs.Blacklist", {
            url: "/Blacklist",
            templateUrl: "../views/tpl/argumentsConfigure/Blacklist.html",
            controller: "BlacklistCtrl"
        })
        //品种内映射
        .state("tabs.VarietInmapping", {
            url: "/VarietInmapping",
            templateUrl: "../views/tpl/argumentsConfigure/VarietInmapping.html",
            controller: "VarietInmappingCtrl"
        })
        //分配规则
        .state("tabs.Distributionrules", {
            url: "/Distributionrules",
            templateUrl: "../views/tpl/argumentsConfigure/Distributionrules.html",
            controller: "DistributionrulesCtrl"
        })
        //结算管理
        //结算价管理
        .state("tabs.Settlepricemanagement", {
            url: "/Settlepricemanagement",
            templateUrl: "../views/tpl/Settlemanagement/Settlepricemanagement.html",
            controller: "SettlepricemanagementCtrl"
        })
        //历史结算账户
        .state("tabs.Histaccounts", {
            url: "/Histaccounts",
            templateUrl: "../views/tpl/Settlemanagement/Histaccounts.html",
            controller: "HistaccountsCtrl"
        })
        //历史持仓
        .state("tabs.Histhold", {
            url: "/Histhold",
            templateUrl: "../views/tpl/Settlemanagement/Histhold.html",
            controller: "HistholdCtrl"
        })
        //历史成交
        .state("tabs.Histtransaction", {
            url: "/Histtransaction",
            templateUrl: "../views/tpl/Settlemanagement/Histtransaction.html",
            controller: "HisttransactionCtrl"
        })
        //历史分配规则
        .state("tabs.HistRules", {
            url: "/HistRules",
            templateUrl: "../views/tpl/Settlemanagement/HistRules.html",
            controller: "HistRulesCtrl"
        })
        //交易合约
        .state("tabs.HistTransactioncontract", {
            url: "/HistTransactioncontract",
            templateUrl: "../views/tpl/Settlemanagement/HistTransactioncontract.html",
            controller: "HistTransactioncontractCtrl"
        })
        //审核流水
        .state("tabs.Histrunwater", {
            url: "/Histrunwater",
            templateUrl: "../views/tpl/Settlemanagement/Histrunwater.html",
            controller: "HistrunwaterCtrl"
        })
        //报表导出
        .state("tabs.HistReportexport", {
            url: "/HistReportexport",
            templateUrl: "../views/tpl/Settlemanagement/HistReportexport.html",
            controller: "HistReportexportCtrl"
        })

}]);

function addEventOnResize(fn) {
    var originFn = window.onresize
    window.onresize = function () {
        originFn && originFn()
        fn()
    }
}
//最小值
Array.prototype.min = function () {
    var min = this[0];
    var len = this.length;
    for (var i = 1; i < len; i++) {
        if (this[i] < min) {
            min = this[i];
        }
    }
    return min;
}
//最大值
Array.prototype.max = function () {
    var max = this[0];
    var len = this.length;
    for (var i = 1; i < len; i++) {
        if (this[i] > max) {
            max = this[i];
        }
    }
    return max;
}
//是否整数
function isInteger(obj) {
    return obj % 1 === 0;
}