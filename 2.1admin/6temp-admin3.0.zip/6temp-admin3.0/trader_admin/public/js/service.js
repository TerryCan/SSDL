//后台
app
.factory('localStorageService', [function () {
	return {
		get: function localStorageServiceGet(key, defaultValue) {
			var stored = localStorage.getItem(key);
			try {
				stored = angular.fromJson(stored);
			} catch (error) {
				stored = null;
			}
			return stored;
		},
		update: function localStorageServiceUpdate(key, value) {
			localStorage.setItem(key, angular.toJson(value));
		},
		clear: function localStorageServiceClear(key) {
			localStorage.removeItem(key);
		}
	};
}])
.factory('dataFilter', [function () {
	return {
		msg_null: function (data) {
			if (data == '' || data == null) {
				data = '--';
			}
			return data;
		},
		msg_null_null: function (data) {
			if (data == '' || data == null) {
				data = '';
			}
			return data;
		},
		orgCodeData: function (data) {
			if (data == '' || data == null) {
				data = '--';
			} else {
				if (data == 11) {
					data = '特会';
				}
				if (data == 20) {
					data = '会员';
				}
				if (data == 60) {
					data = '代理';
				}
				if (data == 120) {
					data = '客户';
				}
			}
			return data;
		}
	};
}])
//全局分页数
.factory('getPageNum', [function () {
	return {
		pageNum: function (data) {
			return [{showNum: 15}, {showNum: 30}, {showNum: 50}, {showNum: 100}];
		}
	};
}])
.factory('myHttp', ['$rootScope', '$http', '$q', function ($rootScope, $http, $q) {
	return {
		get: function (url, data) {
			var deferred = $q.defer(); // 声明延后执行，表示要去监控后面的执行
			$http({
				method: "GET",
				url: $rootScope.baseUrl + url,
				params: data
			}).success(function (res) {
				deferred.resolve(res);  // 声明执行成功，即http请求数据成功，可以返回数据了
			}).error(function (res) {
				deferred.reject(res);   // 声明执行失败，即服务器返回错误
			});
			return deferred.promise;   // 返回承诺，这里并不是最终数据，而是访问最终数据的API
		},
		getJson: function (url, data) {
			var deferred = $q.defer(); // 声明延后执行，表示要去监控后面的执行
			$http({
				method: "GET",
				url: url,
				params: data
			}).success(function (res) {
				deferred.resolve(res);  // 声明执行成功，即http请求数据成功，可以返回数据了
			}).error(function (res) {
				deferred.reject(res);   // 声明执行失败，即服务器返回错误
			});
			return deferred.promise;   // 返回承诺，这里并不是最终数据，而是访问最终数据的API
		},
		post: function (url, data) {
			var deferred = $q.defer(); // 声明延后执行，表示要去监控后面的执行
			$http({
				method: "POST",
				url: $rootScope.baseUrl + url,
				data: data,
				headers: {
					'Content-Type': 'application/x-www-form-urlencoded'
				},
				transformRequest: function (obj) {
					var str = [];
					for (var p in obj) {
						str.push(encodeURIComponent(p) + "=" + encodeURIComponent(obj[p]));
					}
					return str.join("&");
				}
			}).success(function (res) {
				deferred.resolve(res);
			}).error(function (res) {
				deferred.reject(res);
			});
			return deferred.promise;
		}
	};
}])
.factory('dataSer', ['$http', '$q', 'myHttp', 'localStorageService', 'dataFilter', '$rootScope', function ($http, $q, myHttp, localStorageService, dataFilter, $rootScope) {
	return {
		initLine: function () {
			$http.get('../public/static/json/line.json').success(function (data) {
				//读取json设置中的下拉框选项
				localStorageService.update("line", data);
                $rootScope.lineData = localStorageService.get("line");
			});
		},
        getOrganize:function(json){
            var deferred = $q.defer();
            myHttp.post("organize/query/as/page", json)
                .then(function (res) {
                    deferred.resolve(res);
                }, function (res) {
                    deferred.reject(res);
                });
            return deferred.promise;
        },
		organizeQuerySer: function (roles) {		//所属机构
			var deferred = $q.defer();
			var data = {orders: 'asc'};
			myHttp.post("organize/query/as/list", data)
				.then(function (res) {  // 调用承诺API获取数据 .resolve
					var resArr = [];
					if (res.code === "000000") {
						var results = JSON.parse(res.content);
						var tmpArr = [];
						for (var i = 0, r = results.length; i < r; i++) {
							if (results[i].state == 1) {
								var tmp = {};
								tmp.orgCode = results[i].orgCode;//9.21变更,orgCode取成orgNum
								tmp.orgId = results[i].orgId;
								tmp.orgName = results[i].orgName;
								tmp.text = results[i].orgName + ' (' + results[i].orgNum+')';
								tmpArr.push(tmp);
							}
						}
						deferred.resolve(tmpArr);
					} else {
						deferred.reject(res);
					}
				}, function (res) {  // 处理错误 .reject
					deferred.reject(res);
				});
			return deferred.promise;
		},
		organizeQuerylistSer: function (roles) {		//所属机构
			var deferred = $q.defer();
			var data = {orders: 'asc'};
			myHttp.post("organize/query/as/list", data)
				.then(function (res) {  // 调用承诺API获取数据 .resolve
					var resArr = [];
					if (res.code === "000000") {
						var results = JSON.parse(res.content);
						var tmpArr = [];
						for (var i = 0, r = results.length; i < r; i++) {
								var tmp = {};
								tmp.orgCode = results[i].orgCode;//9.21变更,orgCode取成orgNum
								tmp.orgId = results[i].orgId;
								tmp.orgName = results[i].orgName;
								tmp.text = results[i].orgName + ' (' + results[i].orgNum+')';
								tmpArr.push(tmp);
						}
						deferred.resolve(tmpArr);
					} else {
						deferred.reject(res);
					}
				}, function (res) {  // 处理错误 .reject
					deferred.reject(res);
				});
			return deferred.promise;
		},
		readEducation: function () {		//学历
			var deferred = $q.defer();
			myHttp.getJson("../public/static/json/educationList.json")
				.then(function (res) {  // 调用承诺API获取数据 .resolve
					if (res) {
						localStorageService.update("education", res.education)
					}
					deferred.resolve(res);
				}, function (res) {  // 处理错误 .reject
					var alertMessage = res.message;
					deferred.reject(res.message);
				});
			return deferred.promise;
		},
		readOccupation: function () {		//职业
			var deferred = $q.defer();
			myHttp.getJson("../public/static/json/occupationList.json")
				.then(function (res) {  // 调用承诺API获取数据 .resolve
					if (res) {
						localStorageService.update("occupation", res.occupation);
					}
					deferred.resolve(res);
				}, function (res) {  // 处理错误 .reject
					var alertMessage = res.message;
					deferred.reject(res.message);
				});
			return deferred.promise;
		},
		readIndustry: function () {		//行业
			var deferred = $q.defer();
			myHttp.getJson("../public/static/json/industryList.json")
				.then(function (res) {  // 调用承诺API获取数据 .resolve
					if (res) {
						localStorageService.update("industry", res.industry);
					}
					deferred.resolve(res);
				}, function (res) {  // 处理错误 .reject
					deferred.reject(res.message);
				});
			return deferred.promise;
		},
		readProperty: function () {		//投资者行者
			var deferred = $q.defer();
			myHttp.getJson("../public/static/json/propertyList.json")
				.then(function (res) {  // 调用承诺API获取数据 .resolve
					if (res) {
						localStorageService.update("property", res.property);
					}
					deferred.resolve(res);
				}, function (res) {  // 处理错误 .reject
					deferred.reject(res.message);
				});
			return deferred.promise;
		},
		readCertificateType: function () {		//证件类型
			var deferred = $q.defer();
			myHttp.getJson("../public/static/json/certificateTypeList.json")
				.then(function (res) {  // 调用承诺API获取数据 .resolve
					//console.log(res)
					if (res) {
						localStorageService.update("certificateType", res.certificateType);
					}
					deferred.resolve(res);
				}, function (res) {  // 处理错误 .reject
					deferred.reject(res.message);
				});
			return deferred.promise;
		},
		provinceQuerySer: function () {		//省份
			var deferred = $q.defer();
			myHttp.get("mss/query/all/province")
				.then(function (res) {  // 调用承诺API获取数据 .resolve
					if (res.success && res.results.length > 0) {
						var provinceData = [];
						for (var i = 0; i < res.results.length; i++) {
							var provinceDataList = new Object();
							provinceDataList.id = res.results[i].id;
							provinceDataList.provinceName = res.results[i].provinceName;
							provinceData.push(provinceDataList);
						}
						localStorageService.update('provinceData', provinceData);
					}
					deferred.resolve(res);
				}, function (res) {  // 处理错误 .reject
					var alertMessage = res.message;
					deferred.reject(res.message);
				});
			return deferred.promise;
		},
		cityQuerySer: function (loadCityId) {		//城市
			var deferred = $q.defer();
			var data_map = new Object();
			data_map.search_EQ_fatherCityId = loadCityId;
			$http({
				method: "GET",
				url: $rootScope.baseUrl + "mss/query/city/by/provinceId",
				params: data_map
			}).success(function (res) {
				deferred.resolve(res);  // 声明执行成功，即http请求数据成功，可以返回数据了
			}).error(function (res) {
				deferred.reject(res);   // 声明执行失败，即服务器返回错误
			});
			return deferred.promise;
		},
		areaQuerySer: function (loadAreaId) {		//区域
			var deferred = $q.defer();
			var data_map = new Object();
			data_map.search_EQ_fatherAreaId = loadAreaId;
			myHttp.get("mss/query/area/by/cityId", data_map)
				.then(function (res) {  // 调用承诺API获取数据 .resolve
					deferred.resolve(res);
				}, function (res) {  // 处理错误 .reject
					deferred.reject(res);
				});
			return deferred.promise;
		}
	}
}])

//全局提示框
.factory('tipService', ['$timeout', function ($timeout) {
	return {
		message: null,
		type: null,
		setMessage: function (msg, type) {
			this.message = msg;
			this.type = type;
			//提示框显示最多3秒消失
			var _self = this;
			$timeout(function () {
				_self.clear();
			}, 3000);
		},
		clear: function () {
			this.message = null;
			this.type = null;
		}
	};
}])
//全局确认提示框
.factory('confirmService', ['$http', '$q', '$rootScope', function ($http, $q, $rootScope) {
	return {
		set: function (title, message, opt) {
			$rootScope.confirmTitle = title;
			$rootScope.confirmMessage = message;
			$rootScope.confirmShow = true;
			$rootScope.confirmImplement = opt;
		},
		clear: function () {
			$rootScope.confirmTitle = null;
			$rootScope.confirmMessage = null;
			$rootScope.confirmShow = false;
			$rootScope.confirmImplement = function () {
			};
		}
	};
}])
.factory('timestamp', function () {
	return {
		timestampCoverHms: function (date, type) {
			var date = new Date(date);
			var Y = date.getFullYear() + '-';
			var M = (date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1) + '-';
			var D = (date.getDate() < 10 ? '0' + (date.getDate()) : date.getDate()) + ' ';
			var h = (date.getHours() < 10 ? '0' + date.getHours() : date.getHours()) + ':';
			var m = (date.getMinutes() < 10 ? '0' + date.getMinutes() : date.getMinutes()) + ':';
			var s = (date.getSeconds() < 10 ? '0' + date.getSeconds() : date.getSeconds());
			switch (type) {
				case 'ymd':
					return Y + M + D;
					break;
				case 'all':
					return Y + M + D + h + m + s;
					break;
				case 'm':
					return m;
					break;
				case 'h':
					return h;
					break;
				default:
					return h + m + s;
					break;
			}
		}
	}
})
//角色状态查询
.factory('getUserStates', function ($http, $q, myHttp) {
	return {
		userState: function () {
			var deferred = $q.defer();
			myHttp.getJson("../public/static/json/userState.json")
				.then(function (res) {  // 调用承诺API获取数据 .resolve
					deferred.resolve(res);
				}, function (res) {  // 处理错误 .reject
					deferred.reject(res.message);
				});
			return deferred.promise;
		}
	}
})
//角色类型查询
.factory('getUserType', function () {
	var json = [
		{id: '1', name: '机构角色'},
		// {id: '2', name: '超极管理员角色'},
		{id: '3', name: '管理员角色'},
		{id: '4', name: '客户角色'}
	]
	return json;
})
//角色分组类型
.factory('getGroupType', function () {
	var json = [
		{id: '1', name: '托底授权分组'},
		{id: '2', name: '用户授权分组'}
	]
	return json;
})
//市场查询
.factory('getPrevSource', function () {
	return {
		market: function () {
			return ['NYMEX', 'COMEX', 'CBOT'];
		},
		product: function () {
			return ['CL', 'SL', 'HG', 'NG', 'C', 'S'];
		},
		account: function () {
			return [1, 2, 3];
		}
	}
})
.factory('loginCtrlDataSer', ['$http', 'myHttp', '$q','$rootScope', function ($http, myHttp, $q,$rootScope) {
	return {
		login: function (username, password, orgCode) {	//交易账户
			var data = new Object();
			data.j_username = username;
			data.j_password = password;
			data.j_orgcode = orgCode;
			var deferred = $q.defer();
			myHttp.post("login_check", data)
				.then(function (res) {  // 调用承诺API获取数据 .resolve
					deferred.resolve(res);
				}, function (res) {  // 处理错误 .reject
					deferred.reject(res);
				});
			return deferred.promise;
		},
		customized:function(data){
                var deferred=$q.defer();
                $http({
                   method:"POST",
                   url: $rootScope.baseUrl + "customize/org/customized/get",
                   data:data,
                }).success(function(res){
                    deferred.resolve(res);
                }).error(function(res){
                    deferred.reject(res);
                });
                return deferred.promise;
            },
		getAuthorised:function(){
			var deferred = $q.defer();
			myHttp.post("role/query/has/authorised/as/list/oneself")
				.then(function (res) {  // 调用承诺API获取数据 .resolve
					deferred.resolve(res);
				}, function (res) {  // 处理错误 .reject
					deferred.reject(res);
				});
			return deferred.promise;
		}
	};
}])
//客户管理
.factory('customerMangerCtrlSer', ['$http', 'localStorageService', 'myHttp', '$q', '$rootScope', function ($http, localStorageService, myHttp, $q, $rootScope) {
	return {
		search: function (json) {
			var deferred = $q.defer();
			myHttp.post("user/query/customer/as/page", json)
				.then(function (res) {  // 调用承诺API获取数据 .resolve
					deferred.resolve(res);
				}, function (res) {  // 处理错误 .reject
					deferred.reject(res);
				});
			return deferred.promise;
		},
		userTypeSearch: function () {
			var json = {
				page: 1,
				rows: 9999999,
				orders: 'asc'
			}
			var deferred = $q.defer();
			myHttp.post("role/query/as/page", json)
				.then(function (res) {  // 调用承诺API获取数据 .resolve
					deferred.resolve(res);
				}, function (res) {  // 处理错误 .reject
					deferred.reject(res);
				});
			return deferred.promise;
		},
		addCustomer: function (addOrgChooseVal, userType, userCodeVal, createUserSecurityV, userRealInfoV, userInfoV, contactsVs) {
			var json = new Object;
			json = {
				orgId: addOrgChooseVal,
				type: userType,
				roleId: userCodeVal,
				createUserSecurityV: createUserSecurityV,
				userRealInfoV: userRealInfoV,
				userInfoV: userInfoV,
				contactsVs: contactsVs
			}
			console.log(json)
			var deferred = $q.defer();
			$http({
				method: 'POST',
				url: $rootScope.baseUrl + 'user/create',
				data: json
			}).then(function successCallback(response) {
				deferred.resolve(response);
			}, function errorCallback(response) {
				deferred.reject(response);
			});
			return deferred.promise;
		},
		getCustomeInfo: function (userId) {
			var json = new Object;
			json = {
				userId: userId
			}
			var deferred = $q.defer();
			$http({
				method: 'POST',
				url: $rootScope.baseUrl + 'user/get',
				data: json
			}).then(function successCallback(response) {
				deferred.resolve(response);
			}, function errorCallback(response) {
				deferred.reject(response);
			});
			return deferred.promise;
		},
		editUserInfoV: function (userId, userInfoV) {
			var json = new Object;
			json = {
				userId: userId,
				userInfoV: userInfoV
			}
			var deferred = $q.defer();
			$http({
				method: 'POST',
				url: $rootScope.baseUrl + 'user/save/info',
				data: json
			}).then(function successCallback(response) {
				deferred.resolve(response);
			}, function errorCallback(response) {
				deferred.reject(response);
			});
			return deferred.promise;
		},
		userRealInfoV: function (userId, userRealInfoV) {
			var json = new Object;
			json = {
				userId: userId,
				userRealInfoV: userRealInfoV
			}
			var deferred = $q.defer();
			$http({
				method: 'POST',
				url: $rootScope.baseUrl + 'user/save/real/info',
				data: json
			}).then(function successCallback(response) {
				deferred.resolve(response);
			}, function errorCallback(response) {
				deferred.reject(response);
			});
			return deferred.promise;
		},
		addContacts: function (userId, contactsVs) {
			var json = new Object;
			json = {
				userId: userId,
				contactsVs: contactsVs
			}
			var deferred = $q.defer();
			$http({
				method: 'POST',
				url: $rootScope.baseUrl + 'user/save/contacts',
				data: json
			}).then(function successCallback(response) {
				deferred.resolve(response);
			}, function errorCallback(response) {
				deferred.reject(response);
			});
			return deferred.promise;
		},
        getSignData: function (json) {
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: $rootScope.baseUrl + 'exbank/get/user/signup/byuserId',
                data: json,
                headers: {
                    'Content-Type': 'application/json;charset=UTF-8'
                }
            }).success(function (res) {
                deferred.resolve(res);
            }).error(function (res) {
                deferred.reject(res);
            });
            return deferred.promise;
        },
		freeze: function (userId) {
			var json = new Object;
			json = {
				userId: userId
			}
			var deferred = $q.defer();
			$http({
				method: 'POST',
				url: $rootScope.baseUrl + 'user/freeze',
				data: json
			}).then(function successCallback(response) {
				deferred.resolve(response);
			}, function errorCallback(response) {
				deferred.reject(response);
			});
			return deferred.promise;
		},
		unfreeze: function (userId) {
			var json = new Object;
			json = {
				userId: userId
			}
			var deferred = $q.defer();
			$http({
				method: 'POST',
				url: $rootScope.baseUrl + 'user/unfreeze',
				data: json
			}).then(function successCallback(response) {
				deferred.resolve(response);
			}, function errorCallback(response) {
				deferred.reject(response);
			});
			return deferred.promise;
		},
		passCheck: function (userId) {
			var json = new Object;
			json = {
				userId: userId
			}
			var deferred = $q.defer();
			$http({
				method: 'POST',
				url: $rootScope.baseUrl + 'user/pass',
				data: json
			}).then(function successCallback(response) {
				deferred.resolve(response);
			}, function errorCallback(response) {
				deferred.reject(response);
			});
			return deferred.promise;
		},
		failedCheck: function (userId) {
			var json = new Object;
			json = {
				userId: userId
			}
			var deferred = $q.defer();
			$http({
				method: 'POST',
				url: $rootScope.baseUrl + 'user/fail',
				data: json
			}).then(function successCallback(response) {
				deferred.resolve(response);
			}, function errorCallback(response) {
				deferred.reject(response);
			});
			return deferred.promise;
		},
		open: function (userId) {
			var json = new Object;
			json = {
				userId: userId
			}
			var deferred = $q.defer();
			$http({
				method: 'POST',
				url: $rootScope.baseUrl + 'user/open',
				data: json
			}).then(function successCallback(response) {
				deferred.resolve(response);
			}, function errorCallback(response) {
				deferred.reject(response);
			});
			return deferred.promise;
		},
		close: function (userId) {
			var json = new Object;
			json = {
				userId: userId
			}
			var deferred = $q.defer();
			$http({
				method: 'POST',
				url: $rootScope.baseUrl + 'user/close',
				data: json
			}).then(function successCallback(response) {
				deferred.resolve(response);
			}, function errorCallback(response) {
				deferred.reject(response);
			});
			return deferred.promise;
		},
		getChangeInfo:function(json){
			var deferred=$q.defer();
			$http({
				method:'POST',
				url:$rootScope.baseUrl+'role/query/change/role',
				data:json
			}).then(function(res){
				deferred.resolve(res);
			},function(res){
				deferred.reject(res);
			});
			return deferred.promise;
		},
		sendChangeInfo:function(json){
			var deferred=$q.defer();
			$http({
				method:'POST',
				url:$rootScope.baseUrl+'user/save/change/role',
				data:json
			}).then(function(res){
				deferred.resolve(res);
			},function(res){
				deferred.reject(res);
			})
			return deferred.promise;
		}
	}
}])
//会员管理
.factory('memberMangerCtrlSer', ['$http', 'localStorageService', 'myHttp', '$q', '$rootScope', function ($http, localStorageService, myHttp, $q, $rootScope) {
	return {
		search: function (showNum, nowPage, orgNum, orgName, state,loginName) {
			var json = {
				page: nowPage,
				rows: showNum,
				orders: 'asc',
				search_A_LIKE_orgNum: (orgNum) ? orgNum : '',
				search_A_LIKE_orgName: (orgName) ? orgName : '',
				search_A_EQ_state: (state) ? state : '',
                'search_A_EQ_sysUserSecuritys.loginName': (loginName) ? loginName : ''
                // 'search_A_EQ_sysUserSecuritys.type': 2
			};
			var deferred = $q.defer();
			myHttp.post("organize/query/as/page", json)
				.then(function (res) {  // 调用承诺API获取数据 .resolve
					deferred.resolve(res);
				}, function (res) {  // 处理错误 .reject
					deferred.reject(res);
				});
			return deferred.promise;
		},
		getRoleType: function (json) {
			var deferred = $q.defer();
			$http({
				method: 'POST',
				url: $rootScope.baseUrl + 'role/query/open',
				data: json
			}).then(function successCallback(response) {
				deferred.resolve(response);
			}, function errorCallback(response) {
				deferred.reject(response);
			});
			return deferred.promise;
		},
		add: function (createOrganizeRelationV, organizeRealInfoV, organizeInfoV, createUserSecurityV, contactsVs) {
			var json = new Object;
			json = {
				createOrganizeRelationV: createOrganizeRelationV,
				organizeRealInfoV: organizeRealInfoV,
				createUserSecurityV: createUserSecurityV,
				organizeInfoV: organizeInfoV,
				contactsVs: contactsVs
			}
			var deferred = $q.defer();
			$http({
				method: 'POST',
				url: $rootScope.baseUrl + 'organize/create',
				data: json
			}).then(function successCallback(response) {
				deferred.resolve(response);
			}, function errorCallback(response) {
				deferred.reject(response);
			});
			return deferred.promise;
		},
		freeze: function (orgId) {
			var json = new Object;
			json = {
				orgId: orgId
			}
			var deferred = $q.defer();
			$http({
				method: 'POST',
				url: $rootScope.baseUrl + 'organize/freeze',
				data: json
			}).then(function successCallback(response) {
				deferred.resolve(response);
			}, function errorCallback(response) {
				deferred.reject(response);
			});
			return deferred.promise;
		},
		unfreeze: function (orgId) {
			var json = new Object;
			json = {
				orgId: orgId
			}
			var deferred = $q.defer();
			$http({
				method: 'POST',
				url: $rootScope.baseUrl + 'organize/unfreeze',
				data: json
			}).then(function successCallback(response) {
				deferred.resolve(response);
			}, function errorCallback(response) {
				deferred.reject(response);
			});
			return deferred.promise;
		},
		passCheck: function (orgId) {
			var json = new Object;
			json = {
				orgId: orgId
			}
			var deferred = $q.defer();
			$http({
				method: 'POST',
				url: $rootScope.baseUrl + 'organize/pass',
				data: json
			}).then(function successCallback(response) {
				deferred.resolve(response);
			}, function errorCallback(response) {
				deferred.reject(response);
			});
			return deferred.promise;
		},
		failedCheck: function (orgId) {
			var json = new Object;
			json = {
				orgId: orgId
			}
			var deferred = $q.defer();
			$http({
				method: 'POST',
				url: $rootScope.baseUrl + 'organize/fail',
				data: json
			}).then(function successCallback(response) {
				deferred.resolve(response);
			}, function errorCallback(response) {
				deferred.reject(response);
			});
			return deferred.promise;
		},
		open: function (orgId) {
			var json = new Object;
			json = {
				orgId: orgId
			}
			var deferred = $q.defer();
			$http({
				method: 'POST',
				url: $rootScope.baseUrl + 'organize/open',
				data: json
			}).then(function successCallback(response) {
				deferred.resolve(response);
			}, function errorCallback(response) {
				deferred.reject(response);
			});
			return deferred.promise;
		},
		close: function (orgId) {
			var json = new Object;
			json = {
				orgId: orgId
			}
			var deferred = $q.defer();
			$http({
				method: 'POST',
				url: $rootScope.baseUrl + 'organize/close',
				data: json
			}).then(function successCallback(response) {
				deferred.resolve(response);
			}, function errorCallback(response) {
				deferred.reject(response);
			});
			return deferred.promise;
		},
		getOrganizeData: function (orgId) {
			var json = new Object;
			json = {
				orgId: orgId
			}
			var deferred = $q.defer();
			$http({
				method: 'POST',
				url: $rootScope.baseUrl + 'organize/get',
				data: json
			}).then(function successCallback(response) {
				deferred.resolve(response);
			}, function errorCallback(response) {
				deferred.reject(response);
			});
			return deferred.promise;
		},
		organizeRealInfoV: function (orgId, organizeRealInfoV) {
			var json = new Object;
			json = {
				orgId: orgId,
				organizeRealInfoV: organizeRealInfoV
			}
			var deferred = $q.defer();
			$http({
				method: 'POST',
				url: $rootScope.baseUrl + 'organize/save/real/info',
				data: json
			}).then(function successCallback(response) {
				deferred.resolve(response);
			}, function errorCallback(response) {
				deferred.reject(response);
			});
			return deferred.promise;
		},
		organizeInfoV: function (orgId, organizeInfoV) {
			var json = new Object;
			json = {
				orgId: orgId,
				organizeInfoV: organizeInfoV
			}
			var deferred = $q.defer();
			$http({
				method: 'POST',
				url: $rootScope.baseUrl + 'organize/save/info',
				data: json
			}).then(function successCallback(response) {
				deferred.resolve(response);
			}, function errorCallback(response) {
				deferred.reject(response);
			});
			return deferred.promise;
		},
		contactsVs: function (orgId, contactsVs) {
			var json = new Object;
			json = {
				orgId: orgId,
				contactsVs: contactsVs
			}
			var deferred = $q.defer();
			$http({
				method: 'POST',
				url: $rootScope.baseUrl + 'organize/save/contacts',
				data: json
			}).then(function successCallback(response) {
				deferred.resolve(response);
			}, function errorCallback(response) {
				deferred.reject(response);
			});
			return deferred.promise;
		},
        deleteContactsVs: function (json) {
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: $rootScope.baseUrl + 'organize/delete/contacts',
                data: json
            }).then(function successCallback(response) {
                deferred.resolve(response);
            }, function errorCallback(response) {
                deferred.reject(response);
            });
            return deferred.promise;
        }
	}
}])
//管理员管理
.factory('administratorsManageCtrlSer', ['$http', 'localStorageService', 'myHttp', '$q', '$rootScope', function ($http, localStorageService, myHttp, $q, $rootScope) {
	return {
		search: function (json) {
			var deferred = $q.defer();
			myHttp.post("user/query/admin/as/page", json)
				.then(function (res) {  // 调用承诺API获取数据 .resolve
					deferred.resolve(res);
				}, function (res) {  // 处理错误 .reject
					deferred.reject(res);
				});
			return deferred.promise;
		}
	}
}])
//新增用户 新流程 分步骤
.factory('addAllTypeUserCtrlSer', ['$http', 'localStorageService', 'myHttp', '$q', '$rootScope', function ($http, localStorageService, myHttp, $q, $rootScope) {
	return {
		step2: function (email, phone,orgCode) {
			var createUserSecurityV = {
				email: email,
				phone: phone
			}
			var json={
				createUserSecurityV:createUserSecurityV,
				orgCode:orgCode
			}
			var deferred = $q.defer();
			$http({
				method: 'POST',
				url: $rootScope.baseUrl + 'user/create/online/step1',
				data:json
			}).then(function successCallback(response) {
				deferred.resolve(response);
			}, function errorCallback(response) {
				deferred.reject(response);
			});
			return deferred.promise;
		},
		step3: function (code, orgCode) {
			var deferred = $q.defer();
			$http({
				method: 'POST',
				url: $rootScope.baseUrl + 'user/create/online/step2',
				data: {"code": code, "orgCode": orgCode}
			}).then(function successCallback(response) {
				deferred.resolve(response);
			}, function errorCallback(response) {
				deferred.reject(response);
			});
			return deferred.promise;
		},
		step4: function (code, orgCode, createUserSecurityV, userRealInfoV, userInfoV, contactsVs) {
			var deferred = $q.defer();
			$http({
				method: 'POST',
				url: $rootScope.baseUrl + 'user/create/online/step3',
				data: {
					"code": code,
					"orgCode": orgCode,
					"createUserSecurityV": createUserSecurityV,
					"userRealInfoV": userRealInfoV,
					"userInfoV": userInfoV,
					"contactsVs": contactsVs
				}
			}).then(function successCallback(response) {
				deferred.resolve(response);
			}, function errorCallback(response) {
				deferred.reject(response);
			});
			return deferred.promise;
		},
		addAdminManage: function (orgId, type, createUserSecurityV, userRealInfoV, userInfoV, contactsVs) {
			var deferred = $q.defer();
			$http({
				method: 'POST',
				url: $rootScope.baseUrl + 'user/create',
				data: {
					"orgId": orgId,
					"type": type,
					"createUserSecurityV": createUserSecurityV,
					"userRealInfoV": userRealInfoV,
					"userInfoV": userInfoV,
					"contactsVs": contactsVs
				}
			}).then(function successCallback(response) {
				deferred.resolve(response);
			}, function errorCallback(response) {
				deferred.reject(response);
			});
			return deferred.promise;
		},
		getUserInfo: function (userId) {
			var deferred = $q.defer();
			$http({
				method: 'POST',
				url: $rootScope.baseUrl + '/user/get',
				data: {"userId": userId}
			}).then(function successCallback(response) {
				deferred.resolve(response);
			}, function errorCallback(response) {
				deferred.reject(response);
			});
			return deferred.promise;
		}
	}
}])

//账户货币类型
.factory('getCurrencyType', function ($q,$http,$rootScope) {
	var deferred = $q.defer();
	$http({
		method: 'POST',
		url: $rootScope.baseUrl + 'admin/config/currency/query/by/user',
		headers: {
			'Content-Type': 'application/json;charset=UTF-8'
		}
	}).success(function (res) {
		deferred.resolve(res);
	}).error(function (res) {
		deferred.reject(res);
	});
	return deferred.promise;
})
//账户货币类型—出入金
.factory('getCurrencyMethod', function ($q,$http,$rootScope) {
    return{
        obtainCurrencyType:function(){
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: $rootScope.baseUrl + 'admin/config/currency/query/by/user',
                headers: {
                    'Content-Type': 'application/json;charset=UTF-8'
                }
            }).success(function (res) {
                deferred.resolve(res);
            }).error(function (res) {
                deferred.reject(res);
            });
            return deferred.promise;
        }
    }
});