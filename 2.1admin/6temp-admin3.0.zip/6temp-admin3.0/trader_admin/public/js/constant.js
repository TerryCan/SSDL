app
//资金管理：
 // 银行反馈
    .factory('getBankOpState', function () {
        var json = [
            {id: '-1', name: '失败'},
            {id: '0', name: '无操作'},
            {id: '1', name: '成功'}
        ]
        return json;
    })
    // 账户状态
    .factory('getAccountState', function () {
        var json = [
            {id: '10', name: '正常'},
            {id: '30', name: '爆仓'},
            {id: '50', name: '冻结'},
            {id: '99', name: '删除无效'}
        ]
        return json;
    })
    //错误流水状态
    .factory('getErrorState', function () {
        var json = [
            {id: '0', name: '待处理'},
            {id: '88', name: '已废弃'},
            {id: '99', name: '已处理'}
        ]
        return json;
    })
    // 银行商户状态
    .factory('getBankState', function () {
        var json = [
            {id: '10', name: '生效'},
            {id: '99', name: '已废弃'}
        ]
        return json;
    })
    // 银行账户状态
    .factory('getBankAccount', function () {
        var json = [
            {id: '10', name: '签约并已设置指定账户'},
            {id: '50', name: '签约待设置指定账户'},
            {id: '99', name: '解约'}
        ]
        return json;
    })
    // 账户类型
    .factory('getAccountType', function () {
        var json = [
            {id: '1', name: '活期'},
            {id: '2', name: '定期'},
            {id: '3', name: '交易周期'}
        ]
        return json;
    })
    // 流程类型
    .factory('getProcessType', function () {
        var json = [
            {id: '1', name: '冻结资金'},
            {id: '2', name: '解冻资金'},
            {id: '3', name: '设置出金阈值'},
            {id: '4', name: '解除出金阈值'}
        ]
        return json;
    })
    //客户类型
    .factory('getCustomType', function () {
        var json = [
            {id: '0', name: '企业客户'},
            {id: '1', name: '个人客户'}
        ]
        return json;
    })
    //密钥存储类型
    .factory('getKeyType', function () {
        var json = [
            {id: '1', name: '文件'},
            {id: '2', name: '数据库'}
        ]
        return json;
    })
    //方向
    .factory('getIoType', function () {
        var json = [
            {id: '-1', name: '汇出'},
            {id: '1', name: '汇入'}
        ]
        return json;
    })
    //资金额度方向
    .factory('getDirection', function () {
        var json = [
            {id: '0', name: '汇入'},
            {id: '1', name: '汇出'}
        ]
        return json;
    })
    //出金状态
    .factory('getExternalResult', function () {
        var json = [
            {id: 'P', name: '进行中'},
            {id: 'Y', name: '成功'},
            {id: 'F', name: '失败'}
        ]
        return json;
    })
    //流水类型
    .factory('getTradeType', function () {
        var json = [
            {id: '0', name: '出入金'},
            {id: '1', name: '订单结算'},
            {id: '2', name: '内部自动转账'},
            {id: '3', name: '银行调账'},
            {id: '4', name: '资金冻结/解冻'},
            {id: '5', name: '盈亏'},
            {id: '6', name: '仓息'},
            {id: '7', name: '手续费'},
            {id: '8', name: '交收费'},
            {id: '9', name: '爆仓结算'},
            {id: '10', name: '交收单结算'}
        ];
        return json;
    })
    //附属账户流水查询——交易类型
    .factory('getAccountTradeType', function () {
        var json = [
            {id: '1', name: '客户充值'},
            {id: '2', name: '客户入金'},
            {id: '3', name: '客户出金'},
            {id: '5', name: '内部资金转换'},
            {id: '7', name: '系统补正'},
            {id: '8', name: '手续费'},
            {id: '9', name: '客户提现'}
        ]
        return json;
    })
    //账户交易审核
    .factory('getAccountStatus', function () {
        var json = [
            {id: '0', name: '待审核'},
            //{id: '1', name: '出入金审核通过'},
            // {id: '2', name: '出入金审核不通过'},
            // {id: '3', name: '已冻结待解冻'},
            // {id: '95', name: '入金待银行交易完成'},
            // {id: '96', name: '入金审核不通过'},
            // {id: '97', name: '操作失败撤销'},
            // {id: '98', name: '银行操作失败资金回退'},
            {id: '8888', name: '审核不通过-无效流水'},
            {id: '9999', name: '审核通过-有效流水'}
        ]
        return json;
    })
    //支付通道商户管理Boolean转换
    .factory('switchBoolean', function () {
        var json = [
            {id: '-1', name: '否'},
            {id: '1', name: '能'}
        ]
        return json;
    })
    //第三方支付
    .factory('switchThirdPay', function () {
        var json = [
            {id: '-1', name: '银行'},
            {id: '1', name: '第三方支付'}
        ]
        return json;
    })
    //第三放支付保存形式
    .factory('getKeyStoreType', function () {
        var json = [
            {id: '1', name: '文件'},
            {id: '2', name: '数据库'}
        ]
        return json;
    })
    //手续费类型
    .factory('getFeeType', function () {
        var json = [
            {id: '0', name: '不收取'},
            {id: '1', name: '百分比'},
            {id: '2', name: '固定金额'}
        ]
        return json;
    })
    .factory('getCollectionState', function () {
        var json = [
            {id: '1', name: '验证失败'},
            {id: '-2', name: '未验证'},
            {id: '-1', name: '已验证发送成功'}
        ]
        return json;
    })
// 上手管理：
    // 上手路由管理
    .factory('getRouteStatus', function () {
        var json = [
            {id: '1', name: '指定账号'},
            {id: '2', name: '轮询'},
            {id: '3', name: '自动分配'}
        ]
        return json;
    })
    // 上手可交易商品
    .factory('getTradeStatus', function () {
        var json = [
            {id: '0', name: '允许开仓和平仓'},
            {id: '1', name: '禁止开仓'},
            {id: '2', name: '禁止平仓'},
            {id: '3', name: '禁止平仓和禁止平仓'}
        ]
        return json;
    })

 //风控：
    // 风控规则——公式类型
    .factory('getFormularRiskType', function () {
        var json = [
            {id: '0', name: '风险率'},
            {id: '1', name: '自有风险率'},
            {id: '2', name: '权益'}
        ]
        return json;
    })
    // 风控规则——条件类型
    .factory('getRiskCtrlConditionType', function () {
        var json = [
            {id: '0', name: 'x>参数1'},
            {id: '1', name: 'x>=参数1'},
            {id: '2', name: 'x<参数1'},
            {id: '3', name: 'x<=参数1'},
            {id: '4', name: '参数1<x<参数2'},
            {id: '5', name: '参数1<=x<=参数2'}
        ]
        return json;
    })
    // 规则触发后的动作类型
    .factory('getRiskActionType', function () {
        var json = [
            {id: '0', name: '无'},
            {id: '1', name: '禁止开仓'},
            {id: '2', name: '禁止平仓'},
            {id: '4', name: '告警'},
            {id: '8', name: '强制平仓'}
        ]
        return json;
    })
    // 规则触发后的动作类型过滤查询
    .factory('getRiskActionTypeOne', function () {
        var json = [
            {id: '1', name: '禁止开仓'},
            {id: '2', name: '禁止平仓'},
            {id: '4', name: '告警'},
            {id: '8', name: '强制平仓'}
        ]
        return json;
    })
    // 强平方式
    .factory('getRiskCtrlForceType', function () {
        var json = [
            {id: '0', name: '自动全部强平'},
            {id: '1', name: '自动逐笔强平'},
            {id: '2', name: '手动强平'}
        ]
        return json;
    })
    // 交易——规则类型
    .factory('getTradeRuleType', function () {
        var json = [
            {id: '0', name: '当市价在止盈止损价上下"参数1"档内禁止设置'},
            {id: '1', name: '最大持仓量不得大于"参数1"'},
            {id: '2', name: '单笔交易量不得大于"参数1"'},
            {id: '4', name: ' 委托单频率不得大于"参数1"次/分钟'},
            {id: '5', name: '市价在挂单价上下"参数1"档内允许进场'}
        ]
        return json;
    })
    //交易——规则条件
    .factory('getTradeRuleConditionType', function () {
        var json = [
            {id: '0', name: 'x>参数1'},
            {id: '1', name: 'x>=参数1'},
            {id: '2', name: 'x<参数1'},
            {id: '3', name: 'x<=参数1'},
            {id: '4', name: '参数1<x<参数2'},
            {id: '5', name: '参数1<=x<=参数2'}
        ]
        return json;
    })
    .factory('getProductScope', function () {
        var json = [
            {id: '10', name: '同级'},
            {id: '20', name: '同级、下级'}
        ]
        return json;
    })
    .factory('timestamp', function () {
        return {
            //时间戳转换日期类型
            timestampCoverHms: function (date, type) {
                var date = new Date(date);
                var Y = date.getFullYear() + '-';
                var M = (date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1) + '-';
                var D = (date.getDate() < 10 ? '0' + (date.getDate()) : date.getDate()) + ' ';
                var h = (date.getHours() < 10 ? '0' + date.getHours() : date.getHours()) + ':';
                var m = (date.getMinutes() < 10 ? '0' + date.getMinutes() : date.getMinutes()) + ':';
                var s_m = (date.getMinutes() < 10 ? '0' + date.getMinutes() : date.getMinutes());
                var s = (date.getSeconds() < 10 ? '0' + date.getSeconds() : date.getSeconds());
                switch (type) {
                    case 'ymd':
                        return Y + M + D;
                        break;
                    case 'all':
                        return Y + M + D + h + m + s;
                        break;
                    case 'm':
                        return m;
                        break;
                    case 'h':
                        return h;
                        break;
                    case 'hm':
                        return h + s_m;
                        break;
                    default:
                        return h + m + s;
                        break;
                }
            },
            //当天UTC毫秒数转化为系统时间
            daySecondsToDate: function (parameter) {
                var h = Math.floor(parameter/ 3600);
                var minute = Math.floor((parameter - h * 3600) / 60);
                var second = parameter - h * 3600 - minute * 60;
                return ((h<16)?(h+8):(h-16)) + ':' + minute + ':' + second;
            },
            //当天系统时间转化为UTC毫秒数
            DateToSeconds: function (parameter) {
                var str1 = parameter.split(":");
                var h = parseInt(str1[0], 10) * 3600;
                var m = parseInt(str1[1], 10) * 60;
                var s = parseInt(str1[2], 10);
                return ((h + m + s-28800)<0)?(86400+(h + m + s-28800)):(h + m + s-28800);
            },
            // 设置系统默认查询时间
            defaultDate:function(current){
                if(current==='start'){
                    var date=new Date();
                    var day= (date.getDate() < 10 ? '0' + (date.getDate()) : date.getDate()) + ' ';
                    if(date.getMonth()==0){
                        var year=date.getFullYear()-1 + '-';
                        var month=12 + '-';
                        return year+month+day+ '00'+ ':00'+':00';
                    }else{
                        var year=date.getFullYear() + '-';
                        var month=(date.getMonth()< 10 ? '0' + date.getMonth() : date.getMonth()) + '-';
                        return year+month+day+ '00'+ ':00'+':00';
                    }
                }else{
                    var date=new Date();
                    var year=date.getFullYear() + '-';
                    var month=(date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1) + '-';
                    var day= (date.getDate() < 10 ? '0' + (date.getDate()) : date.getDate()) + ' ';
                    return year+month+day+ '00'+ ':00'+':00';
                }
            },
            formatTimeKind:function(parameter){
                var divideTime=parameter.split(' ');
                var divTwoTime=divideTime[0].split('-');
                var endTime=divTwoTime[0]+"/"+divTwoTime[1]+"/"+divTwoTime[2]+" "+divideTime[1];
                return endTime
            }
        }
    })

    //周一至周日
    .factory('getweekType', function () {
        var json = [
            {val: '2', name: '周一'},
            {val: '3', name: '周二'},
            {val: '4', name: '周三'},
            {val: '5', name: '周四'},
            {val: '6', name: '周五'},
            {val: '7', name: '周六'},
            {val: '1', name: '周日'}
        ]
        return json;
    })
    //24小时
    .factory('get24h', function () {
        var json = []
        for (var i = 0; i < 24; i++) {
            if (i < 10) {
                i = '0' + i;
            }
            var str = i + ':00:00';
            json.push(str)
        }
        return json;
    })
    //开平
    .factory('getOffset', function () {
        var json = [
            {id: '0', name: '无'},
            {id: '1', name: '开'},
            {id: '2', name: '平'}
        ]
        return json;
    })
    .factory('getOrderState', function () {
        var json = [
            {id: '0', name: '指令失败'},
            {id: '1', name: '已受理'},
            {id: '2', name: '已挂起'},
            {id: '3', name: '已排队'},
            {id: '4', name: '待撤销'},
            {id: '5', name: '待修改'},
            {id: '6', name: '部分撤单'},
            {id: '7', name: '完全撤单'},
            {id: '8', name: '部分成交'},
            {id: '9', name: '完全成交'}
        ]

        return json;
    })
    //委托类型
    .factory('getOrderType', function () {
        var json = [
            {id: '0', name: '限价'},
            {id: '1', name: '市价'}
        ]
        return json;
    })
    //产品管理状态
    .factory('getProManageState', function () {
        var json = [
            {id: '-3', name: '新建驳回'},
            {id: '-2', name: '新建待审核'},
            {id: '-1', name: '销毁'},
            {id: '1', name: '正常'},
            {id: '2', name: '退市待审核'},
            {id: '3', name: '正常销毁审核'},
            {id: '8000', name: '退市'},
            {id: '8001', name: '上市待审核'},
            {id: '8002', name: '退市销毁待审核'}
        ]
        return json;
    })
    //admin3.0状态
    .factory('getadminState', function () {
        var json = [
            {id: '-3', name: '驳回'},
            {id: '-2', name: '待审核'},
            {id: '-5', name: '注销待启用'},
            {id: '-1', name: '注销'},
            {id: '1', name: '正常'},
            {id: '2', name: '冻结待审核'},
            {id: '3', name: '注销待审核'},
            {id: '0', name: '初始状态'}
        ]
        return json;
    })
    //产品管理个性化状态
    .factory('getClassificationState', function () {
        var json = [
            {id: '-3', name: '驳回'},
            {id: '-2', name: '待审核'},
            {id: '-1', name: '销毁'},
            {id: '1', name: '正常'},
            {id: '2', name: '冻结待审核'},
            {id: '3', name: '正常注销待审核'},
            {id: '8000', name: '冻结'},
            {id: '8001', name: '冻结解冻待审核'},
            {id: '8002', name: '冻结注销待审核'}
        ]
        return json;
    })
    //内外盘
    .factory('plateType', function () {
        var json = [
            {val: '0', name: '内盘'},
            {val: '1', name: '外盘'},
        ]
        return json;
    })
    //委托/成交
    .factory('EntrustType', function () {
        var json = [
            {val: '0', name: '委托'},
            {val: '1', name: '成交'},
        ]
        return json;
    })
    // 交易
    //买卖方向
    .factory('getOrderDirect', function () {
        var json = [
            {id: '-1', name: '卖'},
            {id: '1', name: '买'}
        ]
        return json;
    })
    //委托类型
    .factory('getPriceCondition', function () {
        var json = [
            {id: '0', name: '限价'},
            {id: '1', name: '市价'},
            {id: '15', name: '限价止损'},
            {id: '16', name: '市价止损'}
        ]
        return json;
    })
    //委托状态
    .factory('getOrderState', function () {
        var json = [
            {id: '0', name: '指令失败'},
            {id: '1', name: '已受理'},
            {id: '2', name: '已挂起'},
            {id: '3', name: '已排队'},
            {id: '4', name: '待撤销'},
            {id: '5', name: '待修改'},
            {id: '6', name: '部分撤单'},
            {id: '7', name: '完全撤单'},
            {id: '8', name: '部分成交'},
            {id: '9', name: '完全成交'},
            // {id: '10', name: '部分成交还在队列中'},
            // {id: '11', name: '部分成交不在队列中'},
            // {id: '12', name: '未成交还在队列中'},
            // {id: '13', name: '未成交不在队列中'},
            // {id: '14', name: '撤单'},
            {id: '15', name: '未知'},
            // {id: '16', name: '尚未触发'},
            // {id: '17', name: '已触发'}
        ]
        return json;
    })

    //报单
    .factory('getOrderReason', function () {
        var json = [
            {id: '0', name: '报单'},
            {id: '1', name: '强平'},
            {id: '2', name: '逐笔强平'},
            {id: '3', name: '止损'},
            {id: '4', name: '止盈'},
            {id: '5', name: '强平重发'}
        ]
        return json;
    })
    //触发类型
    .factory('getRequestType', function () {
        var json = [
            {id: '1', name: '委托报单'},
            {id: '2', name: '委托改单'},
            {id: '3', name: '委托撤销'},
            {id: '4', name: '平仓委托'},
            {id: '5', name: '止盈止损'},
            {id: '6', name: '变更委托状态'},
            {id: '7', name: '系统平仓委托'},
            {id: '8', name: '系统委托撤销'}
        ]
        return json;
    })
    //额度流水类型
    .factory('waterType', function () {
        var json = [
            {val: '0', name: '出入金'},
            {val: '1', name: '盈亏'},
            {val: '2', name: '手续费'}
        ]
        return json;
    })

    //额度状态
    .factory('getAmountState', function () {
        var json = [
            {val: '0', name: '待审核'},
            {val: '1', name: '审核通过已生效'},
            {val: '-1', name: '驳回'}
        ]
        return json;
    })
    //签约状态
    .factory('signState', function () {
        var json = [
            {val: '10', name: '有效'},
            {val: '99', name: '无效'}
        ];
        return json;
    })
    //公告状态
    .factory('noticeState', function () {
        var json = [
            {val: '-3', name: '驳回'},
            {val: '-2', name: '待审核'},
            {val: '-1', name: '注销'},
            {val: '1', name: '正常'},
            {val: '2', name: '冻结待审核'},
            {val: '3', name: '正常注销待审核'},
            {val: '8000', name: '冻结'},
            {val: '8001', name: '冻结解冻待审核'},
            {val: '8002', name: '冻结注销待审核'}
        ]
        return json;
    })
    //账户流水类型
    .factory('accountTransType', function () {
        var json = [
            {id: '1', name: '客户充值'},
            {id: '2', name: '客户入金'},
            {id: '3', name: '客户出金'},
            {id: '5', name: '内部资金转换'},
            {id: '7', name: '系统补正'},
            {id: '8', name: '手续费'},
            {id: '9', name: '客户提现'}
        ]
        return json;
    })
    //机构管理—性别
    .factory('getSex', function () {
        var json = [
            {id: '1', name: '男'},
            {id: '2', name: '女'}
        ]
        return json;
    })

    //批量角色授权状态
    .factory('getbatchstate', function () {
        var json = [
            {val: '0', name: '初始状态'},
            {val: '1', name: '待审状态'},
            {val: '7', name: '用户终止状态'},
            {val: '8', name: '系统终止状态'},
            {val: '9', name: '完成状态'}

        ]
        return json;
    })
    //批量角色操作类型
    .factory('getoperatelist', function () {
        var json = [
            {id:'0', name: '批量新增'},
            {id:'1', name: '批量删除'},

        ]
        return json;
    })
    //市场管理
    .factory('getmarket', function () {
        var json = [
            {val:'0', name: '内部'},
            {val:'1', name: '外部'},
        ]
        return json;
    })
    //锁仓
    .factory('getlockFlagtype', function () {
        var json = [
            {val:true, name: '是'},
            {val:false, name: '否'},
        ]
        return json;
    })


