app.controller('transactionMappingCtrl', ['$scope', '$rootScope', 'getPageNum', 'transactionMappingCtrlSer', 'marketMappingCtrlSer', 'accountManagementSer', 'tradeProductSerAll', 'getOptionalopponentmechanismData', 'productManageSer','dataSer','confirmService', function($scope, $rootScope, getPageNum, transactionMappingCtrlSer, marketMappingCtrlSer, accountManagementSer, tradeProductSerAll, getOptionalopponentmechanismData, productManageSer,dataSer,confirmService) {
			$scope.productIdname = "";
			$scope.tableshow = false;
			$scope.marketstate = false;
			$scope.channelName = "";
			$scope.productId = "";
			$scope.phchannelId = "";
			$scope.addPsOrgVal = "";
			$scope.channelProduct = "";
			$scope.addmarket = function() {
				$scope.tableshow = true;
				$scope.marketstate = false;
				$scope.addEditText = "新增";
				$scope.productId = '';
				$scope.phchannelId = '', //上手ID
				$scope.addPsOrgVal= '',
				$scope.channelProductId = '', //上手产品ID
				$scope.channelProduct= '',
				$scope.accountSymbolId = "",
				$scope.opponentOrgId = '',
				$scope.opponentOrgCode = '',
				$scope.upAccountOrganizeId = ''
				$scope.channelmaplists=[];
			}
			$scope.chooseItemTab1 = null;
			$scope.editmarket = function() {
				if (!$scope.chooseItemTab1) {
					$rootScope.tipService.setMessage('请先选择产品ID', 'warning');
				} else {
					$scope.tableshow = true;
					$scope.addEditText = "修改";
				}
			}
					//所属机构
			dataSer.organizeQuerySer()
			.then(function(res) {
				$scope.orgList = res;
				console.log($scope.orgList);
			});
				//全部状态下所属机构
			dataSer.organizeQuerylistSer()
				.then(function(res) {
						$scope.orgAllList = res;
					console.log($scope.orgList)
				});

			$scope.opText=function(opponentOrgCode){
				for (var i = 0, r = $scope.orgAllList.length; i < r; i++) {
					if (opponentOrgCode == $scope.orgAllList[i].orgCode) {
						return $scope.orgAllList[i].text;
					}
				}
			}

			$scope.search = function() {
				transactionMappingCtrlSer.search($scope.showNum.showNum, $scope.currentPage, $scope.productIdname)
					.then(function(res) {
						if (res.code === '000000') {
							var data = JSON.parse(res.content);
							$scope.chooseProId = null;
							console.log(data)
							$scope.searchResult = data.content;
							$scope.showPage = true;
							$scope.dataNum = data.totalElements;
							console.log($scope.dataNum)
							$scope.PageNum();
						} else {
							$rootScope.tipService.setMessage(res.message, 'warning');
						}
					}, function(error) {
						$rootScope.tipService.setMessage(error.message, 'warning');
					});
			}
			$scope.turnPage = function(url) {
				$state.go(url);
			}

			$scope.productChannelmap = {
				productId: "", //产品编号
				channelmaps: [{
					phchannelId: "", //上手ID
					channelProductId: "", //上手产品ID
					accountSymbolId: "",
					opponentOrgId: "",
					opponentOrgCode: "",
					upAccountOrganizeId: ""
				}]
			}

			//产品ID
			marketMappingCtrlSer.prosearch(1, 99999, '')
				.then(function(res) {
					//console.log(JSON.parse(res.content))
					var prolistdt = JSON.parse(res.content);
					$scope.prolist = [];
					for (var i = 0, r = prolistdt.length; i < r; i++) {
						if (prolistdt[i].state == 1 || prolistdt[i].state == 8000) {
							$scope.prolist.push(prolistdt[i]);
						}
					}
				});
			//产品ID

			marketMappingCtrlSer.prosearch(1, 99999, '')
				.then(function(res) {
					$scope.prolistt = JSON.parse(res.content);
					console.log($scope.prolistt)
				});

			$scope.PtText = function(productId) {
				if ($scope.prolistt) {
					for (var i = 0, r = $scope.prolistt.length; i < r; i++) {
						//console.log($scope.prolist[i])
						if ($scope.prolistt[i].productId == productId) {
							return $scope.prolistt[i].productName;
						}
					}
				}
			}
			productManageSer.productSearch()
				.then(function(res) {
					console.log(res)
					$scope.productManagelist = res.list;
					console.log($scope.productManagelist)
				});
			$scope.keyText = function(channelProductId) {
				if($scope.prolistt){
					for (var i = 0, r = $scope.productManagelist.length; i < r; i++) {
						if ($scope.productManagelist[i].key == channelProductId) {
							return $scope.productManagelist[i].market + '-' + $scope.productManagelist[i].commodity + '-' + $scope.productManagelist[i].contract;
						}
					}
				}
			}

			//上手账号
			accountManagementSer.accountSearch()
				.then(function(response) {
					console.log(response)
					var accountList = response.list;
					$scope.accountList = accountList;
					//console.log($scope.accountList);
				})
				//上手账号机构查询
			transactionMappingCtrlSer.accountSer($scope.addkey)
				.then(function(res) {
					console.log(res)
					$scope.organizelist = res;
					//console.log($scope.organizelist)
				}, function(error) {
					console.log(error);
				})
			$scope.selectAction = function() {
                $scope.addPsOrgVal="";
				console.log($scope.phchannelId);
				//可交易商品查询
				transactionMappingCtrlSer.symbolSearch($scope.phchannelId)
					.then(function(response) {
						console.log(response)
						$scope.tradeList = response.data.list;
						console.log($scope.tradeList);
					}, function(error) {
						console.log(error);
					})

				//上手账号机构查询
				transactionMappingCtrlSer.accountSer($scope.phchannelId)
					.then(function(res) {
						//console.log(res)
						$scope.organizelist = res;
						//console.log($scope.organizelist)
					}, function(error) {
						console.log(error);
					})

			}

			$scope.addPsOrgValFTC = function(d) {
				//console.log(d);
				$scope.opponentOrgId = d.OrgId;
				$scope.opponentOrgCode = d.OrgCode;
				$scope.upAccountOrganizeId = d.key
				$scope.addPsOrgVal = d.text;
			}



			//单选
			$scope.positionCheck = function(index, productChannelmapId,productId) {
				$scope.chooseItemTab1 = productChannelmapId;
				$scope.productChannelmapId = $scope.searchResult[index].productChannelmapId;
				$scope.phchannelId = $scope.searchResult[index].phchannelId;
				$scope.channelProductId = $scope.searchResult[index].channelProductId;
				$scope.opponentOrgId = $scope.searchResult[index].opponentOrgId;
				$scope.opponentOrgCode = $scope.searchResult[index].opponentOrgCode;
				$scope.upAccountOrganizeId = $scope.searchResult[index].upAccountOrganizeId;
				$scope.addPsOrgVal = $scope.phchannelId +'('+$scope.searchResult[index].createOrgCode+')';
				$scope.channelProduct = $scope.searchResult[index].channelProductId;
				$('#dataReport input[type=checkbox]').prop('checked', false);
				$('#dataReport input[type=checkbox]').eq(index).prop('checked', true);
				console.log($scope.productChannelmapId);

			}
    		$scope.channelmaplists=[];
			$scope.addrule = function() {
                var words = $scope.channelProduct.split('-');
                console.log(words)
                var channelProductId = words[1];
                var accountSymbolId = words[0];
                var SingleRuleData={
                    productId: $scope.productId,
                    phchannelId: $scope.phchannelId,
                    channelProductId: channelProductId,
                    accountSymbolId: accountSymbolId,
                    opponentOrgId: $scope.opponentOrgId,
                    opponentOrgCode: $scope.opponentOrgCode,
                    upAccountOrganizeId: $scope.upAccountOrganizeId
                }
                console.log(SingleRuleData)
				$scope.channelmaplists.push(SingleRuleData);
                console.log($scope.channelmaplists)
			}

			$scope.deletesd = function(index) {
				$scope.channelmaplists.splice(index, 1);
			}
			$scope.saveinfo = function() {
				if ($scope.addEditText == '新增') {
					var productChannelmap = {
						productId: $scope.productId,
                        channelmaps: $scope.channelmaplists,
					}

					var json = {
						productChannelmap: productChannelmap
					}
					if (toValidate('#traMapp')) {
						transactionMappingCtrlSer.addnew(json)
							.then(function(res) {
								console.log(res)
								if (res.data.code == '000000') {
									$scope.tableshow = false;
									$rootScope.tipService.setMessage(res.data.message, 'warning');
									$scope.search();
								} else {
									$rootScope.tipService.setMessage(res.data.message, 'warning');
								}
							})
					}
			}else if ($scope.addEditText == '修改') {
				if (!$scope.channelProduct) {
					$rootScope.tipService.setMessage('上手可交易商品必填', 'warning');
				} else {
					var productChannelmap = {
						productChannelmapId: $scope.productChannelmapId,
						productId: $scope.productId,
						channelmaps:$scope.channelmaplists,
					}

					var json = {
						productChannelmap: productChannelmap
					}
					if (toValidate('#traMapp')) {
						transactionMappingCtrlSer.addnew(json)
							.then(function(res) {
								console.log(res)
								if (res.data.code == '000000') {
									$scope.tableshow = false;
									$rootScope.tipService.setMessage(res.data.message, 'warning');
									$scope.search();
								} else {
									$rootScope.tipService.setMessage(res.data.message, 'warning');
								}
							})
					}
				}
			}
			}
			//删除
			$scope.delete = function() {
					if (!$scope.chooseItemTab1) {
						$rootScope.tipService.setMessage('请先选择交易映射信息', 'warning');
					} else {
						confirmService.set('确认提示', '确定要删除此交易映射信息?', function() {
							transactionMappingCtrlSer.Delete($scope.chooseItemTab1)
								.then(function(res) {
									if (res.data.code == "000000") {
									$rootScope.tipService.setMessage(res.data.message, 'warning');
									$scope.search();
									} else {
										$rootScope.tipService.setMessage(res.data.message, 'warning');
									}
								}, function(error) {
									$rootScope.tipService.setMessage(error.data.message, 'warning');
								});
							confirmService.clear();
						});
					}
				}

			$scope.proVal=function(){
				if(!$scope.productId){
					$rootScope.tipService.setMessage('请先选择产品名称', 'warning');
				}else{
					var json = {
						search_A_LIKE_productId: $scope.productId
					}
					transactionMappingCtrlSer.searchpro(json)
						.then(function (res) {
							if(res.code=="000000"){
								$scope.channeval=JSON.parse(res.content);
								console.log($scope.channeval)
                                $scope.channelmaplists=[];
                                for  (var i = 0, r = $scope.channeval.length; i < r; i++) {
                                    var channelist={
                                        productId: $scope.channeval[i].productId,
                                        phchannelId: $scope.channeval[i].phchannelId,
                                        channelProductId:$scope.channeval[i].channelProductId,
                                        accountSymbolId: $scope.channeval[i].accountSymbolId,
                                        opponentOrgId: $scope.channeval[i].opponentOrgId,
                                        opponentOrgCode: $scope.channeval[i].opponentOrgCode,
                                        upAccountOrganizeId: $scope.channeval[i].upAccountOrganizeId
                                    }
                                    $scope.channelmaplists.push(channelist);
								}
                                //$scope.channelmaplists=[];
								if(!channelist){
									console.log(channelist)
                                    $scope.channelmaplists=[];
								}
							}else {
								$rootScope.tipService.setMessage(res.message, 'warning');
							}
						})
                    $scope.phchannelId="";
                    $scope.addPsOrgVal="";
                    $scope.channelProduct="";
				}
			}

			/* 分页功能实现 */
			var pageInitialize = function() {
				$scope.dataNum = 0; //数据总条数
				$scope.dataPage = 0; //分页数
				$scope.currentPage = 1; //当前页数
				$scope.jumpPageNum = '';
			}
			$scope.showDataChoose = getPageNum.pageNum(); //获取分页
			$scope.showNum = $scope.showDataChoose[0]; //初始显示刷具条数
			$scope.dataPageNumber = []; //生成页面数
			$scope.showPage = false;
			$scope.pageSelect = function(params) {
				$scope.showNum.showNum = params.showNum;
				pageInitialize();
				$scope.search();
			}
			$scope.changePageNumber = function(params) {
				$scope.currentPage = params;
				$scope.search();
				$scope.PageNum();
			}
			$scope.PageNum = function() {
				if ($scope.showNum.showNum < $scope.dataNum) {
					$scope.dataPage = parseInt($scope.dataNum / $scope.showNum.showNum) + 1;
				} else {
					$scope.dataPage = 0;
				}
				$scope.dataPageNumber = [];
				for (var i = 0; i < $scope.dataPage; i++) {
					$scope.dataPageNumber.push(i + 1);
				}
			}
			$scope.jumpPage = function(num) {
				num = parseInt(num);
				if (parseInt(num, 10) === num && num <= ($scope.dataPage + 1) && num > 0) {
					$scope.currentPage = num;
					$scope.PageNum();
					$scope.search();
				}
			}
			$scope.pageSlect = function(type) {
				if (type == 'prev') {
					if ($scope.currentPage != 1) {
						$scope.currentPage--;
						$scope.PageNum();
						$scope.search();
					}
				} else {
					if ($scope.currentPage < $scope.dataPage) {
						$scope.currentPage++;
						$scope.PageNum();
						$scope.search();
					}
				}
			}
			pageInitialize();
			//$scope.search();
	}])
	.factory('transactionMappingCtrlSer', ['$http', 'localStorageService', 'myHttp', '$q', '$rootScope', function($http, localStorageService, myHttp, $q, $rootScope) {
		return {
			search: function(showNum, nowPage, productIdname) {
				var data = new Object();
				var json = {
					page: nowPage,
					rows: showNum,
					orders: 'asc',
					search_A_LIKE_productId: productIdname

				}
				var deferred = $q.defer();
				myHttp.post("config/product/query/productChannelmap/as/page", json)
					.then(function(res) { // 调用承诺API获取数据 .resolve
						deferred.resolve(res);
					}, function(res) { // 处理错误 .reject
						deferred.reject(res);
					});
				return deferred.promise;
			},
            searchpro: function(json) {
                var deferred = $q.defer();
                myHttp.post("config/product/query/productChannelmap/as/list", json)
                    .then(function(res) { // 调用承诺API获取数据 .resolve
                        deferred.resolve(res);
                    }, function(res) { // 处理错误 .reject
                        deferred.reject(res);
                    });
                return deferred.promise;
            },
			symbolSearch: function(phchannelId) {
				var json = {
					"account": phchannelId
				}
				var deferred = $q.defer();
				$http({
					method: 'POST',
					url: $rootScope.baseUrl + 'c/up/account/symbol/query/by/account',
					data: json
				}).then(function successCallback(response) {
					//console.log(response)
					deferred.resolve(response);
				}, function errorCallback(response) {
					deferred.reject(response);
				});
				return deferred.promise;
			},
			accountSer: function(phchannelId) { //所属机构
				/*	var deferred = $q.defer();
					var data = {account:phchannelId,orders:'asc'};
					myHttp.post("c/up/account/organize/query/by/account",data)*/
				var json = {
					account: phchannelId,
					orders: 'asc'
				}
				var deferred = $q.defer();
				$http({
					method: 'POST',
					url: $rootScope.baseUrl + 'c/up/account/organize/query/by/account',
					data: json
				}).then(function(res) { // 调用承诺API获取数据 .resolve
					//console.log(res)
					if (res.data.retMsg.code === "000000") {
						var results = res.data.list;
						//console.log(results)
						var tmpArr = [];
						for (var i = 0, r = results.length; i < r; i++) {
							var tmp = {};
							tmp.OrgCode = results[i].OrgCode;
							tmp.OrgId = results[i].OrgId;
							tmp.account = results[i].account;
							tmp.key = results[i].key;
							tmp.text = results[i].account + '(' + results[i].OrgCode+')';
							tmpArr.push(tmp);
						}
						deferred.resolve(tmpArr);
					} else {
						deferred.reject(res);
					}
				}, function(res) { // 处理错误 .reject
					deferred.reject(res);
				});
				return deferred.promise;
			},
			addnew: function(json) {
				var deferred = $q.defer();
				$http({
					method: 'POST',
					url: $rootScope.baseUrl + 'config/product/save/productChannelmap',
					data: json
				}).then(function successCallback(response) {
					deferred.resolve(response);
				}, function errorCallback(response) {
					deferred.reject(response);
				});
				return deferred.promise;
			},
			Delete: function(chooseItemTab1){
			var deferred = $q.defer();
			$http({
				method: 'POST',
				url: $rootScope.baseUrl + 'config/product/delete/productChannelmap',
				data: {
					"productChannelmapId": chooseItemTab1
				}
			}).then(function successCallback(response) {
				deferred.resolve(response);
			}, function errorCallback(response) {
				deferred.reject(response);
			});
			return deferred.promise;
		}
		}
	}])