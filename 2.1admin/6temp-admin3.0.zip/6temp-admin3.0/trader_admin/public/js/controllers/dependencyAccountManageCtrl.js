app.controller('dependencyAccountManageCtrl', ['$scope', '$rootScope', 'tipService', 'accountDetail', 'getPageNum','localStorageService','getCurrencyType','getIoType','accountTransType','timestamp', function ($scope, $rootScope, tipService, accountDetail, getPageNum,localStorageService,getCurrencyType,getIoType,accountTransType,timestamp) {
    $scope.backHome= function () {
        $scope.changeState('tabs.home');
    };
    //时间戳
    $scope.timeSwitch = function (stamp) {
        return timestamp.timestampCoverHms(stamp, 'all')
    }
    //出入金方向
    $scope.ioTypeNum = getIoType;
    $scope.getIoType = function (params) {
        for (var i = 0, r = $scope.ioTypeNum.length; i < r; i++) {
            if (params == $scope.ioTypeNum[i].id) {
                return $scope.ioTypeNum[i].name;
            }
        }
    };
    //账户交易类型
    $scope.tradeType = accountTransType;
    $scope.getTradeType = function (params) {
        for (var i = 0, r = $scope.tradeType.length; i < r; i++) {
            if (params == $scope.tradeType[i].id) {
                return $scope.tradeType[i].name;
            }
        }
    };
    // 货币转换
    getCurrencyType.then(function (res) {
        $scope.currencyList = JSON.parse(res.content);
        // console.log($scope.currencyList);
    });
    $scope.getCurrency = function (parameter) {
        if ($scope.currencyList) {
            for (var i = 0; i < $scope.currencyList.length; i++) {
                if (parameter == $scope.currencyList[i].currency) {
                    return $scope.currencyList[i].currencyName;
                }
            }
        }
    };
    $scope.accountCurrency='';
    $scope.tradeDetailSearch = function (type) {
        // $scope.changeState('tabs.tradeAccountManage');
        var json = {
            page: $scope.currentPage,
            rows: $scope.showNum.showNum,
            orders: 'asc',
            search_A_EQ_currency: $scope.accountCurrency
        }
        accountDetail.tradeDetail(json)
            .then(function (response) {
                if (response.code == "000000") {
                    if (type == 'btnSearch') {
                        pageInitialize();
                    }
                    var data = JSON.parse(response.content);
                    $scope.tradeResult = data.content;
                    console.log($scope.tradeResult);
                    $scope.showPage = true;
                    $scope.searchResult = data.content;
                    $scope.dataNum = data.totalElements;
                    $scope.PageNum();
                }
                else {
                    $rootScope.tipService.setMessage(response.message, 'warning');
                }
            }, function (error) {
                $rootScope.tipService.setMessage(error.message, 'warning');
            });
        // $scope.chooseItemTab1 = null;
    }
    /* 分页功能实现 */
    var pageInitialize = function () {
        $scope.dataNum = 0;//数据总条数
        $scope.dataPage = 0;//分页数
        $scope.currentPage = 1;//当前页数
        $scope.jumpPageNum = '';
    }
    $scope.showDataChoose = getPageNum.pageNum();//获取分页
    $scope.showNum = $scope.showDataChoose[0];//初始显示刷具条数
    $scope.dataPageNumber = [];//生成页面数
    $scope.showPage = false;
    $scope.pageSelect = function (params) {
        console.log(params);
        $scope.showNum.showNum = params.showNum;
        pageInitialize();
        $scope.search();
    }
    $scope.changePageNumber = function (params) {
        $scope.currentPage = params;
        $scope.search();
        $scope.PageNum();
    }
    $scope.PageNum = function () {
        if ($scope.showNum.showNum < $scope.dataNum) {
            $scope.dataPage = parseInt($scope.dataNum / $scope.showNum.showNum) + 1;
        }
        else {
            $scope.dataPage = 0;
        }
        $scope.dataPageNumber = [];
        for (var i = 0; i < $scope.dataPage; i++) {
            $scope.dataPageNumber.push(i + 1);
        }
    }
    $scope.jumpPage = function (num) {
        num = parseInt(num);
        if (parseInt(num, 10) === num && num <= ($scope.dataPage + 1) && num > 0) {
            $scope.currentPage = num;
            $scope.PageNum();
            $scope.search();
        }
    }
    $scope.pageSlect = function (type) {
        if (type == 'prev') {
            if ($scope.currentPage != 1) {
                $scope.currentPage--;
                $scope.PageNum();
                $scope.search();
            }
        }
        else {
            if ($scope.currentPage < $scope.dataPage) {
                $scope.currentPage++;
                $scope.PageNum();
                $scope.search();
            }
        }
    }
    pageInitialize();
    $scope.tradeDetailSearch();
}])
    .factory('accountDetail', ['$http','$rootScope', 'localStorageService', 'myHttp', '$q', function ($http,$rootScope,localStorageService, myHttp, $q) {
        return {
            tradeDetail: function (json) {
                var deferred = $q.defer();
                myHttp.post("exbank/query/exaccountios/page", json)
                    .then(function (res) {
                        deferred.resolve(res);
                    }, function (res) {
                        deferred.reject(res);
                    })
                return deferred.promise;
            }
        }
    }])
