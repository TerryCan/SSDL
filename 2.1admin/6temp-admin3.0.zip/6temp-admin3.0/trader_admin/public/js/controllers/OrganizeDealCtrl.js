app.controller('OrganizeDealCtrl',['$scope','$rootScope','organizeDealSever','$timeout','getPageNum','timestamp','getOrderDirect','getCurrencyType','localStorageService',function($scope,$rootScope,organizeDealSever,$timeout,getPageNum,timestamp,getOrderDirect,getCurrencyType,localStorageService){
    $scope.toggleTraderSearchState=false;
    $scope.Toggle = function(){
        $scope.toggleTraderSearchState = !$scope.toggleTraderSearchState;
        if($scope.toggleTraderSearchState){
           $('.search_column').css('height','auto');
        }
        else{
           $('.search_column').css('height','36px');
        }
    };
    //买卖方向
    $scope.orderDirect = getOrderDirect;
    //获取币种
    getCurrencyType.then(function(res) {
        $scope.getCurrencyType = JSON.parse(res.content);
        console.log($scope.getCurrencyType);
    });

    var processContent,processTotal;
    var source = {
        type: 'POST',
        datatype: "json",
        datafields: [  //数据字段定义
            {name: 'userName', type: 'string'},
            {name: 'productName', type: 'string'},
            {name: 'productCode', type: 'string'},
            {name: 'matchFeeCurrency', type: 'string'},
            {name: 'orderDirect', type: 'string'},

            {name: 'matchVolume', type: 'string'},
            {name: 'matchPrice', type: 'string'},
            {name: 'orderPrice', type: 'orderPrice'},
            {name: 'createTime', type: 'string'}
        ],
        url: $rootScope.baseUrl + 'admin/trade/match/query/org/as/page',
        root: "content",
        pagesize:10,
        processData: function (data) {
            data.page = (data.pagenum + 1)?(data.pagenum + 1):1;
            data.rows =(data.pagesize)?(data.pagesize):10;
            data.order =($scope.order)?$scope.order:'desc';
            data.sort =($scope.sort)?$scope.sort:'createTime';
            data.search_A_EQ_userName = ($scope.directiveUserId) ? $scope.directiveUserId : '';
            data.search_A_EQ_orderDirect = ($scope.SearchOrderDirect) ? $scope.SearchOrderDirect : '';
            data.search_A_GTE_createTime = ($scope.createTimeStart) ? $scope.createTimeStart : '';
            data.search_A_LTE_createTime = ($scope.createTimeEnd) ? $scope.createTimeEnd : '';
            data.search_A_EQ_matchFeeCurrency = ($scope.SearchCurrencyType) ? $scope.SearchCurrencyType : '';

            $scope.orgCode = localStorageService.get('oldOrgCode');
            if ($scope.organizeValue == true && $scope.downOrganizeValue == true) {
                data.search_A_LLIKE_orgCode = ($scope.orgCode) ? $scope.orgCode : '';
            }
            if ($scope.organizeValue == true && $scope.downOrganizeValue == false) {
                data.search_A_EQ_orgCode = ($scope.orgCode) ? $scope.orgCode : '';
            }
            if ($scope.organizeValue == false && $scope.downOrganizeValue == true) {
                data.search_A_LLIKE_orgCode = ($scope.orgCode) ? $scope.orgCode + '-' : '';
            }
        }, //传递参数处理
        beforeLoadComplete: function (records) { //数据完全加载完执行绘制表格
            var start;
            for (var i in records) {
                start = parseInt(i);
                break;
            }
            for (var k = 0, r = processContent.length; k < r; k++) {
                records[start + k].userName = processContent[k].userName;
                records[start + k].productName = processContent[k].productName;
                records[start + k].productCode = processContent[k].productCode;
                records[start + k].matchFeeCurrency = processContent[k].matchFeeCurrency;
                records[start + k].orderDirect = processContent[k].orderDirect;

                records[start + k].matchVolume = processContent[k].matchVolume;
                records[start + k].matchPrice = processContent[k].matchPrice;
                records[start + k].orderPrice = processContent[k].orderPrice;
                records[start + k].createTime = processContent[k].createTime
            }
        },
        beforeprocessing: function (data) { //处理总页数
            var processData = JSON.parse(data.content);
            console.log(processData);
            processContent = processData.content;
            source.totalrecords = processData.totalElements == 0 ? 5 : processData.totalElements;
            processTotal = processData.totalElements;
        },
        loadComplete: function (records) {
            $scope.saveResult=JSON.parse(records.content);
            var data =  $scope.saveResult.totalElements;
            if (data == 0) {
                $('#contenttableentrustDetailGrid > div').remove();
            }
        },
        endUpdate: true
    };
    //创建数据适配器
    var dataAdapter = null;
    $scope.searchAjax = function () {
        $scope.toggleTraderSearchState = false;
        $('.search_column').css('height', '36px');
        if (dataAdapter == null) {
            dataAdapter = new $.jqx.dataAdapter(source);
            //创建表格
            $("#entrustDetailGrid").jqxGrid({
                source: dataAdapter,
                columns: [  //表格数据域
                    {
                        text: '用户名',
                        datafield: 'userName',
                        minwidth: 11 + '%',
                        cellsalign: 'center',
                        align: 'center',
                        width: '11%'
                    },
                    {
                        text: '商品名',
                        datafield: 'productName',
                        minwidth: 11 + '%',
                        cellsalign: 'center',
                        align: 'center',
                        width:'11%'
                    },
                    {
                        text: '商品代码',
                        datafield: 'productCode',
                        minwidth:11 + '%',
                        align: 'center',
                        width:'11%'
                    },
                    {
                        text: '币种',
                        datafield: 'matchFeeCurrency',
                        minwidth: 11 + '%',
                        cellsalign: 'center',
                        align: 'center',
                        width:'11%',
                        cellsrenderer: function (row, columnfield, value, defaulthtml, columnproperties) {
                            if ($scope.getCurrencyType) {
                                for (var i = 0; i < $scope.getCurrencyType.length; i++) {
                                    if (value == $scope.getCurrencyType[i].currency) {
                                        return $scope.getCurrencyType[i].currencyName;
                                    }
                                }
                            }
                        }
                    },
                    {
                        text: '买卖方向',
                        datafield: 'orderDirect',
                        minwidth: 11 + '%',
                        cellsalign: 'center',
                        align: 'center',
                        width:'11%',
                        cellsrenderer: function (row, columnfield, value, defaulthtml, columnproperties) {
                            if (getOrderDirect) {
                                for (var i = 0; i <getOrderDirect.length; i++) {
                                    if (value ==getOrderDirect[i].id) {
                                        return getOrderDirect[i].name;
                                    }
                                }
                            }
                        }
                    },
                    {
                        text: '手数',
                        datafield: 'matchVolume',
                        minwidth: 11 + '%',
                        width:'11%',
                        align: 'center'
                    },
                    {
                        text: '价格',
                        datafield: 'matchPrice',
                        minwidth: 11 + '%',
                        align: 'center',
                        width:'11%',
                        cellsalign: 'center'
                    },
                    {
                        text: '手续费',
                        datafield: 'orderPrice',
                        minwidth: 11 + '%',
                        align: 'center',
                        cellsalign: 'center',
                        width:'11%'
                    },
                    {
                        text: '成交时间',
                        datafield: 'createTime',
                        minwidth:12 + '%',
                        cellsalign: 'center',
                        align: 'center',
                        width:'12%',
                        cellsrenderer: function (row, columnfield, value, defaulthtml, columnproperties) {
                            return timestamp.timestampCoverHms(value, 'all');
                        }
                    }
                ],
                width: 100 + '%',
                height: 87 + '%',
                theme:'metrodark',
                virtualmode: true,
                rendergridrows: function (params) { //将数据渲染到页面
                    return params.data;
                },
                pageable: true,
                pagesizeoptions: ['10','30','100','200'],
                sortable: true,
                // altrows: true,
                columnsresize: true,//列间距是否可调整
                selectionmode: 'singlecell',//选择模式
                clipboard: true,
            });
        }else {
            $("#entrustDetailGrid").jqxGrid('updatebounddata', 'cells');
        }
    };
    //分页
    $("#entrustDetailGrid").on("pagechanged", function (event) {
        console.log(event)
    });
    //排序
    $("#entrustDetailGrid").on("sort", function (event) {
        var sortinformation = event.args.sortinformation;
        $scope.sort=sortinformation.sortcolumn;
        $scope.order=($scope.sort)?(sortinformation.sortdirection.ascending)?'asc':'desc':'asc';
        data={
            order:$scope.order,
            sort:$scope.sort
        };
        source.processData(data);
        $("#entrustDetailGrid").jqxGrid('updatebounddata', 'sort');
    });

    //查询字段
    $scope.orgName = '';
    $scope.SearchOrderDirect = '';
    $scope.createTimeStart='';
    $scope.createTimeEnd='';
    $scope.SearchCurrencyType = '';
    $scope.search = function (type) {
        $('.search_column').css('height','36px');
        if (type == 'search') {
            pageInitialize()
        };
        $scope.orgCode=localStorageService.get('oldOrgCode');
        var json = {
            page: $scope.currentPage,
            rows: $scope.showNum.showNum,
            order:'desc',
            sort:'createTime',
            search_A_EQ_userName: $scope.directiveUserId,
            search_A_EQ_orderDirect: $scope.SearchOrderDirect,
            search_A_GTE_createTime: $scope.createTimeStart,
            search_A_LTE_createTime: $scope.createTimeEnd,
            search_A_EQ_matchFeeCurrency: $scope.SearchCurrencyType
        };
        if($scope.organizeValue==true && $scope.downOrganizeValue==true){
            json.search_A_LLIKE_orgCode=($scope.orgCode)?$scope.orgCode:'';
        }
        if($scope.organizeValue==true && $scope.downOrganizeValue==false){
            json.search_A_EQ_orgCode=($scope.orgCode)?$scope.orgCode:'';
        }
        if($scope.organizeValue==false && $scope.downOrganizeValue==true){
            json.search_A_LLIKE_orgCode=($scope.orgCode)?$scope.orgCode+'-':'';
        }
        organizeDealSever.organizeSearch(json)
            .then(function(response){
                console.log(response);
                if(response.code == '000000'){
                    if (type == 'btnSearch') {
                        pageInitialize();
                    }
                    var data = JSON.parse(response.content);
                    $scope.searchResult = data.content;
                    console.log($scope.searchResult);
                    $scope.showPage = true;
                    $scope.dataNum = data.totalElements;
                    $scope.PageNum();
                }else {
                    $rootScope.tipService.setMessage(response.message, 'warning');
                }
            }, function (error) {
                $rootScope.tipService.setMessage(error.message, 'warning');
            });
    };
    /**
     * 分页功能实现TerryMin
     * **/
    $scope.showDataChoose = getPageNum.pageNum(); //获取分页
    $scope.showNum = $scope.showDataChoose[0]; //初始显示刷具条数

    $scope.showPage = false;
    var pageInitialize = function () {
        $scope.dataNum = 0; //数据总条数
        $scope.dataPage = 0; //分页数
        $scope.currentPage = 1; //当前页数
        $scope.jumpPageNum = '';
    };
    pageInitialize();
    // x/y $scope.dataPage
    $scope.PageNum = function () {
        if ($scope.showNum.showNum < $scope.dataNum) {
            $scope.dataPage =Math.ceil($scope.dataNum / $scope.showNum.showNum);
        } else {
            $scope.dataPage = 0;
        }
        if($scope.dataPage>1 && $scope.currentPage>0){
            if($scope.dataPage<$scope.currentPage){
                $scope.currentPage=1;
                $scope.search();
            }
        }
    };
    //上页下页 $scope.currentPage
    $scope.pageSlect = function (type) {
        if (type == 'prev') {
            if ($scope.currentPage != 1) {
                $scope.currentPage--;
                $scope.PageNum();
                $scope.search();
            }
        } else {
            if ($scope.currentPage < $scope.dataPage) {
                $scope.currentPage++;
                $scope.PageNum();
                $scope.search();
            }
        }
    };
    // 每页条数单元
    $scope.pageSelect = function (params) {
        $scope.showNum.showNum = params.showNum;
        pageInitialize();
        $scope.search();
    };
    //页数跳转 currentPage
    $scope.jumpPage = function (num) {
        num = parseInt(num);
        if (parseInt(num, 10) === num && num <= ($scope.dataPage + 1) && num > 0) {
            $scope.currentPage = num;
            $scope.PageNum();
            $scope.search();
        }
    };
}])
    .factory('organizeDealSever',['$q','$http','$rootScope','myHttp',function($q,$http,$rootScope,myHttp){
        return{
            organizeSearch: function (json) {
                var deferred = $q.defer();
                myHttp.post("admin/trade/match/query/org/as/page", json)
                    .then(function (res) {
                        deferred.resolve(res);
                    }, function (res) {
                        deferred.reject(res);
                    });
                return deferred.promise;
            }
        }
    }]);