app.controller("forgot_passwordCtrl",['$scope','$state','$rootScope','tipService','dataSer','timestamp','$timeout','addUserCtrlSer','confirmService',function($scope,$state,$rootScope,tipService,dataSer,timestamp,$timeout,addUserCtrlSer,confirmService){
	$scope.step = 1;
	$scope.orgCode="";
	$scope.loginName="";

	//页面跳转
	$scope.trunPage = function(url){
		$state.go(url);
	};
    //获取验证码1
    var wait=60;
    $scope.timeNum= "(" + wait + ")秒后可重发";
    $scope.time=function() {
        if (wait == 0) {
            $("#dataReport button").attr("disabled",false);
            $scope.timeNum = "发送验证码";
            wait = 60;
        } else {
            $("#dataReport button").attr("disabled", true);
            $scope.timeNum= "(" + wait + ")秒后可重发";
            wait--;
            $timeout(function() {
                    $scope.time()
                },
                1000)
        }
    };
    //获取验证码2
    $scope.getTime=function(){
        if (wait == 0) {
            $("#dataReport button").attr("disabled",false);
            $scope.timeNum = "发送验证码";
            wait = 60;
        } else {
            $("#dataReport button").attr("disabled", true);
            $scope.timeNum= "(" + wait + ")秒后可重发";
            wait--;
            $timeout(function() {
                    $scope.time()
                },
                1000)
        }
        addUserCtrlSer.loginStep2($scope.orgCode,$scope.loginName)
            .then(function(res){
                if(res.data.code == '000000'){
                    confirmService.set('步骤提示','邮件已发送，请去邮箱获取验证码',function(){
                        confirmService.clear();
                    });
                }
                else{
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                }
            },function(error){
                $rootScope.tipService.setMessage(error.data.message, 'warning');
            });
    };
   $scope.loginStep2=function(step){
		//获取邮箱
		if(step == 1){
			if(toValidate('#loginStep_form')){
				addUserCtrlSer.loginStep2($scope.orgCode,$scope.loginName)
				.then(function(res){
					if(res.data.code == '000000'){
						confirmService.set('步骤提示','邮件已发送，请去邮箱获取验证码',function(){
                            $scope.time();
							 $scope.step = 2;
							confirmService.clear();
						});	
					}
					else{
						$rootScope.tipService.setMessage(res.data.message, 'warning');
					}
				},function(error){
					$rootScope.tipService.setMessage(error.data.message, 'warning');
				});
			}
		}else if(step ==2){
			//用户邮箱验证
			if(toValidate('#loginStep2_form')){
			if($scope.password != '' && $scope.newRepeatPwd != '' && $scope.password == $scope.newRepeatPwd){
				addUserCtrlSer.loginStep3($scope.MailCode,$scope.password)
				.then(function(res){
					console.log(res);
					if(res.data.code == '000000'){
						confirmService.set('步骤提示','恭喜你！修改密码成功',function(){
							confirmService.clear();
							$state.go('login');
						});	
					}
					else{
						$rootScope.tipService.setMessage(res.data.message, 'warning');
					}
				},function(error){
					$rootScope.tipService.setMessage(error.data.message, 'warning');
				});
			}
		}
		}

   }
}])
    //新增用户 新流程 分步骤
    .factory('addUserCtrlSer', ['$http', 'localStorageService', 'myHttp', '$q', '$rootScope', function ($http, localStorageService, myHttp, $q, $rootScope) {
        return {
            loginStep2: function (orgCode,loginName) {
                var json={
                    orgCode:orgCode,
                    loginName:loginName
                }
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'user/forget/password/step1',
                    data:json
                }).then(function successCallback(response) {
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
             loginStep3: function (MailCode, password) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'user/forget/password/step2',
                    data: {"code":MailCode,"password":password}
                }).then(function successCallback(response) {
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            }
        }
    }])