app.controller("customerManageCtrl", function ($scope, $rootScope, $state, tipService, getUserStates, getUserType, customerMangerCtrlSer, getPageNum, timestamp, localStorageService, $timeout,confirmService) {
    $scope.toggleTraderSearchState = false;
    $scope.Toggle = function () {
        $scope.toggleTraderSearchState = !$scope.toggleTraderSearchState;
        if ($scope.toggleTraderSearchState) {
            $('.search_column').css('height', 'auto');
        } else {
            $('.search_column').css('height', '36px');
        }
    };
    //修改权限
    var jurisdictionList = sessionStorage.getItem('nav');
    var realInfoState = (/ORGANIZE_CUSTOMER_SAVE_REAL_INFO/gi).test(jurisdictionList);
    var saveInfoState = (/ORGANIZE_CUSTOMER_SAVE_INFO/gi).test(jurisdictionList);
    if(realInfoState && saveInfoState) {
        $scope.modifyColumn = true;
    } else {
        $scope.modifyColumn = false;
    }

    //时间戳
    $scope.timestamp = function (stamp) {
        return timestamp.timestampCoverHms(stamp, 'all');
    };
    // 客户状态
    getUserStates.userState().then(function (res) {
        $scope.customerStateList = res;
    });
    $scope.getState = function (params) {
        for (var i in $scope.customerStateList) {
            if (params == i) {
                return $scope.customerStateList[i];
            }
        }
    };
    //获取用户角色
    var roleTypeList = getUserType;
    $scope.changeRoleTypeText = function (value) {
        for (var i = 0, r = roleTypeList.length; i < r; i++) {
            if (roleTypeList[i].id == value) {
                return roleTypeList[i].name;
            }
        }
    };

    var processContent, processTotal;
    var source = {
        type: 'POST',
        datatype: "json",
        datafields: [  //数据字段定义
            {name: 'userId', type: 'string'},
            {name: 'roleId', type: 'string'},
            {name: 'state', type: 'string'},
            {name: 'loginName', type: 'string'},
            {name: 'realInfo', type: 'object'},

            {name: 'role', type: 'object'},
            {name: 'email', type: 'string'},
            {name: 'phone', type: 'string'},
            {name: 'state', type: 'string'},
            {name: 'registerTime', type: 'string'}
        ],
        url: $rootScope.baseUrl + 'user/query/customer/as/page',
        root: "content",
        pagesize: 10,
        processData: function (data) {
            data.page = (data.pagenum + 1) ? (data.pagenum + 1) : 1;
            data.rows = (data.pagesize) ? (data.pagesize) : 10;
            data.order = ($scope.order) ? $scope.order : 'desc';
            data.sort = ($scope.sort) ? $scope.sort : 'registerTime';
            data.search_A_LIKE_loginName = ($scope.loginName) ? $scope.loginName : '';
            data.search_A_LIKE_email = ($scope.email) ? $scope.email : '';
            data.search_A_LIKE_phone = ($scope.phone) ? $scope.phone : '';
            data.search_A_EQ_state = ($scope.chooseCustomerState) ? $scope.chooseCustomerState : '';
            data['search_A_LIKE_sysUserRealInfo.name'] = ($scope.realName) ? $scope.realName : '';
            data.search_A_GTE_registerTime = ($scope.registerTimeStart) ?$scope.registerTimeStart: '';
            data.search_A_LTE_registerTime = ($scope.registerTimeEnd) ?$scope.registerTimeEnd: '';

            $scope.orgCode = localStorageService.get('oldOrgCode');
            if ($scope.organizeValue == true && $scope.downOrganizeValue == true) {
                data['search_A_LLIKE_sysOrganizeRelation.orgCode'] = ($scope.orgCode) ? $scope.orgCode : '';
            }
            if ($scope.organizeValue == true && $scope.downOrganizeValue == false) {
                data['search_A_LLIKE_sysOrganizeRelation.orgCode'] = ($scope.orgCode) ? $scope.orgCode : '';
            }
            if ($scope.organizeValue == false && $scope.downOrganizeValue == true) {
                data['search_A_LLIKE_sysOrganizeRelation.orgCode'] = ($scope.orgCode) ? $scope.orgCode + '-' : '';
            }
        }, //传递参数处理
        beforeLoadComplete: function (records) { //数据完全加载完执行绘制表格
            var start;
            for (var i in records) {
                start = parseInt(i);
                break;
            }
            for (var k = 0, r = processContent.length; k < r; k++) {
                records[start + k].userId = processContent[k].userId;
                records[start + k].roleId = processContent[k].roleId;
                records[start + k].state = processContent[k].state;
                records[start + k].loginName = processContent[k].loginName;
                records[start + k].realInfo = processContent[k].realInfo;

                records[start + k].role = processContent[k].role;
                records[start + k].email = processContent[k].email;
                records[start + k].phone = processContent[k].phone;
                records[start + k].state = processContent[k].state;
                records[start + k].registerTime = processContent[k].registerTime;
            }
        },
        beforeprocessing: function (data) { //处理总页数
            var processData = JSON.parse(data.content);
            console.log(processData);
            processContent = processData.content;
            source.totalrecords = processData.totalElements == 0 ? 5 : processData.totalElements;
            // source.totalrecords =processData.totalElements;
            processTotal = processData.totalElements;
        },
        loadComplete: function (records) {
            $scope.saveResult = JSON.parse(records.content);
            var data = $scope.saveResult.totalElements;
            if (data == 0) {
                $('#contenttableentrustDetailGrid > div').remove();
            }
        },
        endUpdate: true
    };
    //创建数据适配器
    var dataAdapter = null;
    $scope.searchAjax = function () {
        $scope.toggleTraderSearchState = false;
        $('.search_column').css('height', '36px');
        if (dataAdapter == null) {
            dataAdapter = new $.jqx.dataAdapter(source);
            //创建表格
            $("#entrustDetailGrid").jqxGrid({
                source: dataAdapter,
                columns: [  //表格数据域
                    {
                        text: '用户名',
                        datafield: 'loginName',
                        width: '14%',
                        minwidth: 14 + '%',//设置列min宽
                        align: 'center'//设置表头
                    },
                    {
                        text: '用户实名',
                        datafield: 'realInfo',
                        minwidth: 14 + '%',
                        cellsalign: 'center',
                        align: 'center',
                        width: '14%',
                        cellsrenderer: function (row, columnfield, value, defaulthtml, columnproperties) {
                            if (value) {
                                return value.name
                            }
                        }
                    },
                    {
                        text: '角色名',
                        datafield: 'role',
                        width: '14%',
                        minwidth: 14 + '%',
                        align: 'center',
                        cellsrenderer: function (row, columnfield, value, defaulthtml, columnproperties) {
                            if (value) {
                                return value.roleName
                            }
                        }
                    },
                    {
                        text: '邮箱',
                        datafield: 'email',
                        width: '14%',
                        minwidth: 14 + '%',
                        align: 'center',
                        cellsrenderer: function (row, columnfield, value, defaulthtml, columnproperties) {
                            if (value) {
                                return value.slice(0, 3) + "***@" + value.split("@")[1]
                            }
                        }
                    },
                    {
                        text: '手机号',
                        datafield: 'phone',
                        width: '14%',
                        minwidth: 14 + '%',
                        align: 'center',
                        sortable:false,
                        cellsrenderer: function (row, columnfield, value, defaulthtml, columnproperties) {
                            if (value) {
                                return value.slice(0, 3) + "***" + value.slice(7,11)
                            }
                        }
                    },
                    {
                        text: '状态',
                        datafield: 'state',
                        width: '14%',
                        minwidth: 14 + '%',
                        align: 'center',
                        cellsrenderer: function (row, columnfield, value, defaulthtml, columnproperties) {
                            if ($scope.customerStateList) {
                                for (var i in $scope.customerStateList) {
                                    if (value == i) {
                                        return $scope.customerStateList[i];
                                    }
                                }
                            }
                        }
                    },
                    {
                        text: '注册时间',
                        datafield: 'registerTime',
                        width: '16%',
                        minwidth: 16 + '%',
                        align: 'center',
                        cellsrenderer: function (row, columnfield, value, defaulthtml, columnproperties) {
                            if (value) {
                                return timestamp.timestampCoverHms(value, 'all');
                            }
                        }
                    }
                ],
                width:100+'%',
                height: 81 + '%',
                theme: 'metrodark',
                virtualmode: true,
                rendergridrows: function (params) { //将数据渲染到页面
                    return params.data;
                },
                pageable: true,
                pagesizeoptions: ['10', '30', '100', '200'],
                // sortable: true,
                columnsresize: true,//列间距是否可调整
                clipboard: true
            });
        } else {
            $("#entrustDetailGrid").jqxGrid('updatebounddata', 'cells');
        }
    };

    //分页
    $("#entrustDetailGrid").on("pagechanged", function (event) {
        console.log(event)
    });
    //排序
    $("#entrustDetailGrid").on("sort", function (event) {
        var sortinformation = event.args.sortinformation;
        $scope.sort = sortinformation.sortcolumn;
        $scope.order = ($scope.sort) ? (sortinformation.sortdirection.ascending) ? 'asc' : 'desc' : 'asc';
        data = {
            order: $scope.order,
            sort: $scope.sort
        };
        source.processData(data);
        $("#entrustDetailGrid").jqxGrid('updatebounddata', 'sort');
    });
    //选中
    $scope.chooseOrgData = {
        userId: null,
        roleId: null,
        state: null
    };
    $('#entrustDetailGrid').on('rowselect', function (event) {
        $scope.userId = event.args.row.userId;
        $scope.state=event.args.row.state;
        $scope.chooseOrgData.userId = event.args.row.userId;
        $scope.chooseOrgData.roleId = event.args.row.roleId;
        $scope.chooseOrgData.state = event.args.row.state;
        $scope.$apply()
    });

    //签约明细
    $scope.signState = function () {
        if ($scope.chooseOrgData.userId) {
            var json = {
                userId: $scope.chooseOrgData.userId
            };
            customerMangerCtrlSer.getSignData(json)
                .then(function (res) {
                    if (res.code == '000000') {
                        if (res.content) {
                            $scope.resignColumn = true;
                            $scope.signResult = JSON.parse(res.content);
                            $scope.resign_cardNo = $scope.signResult.cardNo;
                            $scope.resign_cardName = $scope.signResult.cardName;
                            $scope.resign_identityCard = $scope.signResult.identityCard;
                            $scope.resign_cusMobile = $scope.signResult.cusMobile.slice(0, 3) + "***" + $scope.signResult.cusMobile.slice(7,11);
                            $scope.resign_recvTgfi = $scope.signResult.recvTgfi;
                            $scope.resign_custBank = $scope.signResult.custBank;
                        } else {
                            $rootScope.tipService.setMessage('签约信息为空!', 'warning');
                        }
                    } else {
                        $rootScope.tipService.setMessage(res.message, 'warning');
                    }
                });
        } else {
            $rootScope.tipService.setMessage('请先选择用户!', 'warning');
        }
    };
    //角色变更
    $scope.userRoleId = '';
    $scope.changeUser = function () {
        if ($scope.chooseOrgData.userId) {
            localStorageService.update('userId', $scope.chooseOrgData.userId);
            var json = {
                userId: $scope.chooseOrgData.userId
            };
            customerMangerCtrlSer.getChangeInfo(json)
                .then(function (res) {
                    $scope.changeUserInfo = JSON.parse(res.data.content);
                    if (res.data.code == '000000') {
                        $scope.userChangeColumn = true;
                        $scope.searchAjax();
                    } else {
                        $rootScope.tipService.setMessage(res.data.message, 'warning');
                    }
                }, function (error) {
                    $rootScope.tipService.setMessage(error.data.message, 'warning');
                });
        } else {
            $rootScope.tipService.setMessage('请先选择用户!', 'warning');
        }
    };
    $scope.userChangeBtn = function () {
        var userIdData = localStorageService.get('userId');
        var json = {
            userId: userIdData,
            roleId: $scope.userRoleId
        };
        customerMangerCtrlSer.sendChangeInfo(json)
            .then(function (res) {
                if (res.data.code == '000000') {
                    $scope.userChangeColumn = false;
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                } else {
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                }
            }, function (error) {
                console.log(error);
                $rootScope.tipService.setMessage(error.data.message, 'warning');
            });
    };

    //修改
    //页面跳转
    $scope.trunPage = function (url, type) {
        if (type == 'customManageAdd') {
            var info = new Object();
            info.type = 4;
            info.typeName = '客户角色';
            info.active = ' ';
            localStorageService.update('allUserAddInfo', info);
        } else if (type == 'customManageEdit') {
            if ($scope.chooseOrgData.userId == null) {
                $rootScope.tipService.setMessage('请先选择客户', 'warning');
                return;
            } else {
                var info = new Object();
                info.type = 4;
                info.typeName = '客户角色';
                info.active = 'edit';
                info.editUserId = $scope.chooseOrgData.userId;
                localStorageService.update('allUserAddInfo', info);
            }
        }
        $state.go(url);
    };

    //注销
    $scope.cancel = function () {
        if (!$scope.chooseOrgData.userId) {
            $rootScope.tipService.setMessage('请先选择用户', 'warning');
        }else {
            confirmService.set('确认提示', '确定要注销此账户?', function () {
                customerMangerCtrlSer.close($scope.chooseOrgData.userId).then(function (res) {
                    if (res.data.code == '000000') {
                        $rootScope.tipService.setMessage(res.data.message, 'warning');
                        $scope.searchAjax();
                    } else {
                        $rootScope.tipService.setMessage(res.data.message, 'warning');
                    }
                }, function (error) {
                    $rootScope.tipService.setMessage(error.data.message, 'warning');
                });
                confirmService.clear();
            })
        }
    };

    //冻结
    $scope.freeze = function () {
        if ($scope.chooseOrgData.userId) {
            customerMangerCtrlSer.freeze($scope.chooseOrgData.userId)
                .then(function (res) {
                    if (res.data.code == '000000') {
                        $rootScope.tipService.setMessage(res.data.message, 'warning');
                        $scope.searchAjax();
                    } else {
                        $rootScope.tipService.setMessage(res.data.message, 'warning');
                    }
                }, function (error) {
                    $rootScope.tipService.setMessage(error.data.message, 'warning');
                });

        } else {
            $rootScope.tipService.setMessage('请先选择用户!', 'warning');
        }
    };
    //解冻
    $scope.unFreeze = function () {
        if ($scope.chooseOrgData.userId) {
            customerMangerCtrlSer.unfreeze($scope.chooseOrgData.userId)
                .then(function (res) {
                    if (res.data.code == '000000') {
                        $rootScope.tipService.setMessage(res.data.message, 'warning');
                        $scope.searchAjax();
                    } else {
                        $rootScope.tipService.setMessage(res.data.message, 'warning');
                    }
                }, function (error) {
                    $rootScope.tipService.setMessage(error.data.message, 'warning');
                });
        } else {
            $rootScope.tipService.setMessage('请先选择用户!', 'warning');
        }
    };
    //通过审核
    $scope.passCheck = function () {
        if ($scope.chooseOrgData.userId) {
            customerMangerCtrlSer.passCheck($scope.chooseOrgData.userId)
                .then(function (res) {
                    if (res.data.code == '000000') {
                        $rootScope.tipService.setMessage(res.data.message, 'warning');
                        $scope.searchAjax();
                    } else {
                        $rootScope.tipService.setMessage(res.data.message, 'warning');
                    }
                }, function (error) {
                    $rootScope.tipService.setMessage(error.data.message, 'warning');
                });

        } else {
            $rootScope.tipService.setMessage('请先选择用户!', 'warning');
        }
    };
    //重提审核
    $scope.rePassCheck = function () {
        if ($scope.chooseOrgData.userId) {
            customerMangerCtrlSer.open($scope.chooseOrgData.userId)
                .then(function (res) {
                    if (res.data.code == '000000') {
                        $rootScope.tipService.setMessage(res.data.message, 'warning');
                        $scope.searchAjax();
                    } else {
                        $rootScope.tipService.setMessage(res.data.message, 'warning');
                    }
                }, function (error) {
                    $rootScope.tipService.setMessage(error.data.message, 'warning');
                });
        } else {
            $rootScope.tipService.setMessage('请先选择用户!', 'warning');
        }
    };
    //驳回
    $scope.failedCheck = function () {
        if ($scope.chooseOrgData.userId) {
            customerMangerCtrlSer.failedCheck($scope.chooseOrgData.userId)
                .then(function (res) {
                    if (res.data.code == '000000') {
                        $rootScope.tipService.setMessage(res.data.message, 'warning');
                        $scope.searchAjax();
                    } else {
                        $rootScope.tipService.setMessage(res.data.message, 'warning');
                    }
                }, function (error) {
                    $rootScope.tipService.setMessage(error.data.message, 'warning');
                });
        } else {
            $rootScope.tipService.setMessage('请先选择用户!', 'warning');
        }
    };

});