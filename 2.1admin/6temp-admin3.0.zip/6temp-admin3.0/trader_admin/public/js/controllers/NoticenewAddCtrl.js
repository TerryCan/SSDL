app.controller('NoticenewAddCtrl', ['$scope', 'dataSer', 'CommissionallocationAddCtrlSer', 'NoticenewAddCtrlSel', '$state', '$rootScope', function($scope, dataSer, CommissionallocationAddCtrlSer, NoticenewAddCtrlSel, $state, $rootScope) {
	 var E = window.wangEditor;
        var editor = new E('#editor');
        editor.customConfig.pasteFilterStyle = true;
        console.log(editor.customConfig.pasteFilterStyle)
        editor.customConfig.menus = [
        'head',  // 标题
	    'bold',  // 粗体
	    'italic',  // 斜体
	    'underline',  // 下划线
	    'strikeThrough',  // 删除线
	    'foreColor',  // 文字颜色
	    'backColor',  // 背景颜色
	    'list',  // 列表
	    'justify',  // 对齐方式
	    'table',  // 表格
	    'code',  // 插入代码
	    'undo',  // 撤销
	    'redo'  // 重复
   		 ]
        editor.create();
        document.getElementById('editor').onkeyup = function(){

        	 $scope.content= editor.txt.html();
        };

		$scope.goBack = function() {
				$state.go('tabs.Noticequery');
			}
			//机构列表
		$scope.addOrgVal = ''; //显示值
		$scope.orgId = ''; //选择值
		dataSer.organizeQuerySer()
			.then(function(res) {
				console.log(res)
				$scope.orgList = res;
				//console.log($scope.orgList)
			});
		$scope.allnotlickList = [];
		$scope.copyuesrList = [];
		$scope.addOrgValFTC = function(d) {
				//console.log(data);
				$scope.allotOrgId = d.orgId;
				$scope.superorgCode = d.orgCode;
				$scope.addOrgVal = d.text;
				NoticenewAddCtrlSel.AllSer(99999,1,$scope.allotOrgId)
					.then(function(res) {
						console.log(res)
						if(res.code=="000000"){
						//$scope.allnotlickList = JSON.parse(res.content).content;
						//console.log($scope.allnotlickList);
						for (var i = 0, r = $scope.allnotlickList.length; i < r; i++) {
							if ($scope.allnotlickList[i].state == 1) {
								$scope.allnotlickList.push({
									orgCode: $scope.allnotlickList[i].orgCode,
									orgName: $scope.allnotlickList[i].orgName
								})
							}
						}
						}
					})
				$scope.uesrshow = false;
			}
		$scope.addOrg = function(index) {
			//console.log(index)
			$scope.copyuesrList.unshift($scope.allnotlickList.splice(index, 1)[0]);
		}
		$scope.backOrg = function(index) {
				$scope.allnotlickList.unshift($scope.copyuesrList.splice(index, 1)[0]);
			}
			//清除数据
		$scope.title = "";
		$scope.content = "";
		$scope.createTimeStart = "";
		$scope.createTimeend = "";
		$scope.orgId = "";
		$scope.orgCode = "";
		$scope.readType = "";
		$scope.roleIds = "";
		$scope.userIds = "";


	/*	//切换
		$scope.TypeSelect = function() {
				if ($scope.readType == 5) {
					$scope.uesrshow = true;

				} else if ($scope.readType == 1 || $scope.readType == 2) {
					$scope.uesrshow = false;
				}

			}*/
			//创建公告
		$scope.addNoticeInfo = function() {
						if($scope.title == undefined || $scope.title == '') {
				$rootScope.tipService.setMessage('请先填写标题', 'warning');
			} else if ($scope.content == undefined || $scope.content == '') {
				$rootScope.tipService.setMessage('请先填写内容', 'warning');
			}else{
			var noticeV = {
				title: $scope.title,
				content:$scope.content,
				validStartTime: $scope.createTimeStart,
				validEndTime:$scope.createTimeend,
				configs: [{
					orgId: $scope.allotOrgId,
					orgCode: $scope.superorgCode,
					readType: $scope.readType,
					userIds: $scope.uesrconfigs,
				}]
			}
			console.log(noticeV)
			var json = {
				noticeV: noticeV
			}
			NoticenewAddCtrlSel.addInfo(json)
				.then(function(res) {
					if (res.data.code =="000000") {
						$rootScope.tipService.setMessage(res.data.message, 'warning');
						$state.go('tabs.Noticequery');
					}else{
						$rootScope.tipService.setMessage(res.data.message, 'warning');
					}

				},function(error){
					$rootScope.tipService.setMessage(error.data.message, 'warning');
				})
			}
		}
	}])
	.factory('NoticenewAddCtrlSel', ['$http', 'localStorageService', 'myHttp', '$q', '$rootScope', function($http, localStorageService, myHttp, $q, $rootScope) {
		return {
			AllSer: function(page,rows,allotOrgId) { //所属下级机构
				var data = {
					rows:99999,
					page:1,
					orders: 'asc',
					search_LIKE_orgId: allotOrgId,
					//search_NOTLIKE_orgCode: superorgCode + '-%-%'
				};
				var deferred = $q.defer();
				myHttp.post("user/query/customer/as/page", data)
					.then(function(res) { // 调用承诺API获取数据 .resolve
						//console.log(res)
						var resArr = [];
						if (res.code === "000000") {
							var results = JSON.parse(res.content).content;
							//console.log(results)
							var tmpArr = [];
							for (var i = 0, r = results.length; i < r; i++) {
								if (results[i].state == 1) {
									var tmp = {};
									tmp.orgCode = results[i].organize.orgCode;
									tmp.orgId = results[i].organize.orgId;
									tmp.orgName = results[i].organize.orgName;
									tmp.text = '分配机构名:' + results[i].orgName + ' | 分配机构代码:' + results[i].orgCode;
									tmpArr.push(tmp);
								}
							}
							deferred.resolve(tmpArr);
						} else {
							deferred.reject(res);
						}
					}, function(res) { // 处理错误 .reject
						deferred.reject(res);
					});
				return deferred.promise;
			},
			addInfo: function(json) {
				var deferred = $q.defer();
				$http({
						method: 'POST',
						url: $rootScope.baseUrl + 'notice/create',
						data: json
					})
					.then(function(res) { // 调用承诺API获取数据 .resolve
						deferred.resolve(res);
					}, function(res) { // 处理错误 .reject
						deferred.reject(res);
					});
				return deferred.promise;
			}

		}
	}])