app.controller('accessManageCtrl', ['$rootScope', '$scope', 'accessManageSer', 'dataSer', '$timeout', '$sce', 'getPageNum','localStorageService', function ($rootScope, $scope, accessManageSer, dataSer, $timeout, $sce, getPageNum,localStorageService) {
    $scope.toggleTraderSearchState=false;
    $scope.Toggle = function(){
        $scope.toggleTraderSearchState = !$scope.toggleTraderSearchState;
        if($scope.toggleTraderSearchState){
           $('.search_column').css('height','auto');
        }
        else{
           $('.search_column').css('height','36px');
        }
    };

    var processContent,processTotal;
    var source = {
        type: 'POST',
        datatype: "json",
        datafields: [  //数据字段定义
            {name: 'bankCode', type: 'string'},
            {name: 'bankName', type: 'string'}
        ],
        url: $rootScope.baseUrl + 'exbank/query/bankchannel/page',
        root: "content",
        pagesize:10,
        processData: function (data) { //传递参数处理
            data.page = (data.pagenum + 1)?(data.pagenum + 1):1;
            data.rows =(data.pagesize)?(data.pagesize):10;
            // data.order =($scope.order)?$scope.order:'desc';
            // data.sort =($scope.sort)?$scope.sort:'createTime';
            data.search_EQ_bankCode = ($scope.bankCode) ? $scope.bankCode : '';
            data.search_LIKE_bankName =($scope.bankName)?$scope.bankName:'';

        },
        loadComplete: function (records) {
            console.log(records)
            $scope.saveResult=JSON.parse(records.content);
            var data =  $scope.saveResult.totalElements;
            if (data == 0) {
                $('#contenttableentrustDetailGrid > div').remove();
            }
        },
        loadError: function (xhr, status, error){ //加载错误调用
            console.log(xhr, status, error)
            if(xhr.status=="404"){
                $rootScope.tipService.setMessage('用户登入状态过期!', 'warning');
            }
        },
        beforeLoadComplete: function (records) { //数据完全加载完执行绘制表格
            var start;
            for (var i in records) {
                start = parseInt(i);
                break;
            }
            for (var k = 0, r = processContent.length; k < r; k++) {
                records[start + k].bankCode = processContent[k].bankCode;
                records[start + k].bankName = processContent[k].bankName;
            }
        },
        beforeprocessing: function (data) { //处理总页数
            console.log(data);
            if(data.code=="000000"){
                var processData = JSON.parse(data.content);
                console.log(processData)
                processContent = processData.content;
                source.totalrecords = processData.totalElements == 0 ? 5 : processData.totalElements;
                processTotal = processData.totalElements;
            }else{
                $rootScope.tipService.setMessage(data.message, 'warning');
            }
        },
        endUpdate: true
    };
    //创建数据适配器
    var dataAdapter = null;
    $scope.searchAjax = function () {
        $scope.featureShow=true;
        $scope.toggleTraderSearchState = false;
        $('.search_column').css('height', '36px');
        if (dataAdapter == null) {
            dataAdapter = new $.jqx.dataAdapter(source);
            //创建表格
            $("#entrustDetailGrid").jqxGrid({
                // autowidth: true,
                source: dataAdapter,
                columns: [  //表格数据域
                    {
                        text: '通道代码',
                        datafield: 'bankCode',
                        width: '50%',
                        align: 'center'//设置表头
                    },
                    {
                        text: '通道名',
                        datafield: 'bankName',
                        cellsalign: 'center',
                        align: 'center',
                        width: '50%'
                    }
                ],
                width:100 + '%',
                // autowidth:true,
                // shrinkToFit:true,
                height: 88 + '%',
                theme:'metrodark',
                virtualmode: true,
                rendergridrows: function (params) { //将数据渲染到页面
                    return params.data;
                },
                pageable: true,
                pagesizeoptions: ['10','30','100','200'],
                // sortable: true,
                columnsresize: true,//列间距是否可调整
                clipboard: true
            });
        }else {
            $("#entrustDetailGrid").jqxGrid('updatebounddata', 'cells');
        }
    };

    // var a  = $("#entrustDetailGrid").jqxGrid();console.log(a)
    // $('#entrustDetailGrid').on('resize', function (event) {
    //     alert(11)
    //     console.log(event);
    //     var resizedItem = event.args.item,
    //         type = resizedItem.type;
    //
    // });

    // 设置表格宽度
    // $(function(){
    //     $(window).resize(function(){
    //         console.log($(window).width()-200);
    //         $("#entrustDetailGrid").setGridWidth($(window).width()*0.8);
    //     });
    // });

    // $(function(){
    //     $(window).resize(function(){
    //         $("#entrustDetailGrid").setGridWidth($(window).width()*0.99);　
    //         $("#entrustDetailGrid").setGridWidth(document.body.clientWidth*0.99);
    //     });
    // });

    //分页
    $("#entrustDetailGrid").on("pagechanged", function (event) {
        console.log(event)
    });
    //排序
    $("#entrustDetailGrid").on("sort", function (event) {
        var sortinformation = event.args.sortinformation;
        $scope.sort=sortinformation.sortcolumn;
        $scope.order=($scope.sort)?(sortinformation.sortdirection.ascending)?'asc':'desc':'asc';
        data={
            order:$scope.order,
            sort:$scope.sort
        };
        source.processData(data);
        $("#entrustDetailGrid").jqxGrid('updatebounddata', 'sort');
    });
    //选中
    $('#entrustDetailGrid').on('rowselect', function (event) {
        $scope.pine_bankCode = event.args.row.bankCode;
        $scope.pine_bankName = event.args.row.bankName;
    });



    $scope.pine_bankCode = '';
    $scope.pine_bankName = '';
    $scope.channelText = '';
    $scope.add = function (type){
        if (!type) {
            $scope.channelText = '新增';
            $scope.pine_bankCode ='';
            $scope.pine_bankName ='';
            $scope.channelColumn = true;
            $scope.bankCodeShow = true;
        } else {
            if (!$scope.pine_bankCode) {
                $rootScope.tipService.setMessage('请先选择通道', 'warning');
            } else {
                $scope.channelText = '修改';
                $scope.channelColumn = true;
                $scope.bankCodeShow = false;

            }
        }
    };
    $scope.channelFunc = function () {
        if ($scope.channelText == '新增') {
            var bankChannelV = {
                bankCode: parseInt($scope.pine_bankCode),
                bankName: $scope.pine_bankName
            };
            var json = {
                bankChannelV: bankChannelV
            };
            accessManageSer.unitAdd(json)
                .then(function (res) {
                    $scope.channelColumn = false;
                    $rootScope.tipService.setMessage(res.message, 'warning');
                    $scope.searchAjax();
                }, function (error) {
                    $rootScope.tipService.setMessage(error.message, 'warning');
                })
        } else {
            var bankChannelV = {
                bankCode: parseInt($scope.pine_bankCode),
                bankName: $scope.pine_bankName
            };
            var json = {
                bankChannelV: bankChannelV
            }
            accessManageSer.unitModify(json)
                .then(function (res) {
                    $scope.channelColumn = false;
                    $rootScope.tipService.setMessage(res.message, 'warning');
                    $scope.searchAjax();
                }, function (error) {
                    $rootScope.tipService.setMessage(error.message, 'warning');
                })
        }
    }
}])
// Server
    .factory('accessManageSer', ['$http', 'localStorageService', 'myHttp', '$q', '$rootScope', function ($http, localStorageService, myHttp, $q, $rootScope) {
        return {
            unitAdd: function (json) {
                var deferred = $q.defer();
                $http({
                    method: "POST",
                    url: $rootScope.baseUrl + "exbank/create/bankchannel",
                    data: json,
                    headers: {
                        'Content-Type': 'application/json;charset=UTF-8'
                    }
                }).success(function (res) {
                    deferred.resolve(res);
                }).error(function (res) {
                    deferred.reject(res);
                });
                return deferred.promise;
            },
            unitModify: function (json) {
                var deferred = $q.defer();
                $http({
                    method: "POST",
                    url: $rootScope.baseUrl + "exbank/update/bankchannel",
                    data: json,
                    headers: {
                        'Content-Type': 'application/json;charset=UTF-8'
                    }
                }).success(function (res) {
                    deferred.resolve(res);
                }).error(function (res) {
                    deferred.reject(res);
                });
                return deferred.promise;
            }
        }
    }])