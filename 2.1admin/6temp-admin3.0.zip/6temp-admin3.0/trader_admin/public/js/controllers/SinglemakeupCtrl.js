app.controller('SinglemakeupCtrl', ['$scope', 'SinglemakeupCtrlSel', 'getPageNum', 'localStorageService', '$state', 'getPrevSourceAgreementData', '$rootScope','getCollectionState', function ($scope, SinglemakeupCtrlSel, getPageNum, localStorageService, $state, getPrevSourceAgreementData, $rootScope,getCollectionState) {

    var processContent,processTotal;
    var source = {
        type: 'POST',
        datatype: "json",
        datafields: [  //数据字段定义
            {name: 'recoverId', type: 'string'},
            {name: 'channelType', type: 'string'},
            {name: 'state', type: 'string'},
            {name: 'remark', type: 'string'}
        ],
        url: $rootScope.baseUrl + 'admin/trade/recover/query/as/page',
        root: "content",
        pagesize:10,
        processData: function (data) {
            data.page = (data.pagenum + 1)?(data.pagenum + 1):1;
            data.rows =(data.pagesize)?(data.pagesize):10;
            data.order =($scope.order)?$scope.order:'desc';
            data.sort =($scope.sort)?$scope.sort:'createTime';
        }, //传递参数处理
        beforeLoadComplete: function (records) { //数据完全加载完执行绘制表格
            var start;
            for (var i in records) {
                start = parseInt(i);
                break;
            }
            for (var k = 0, r = processContent.length; k < r; k++) {
                records[start + k].recoverId = processContent[k].recoverId;
                records[start + k].channelType = processContent[k].channelType;
                records[start + k].state = processContent[k].state;
                records[start + k].remark = processContent[k].remark;
            }
        },
        beforeprocessing: function (data) { //处理总页数
            console.log(data)
            var processData = JSON.parse(data.content);
            processContent = processData.content;
            source.totalrecords = processData.totalElements == 0 ? 5 : processData.totalElements;
            processTotal = processData.totalElements;
        },
        loadComplete: function (records) {
            $scope.saveResult=JSON.parse(records.content);
            var data =  $scope.saveResult.totalElements;
            if (data == 0) {
                $('#contenttableentrustDetailGrid > div').remove();
            }
        },
        endUpdate: true
    };
    //创建数据适配器
    var dataAdapter = null;
    $scope.searchAjax = function () {
        $scope.toggleTraderSearchState = false;
        $('.search_column').css('height', '36px');
        if (dataAdapter == null) {
            dataAdapter = new $.jqx.dataAdapter(source);
            //创建表格
            $("#entrustDetailGrid").jqxGrid({
                source: dataAdapter,
                columns: [  //表格数据域
                    {
                        text: '通道类型',
                        datafield: 'channelType',
                        width: '30%',
                        minwidth: 30 + '%',//设置列min宽
                        align: 'center'//设置表头
                    },
                    {
                        text: '状态',
                        datafield: 'state',
                        minwidth: 33 + '%',
                        cellsalign: 'center',
                        align: 'center',
                        width: '33%',
                        cellsrenderer: function (row, columnfield, value, defaulthtml, columnproperties) {
                            if (getCollectionState) {
                                for (var i = 0; i <getCollectionState.length; i++) {
                                    if (value ==getCollectionState[i].id) {
                                        return getCollectionState[i].name;
                                    }
                                }
                            }
                        }
                    },
                    {
                        text: '备注',
                        datafield: 'remark',
                        width:'37%',
                        minwidth: 37 + '%',
                        align: 'center'
                    }
                ],
                width: 100 + '%',
                height: 81 + '%',
                theme:'metrodark',
                virtualmode: true,
                rendergridrows: function (params) { //将数据渲染到页面
                    return params.data;
                },
                pageable: true,
                pagesizeoptions: ['10','30','100','200'],
                sortable: true,
                columnsresize: true,//列间距是否可调整
                // selectionmode: 'singlecell',//选择模式
                clipboard: true,
                // selectionmode: 'checkbox',//复选框
            });
        }else {
            $("#entrustDetailGrid").jqxGrid('updatebounddata', 'cells');
        }
    };

    //分页
    $("#entrustDetailGrid").on("pagechanged", function (event) {
        console.log(event)
    });
    //排序
    $("#entrustDetailGrid").on("sort", function (event) {
        var sortinformation = event.args.sortinformation;
        $scope.sort=sortinformation.sortcolumn;
        $scope.order=($scope.sort)?(sortinformation.sortdirection.ascending)?'asc':'desc':'asc';
        data={
            order:$scope.order,
            sort:$scope.sort
        };
        source.processData(data);
        $("#entrustDetailGrid").jqxGrid('updatebounddata', 'sort');
    });
    //选中
    $('#entrustDetailGrid').on('rowselect', function (event) {
        $scope.chooseNoticeId = event.args.row.recoverId;
        console.log( $scope.chooseNoticeId)
    });


    //新增
    $scope.channelType = "";
    $scope.fileFileId = "";
    $scope.remark = "";
    $scope.NewSubmit = function () {
        var recoverVIce = {
            channelType: $scope.channelType, // 通道类型
            fileId: $scope.fileFileId, // 附件
            remark: $scope.remark// 备注
        };
        SinglemakeupCtrlSel.NewSubmitAdd(recoverVIce)
            .then(function (res) {
                if (res.data.code == "000000") {
                    $scope.newShow = false;
                    $scope.searchAjax();
                } else {
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                }
            }, function (error) {
                $rootScope.tipService.setMessage(error.data.message, 'warning');
            })
    };
    //明细
    $scope.recoversearch = function (url) {
        if ($scope.chooseNoticeId == null) {
            $rootScope.tipService.setMessage('请先选择通道类型', 'warning');
        } else {
            localStorageService.update('REchooseNoticeId', $scope.chooseNoticeId);
            $state.go(url);
        }
    };
    //提交验证
    $scope.validateShow = function () {
        if (!$scope.chooseNoticeId) {
            $rootScope.tipService.setMessage('请先选择补录单', 'warning');
        } else {
            var json = {
                recoverId: $scope.chooseNoticeId
            };
            SinglemakeupCtrlSel.validate(json)
                .then(function (res) {
                    if (res.data.code == "000000") {
                        $rootScope.tipService.setMessage(res.data.message, 'warning');
                    } else {
                        $rootScope.tipService.setMessage(res.data.message, 'warning');
                    }
                }, function (error) {
                    $rootScope.tipService.setMessage(error.data.message, 'warning');
                })
        }
    };


    //xls文件上传
    uploadImg = function (id, num) {
        function doCheck() {
            var file = $("#AddfileFileId").val();
            if (file == '' || file == null) {
                $("#error").html("请选择所要上传的文件！");
            } else {
                var index = file.lastIndexOf(".");
                if (index < 0) {
                    $("#error").html("上传的文件格式不正确，请选择97-2003Excel文件(*.xls)！");
                } else {
                    var ext = file.substring(index + 1, file.length);
                    if (ext != "xls") {
                        $("#error").html("上传的文件格式不正确，请选择97-2003Excel文件(*.xls)！");
                    } else {
                        $("#error").hide();
                        return true;
                    }
                }
            }
            return false;
        }

        doCheck();
        //console.log(id,num);
        var urlUpload = $rootScope.baseUrl + 'file/upload';
        upload_img(urlUpload, id, function (res, status) {
            if (res.code == '000000') {
                var data = JSON.parse(res.content);
                console.log(data);
                var ImgId = data[0].fileId;
                switch (num) {
                    case 1:
                        $scope.fileFileId = ImgId;
                        //console.log($scope.orgLogoFileIdImg1)
                        $('#fileFileId').attr('src', "" + $rootScope.baseUrl + "/file/download?fileId=" + ImgId + "");
                        break;
                }
            }
        });
    };

    // 上传图片
    // url:后台访问路径 fileId:input file按钮id, btn:点击的按钮id, fileInput:接收上传图片的id
    function upload_img(url, fileId, callback) {
        $.ajaxFileUpload({
            url: url,
            type: 'post',
            secureuri: false,
            fileElementId: fileId, // file标签的id
            dataType: 'json', // 返回数据的类型
            data: {
                name: fileId
            },
            success: function (data, status) {
                callback(data, status);
            },
            error: function (data, status, e) {
                console.log(data, status, e);
            }
        });
    }


}])
    .factory('SinglemakeupCtrlSel', ['$http', 'localStorageService', 'myHttp', '$q', '$rootScope', function ($http, localStorageService, myHttp, $q, $rootScope) {
        return {
            search: function (json) {
                var deferred = $q.defer();
                myHttp.post("admin/trade/recover/query/as/page", json)
                    .then(function (res) { // 调用承诺API获取数据 .resolve
                        deferred.resolve(res);
                    }, function (res) { // 处理错误 .reject
                        deferred.reject(res);
                    });
                return deferred.promise;
            },
            NewSubmitAdd: function (recoverVIce) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'admin/trade/recover/create',
                    data: {
                        "recoverVIce": recoverVIce
                    }
                }).then(function successCallback(response) {
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
            validate: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'admin/trade/recover/validate/send',
                    data: json
                }).then(function successCallback(response) {
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            }
        }
    }])