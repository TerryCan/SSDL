app.controller('merchantManageAddCtrl', ['$scope', '$rootScope', 'dataSer', 'merchantManageAdd', 'getKeyStoreType', 'getFeeType', 'switchBoolean', 'switchThirdPay', 'getCurrencyType', 'getBankState', function ($scope, $rootScope, dataSer, merchantManageAdd, getKeyStoreType, getFeeType, switchBoolean, switchThirdPay, getCurrencyType, getBankState) {
    $scope.goBack = function () {
        $scope.changeState('tabs.merchantManage');
    };
    // 数据转化
    $scope.bankState = getBankState;
    $scope.KeyStoreType = getKeyStoreType;
    $scope.FeeType = getFeeType;
    $scope.booleanTo = switchBoolean;
    $scope.getBoolean = function (parameter) {
        for (i = 0; i < switchBoolean.length; i++) {
            if (parameter == switchBoolean[i].id) {
                return switchBoolean[i].name;
            }
        }
    };
    //第三方支付
    $scope.thirdPay = switchThirdPay;
    $scope.getThirdPay = function (parameter) {
        for (i = 0; i < switchThirdPay.length; i++) {
            if (parameter == switchThirdPay[i].id) {
                return switchThirdPay[i].name;
            }
        }
    };
    // 货币转换
    getCurrencyType.then(function (res) {
        $scope.currencyList = JSON.parse(res.content);
    });
    $scope.getCurrency = function (parameter) {
        if ($scope.currencyList) {
            for (var i = 0; i < $scope.currencyList.length; i++) {
                if (parameter == $scope.currencyList[i].currency) {
                    return $scope.currencyList[i].currencyName;
                }
            }
        }
    };
    //所属机构
    $scope.editUserLocked = false;
    $scope.isShowOrgList = false;
    $scope.addOrgVal = ''; //显示值
    $scope.orgCode = '';
    $scope.addOrgChooseVal = ''; //选择值
    dataSer.organizeQuerySer().then(function (res) {
        $scope.orgList = res;
        console.log($scope.orgList);
    });
    $scope.addOrgValFTC = function (val, orgCode, showval) {
        $scope.addOrgChooseVal = val;
        $scope.orgCode = orgCode;
        $scope.addOrgVal = showval;
        $scope.isShowOrgList = false;
    }
    $scope.hideOrgList = function () {
        $scope.isShowOrgList = false;
        $(".OrgList").blur();
    };

    // //银行通道
    var bankJson = {
        page: 1,
        rows: 9999,
        orders: 'asc'
    };
    merchantManageAdd.bankChannel(bankJson).then(function (res) {
        $scope.bankChannelList = JSON.parse(res.content).content;
        console.log($scope.bankChannelList);
    });

    $scope.bankAccountNo = '';
    $scope.bankUserName = '';
    $scope.memberNumber = '';
    $scope.terminalNumbwe1 = '';
    $scope.terminalNumbwe2 = '';
    $scope.terminalNumbwe3 = '';
    $scope.bankMngnodeNum = '';
    $scope.channelBankCode = '';
    $scope.channelDefaultFlag = '';
    $scope.channelThirdpayFlag = '';
    $scope.channelCurrency = '';
    $scope.channelStatus = '';

    $scope.bankRequestUrl = '';
    $scope.md5Password = '';
    $scope.prikeyPassowrd = '';
    $scope.prikeyName = '';
    $scope.prikeySavetype = '';
    $scope.pubkeyName = '';
    $scope.pubkeySavetype = '';
    $scope.gatepayReturnPage='';
    $scope.gatepayReturnUrl='';

    $scope.payFeeNum = '';
    $scope.payFeeType = '';
    $scope.withdrawFeeType = '';
    $scope.channelThirdpayFlag = '';
    $scope.channelSignUpFlag = '';
    $scope.channelPayFlag = '';
    $scope.channelWithdrawFlag = '';
    $scope.withdrawFeeNum = '';
    //数据处理
    $scope.chooseChannel = function () {
        if ($scope.channelThirdpayFlag == -1) { //银行
            $scope.bankFlag = true;
            $scope.thirdFlag = false;
            $scope.bankFlagStatus = false;
            $scope.thirdFlagStatus = true;
            $scope.prikeySavetype = '';
            $scope.pubkeySavetype = '';
        } else if ($scope.channelThirdpayFlag == 1) { //第三方支付
            $scope.thirdFlag = true;
            $scope.bankFlag = false;
            $scope.bankFlagStatus = true;
            $scope.thirdFlagStatus = false;
            $scope.prikeySavetype = 1;
            $scope.pubkeySavetype = 1;
        } else {
            $scope.prikeySavetype = '';
            $scope.pubkeySavetype = '';
        }
    };
    $scope.merchantAdd = function () {
        var merchantFullV = {
            basicV: {
                bankCode: $scope.channelBankCode,
                bankAccountNo: $scope.bankAccountNo,
                bankUserName: $scope.bankUserName,
                bankMngnodeNum: $scope.bankMngnodeNum,
                memberNumber: $scope.memberNumber,
                orgId: $scope.addOrgChooseVal,
                orgCode: $scope.orgCode,
                terminalNumbwe1: $scope.terminalNumbwe1,
                terminalNumbwe2: $scope.terminalNumbwe2,
                terminalNumbwe3: $scope.terminalNumbwe3,
                defaultFlag: parseInt($scope.channelDefaultFlag),
                thirdpayFlag: parseInt($scope.channelThirdpayFlag),
                currency: parseInt($scope.channelCurrency),
                status: parseInt($scope.channelStatus)
            },
            sysconfigV: {
                bankRequestUrl: $scope.bankRequestUrl,
                md5Password: $scope.md5Password,
                prikeyPassowrd: $scope.prikeyPassowrd,
                prikeyName: $scope.prikeyName,
                prikeySavetype: $scope.prikeySavetype,
                pubkeyName: $scope.pubkeyName,
                pubkeySavetype: $scope.pubkeySavetype,
                gatepayReturnPage:$scope.gatepayReturnPage,
                gatepayReturnUrl:$scope.gatepayReturnUrl
            },
            transconfigV: {
                signUpFlag: parseInt($scope.channelSignUpFlag),
                payFlag: parseInt($scope.channelPayFlag),
                withdrawFlag: parseInt($scope.channelWithdrawFlag),
                payFeeNum: $scope.payFeeNum,
                payFeeType: parseInt($scope.payFeeType),
                withdrawFeeNum: $scope.withdrawFeeNum,
                withdrawFeeType: parseInt($scope.withdrawFeeType)
            }
        };
        var json = {
            merchantFullV: merchantFullV
        };
        merchantManageAdd.unitAdd(json)
            .then(function (res) {
                if (res.code == '000000') {
                    $rootScope.tipService.setMessage(res.message, 'warning');
                    $scope.changeState('tabs.merchantManage');
                } else {
                    $rootScope.tipService.setMessage(res.message, 'warning');
                }
            }, function (error) {
                $rootScope.tipService.setMessage(error.message, 'warning');
            })

    }
}])
    .factory('merchantManageAdd', ['$http', 'localStorageService', 'myHttp', '$q', '$rootScope', function ($http, localStorageService, myHttp, $q, $rootScope) {
        return {
            unitAdd: function (json) {
                var deferred = $q.defer();
                $http({
                    method: "POST",
                    url: $rootScope.baseUrl + "exbank/create/bankmerchant/full",
                    data: json,
                    headers: {
                        'Content-Type': 'application/json;charset=UTF-8'
                    }
                }).success(function (res) {
                    deferred.resolve(res);
                }).error(function (res) {
                    deferred.reject(res);
                });
                return deferred.promise;
            },
            //银行通道
            bankChannel: function (json) {
                var deferred = $q.defer();
                myHttp.post("exbank/query/bankchannel/page", json)
                    .then(function (res) {
                        deferred.resolve(res);
                    }, function (res) {
                        deferred.reject(res);
                    });
                return deferred.promise;
            }
        }
    }]);