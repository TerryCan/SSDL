app.controller('TwodimensionalcodequeryCtrl', ['$scope', 'dataSer','$state', '$rootScope','TwodimensionalcodequeryCtrlSel','getPageNum','localStorageService','confirmService', function($scope, dataSer, $state, $rootScope,TwodimensionalcodequeryCtrlSel,getPageNum,localStorageService,confirmService) {
	//全部状态下所属机构
    dataSer.organizeQuerylistSer()
        .then(function(res) {
                $scope.meborgList = res;
        });

    $scope.getOrgVal = function(orgCode) {
        if($scope.meborgList){
        for (var i = 0; i < $scope.meborgList.length; i++) {
            if (orgCode == $scope.meborgList[i].orgCode) {
                return $scope.meborgList[i].text;
            }
            }
        }
    }
    //查询
    $scope.search = function(type) {
                if (type == 'search') {
                    pageInitialize()
                };
                TwodimensionalcodequeryCtrlSel.search($scope.showNum.showNum, $scope.currentPage)
                        .then(function(res) {
                            console.log(res)
                            if (res.code == '000000') {
                                $scope.showPage = true;
                                $scope.TwoResult = JSON.parse(res.content).content;
                                $scope.dataNum = JSON.parse(res.content).totalElements;
                                $scope.PageNum();
                                console.log($scope.TwoResult)
                            } else {
                                $rootScope.tipService.setMessage(res.message, 'warning');
                            }
                        }, function(error) {
                            $rootScope.tipService.setMessage(error.message, 'warning');
                        });
                }
            //单选
            $scope.chooseProId = null;
            $scope.checkedTab1 = function(index,orgQrcodeId) {
                $scope.chooseProId = $scope.TwoResult[index].orgQrcodeId;
                console.log($scope.chooseProId)
                $('#dataReport input[type=checkbox]').prop('checked', false);
                $('#dataReport input[type=checkbox]').eq(index).prop('checked', true);

            }

                //修改
            $scope.edit = function(url) {
                if ($scope.chooseProId == null) {
                    $rootScope.tipService.setMessage('请先选择自定义信息', 'warning');
                } else {
                    localStorageService.update('chooseTwochooseProId', $scope.chooseProId);
                    $state.go(url);
                }
            }
                    //删除
            $scope.delete = function() {
            if (!$scope.chooseProId) {
                $rootScope.tipService.setMessage('请先选择二维码信息', 'warning');
            } else {
                confirmService.set('确认提示', '确定要删除此二维码信息?', function() {
                    TwodimensionalcodequeryCtrlSel.Delete($scope.chooseProId)
                        .then(function(res) {
                            if (res.data.code == "000000") {
                            $rootScope.tipService.setMessage(res.data.message, 'warning');
                            $scope.search();
                            } else {
                                $rootScope.tipService.setMessage(res.data.message, 'warning');
                            }
                        }, function(error) {
                            $rootScope.tipService.setMessage(error.data.message, 'warning');
                        });
                    confirmService.clear();
                });
            }
        }

	/**
     * 分页功能实现TerryMin
     * **/
    $scope.showDataChoose = getPageNum.pageNum(); //获取分页
    $scope.showNum = $scope.showDataChoose[0]; //初始显示刷具条数

    $scope.showPage = false;
    var pageInitialize = function () {
        $scope.dataNum = 0; //数据总条数
        $scope.dataPage = 0; //分页数
        $scope.currentPage = 1; //当前页数
        $scope.jumpPageNum = '';
    };
    pageInitialize();
    // x/y $scope.dataPage
    $scope.PageNum = function () {
        if ($scope.showNum.showNum < $scope.dataNum) {
            $scope.dataPage =Math.ceil($scope.dataNum / $scope.showNum.showNum);
        } else {
            $scope.dataPage = 0;
        }
        if($scope.dataPage>1 && $scope.currentPage>0){
            if($scope.dataPage<$scope.currentPage){
                $scope.currentPage=1;
                $scope.search();
            }
        }
    };
    //上页下页 $scope.currentPage
    $scope.pageSlect = function (type) {
        if (type == 'prev') {
            if ($scope.currentPage != 1) {
                $scope.currentPage--;
                $scope.PageNum();
                $scope.search();
            }
        } else {
            if ($scope.currentPage < $scope.dataPage) {
                $scope.currentPage++;
                $scope.PageNum();
                $scope.search();
            }
        }
    };
    // 每页条数单元
    $scope.pageSelect = function (params) {
        $scope.showNum.showNum = params.showNum;
        pageInitialize();
        $scope.search();
    };
    //页数跳转 currentPage
    $scope.jumpPage = function (num) {
        num = parseInt(num);
        if (parseInt(num, 10) === num && num <= ($scope.dataPage + 1) && num > 0) {
            $scope.currentPage = num;
            $scope.PageNum();
            $scope.search();
        }
    };
    //页面跳转
    $scope.trunPage = function(url) {
            $state.go(url);
        }

}])
.factory('TwodimensionalcodequeryCtrlSel', ['$http', 'localStorageService', 'myHttp', '$q', '$rootScope', function($http, localStorageService, myHttp, $q, $rootScope) {
	return {
		    search: function(showNum, nowPage/*, title, searchUserStatesTab1*/) {
                var json = {
                    page: nowPage,
                    rows: showNum,
                    order: 'desc',
                    //sort:'createTime',
                    //search_A_LIKE_title: (title) ? title : '',
                    //search_A_EQ_state: (searchUserStatesTab1) ? searchUserStatesTab1 : ''
                }

                var deferred = $q.defer();
                myHttp.post("customize/org/qrcode/as/page", json)
                    .then(function(res) { // 调用承诺API获取数据 .resolve
                        deferred.resolve(res);
                    }, function(res) { // 处理错误 .reject
                        deferred.reject(res);
                    });
                return deferred.promise;
            },
            getTwooInfo: function(orgQrcodeId) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'customize/org/qrcode/get',
                    data: {
                        "qrcodeId": orgQrcodeId
                    }
                }).then(function successCallback(response) {
                    console.log(response)
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
            Delete: function(orgQrcodeId) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'customize/org/qrcode/delete',
                    data: {
                        "qrcodeId": orgQrcodeId
                    }
                }).then(function successCallback(response) {
                    console.log(response)
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
	}
}])