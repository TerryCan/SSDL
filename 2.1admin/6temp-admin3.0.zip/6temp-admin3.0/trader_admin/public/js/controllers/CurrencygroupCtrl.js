app.controller('CurrencygroupCtrl', ['$rootScope', '$scope', 'getPageNum', 'CurrencygroupCtrllSer', 'getClassificationState', 'dataSer', 'localStorageService', 'confirmService','$timeout','getadminState', function ($rootScope, $scope, getPageNum, CurrencygroupCtrllSer, getClassificationState, dataSer, localStorageService, confirmService,$timeout,getadminState) {
    $scope.toggleTraderSearchState = false;
    $scope.Toggle = function () {
        $scope.toggleTraderSearchState = !$scope.toggleTraderSearchState;
        if ($scope.toggleTraderSearchState) {
            $('.search_column').css('height', 'auto');
        }
        else {
            $('.search_column').css('height', '36px');
        }
    };
    $scope.currencyzu='';
    $scope.ToState='';
    localStorageService.clear('userIdChecked');
    $scope.tableshow = false;
    $scope.search = function (type) {
        $scope.toggleTraderSearchState = false;
        $('.search_column').css('height', '36px');
        if (type == 'search') {
            pageInitialize()
        };
        $scope.orgCode=localStorageService.get('oldOrgCode');
        var json = {
            page: $scope.currentPage,
            rows: $scope.showNum.showNum,
            orders: 'asc',
            search_EQ_orgCode: ($scope.orgCode) ?  $scope.orgCode : '',
            search_EQ_state: $scope.ToState,
            search_LIKE_currencyGroupName: $scope.currencyzu,

        };
        CurrencygroupCtrllSer.search(json)
            .then(function (res) {
                console.log(res)
                if (res.code == '000000') {
                    $scope.showPage = true;
                    var data = JSON.parse(res.content);
                    $scope.searchResult = data.content;
                    console.log($scope.searchResult);
                    $scope.dataNum = data.totalElements;
                    $scope.PageNum();

                    var checkedUserId=localStorageService.get('userIdChecked'); //获取上一次存储的id
                    $scope.switchUserId(checkedUserId,$scope.searchResult); //执行选中方法
                } else {
                    $rootScope.tipService.setMessage(res.message, 'warning');
                }
            }, function (error) {
                $rootScope.tipService.setMessage(error.message, 'warning');
            });
    }

    dataSer.organizeQuerySer()
        .then(function (res) {
            $scope.orgList = res;
            console.log($scope.orgList)
        });

    $scope.addOrgValFTC = function (data) {
        console.log(data);
        $scope.orgId = data.orgId;
        $scope.orgCode = data.orgCode;
        $scope.addOrgVal = data.text;
    }
    //全部状态下所属机构
    dataSer.organizeQuerylistSer()
        .then(function (res) {
            $scope.orgAllList = res;
        });

    $scope.adjustText = function (orgId) {
        if ($scope.orgAllList) {
            for (var i = 0, r = $scope.orgAllList.length; i < r; i++) {
                if ($scope.orgAllList[i].orgId == orgId) {
                    return $scope.orgAllList[i].text;
                }
            }
        }
    }
    /**
     * 分页功能实现TerryMin
     * **/
    $scope.showDataChoose = getPageNum.pageNum(); //获取分页
    $scope.showNum = $scope.showDataChoose[0]; //初始显示刷具条数
    $scope.showPage = false;
    var pageInitialize = function () {
        $scope.dataNum = 0; //数据总条数
        $scope.dataPage = 0; //分页数
        $scope.currentPage = 1; //当前页数
        $scope.jumpPageNum = '';
    };
    pageInitialize();

    // x/y $scope.dataPage
    $scope.PageNum = function () {
        $scope.showPage = true;
        if ($scope.showNum.showNum < $scope.dataNum) {
            $scope.dataPage =Math.ceil($scope.dataNum / $scope.showNum.showNum);
        } else {
            $scope.dataPage = 0;
        }
    };
    //上页下页 $scope.currentPage
    $scope.pageSlect = function (type) {
        if (type == 'prev') {
            if ($scope.currentPage != 1) {
                $scope.currentPage--;
                $scope.PageNum();
                $scope.search();
            }
        } else {
            if ($scope.currentPage < $scope.dataPage) {
                $scope.currentPage++;
                $scope.PageNum();
                $scope.search();
            }
        }
    };
    // 每页条数单元
    $scope.pageSelect = function (params) {
        $scope.showNum.showNum = params.showNum;
        pageInitialize();
        $scope.search();
    };
    //页数跳转 currentPage
    $scope.jumpPage = function (num) {
        num = parseInt(num);
        if (parseInt(num, 10) === num && num <= ($scope.dataPage + 1) && num > 0) {
            $scope.currentPage = num;
            $scope.PageNum();
            $scope.search();
        }
    };

    $scope.orgId = '';
    $scope.orgCode = '';
    $scope.state = '';
    $scope.hideRoleaut=true;
    $scope.showRoleaut=true;
    // 选择
    $scope.checkedTab1 = function (index,applyId,currencyGroupId,orgId,orgCode,currencyGroupName,state){
        $scope.chooseUserData={
            applyId:applyId,
            currencyGroupId: currencyGroupId,
            orgId: orgId,
            orgCode:orgCode,
            currencyGroupName:currencyGroupName,
            state: state,
        };
        console.log($scope.chooseUserData)
        var userIdChecked = localStorageService.get('userIdChecked');
        $('#dataReport input[type=checkbox]').prop('checked', false);
        if (currencyGroupId == userIdChecked) {
            localStorageService.clear('userIdChecked');
            $scope.chooseItemTab1 = '';
            $scope.applyId = '';
            $scope.state= '';
        } else {
            $('#dataReport input[type=checkbox]').eq(index).prop('checked', true);
            localStorageService.update('userIdChecked', currencyGroupId);
            $scope.chooseItemTab1 = currencyGroupId;
            $scope.applyId= applyId;
            $scope.state= state;
        }
        if ($scope.chooseUserData.applyId != null) {
            console.log($scope.chooseUserData.applyId)
            $scope.hideRoleaut=false;
            $scope.showRoleaut=false;
        }else{
            $scope.showRoleaut=true;
            $scope.hideRoleaut=true;
        };
    };
    // 存储选中
    $scope.switchUserId = function (parameter, responseData) {
        $timeout(function () {
            for (var i = 0; i < responseData.length; i++) {
                if (parameter == responseData[i].currencyGroupId) {
                    $('#dataReport input[type=checkbox]').eq(i).prop('checked', true);
                    return;
                }
            }
        }, 1500)
    };
    $scope.allotTypeData=getadminState;
    $scope.allotTypeText = function(val) {
        for (var i = 0, r = $scope.allotTypeData.length; i < r; i++) {
            if (val == $scope.allotTypeData[i].id) {
                return $scope.allotTypeData[i].name;
            }
        }
    }
    $scope.add = function () {
        $scope.tableshow = true;
        $scope.addEditText = '新增';
        $scope.addOrgVal = "";
        $scope.currencyGroupName="";
    }

    $scope.edit = function () {
        if (!$scope.chooseItemTab1) {
            $rootScope.tipService.setMessage('请先申请变更', 'warning');
        } else {
            $scope.addEditText = '申请变更';
            $scope.tableshow = true;
            $scope.currencyGroupId=$scope.chooseUserData.currencyGroupId;
            $scope.currencyGroupName = $scope.chooseUserData.currencyGroupName;
            $scope.orgId = $scope.chooseUserData.orgId;
            $scope.orgCode = $scope.chooseUserData.orgCode;
            console.log($scope.orgId)
            //匹配机构代码
            var json = {
                page: 1,
                rows: 9999,
                search_A_EQ_state: 1
            };
            dataSer.getOrganize(json).then(function (res) {
                if (res.code == '000000') {
                    $scope.equalOrgCode = JSON.parse(res.content).content;
                    //console.log($scope.equalOrgCode);
                    for (var i = 0; i < $scope.equalOrgCode.length; i++) {
                        if ($scope.chooseUserData.orgId == $scope.equalOrgCode[i].orgId) {
                            $scope.addOrgVal = $scope.equalOrgCode[i].orgName + '(' + $scope.equalOrgCode[i].orgNum + ')';
                            //console.log($scope.addOrgVal)
                        }
                    }
                } else {
                    console.log(res);
                }
            });
        }
    }
    $scope.addSubmit = function () {
        if ($scope.addEditText == "新增") {
            var configCurrencyGroupVIce = {
                orgId: $scope.orgId,
                orgCode: $scope.orgCode,
                currencyGroupName:$scope.currencyGroupName,
            }
            var json = {
                configCurrencyGroupVIce: configCurrencyGroupVIce
            }
            CurrencygroupCtrllSer.Addsub(json)
                .then(function (res) {
                        if (res.data.code == "000000") {
                            $scope.tableshow = false;
                            $rootScope.tipService.setMessage(res.data.message, 'warning');
                            localStorageService.clear('userIdChecked');
                            $scope.search();
                        }else{
                            $rootScope.tipService.setMessage(res.data.message, 'warning');
                        }
                    },function(error){
                        $rootScope.tipService.setMessage(error.data.message, 'warning');
                    }
                )
        } else if ($scope.addEditText == "申请变更") {
            var configCurrencyGroupVIce = {
                orgId: $scope.orgId,
                orgCode: $scope.orgCode,
                currencyGroupId:$scope.chooseItemTab1,
                currencyGroupName:$scope.currencyGroupName,
            }
            var json = {
                configCurrencyGroupVIce: configCurrencyGroupVIce
            }
            CurrencygroupCtrllSer.editsub(json)
                .then(function (res) {
                    if (res.data.code == "000000") {
                        $scope.tableshow = false;
                        $rootScope.tipService.setMessage(res.data.message, 'warning');
                        localStorageService.clear('userIdChecked');
                        $scope.search();
                    }
                    else {
                        $rootScope.tipService.setMessage(res.data.message, 'warning');
                    }
                },function(error){
                    $rootScope.tipService.setMessage(error.data.message, 'warning')
                })
        }
    }

    $scope.audit=function () {
        if (!$scope.applyId) {
            $rootScope.tipService.setMessage('请先审核变更', 'warning');
        } else {
            var json={
                applyId:$scope.applyId
            }
            CurrencygroupCtrllSer.get(json)
                .then(function(res){
                    console.log(res)
                    if(res.data.code=="000000"){
                        var getData=JSON.parse(res.data.content);
                        $scope.getDatalist=getData.configCurrencyGroupV;
                        console.log($scope.getDatalist)
                        $scope.addEditText = "审核品种变更";
                        $scope.tableshowxq = true;
                        $scope.commodityId=$scope.getDatalist.commodityId;
                        $scope.currencyGroupId=$scope.getDatalist.currencyGroupId;
                        $scope.currencyGroupName=$scope.getDatalist.currencyGroupName;
                        $scope.orgId=$scope.getDatalist.orgId;
                        console.log($scope.orgId)
                        //匹配机构代码
                        var json = {
                            page: 1,
                            rows: 9999,
                            search_A_EQ_state: 1
                        };
                        dataSer.getOrganize(json).then(function (res) {
                            if (res.code == '000000') {
                                $scope.equalOrgCode = JSON.parse(res.content).content;
                                //console.log($scope.equalOrgCode);
                                for (var i = 0; i < $scope.equalOrgCode.length; i++) {
                                    if ($scope.orgId == $scope.equalOrgCode[i].orgId) {
                                        $scope.addOrgVal = $scope.equalOrgCode[i].orgName + '(' + $scope.equalOrgCode[i].orgNum + ')';
                                        //console.log($scope.addOrgVal)
                                    }
                                }
                            } else {
                                console.log(res);
                            }
                        });
                    }
                })

        }
    }

    $scope.RoletrueData = function (tmpOpt) {
        var json = {
            applyId: $scope.applyId,
            auditRs: tmpOpt
        };
        CurrencygroupCtrllSer.Roletruetion(json)
            .then(function (res) {
                if (res.data.code == '000000') {
                    $scope.tableshowxq = false;
                    localStorageService.clear('userIdChecked');
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                    $scope.search();
                } else {
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                }
            },function(error) {
                $rootScope.tipService.setMessage(error.data.message, 'warning');
            })
    }
    $scope.RolefalseData = function (tmpOpt) {
        var json = {
            applyId: $scope.applyId,
            auditRs: tmpOpt
        };
        CurrencygroupCtrllSer.Roletruetion(json)
            .then(function (res) {
                if (res.data.code == '000000') {
                    $scope.tableshowxq = false;
                    localStorageService.clear('userIdChecked');
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                    $scope.search();
                } else {
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                }
            },function(error) {
                $rootScope.tipService.setMessage(error.data.message, 'warning');
            })
    }


    $scope.pass=function() {
        if (!$scope.chooseItemTab1) {
            $rootScope.tipService.setMessage('请先选择币种组信息', 'warning');
        } else {
                var json={
                    currencyGroupId:$scope.chooseItemTab1
                }
                CurrencygroupCtrllSer.passCheck(json)
                    .then(function (res) {
                        if (res.data.code == '000000') {
                            localStorageService.clear('userIdChecked');
                            $rootScope.tipService.setMessage(res.data.message, 'warning');
                            $scope.search();
                        } else {
                            $rootScope.tipService.setMessage(res.data.message, 'warning');
                        }
                    }, function (error) {
                        $rootScope.tipService.setMessage(error.data.message, 'warning');
                    });
        }
    }
    $scope.fail=function() {
        if (!$scope.chooseItemTab1) {
            $rootScope.tipService.setMessage('请先选择币种组信息', 'warning');
        } else {
            var json={
                currencyGroupId:$scope.chooseItemTab1
            }
            CurrencygroupCtrllSer.failedCheck(json)
                .then(function (res) {
                    if (res.data.code == '000000') {
                        localStorageService.clear('userIdChecked');
                        $rootScope.tipService.setMessage(res.data.message, 'warning');
                        $scope.search();
                    } else {
                        $rootScope.tipService.setMessage(res.data.message, 'warning');
                    }
                }, function (error) {
                    $rootScope.tipService.setMessage(error.data.message, 'warning');
                });
        }
    }
    $scope.open=function() {
        if (!$scope.chooseItemTab1) {
            $rootScope.tipService.setMessage('请先选择币种组信息', 'warning');
        } else {
            var json={
                currencyGroupId:$scope.chooseItemTab1
            }
            CurrencygroupCtrllSer.open(json)
                .then(function (res) {
                    if (res.data.code == '000000') {
                        localStorageService.clear('userIdChecked');
                        $rootScope.tipService.setMessage(res.data.message, 'warning');
                        $scope.search();
                    } else {
                        $rootScope.tipService.setMessage(res.data.message, 'warning');
                    }
                }, function (error) {
                    $rootScope.tipService.setMessage(error.data.message, 'warning');
                });
        }
    }

    $scope.close=function() {
        if (!$scope.chooseItemTab1) {
            $rootScope.tipService.setMessage('请先选择币种组信息', 'warning');
        } else {
            confirmService.set('确认提示', '确定要销毁此币种组?', function () {
                var json={
                    currencyGroupId:$scope.chooseItemTab1
                }
                CurrencygroupCtrllSer.Close(json)
                    .then(function (res) {
                        if (res.data.code == '000000') {
                            localStorageService.clear('userIdChecked');
                            $rootScope.tipService.setMessage(res.data.message, 'warning');
                            $scope.search();
                        } else {
                            $rootScope.tipService.setMessage(res.data.message, 'warning');
                        }
                    }, function (error) {
                        $rootScope.tipService.setMessage(error.data.message, 'warning');
                    });
                confirmService.clear();
            });
        }
    }
}])
    .factory('CurrencygroupCtrllSer', ['$http', 'localStorageService', 'myHttp', '$q', '$rootScope', function ($http, localStorageService, myHttp, $q, $rootScope) {
        return {
            //查询
            search: function (json) {
                var deferred = $q.defer();
                myHttp.post("admin/config/currency/group/query/page", json)
                    .then(function (res) { // 调用承诺API获取数据 .resolve
                        deferred.resolve(res);
                    }, function (res) { // 处理错误 .reject
                        deferred.reject(res);
                    });
                return deferred.promise;
            },
            //查询列表
            searchlist: function () {
                var deferred = $q.defer();
                myHttp.post("admin/config/currency/query/list")
                    .then(function (res) { // 调用承诺API获取数据 .resolve
                        deferred.resolve(res);
                    }, function (res) { // 处理错误 .reject
                        deferred.reject(res);
                    });
                return deferred.promise;
            },

            Close: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'admin/config/currency/group/close',
                    data: json
                }).then(function successCallback(response) {
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
            Addsub: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'admin/config/currency/group/create',
                    data: json
                }).then(function successCallback(response) {
                    console.log(response)
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
            editsub: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'admin/config/currency/group/apply',
                    data: json
                }).then(function successCallback(response) {
                    console.log(response)
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
            //获取
            get: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'admin/config/currency/group/apply/get',
                    data: json
                }).then(function successCallback(response) {
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
            //变更
            Roletruetion: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'admin/config/currency/group/audit',
                    data: json
                }).then(function successCallback(response) {
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
            //通过
            passCheck: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'admin/config/currency/group/pass',
                    data: json
                }).then(function successCallback(response) {
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
            //不通过
            failedCheck: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'admin/config/currency/group/fail',
                    data: json
                }).then(function successCallback(response) {
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
            //重新提交
            open: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'admin/config/currency/group/open',
                    data: json
                }).then(function successCallback(response) {
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            }

        }
    }])