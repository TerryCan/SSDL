app.controller('EntrustedstatisticsCtrl', ['$rootScope', '$scope', 'EntrustedstatisticsCtrlSel', 'localStorageService', 'timestamp', function ($rootScope, $scope, EntrustedstatisticsCtrlSel, localStorageService, timestamp) {
    $scope.toggleTraderSearchState = false;
    $scope.Toggle = function () {
        $scope.toggleTraderSearchState = !$scope.toggleTraderSearchState;
        if ($scope.toggleTraderSearchState) {
            $('.search_column').css('height', 'auto');
        }
        else {
            $('.search_column').css('height', '36px');
        }
    };
    //查询
    $scope.createTimeStart = '';
    $scope.createTimeEnd = '';
    $scope.search = function () {
        $scope.toggleTraderSearchState = false;
        $('.search_column').css('height', '36px');
        var sumParamsIce = {
            userId: $scope.directiveUserId,
            orgCode: ($scope.upOrgCode) ? $scope.upOrgCode : '',
            createTimeS: ($scope.createTimeStart) ? ($scope.createTimeStart.split(' ')[0] + "T" + $scope.createTimeStart.split(' ')[1]) : '',
            createTimeE: ($scope.createTimeEnd) ? ($scope.createTimeEnd.split(' ')[0] + "T" + $scope.createTimeEnd.split(' ')[1]) : ''
        };
        var json = {
            sumParamsIce: sumParamsIce
        };
        EntrustedstatisticsCtrlSel.search(json).then(function (res) {
            if (res.data.code == '000000') {
                $scope.searchResult = JSON.parse(res.data.content);
                console.log($scope.searchResult);

                var sumResult={
                    productName:'总计',
                    productCode:'',
                    buy:0,
                    sell:0,
                    total:0,
                    limit:0,
                    cancel:0
                };
                for(var i=0;i<$scope.searchResult.length;i++){
                    sumResult.buy+=$scope.searchResult[i].buy;
                    sumResult.sell+=$scope.searchResult[i].sell;
                    sumResult.total+=$scope.searchResult[i].total;
                    sumResult.limit+=$scope.searchResult[i].limit;
                    sumResult.cancel+=$scope.searchResult[i].cancel;
                }
                $scope.searchResult.push(sumResult);
                var source = {
                    localdata: $scope.searchResult,
                    datatype: "array",
                    datafields: [
                        {name: 'productName', type: 'string'},
                        {name: 'productCode', type: 'string'},
                        {name: 'buy', type: 'string'},
                        {name: 'sell', type: 'string'},
                        {name: 'total', type: 'string'},
                        {name: 'limit', type: 'string'},

                        {name: 'cancel', type: 'string'}
                    ]
                };
                var dataAdapter = new $.jqx.dataAdapter(source);
                $("#entrustDetailGrid").jqxGrid(
                    {
                        width: 100 + '%',
                        height: 87 + '%',
                        theme: 'metrodark',
                        source: dataAdapter,//数据源
                        columnsresize: true,
                        selectionmode: 'singlecell',
                        clipboard: true,
                        columns: [  //表格数据域
                            {
                                text: '商品名',
                                datafield: 'productName',
                                minwidth: 13 + '%',
                                cellsalign: 'center',
                                align: 'center',
                                width: '13%'
                            },
                            {
                                text: '商品代码',
                                datafield: 'productCode',
                                minwidth: 13 + '%',
                                align: 'center',
                                width: '13%'
                            },
                            {
                                text: '委托买',
                                datafield: 'buy',
                                minwidth: 13 + '%',
                                cellsalign: 'center',
                                align: 'center',
                                width: '13%'
                            },
                            {
                                text: '委托卖',
                                datafield: 'sell',
                                minwidth: 13 + '%',
                                width: '13%',
                                align: 'center'
                            },
                            {
                                text: '委托合计',
                                datafield: 'total',
                                minwidth: 13 + '%',
                                cellsalign: 'center',
                                align: 'center',
                                width: '13%'
                            },
                            {
                                text: '挂单合计',
                                datafield: 'limit',
                                minwidth: 13 + '%',
                                align: 'center',
                                width: '13%',
                                cellsalign: 'center',
                            },
                            {
                                text: '撤单合计',
                                datafield: 'cancel',
                                minwidth: 22 + '%',
                                align: 'center',
                                cellsalign: 'center',
                                width: '22%'
                            }
                        ]
                    });

            } else {
                $rootScope.tipService.setMessage(res.data.message, 'warning');
            }
        }, function (error) {
            $rootScope.tipService.setMessage(error.data.message, 'warning');
        });
    };

}])
    .factory('EntrustedstatisticsCtrlSel', ['$http', 'localStorageService', 'myHttp', '$q', '$rootScope', function ($http, localStorageService, myHttp, $q, $rootScope) {
        return {
            search: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'admin/trade/order/sum',
                    data: json
                }).then(function (res) { // 调用承诺API获取数据 .resolve
                    deferred.resolve(res);
                }, function (res) { // 处理错误 .reject
                    deferred.reject(res);
                });
                return deferred.promise;
            }
        }
    }])