app.controller('PersonalizedOrganizationCtrl', ['$scope', '$state', '$rootScope', 'localStorageService', 'PersonalizedOrganizationCtrlSer', 'getPageNum', 'confirmService', 'timestamp', 'memberMangerCtrlSer', 'dataSer', function($scope, $state, $rootScope, localStorageService, PersonalizedOrganizationCtrlSer, getPageNum, confirmService, timestamp, memberMangerCtrlSer, dataSer) {
		$scope.toggleTraderSearchState = false;
		$scope.Toggle = function() {
			$scope.toggleTraderSearchState = !$scope.toggleTraderSearchState;
			if ($scope.toggleTraderSearchState) {
				$('.search_column').css('height', 'auto');
			} else {
				$('.search_column').css('height', '36px');
			}
		};
		//页面跳转
		$scope.trunPage = function(url) {
				$state.go(url);
			}
			//全部状态下所属机构
		dataSer.organizeQuerylistSer()
			.then(function(res) {
				$scope.meborgList = res;
				console.log($scope.orgList)
			});

		$scope.getOrgVal = function(orgCode) {
			if ($scope.meborgList) {
				console.log($scope.meborgList)
				for (var i = 0; i < $scope.meborgList.length; i++) {
					if (orgCode == $scope.meborgList[i].orgCode) {
						return $scope.meborgList[i].text;
					}
				}
			}
		}

		$scope.ddrangaa = 1;
		$scope.ddrangcc = function(num) {
			$scope.ddrangaa = num;
			console.log($scope.ddrangaa)
		}

		//全部
		$scope.search = function(type, num) {
		 	$scope.toggleTraderSearchState=false;
			$('.search_column').css('height', '36px');
			if (type == 'search') {
				pageInitialize()
			};
			if ($scope.ddrangaa == 1) {
				PersonalizedOrganizationCtrlSer.OrgAllsearch($scope.showNum.showNum, $scope.currentPage)
					.then(function(res) {
						console.log(res)
						if (res.code == '000000') {
							$scope.showPage = true;
							$scope.PersonalizedResult = JSON.parse(res.content).content;
							$scope.dataNum = JSON.parse(res.content).totalElements;
							$scope.PageNum();
							console.log($scope.dataNum)
						} else {
							$rootScope.tipService.setMessage(res.message, 'warning');
						}
					}, function(error) {
						$rootScope.tipService.setMessage(error.message, 'warning');
					});
			} else if ($scope.ddrangaa == 2) {
				PersonalizedOrganizationCtrlSer.Orgsearch($scope.showNum.showNum, $scope.currentPage)
					.then(function(res) {
						console.log(res)
						if (res.code == '000000') {
							console.log(111)
							$scope.showPage = true;
							$scope.PersonalizedResult = JSON.parse(res.content).content;
							$scope.dataNum = JSON.parse(res.content).totalElements;
							$scope.PageNum();
						} else {
							$rootScope.tipService.setMessage(res.message, 'warning');
						}
					}, function(error) {
						$rootScope.tipService.setMessage(error.message, 'warning');
					});
			}
		}

		//时间戳
		$scope.timestamp = function(stamp) {
				return timestamp.timestampCoverHms(stamp, 'all')
			}
			//单选
		$scope.orgCustomizeId = null;
		$scope.checkedTab1 = function(index, orgCustomizeId) {
			$scope.orgCustomizeId = orgCustomizeId;
			$scope.orgCustomizeId = $scope.PersonalizedResult[index].orgCustomizeId;
			$('#dataReport input[type=checkbox]').prop('checked', false);
			$('#dataReport input[type=checkbox]').eq(index).prop('checked', true);
			console.log($scope.orgCustomizeId)
		}


		//删除
		$scope.delete = function() {
			if (!$scope.orgCustomizeId) {
				$rootScope.tipService.setMessage('请先选择自定义信息', 'warning');
			} else {
				confirmService.set('确认提示', '确定要删除此自定义信息?', function() {
					PersonalizedOrganizationCtrlSer.Delete($scope.orgCustomizeId)
						.then(function(res) {
							if (res.data.code == "000000") {
								$rootScope.tipService.setMessage(res.data.message, 'warning');
								$scope.search();
							} else {
								$rootScope.tipService.setMessage(res.data.message, 'warning');
							}
						}, function(error) {
							$rootScope.tipService.setMessage(error.data.message, 'warning');
						});
					confirmService.clear();
				});
			}
		}

		//修改
		$scope.edit = function(url) {
			if ($scope.orgCustomizeId == null) {
				$rootScope.tipService.setMessage('请先选择自定义信息', 'warning');
			} else {
				localStorageService.update('choosePersonalized', $scope.orgCustomizeId);
				$state.go(url);
			}
		}



		/* 分页功能实现 */
		var pageInitialize = function() {
			$scope.dataNum = 0; //数据总条数
			$scope.dataPage = 0; //分页数
			$scope.currentPage = 1; //当前页数
			$scope.jumpPageNum = '';
		}
		$scope.showDataChoose = getPageNum.pageNum(); //获取分页
		$scope.showNum = $scope.showDataChoose[0]; //初始显示刷具条数
		$scope.dataPageNumber = []; //生成页面数
		$scope.showPage = false;
		$scope.pageSelect = function(params) {
			console.log(params);
			$scope.showNum.showNum = params.showNum;
			pageInitialize();
			$scope.search();
		}
		$scope.changePageNumber = function(params) {
			$scope.currentPage = params;
			$scope.search();
			$scope.PageNum();
		}
		$scope.PageNum = function() {
			if ($scope.showNum.showNum < $scope.dataNum) {
				$scope.dataPage = parseInt($scope.dataNum / $scope.showNum.showNum) + 1;
			} else {
				$scope.dataPage = 0;
			}
			$scope.dataPageNumber = [];
			for (var i = 0; i < $scope.dataPage; i++) {
				$scope.dataPageNumber.push(i + 1);
			}
		}
		$scope.jumpPage = function(num) {
			num = parseInt(num);
			if (parseInt(num, 10) === num && num <= ($scope.dataPage + 1) && num > 0) {
				$scope.currentPage = num;
				$scope.PageNum();
				$scope.search();
			}
		}
		$scope.pageSlect = function(type) {
			if (type == 'prev') {
				if ($scope.currentPage != 1) {
					$scope.currentPage--;
					$scope.PageNum();
					$scope.search();
				}
			} else {
				if ($scope.currentPage < $scope.dataPage) {
					$scope.currentPage++;
					$scope.PageNum();
					$scope.search();
				}
			}
		}
		pageInitialize();
		//$scope.search();
	}])
	.factory('PersonalizedOrganizationCtrlSer', ['$http', 'localStorageService', 'myHttp', '$q', '$rootScope', function($http, localStorageService, myHttp, $q, $rootScope) {
		return {
			//全部
			OrgAllsearch: function(showNum, nowPage /*, title, searchUserStatesTab1*/ ) {
				var json = {
					page: nowPage,
					rows: showNum,
					order: 'desc',
					sort: 'createTime',
					//search_A_LIKE_title: (title) ? title : '',
					//search_A_EQ_state: (searchUserStatesTab1) ? searchUserStatesTab1 : ''
				}

				var deferred = $q.defer();
				myHttp.post("customize/org/customized/query/all", json)
					.then(function(res) { // 调用承诺API获取数据 .resolve
						deferred.resolve(res);
					}, function(res) { // 处理错误 .reject
						deferred.reject(res);
					});
				return deferred.promise;
			},
			Orgsearch: function(showNum, nowPage) {
				var json = {
					page: nowPage,
					rows: showNum,
					order: 'desc',
					sort: 'createTime',
					//search_A_LIKE_title: (title) ? title : '',
					//search_A_EQ_state: (searchUserStatesTab1) ? searchUserStatesTab1 : ''
				}

				var deferred = $q.defer();
				myHttp.post("customize/org/customized/query", json)
					.then(function(res) { // 调用承诺API获取数据 .resolve
						deferred.resolve(res);
					}, function(res) { // 处理错误 .reject
						deferred.reject(res);
					});
				return deferred.promise;
			},

			Delete: function(orgCustomizeId) {
				var deferred = $q.defer();
				$http({
					method: 'POST',
					url: $rootScope.baseUrl + 'customize/org/customized/del',
					data: {
						orgCustomizeId: orgCustomizeId
					}
				}).then(function successCallback(response) {
					deferred.resolve(response);
				}, function errorCallback(response) {
					deferred.reject(response);
				});
				return deferred.promise;
			},
			getNTInfo: function(orgCustomizeId) {
				var json = {
					orgCustomizeId: orgCustomizeId
				}
				var deferred = $q.defer();
				$http({
					method: 'POST',
					url: $rootScope.baseUrl + 'customize/org/customized/detail/get',
					data: json
				}).then(function successCallback(response) {
					console.log(response)
					deferred.resolve(response);
				}, function errorCallback(response) {
					deferred.reject(response);
				});
				return deferred.promise;
			}
		}
	}])