app.controller("memberManageEditCtrl", function ($scope, $state, $rootScope, tipService, confirmService, getUserStates, dataSer, timestamp, memberMangerCtrlSer, localStorageService, $timeout,getSex) {
    $scope.typeName = '机构角色';
    $scope.orgId = null;
    $scope.orgListDisplay = false;
    $scope.orgExtendToggle = false;
    $scope.contactUserToggle = false;

    //获取机构信息 memberEditOrgId
    var memberEditOrgId = localStorageService.get('userIdChecked');
    console.log(memberEditOrgId);
    memberMangerCtrlSer.getOrganizeData(memberEditOrgId)
        .then(function (res) {
            if (res.data.code == '000000') {
                var data = JSON.parse(res.data.content);
                $scope.memberEditData = data.contacts;
                console.log(data);
                $scope.orgName = data.orgName;
                $scope.orgCode = data.orgCode;
                $scope.orgNum = data.orgNum;
                $scope.superOrgCode = (data.superOrganize == null) ? '' : data.superOrganize.orgCode;
                $scope.superOrgName = (data.superOrganize == null) ? '' : data.superOrganize.orgName;
                $scope.state = data.state;
                //机构实名信息 OrgRealInfo
                $scope.natureOrgRealInfo = data.realInfo.nature;//企业性质
                $scope.corporateNameOrgRealInfo = data.realInfo.corporateName;//法人名称
                $scope.corporateCertificateTypeOrgRealInfo = data.realInfo.corporateCertificateType;//法人证件类型
                $scope.corporateCertificateNoOrgRealInfo = data.realInfo.corporateCertificateNo;//法人证件号
                $scope.ccpFIdOrgRealInfo = data.realInfo.ccpFId;//正面
                $scope.ccbFIdOrgRealInfo = data.realInfo.ccbFId;//背面
                $scope.cchFIdOrgRealInfo = data.realInfo.cchFId;//手持
                $scope.licenseFIdOrgRealInfo = data.realInfo.licenseFId;//营业执照附件编号
                $scope.licenseOrgRealInfo = data.realInfo.license;//营业执照
                $scope.codeFIdOrgRealInfo = data.realInfo.codeFId;//组织机构代码证附件编号
                $scope.codeOrgRealInfo = data.realInfo.code;//组织机构代码证
                $scope.creditCodeFIdOrgRealInfo = data.realInfo.creditCodeFId;//机构信用代码证附件编号
                $scope.creditCodeOrgRealInfo = data.realInfo.creditCode;//机构信用代码证
                $scope.openingFIdOrgRealInfo = data.realInfo.openingFId;//开户许可证附件编号
                $scope.openingOrgRealInfo = data.realInfo.opening;//开户许可证
                $scope.taxFIdOrgRealInfo = data.realInfo.taxFId;//税务证附件编号
                $scope.taxOrgRealInfo = data.realInfo.tax;//税务证
                $scope.otherFIdOrgRealInfo = data.realInfo.otherFId;//其他证附件编号
                $scope.otherOrgRealInfo = data.realInfo.other;//其他证

                //机构超级管理员信息
                $scope.userSecurityEmail = (data.userSecurity.email.split("@")[0].split("").length<3)?"***@"+data.userSecurity.email.split("@")[1]:data.userSecurity.email.slice(0,3)+"***@"+data.userSecurity.email.split("@")[1];;
                $scope.userSecurityLoginName = data.userSecurity.loginName;
                $scope.userSecurityPhone = data.userSecurity.phone.slice(0,3)+"***"+data.userSecurity.phone.slice(7,11);

                //机构扩展信息
                if(data.info){
                    $scope.area = data.info.area;//区域
                    $scope.briefIntroduction = data.info.briefIntroduction;//公司简介
                    $scope.businessScope = data.info.businessScope;//经营范围
                    $scope.city = data.info.city;//城市
                    $scope.country = data.info.country;//国家
                    $scope.industry = data.info.industry;//行业
                    $scope.netWorth = data.info.netWorth;//净资产
                    $scope.property = data.info.property;//机构性质
                    $scope.provinces = data.info.provinces;//省份
                    $scope.registeredCapital = data.info.registeredCapital;//注册资金
                    $scope.websiteAddress = data.info.websiteAddress;//公司网址
                }
                //联系人信息
                $scope.isChooseCountry();
                $scope.isChooseProvinces();
                $scope.isChooseCity();
                if ($scope.natureOrgRealInfo == 1) {
                    $('#uploadImg1').attr('src', "" + $rootScope.baseUrl + "/file/download?fileId=" + $scope.ccpFIdOrgRealInfo + "");
                    $('#uploadImg2').attr('src', "" + $rootScope.baseUrl + "/file/download?fileId=" + $scope.ccbFIdOrgRealInfo + "");
                    $('#uploadImg3').attr('src', "" + $rootScope.baseUrl + "/file/download?fileId=" + $scope.cchFIdOrgRealInfo + "");

                    $('#uploadImg9').attr('src', "" + $rootScope.baseUrl + "/file/download?fileId=" + $scope.otherOrgRealInfo + "");
                } else {
                    $('#uploadImg1').attr('src', "" + $rootScope.baseUrl + "/file/download?fileId=" + $scope.ccpFIdOrgRealInfo + "");
                    $('#uploadImg2').attr('src', "" + $rootScope.baseUrl + "/file/download?fileId=" + $scope.ccbFIdOrgRealInfo + "");
                    $('#uploadImg3').attr('src', "" + $rootScope.baseUrl + "/file/download?fileId=" + $scope.cchFIdOrgRealInfo + "");

                    $('#uploadImg4').attr('src', "" + $rootScope.baseUrl + "/file/download?fileId=" + $scope.licenseOrgRealInfo + "");
                    $('#uploadImg5').attr('src', "" + $rootScope.baseUrl + "/file/download?fileId=" + $scope.codeOrgRealInfo + "");
                    $('#uploadImg6').attr('src', "" + $rootScope.baseUrl + "/file/download?fileId=" + $scope.creditCodeOrgRealInfo + "");
                    $('#uploadImg7').attr('src', "" + $rootScope.baseUrl + "/file/download?fileId=" + $scope.openingOrgRealInfo + "");
                    $('#uploadImg8').attr('src', "" + $rootScope.baseUrl + "/file/download?fileId=" + $scope.taxOrgRealInfo + "");
                    $('#uploadImg9').attr('src', "" + $rootScope.baseUrl + "/file/download?fileId=" + $scope.otherOrgRealInfo + "");
                }
            }
            else {
                $rootScope.tipService.setMessage('获取机构信息失败', 'warning');
            }
        });
    $scope.saveOrganizeRealInfoV = function () {
        //机构实名信息 OrgRealInfo
        var organizeRealInfoV = {
            nature: $scope.natureOrgRealInfo,//企业性质
            corporateName: $scope.corporateNameOrgRealInfo,//法人名称
            corporateCertificateType: $scope.corporateCertificateTypeOrgRealInfo,//法人证件类型
            corporateCertificateNo: $scope.corporateCertificateNoOrgRealInfo,//法人证件号
            ccpFId: $scope.ccpFIdOrgRealInfo,//正面
            ccbFId: $scope.ccbFIdOrgRealInfo,//背面
            cchFId: $scope.cchFIdOrgRealInfo,//手持
            licenseFId: $scope.licenseFIdOrgRealInfo,//营业执照附件编号
            license: $scope.licenseOrgRealInfo,//营业执照
            codeFId: $scope.codeFIdOrgRealInfo,//组织机构代码证附件编号
            code: $scope.codeOrgRealInfo,//组织机构代码证
            creditCodeFId: $scope.creditCodeFIdOrgRealInfo,//机构信用代码证附件编号
            creditCode: $scope.creditCodeOrgRealInfo,//机构信用代码证
            openingFId: $scope.openingFIdOrgRealInfo,//开户许可证附件编号
            opening: $scope.openingOrgRealInfo,//开户许可证
            taxFId: $scope.taxFIdOrgRealInfo,//税务证附件编号
            tax: $scope.taxOrgRealInfo,//税务证
            otherFId: $scope.otherFIdOrgRealInfo,//其他证附件编号
            other: $scope.otherOrgRealInfo//其他证
        };
        memberMangerCtrlSer.organizeRealInfoV(memberEditOrgId, organizeRealInfoV)
            .then(function (res) {
                console.log(res);
                if (res.data.code == '000000') {
                    $rootScope.tipService.setMessage('保存成功', 'warning');
                }
                else {
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                }
            });
    };
    $scope.saveOrganizeInfoV = function () {
        //机构扩展信息
        var organizeInfoV = {
            area: $scope.area,//区域
            briefIntroduction: $scope.briefIntroduction,//公司简介
            businessScope: $scope.businessScope,//经营范围
            city: $scope.city,//城市
            country: $scope.country,//国家
            industry: $scope.industry,//行业
            netWorth: $scope.netWorth,//净资产
            property: $scope.property,//机构性质
            provinces: $scope.provinces,//省份
            registeredCapital: $scope.registeredCapital,//注册资金
            websiteAddress: $scope.websiteAddress//公司网址
        }
        memberMangerCtrlSer.organizeInfoV(memberEditOrgId, organizeInfoV)
            .then(function (res) {
                console.log(res);
                if (res.data.code == '000000') {
                    $rootScope.tipService.setMessage('保存成功', 'warning');
                }
                else {
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                }
            });
    };
    $scope.checked = function (index, contactsId) {
        $scope.contactsId = contactsId;
    };
    $scope.delete = function () {
        if ($scope.contactsId) {
            $scope.removeShowing = true;
        } else {
            $rootScope.tipService.setMessage('请先选择联系人!', 'warning');
        }
    };
    //联系人新增
    $scope.saveContactsVs = function () {
        //联系人信息列表
        var contactsVs = [{
            name: $scope.contactsListName,
            telephone: $scope.contactsListLocalPhone,
            mobileTelephone: $scope.contactsListMobilePhone,
            email: $scope.contactsListEmail,
            address: $scope.contactsListAdress,
            postcode: $scope.contactsListPostCode,
            sex: $scope.contactsListGender,
            fax: $scope.contactsListFax
        }];
        memberMangerCtrlSer.contactsVs(memberEditOrgId, contactsVs)
            .then(function (res) {
                if (res.data.code == '000000') {
                    $scope.addShowing = false;
                    $state.go('tabs.memberManage');
                }
                else {
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                }
            }, function (error) {
                $rootScope.tipService.setMessage(error.data.message, 'warning');
            });
    };

    //联系人删除
    $scope.deleteContacts = function () {
        if ($scope.contactsId) {
            var json = {
                orgId: memberEditOrgId,
                contactsIds: $scope.contactsId
            };
            memberMangerCtrlSer.deleteContactsVs(json)
                .then(function (res) {
                    console.log(res);
                    if (res.data.code == '000000') {
                        $scope.removeShowing = false;
                        $state.go('tabs.memberManage');
                    }
                    else {
                        $rootScope.tipService.setMessage(res.data.message, 'warning');
                    }
                }, function (error) {
                    $rootScope.tipService.setMessage(error.data.message, 'warning');
                });
        } else {
            $rootScope.tipService.setMessage('请先选择联系人!', 'warning');
        }

    };
    //性别转换
    $scope.sexData=getSex;
    $scope.transformSex=function(parameter){
        for(var i=0;i<getSex.length;i++){
            if(parameter==getSex[i].id){
                return getSex[i].name
            }
        }
    };
    //机构查询
    dataSer.organizeQuerySer().then(function (res) {
            if (res.code == '000000') {
                $scope.orgList = res;
            }
            else {
                $rootScope.tipService.setMessage(res.message, 'warning');
            }
        }, function (error) {
            $rootScope.tipService.setMessage(error.message, 'warning');
        });

    $scope.goBack = function () {
        $state.go('tabs.memberManage');
    };
    //获取机构扩展信息 行业
    dataSer.readIndustry().then(function (res) {
            $scope.getOrgInfoIndustryData = res.industry;
        });
    //获取机构性质
    dataSer.readOccupation()
        .then(function (res) {
            $scope.getReadOccupationData = res.occupation;
        });
    //获取学历数据
    dataSer.readEducation().then(function (res) {
            $scope.getReadEducationData = res.education;
        });
    //投资者性质
    dataSer.readProperty().then(function (res) {
            $scope.getReadPropertyData = res.property;
        });
    //国家 城市 地区 选择
    $scope.isChooseCountry = function () {
        if ($scope.country) {
            dataSer.provinceQuerySer($scope.country)
                .then(function (res) {
                    if (res.code == '000000') {
                        $scope.provincesData = res.results;
                    }
                });
        }
    };
    $scope.isChooseProvinces = function () {
        if ($scope.provinces) {
            dataSer.cityQuerySer($scope.provinces)
                .then(function (res) {
                    if (res.code == '000000') {
                        $scope.cityData = res.results;
                    }
                });
        }
    };
    $scope.isChooseCity = function () {
        if ($scope.city) {
            dataSer.areaQuerySer($scope.city)
                .then(function (res) {
                    if (res.code == '000000') {
                        $scope.areaData = res.results;
                    }
                });
        }
    };
    //获取证件类型
    dataSer.readCertificateType()
        .then(function (res) {
            $scope.certificateList = res.certificateType;
        });
    $scope.addOrgValFTC = function (data) {
        console.log(data);
        $scope.superOrgId = data.orgCode;
        $scope.addOrgVal = data.text;
    };
    //图片上传
    uploadImg = function (id, num) {
        var urlUpload = $rootScope.baseUrl + 'file/upload';
        upload_img(urlUpload, id, function (data, status) {
            if (data.code === '000000') {
                console.log(data);
                var ImgId = data.results[0].id;
                switch (num) {
                    case 1:
                        $scope.ccpFIdOrgRealInfo = ImgId;
                        $('#uploadImg1').attr('src', "" + $rootScope.baseUrl + "/file/download?fileId=" + ImgId + "");
                        break;
                    case 2:
                        $scope.ccbFIdOrgRealInfo = ImgId;
                        $('#uploadImg2').attr('src', "" + $rootScope.baseUrl + "/file/download?fileId=" + ImgId + "");
                        break;
                    case 3:
                        $scope.cchFIdOrgRealInfo = ImgId;
                        $('#uploadImg3').attr('src', "" + $rootScope.baseUrl + "/file/download?fileId=" + ImgId + "");
                        break;
                    case 4:
                        $scope.licenseOrgRealInfo = ImgId;
                        $('#uploadImg4').attr('src', "" + $rootScope.baseUrl + "/file/download?fileId=" + ImgId + "");
                        break;
                    case 5:
                        $scope.codeOrgRealInfo = ImgId;
                        $('#uploadImg5').attr('src', "" + $rootScope.baseUrl + "/file/download?fileId=" + ImgId + "");
                        break;
                    case 6:
                        $scope.creditCodeOrgRealInfo = ImgId;
                        $('#uploadImg6').attr('src', "" + $rootScope.baseUrl + "/file/download?fileId=" + ImgId + "");
                        break;
                    case 7:
                        $scope.openingOrgRealInfo = ImgId;
                        $('#uploadImg7').attr('src', "" + $rootScope.baseUrl + "/file/download?fileId=" + ImgId + "");
                        break;
                    case 8:
                        $scope.taxOrgRealInfo = ImgId;
                        $('#uploadImg8').attr('src', "" + $rootScope.baseUrl + "/file/download?fileId=" + ImgId + "");
                        break;
                    case 9:
                        $scope.otherOrgRealInfo = ImgId;
                        $('#uploadImg9').attr('src', "" + $rootScope.baseUrl + "/file/download?fileId=" + ImgId + "");
                        break;
                }
            }
        });
    };
    // url:后台访问路径 fileId:input file按钮id, btn:点击的按钮id, fileInput:接收上传图片的id
    function upload_img(url, fileId, callback) {
        $.ajaxFileUpload({
            url: url,
            type: 'post',
            secureuri: false,
            fileElementId: fileId,// file标签的id
            dataType: 'json',// 返回数据的类型
            data: {name: fileId},
            success: function (data, status) {
                callback(data, status)
            },
            error: function (data, status, e) {
                console.log(data, status, e)
            }
        });
    }

     //放大图片
    $('.example img').zoomify();
   /* var imgs = document.getElementsByTagName("img");
    var lens = imgs.length;
    var popup = document.getElementById("popup");

    for (var i = 0; i < lens; i++) {
        imgs[i].onclick = function (event) {
            event = event || window.event;
            var target = document.elementFromPoint(event.clientX, event.clientY);
            showBig(target.src);
        }
    }
    popup.onclick = function () {
        popup.style.display = "none";
    };

    function showBig(src) {
        popup.getElementsByTagName("img")[0].src = src;
        popup.style.display = "block";
    }*/
});