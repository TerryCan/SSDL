app.controller('VarietiesCtrl', ['$rootScope', '$scope', 'getPageNum', 'VarietiesCtrlSer', 'getClassificationState', 'dataSer', 'localStorageService', 'confirmService','$timeout','getlockFlagtype','currencyManagementCtrlSer','getadminState','timestamp', function ($rootScope, $scope, getPageNum, VarietiesCtrlSer, getClassificationState, dataSer, localStorageService, confirmService,$timeout,getlockFlagtype,currencyManagementCtrlSer,getadminState,timestamp) {
    $scope.toggleTraderSearchState = false;
    $scope.Toggle = function () {
        $scope.toggleTraderSearchState = !$scope.toggleTraderSearchState;
        if ($scope.toggleTraderSearchState) {
            $('.search_column').css('height', 'auto');
        }
        else {
            $('.search_column').css('height', '36px');
        }
    };
    localStorageService.clear('userIdChecked');
    $scope.tableshow = false;
    $scope.commodityNames='';
    $scope.ToState='';
    $scope.search = function (type) {
        $scope.toggleTraderSearchState = false;
        $('.search_column').css('height', '36px');
        if (type == 'search') {
            pageInitialize()
        };
        $scope.orgCode=localStorageService.get('oldOrgCode');
        var json = {
            page: $scope.currentPage,
            rows: $scope.showNum.showNum,
            orders: 'asc',
            search_EQ_orgCode: ($scope.orgCode) ?  $scope.orgCode : '',
            search_EQ_commodityState: $scope.ToState,
            search_EQ_commodityName: $scope.commodityNames,

        };
        VarietiesCtrlSer.search(json)
            .then(function (res) {
                console.log(res)
                if (res.code == '000000') {
                    $scope.showPage = true;
                    var data = JSON.parse(res.content);
                    $scope.searchResult = data.content;
                    console.log($scope.searchResult);
                    $scope.dataNum = data.totalElements;
                    $scope.PageNum();

                    var checkedUserId=localStorageService.get('userIdChecked'); //获取上一次存储的id
                    $scope.switchUserId(checkedUserId,$scope.searchResult); //执行选中方法
                } else {
                    $rootScope.tipService.setMessage(res.message, 'warning');
                }
            }, function (error) {
                $rootScope.tipService.setMessage(error.message, 'warning');
            });
    }
    //品种列表
    VarietiesCtrlSer.searchlist()
        .then(function (res) {
            console.log(res)
            if (res.code == '000000') {
                $scope.showPage = true;
                var data = JSON.parse(res.content);
                $scope.searchdatalist = data;
                console.log($scope.searchdatalist);
            } else {
                $rootScope.tipService.setMessage(res.message, 'warning');
            }
        }, function (error) {
            $rootScope.tipService.setMessage(error.message, 'warning');
        });

    /*$scope.datatrue=[
        {val: true, name: '是'},
        {val: false, name: '否'},
    ]
    $scope.datatrueType = function (lockFlag) {
        if ($scope.datatrue) {
            for (var i = 0, r = $scope.datatrue.length; i < r; i++) {
                if ($scope.datatrue[i].val == lockFlag) {
                    return $scope.datatrue[i].name;
                }
            }
        }
    }*/


    /**
     * 分页功能实现TerryMin
     * **/
    $scope.showDataChoose = getPageNum.pageNum(); //获取分页
    $scope.showNum = $scope.showDataChoose[0]; //初始显示刷具条数
    $scope.showPage = false;
    var pageInitialize = function () {
        $scope.dataNum = 0; //数据总条数
        $scope.dataPage = 0; //分页数
        $scope.currentPage = 1; //当前页数
        $scope.jumpPageNum = '';
    };
    pageInitialize();

    $scope.PageNum = function () {
        $scope.showPage = true;
        if ($scope.showNum.showNum < $scope.dataNum) {
            $scope.dataPage =Math.ceil($scope.dataNum / $scope.showNum.showNum);
        } else {
            $scope.dataPage = 0;
        }
    };
    //上页下页 $scope.currentPage
    $scope.pageSlect = function (type) {
        if (type == 'prev') {
            if ($scope.currentPage != 1) {
                $scope.currentPage--;
                $scope.PageNum();
                $scope.search();
            }
        } else {
            if ($scope.currentPage < $scope.dataPage) {
                $scope.currentPage++;
                $scope.PageNum();
                $scope.search();
            }
        }
    };
    // 每页条数单元
    $scope.pageSelect = function (params) {
        $scope.showNum.showNum = params.showNum;
        pageInitialize();
        $scope.search();
    };
    //页数跳转 currentPage
    $scope.jumpPage = function (num) {
        num = parseInt(num);
        if (parseInt(num, 10) === num && num <= ($scope.dataPage + 1) && num > 0) {
            $scope.currentPage = num;
            $scope.PageNum();
            $scope.search();
        }
    };
    $scope.JYshowRoleaut=true;
    $scope.JYhideRoleaut=true;
    $scope.PZshowRoleaut=true;
    $scope.PZhideRoleaut=true;
    $scope.TimeshowRoleaut=true;
    $scope.TimehideRoleaut=true;

    // 选择
    $scope.checkedTab1 = function (index,applyTradeTimeId,commodityId,applyId,applyTradeId,marketId,categoryId,commodityName,commodityCode,contractNum,commodityCurrency,minPriceNume,minPriceDeno,commoditySort,commodityState){
        $scope.chooseUserData={
            applyTradeTimeId:applyTradeTimeId,
            commodityId:commodityId,
            applyId:applyId,
            applyTradeId:applyTradeId,
            marketId:marketId,
            categoryId:categoryId,
            commodityName:commodityName,// 品种名称
            commodityCode:commodityCode, // 品种简码
            contractNum:contractNum,// 合约大小
            commodityCurrency:commodityCurrency,// 品种币种
            minPriceNume:minPriceNume,// 最小变动价分子
            minPriceDeno:minPriceDeno,// 最小变动价分母
            //lockFlag:lockFlag,// 持仓开平方式（锁仓功能等）
            commoditySort:commoditySort,// 品种排序
            commodityState:commodityState,
        };
        console.log($scope.chooseUserData)
        var userIdChecked = localStorageService.get('userIdChecked');
        $('#dataReport input[type=checkbox]').prop('checked', false);
        if (commodityId == userIdChecked) {
            localStorageService.clear('userIdChecked');
            $scope.chooseItemTab1 = '';
            $scope.applyId='';
            $scope.applyTradeId='';
            $scope.commodityState='';
            $scope.applyTradeTimeId='';
        } else {
            $('#dataReport input[type=checkbox]').eq(index).prop('checked', true);
            localStorageService.update('userIdChecked', commodityId);
            $scope.chooseItemTab1 = commodityId;
            $scope.applyId = applyId;
            $scope.applyTradeId= applyTradeId;
            $scope.commodityState=commodityState;
            $scope.applyTradeTimeId=applyTradeTimeId;
        }
        if($scope.chooseUserData.applyTradeId!=null){
            $scope.JYshowRoleaut=false;
            $scope.JYhideRoleaut=false;
        }else{
            $scope.JYshowRoleaut=true;
            $scope.JYhideRoleaut=true;
        }
        if($scope.chooseUserData.applyId!=null){
            $scope.PZshowRoleaut=false;
            $scope.PZhideRoleaut=false;
        }else{
            $scope.PZshowRoleaut=true;
            $scope.PZhideRoleaut=true;
        }
        if($scope.chooseUserData.applyTradeTimeId!=null){
            $scope.TimeshowRoleaut=false;
            $scope.TimehideRoleaut=false;
        }else{
            $scope.TimeshowRoleaut=true;
            $scope.TimehideRoleaut=true;
        }

    };
    // 存储选中
    $scope.switchUserId = function (parameter, responseData) {
        $timeout(function () {
            for (var i = 0; i < responseData.length; i++) {
                if (parameter == responseData[i].commodityId) {
                    $('#dataReport input[type=checkbox]').eq(i).prop('checked', true);
                    return;
                }
            }
        }, 1500)
    };



    VarietiesCtrlSer.marketlists()
        .then(function(res){
            console.log(res)
            if(res.code=="000000"){
                $scope.Marketresults=JSON.parse(res.content);
                console.log($scope.Marketresults)
                $scope.marketNamety=function(marketId){
                    for (var i = 0, r = $scope.Marketresults.length; i < r; i++) {
                        if ($scope.Marketresults[i].marketId == marketId) {
                            return $scope.Marketresults[i].marketName;
                        }
                    }
                }
                }
            })

    VarietiesCtrlSer.categorylists()
        .then(function(res){
            console.log(res)
            if(res.code=="000000"){
                $scope.categoryresults=JSON.parse(res.content);
                console.log($scope.categoryresults)
                $scope.categoryNamety=function(categoryId){
                    for (var i = 0, r = $scope.categoryresults.length; i < r; i++) {
                        if ($scope.categoryresults[i].categoryId == categoryId) {
                            return $scope.categoryresults[i].categoryName;
                        }
                    }
                }
            }
        })

    $scope.lockFlagtype=getlockFlagtype;
    console.log($scope.lockFlagtype)
    $scope.add = function () {
        $scope.tableshow = true;
        $scope.addEditText = '新增';
        $scope.marketId="";
        $scope.categoryId="";
        $scope.commodityName=""; // 品种名称
        $scope.commodityCode=""; // 品种简码
        $scope.contractNum="";// 合约大小
        $scope.commodityCurrency="";// 品种币种
        $scope.minPriceNume="";// 最小变动价分子
        $scope.minPriceDeno="";// 最小变动价分母
        //$scope.lockFlag="";// 持仓开平方式（锁仓功能等）
        $scope.commoditySort="";// 品种排序
    }

    $scope.edit = function () {
        if (!$scope.chooseItemTab1) {
            $rootScope.tipService.setMessage('请先选择品种信息', 'warning');
        } else {
            $scope.addEditText = '修改';
            $scope.tableshow = true;
            $scope.commodityId=$scope.chooseUserData.commodityId;
            $scope.marketId=$scope.chooseUserData.marketId;
            $scope.categoryId=$scope.chooseUserData.categoryId;
            $scope.commodityName=$scope.chooseUserData.commodityName;// 品种名称
            $scope.commodityCode=$scope.chooseUserData.commodityCode; // 品种简码
            $scope.contractNum=parseInt($scope.chooseUserData.contractNum);// 合约大小
            $scope.commodityCurrency=parseInt($scope.chooseUserData.commodityCurrency);// 品种币种
            $scope.minPriceNume=parseFloat($scope.chooseUserData.minPriceNume);// 最小变动价分子
            $scope.minPriceDeno=parseInt($scope.chooseUserData.minPriceDeno);// 最小变动价分母
            //$scope.lockFlag=$scope.chooseUserData.lockFlag.toString() ;// 持仓开平方式（锁仓功能等）
            $scope.commoditySort=parseInt($scope.chooseUserData.commoditySort);// 品种排序
            //匹配机构代码
            var json = {
                page: 1,
                rows: 9999,
                search_A_EQ_state: 1
            };
            dataSer.getOrganize(json).then(function (res) {
                if (res.code == '000000') {
                    $scope.equalOrgCode = JSON.parse(res.content).content;
                    //console.log($scope.equalOrgCode);
                    for (var i = 0; i < $scope.equalOrgCode.length; i++) {
                        if ($scope.chooseUserData.orgId == $scope.equalOrgCode[i].orgId) {
                            $scope.addOrgVal = $scope.equalOrgCode[i].orgName + '(' + $scope.equalOrgCode[i].orgNum + ')';
                            //console.log($scope.addOrgVal)
                        }
                    }
                } else {
                    console.log(res);
                }
            });
        }
    }

    $scope.apply = function () {
        if (!$scope.chooseItemTab1) {
            $rootScope.tipService.setMessage('请先选择品种变更信息', 'warning');
        } else {
            $scope.addEditText = "申请品种变更";
            $scope.tableshow = true;
            $scope.commodityId=$scope.chooseUserData.commodityId;
            $scope.marketId=$scope.chooseUserData.marketId;
            $scope.categoryId=$scope.chooseUserData.categoryId;
            $scope.commodityName=$scope.chooseUserData.commodityName;// 品种名称
            $scope.commodityCode=$scope.chooseUserData.commodityCode; // 品种简码
            $scope.contractNum=parseInt($scope.chooseUserData.contractNum);// 合约大小
            $scope.commodityCurrency=parseInt($scope.chooseUserData.commodityCurrency);// 品种币种
            $scope.minPriceNume=parseFloat($scope.chooseUserData.minPriceNume);// 最小变动价分子
            $scope.minPriceDeno=parseInt($scope.chooseUserData.minPriceDeno);// 最小变动价分母
            //$scope.lockFlag=$scope.chooseUserData.lockFlag.toString() ;// 持仓开平方式（锁仓功能等）
            $scope.commoditySort=parseInt($scope.chooseUserData.commoditySort);// 品种排序
            //匹配机构代码
            var json = {
                page: 1,
                rows: 9999,
                search_A_EQ_state: 1
            };
            dataSer.getOrganize(json).then(function (res) {
                if (res.code == '000000') {
                    $scope.equalOrgCode = JSON.parse(res.content).content;
                    //console.log($scope.equalOrgCode);
                    for (var i = 0; i < $scope.equalOrgCode.length; i++) {
                        if ($scope.chooseUserData.orgId == $scope.equalOrgCode[i].orgId) {
                            $scope.addOrgVal = $scope.equalOrgCode[i].orgName + '(' + $scope.equalOrgCode[i].orgNum + ')';
                            //console.log($scope.addOrgVal)
                        }
                    }
                } else {
                    console.log(res);
                }
            });
        }
    }

    $scope.addSubmit = function () {
        if ($scope.addEditText == "新增") {
            var commodityVIce={
                marketId:$scope.marketId, // 市场编号
                categoryId:$scope.categoryId, // 分类编号
                commodityName:$scope.commodityName, // 品种名称
                commodityCode:$scope.commodityCode, // 品种简码
                contractNum:parseFloat($scope.contractNum),// 合约大小
                commodityCurrency:parseInt($scope.commodityCurrency),// 品种币种
                minPriceNume:parseFloat($scope.minPriceNume),// 最小变动价分子
                minPriceDeno:parseInt($scope.minPriceDeno),// 最小变动价分母
                //lockFlag:$scope.lockFlag.toString() ,// 持仓开平方式（锁仓功能等）
                commoditySort:parseInt($scope.commoditySort),// 品种排序
            };
            var json = {
                commodityVIce: commodityVIce
            }
            VarietiesCtrlSer.Addsub(json)
                .then(function (res) {
                        if (res.data.code == "000000") {
                            $scope.tableshow = false;
                            $rootScope.tipService.setMessage(res.data.message, 'warning');
                            localStorageService.clear('userIdChecked');
                            $scope.search();
                        }else{
                            $rootScope.tipService.setMessage(res.data.message, 'warning');
                        }
                    },function(error){
                        $rootScope.tipService.setMessage(error.data.message, 'warning');
                    }
                )
        } else if ($scope.addEditText == "修改") {
            var commodityVIce={
                commodityId:$scope.commodityId,
                marketId:$scope.marketId, // 市场编号
                categoryId:$scope.categoryId, // 分类编号
                commodityName:$scope.commodityName, // 品种名称
                commodityCode:$scope.commodityCode, // 品种简码
                contractNum:parseFloat($scope.contractNum),// 合约大小
                commodityCurrency:parseInt($scope.commodityCurrency),// 品种币种
                minPriceNume:parseFloat($scope.minPriceNume),// 最小变动价分子
                minPriceDeno:parseInt($scope.minPriceDeno),// 最小变动价分母
                //lockFlag:$scope.lockFlag.toString() ,// 持仓开平方式（锁仓功能等）
                commoditySort:parseInt($scope.commoditySort),// 品种排序
            };
            var json = {
                commodityVIce: commodityVIce
            }
            VarietiesCtrlSer.editsub(json)
                .then(function (res) {
                    if (res.data.code == "000000") {
                        $scope.tableshow = false;
                        $rootScope.tipService.setMessage(res.data.message, 'warning');
                        localStorageService.clear('userIdChecked');
                        $scope.search();
                    }
                    else {
                        $rootScope.tipService.setMessage(res.data.message, 'warning');
                    }
                },function(error){
                    $rootScope.tipService.setMessage(error.data.message, 'warning')
                })
        }else if ($scope.addEditText == "申请品种变更") {
            var commodityVIce={
                commodityId:$scope.commodityId,
                marketId:$scope.marketId, // 市场编号
                categoryId:$scope.categoryId, // 分类编号
                commodityName:$scope.commodityName, // 品种名称
                commodityCode:$scope.commodityCode, // 品种简码
                contractNum:parseFloat($scope.contractNum),// 合约大小
                commodityCurrency:parseInt($scope.commodityCurrency),// 品种币种
                minPriceNume:parseFloat($scope.minPriceNume),// 最小变动价分子
                minPriceDeno:parseInt($scope.minPriceDeno),// 最小变动价分母
                //lockFlag:$scope.lockFlag.toString() ,// 持仓开平方式（锁仓功能等）
                commoditySort:parseInt($scope.commoditySort),// 品种排序
            };
            var json = {
                commodityVIce: commodityVIce
            }
            VarietiesCtrlSer.Apply(json)
                .then(function (res) {
                    if (res.data.code == "000000") {
                        $scope.tableshow = false;
                        $rootScope.tipService.setMessage(res.data.message, 'warning');
                        localStorageService.clear('userIdChecked');
                        $scope.search();
                    }
                    else {
                        $rootScope.tipService.setMessage(res.data.message, 'warning');
                    }
                },function(error){
                    $rootScope.tipService.setMessage(error.data.message, 'warning')
                })
        }
    }

    $scope.get=function () {
        if (!$scope.applyId) {
            $rootScope.tipService.setMessage('请先申请品种变更', 'warning');
        } else {
            var json={
                applyId:$scope.applyId
            }
            VarietiesCtrlSer.Get(json)
                .then(function(res){
                    console.log(res)
                    if(res.data.code=="000000"){
                        var getData=JSON.parse(res.data.content);
                        $scope.getDatalist=getData.configCommodityV;
                        console.log($scope.getDatalist)
                        $scope.addEditText = "审核品种变更";
                       $scope.tableshowxq = true;
                       $scope.commodityId=$scope.getDatalist.commodityId;
                       $scope.marketId=$scope.getDatalist.marketId;
                       $scope.categoryId=$scope.getDatalist.categoryId;
                       $scope.commodityName=$scope.getDatalist.commodityName;// 品种名称
                       $scope.commodityCode=$scope.getDatalist.commodityCode; // 品种简码
                       $scope.contractNum=parseInt($scope.getDatalist.contractNum);// 合约大小
                       $scope.commodityCurrency=parseInt($scope.getDatalist.commodityCurrency);// 品种币种
                       $scope.minPriceNume=parseFloat($scope.getDatalist.minPriceNume);// 最小变动价分子
                       $scope.minPriceDeno=parseInt($scope.getDatalist.minPriceDeno);// 最小变动价分母
                       //$scope.lockFlag=$scope.getDatalist.lockFlag.toString() ;// 持仓开平方式（锁仓功能等）
                       $scope.commoditySort=parseInt($scope.getDatalist.commoditySort);// 品种排序
                       $scope.considerationNum=parseInt($scope.getDatalist.considerationNum);
                    }
                })

        }
    }

    $scope.RoletrueData = function (tmpOpt) {
        var json = {
            applyId: $scope.applyId,
            auditRs: tmpOpt
        };
        VarietiesCtrlSer.Roletruetion(json)
            .then(function (res) {
                if (res.data.code == '000000') {
                    $scope.tableshowxq = false;
                    localStorageService.clear('userIdChecked');
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                    $scope.search();
                } else {
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                }
            },function(error) {
                $rootScope.tipService.setMessage(error.data.message, 'warning');
            })
    }
    $scope.RolefalseData = function (tmpOpt) {
        var json = {
            applyId: $scope.applyId,
            auditRs: tmpOpt
        };
        VarietiesCtrlSer.Roletruetion(json)
            .then(function (res) {
                if (res.data.code == '000000') {
                    $scope.tableshowxq = false;
                    localStorageService.clear('userIdChecked');
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                    $scope.search();
                } else {
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                }
            },function(error) {
                $rootScope.tipService.setMessage(error.data.message, 'warning');
            })
    }
    currencyManagementCtrlSer.currencylist()
        .then(function(res){
            console.log(res)
            if(res.code="000000"){
                $scope.currencyls=JSON.parse(res.content);
                console.log($scope.currencyls)
                $scope.currencytype=function(commodityCurrency){
                    for (var i = 0, r = $scope.currencyls.length; i < r; i++) {
                        if (commodityCurrency == $scope.currencyls[i].currency) {
                            return $scope.currencyls[i].currencyName;
                        }
                }
            }
            }
        })

    $scope.audit=function () {
        if (!$scope.chooseItemTab1) {
            $rootScope.tipService.setMessage('请先选择品种变更信息', 'warning');
        } else {
        $scope.auditshow = true;
        $scope.addEditTexts = "申请交易变更";
        $scope.commodityId=""; // 品种编号（唯一）
        $scope.depositCurrency=""; // 保证金币种
        $scope.depositNormal=""; // 正常保证金
        $scope.depositHold=""; // 维持保证金
        $scope.depositBalance="";// 结算保证金
        $scope.feeCurrency="";// 手续费金币种
        $scope.feeQuota="";// 定额手续费
        $scope.interestCurrency="";// 仓息币种
        $scope.interest="";// 仓息
    }
    }
    $scope.applySubmit=function(){
        var commodityTradeVIce={
            commodityId:$scope.commodityId, // 品种编号（唯一）
            depositCurrency:parseInt($scope.depositCurrency), // 保证金币种
            depositNormal:parseFloat($scope.depositNormal), // 正常保证金
            depositHold:parseFloat($scope.depositHold), // 维持保证金
            depositBalance:parseFloat($scope.depositBalance),// 结算保证金
            feeCurrency:parseInt($scope.feeCurrency),// 手续费金币种
            feeQuota:parseFloat($scope.feeQuota),// 定额手续费
            interestCurrency:parseInt($scope.interestCurrency),// 仓息币种
            interest:parseFloat($scope.interest),// 仓息
        };
        var json = {
            commodityTradeVIce: commodityTradeVIce
        }
        VarietiesCtrlSer.tradeapply(json)
            .then(function (res) {
                if (res.data.code == "000000") {
                    $scope.auditshow = false;
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                    localStorageService.clear('userIdChecked');
                    $scope.search();
                }else{
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                }
            },function(error){
                $rootScope.tipService.setMessage(error.data.message, 'warning');
            })
        }
    $scope.getaudit=function () {
        if (!$scope.applyTradeId) {
            $rootScope.tipService.setMessage('请先申请交易变更', 'warning');
        } else {
            var json={
                applyId:$scope.applyTradeId
            }
            VarietiesCtrlSer.Getaudit(json)
                .then(function(res){
                    console.log(res)
                    if(res.data.code=="000000"){
                        var getData=JSON.parse(res.data.content);
                        $scope.getaduitDatalist=getData.configCommodityTradeV;
                        console.log($scope.getaduitDatalist)
                        $scope.addEditText = "审核交易变更";
                        $scope.auditGetshow = true;
                        $scope.commodityId=$scope.getaduitDatalist.commodityId; // 品种编号（唯一）
                        $scope.depositCurrency=parseInt($scope.getaduitDatalist.depositCurrency); // 保证金币种
                        $scope.depositNormal=parseFloat($scope.getaduitDatalist.depositNormal); // 正常保证金
                        $scope.depositHold=parseFloat($scope.getaduitDatalist.depositHold);// 维持保证金
                        $scope.depositBalance=parseFloat($scope.getaduitDatalist.depositBalance);// 结算保证金
                        $scope.feeCurrency=parseInt($scope.getaduitDatalist.feeCurrency);// 手续费金币种
                        $scope.feeQuota=parseFloat($scope.getaduitDatalist.feeQuota);// 定额手续费
                        $scope.interestCurrency=parseInt($scope.getaduitDatalist.interestCurrency);// 仓息币种
                        $scope.interest=parseFloat($scope.getaduitDatalist.interest);// 仓息
                    }
                })

        }
    }

    $scope.auditRoletrueData = function (tmpOpt) {
        var json = {
            applyId: $scope.applyTradeId,
            auditRs: tmpOpt
        };
        VarietiesCtrlSer.auditRoletruetion(json)
            .then(function (res) {
                if (res.data.code == '000000') {
                    $scope.auditGetshow = false;
                    localStorageService.clear('userIdChecked');
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                    $scope.search();
                } else {
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                }
            },function(error) {
                $rootScope.tipService.setMessage(error.data.message, 'warning');
            })
    }
    $scope.auditRolefalseData = function (tmpOpt) {
        var json = {
            applyId: $scope.applyTradeId,
            auditRs: tmpOpt
        };
        VarietiesCtrlSer.auditRoletruetion(json)
            .then(function (res) {
                if (res.data.code == '000000') {
                    $scope.auditGetshow = false;
                    localStorageService.clear('userIdChecked');
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                    $scope.search();
                } else {
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                }
            },function(error) {
                $rootScope.tipService.setMessage(error.data.message, 'warning');
            })
    }

    $scope.allotTypeData=getadminState;
    $scope.allotTypeText = function(val) {
        for (var i = 0, r = $scope.allotTypeData.length; i < r; i++) {
            if (val == $scope.allotTypeData[i].id) {
                return $scope.allotTypeData[i].name;
            }
        }
    }

    $scope.pass=function() {
        if (!$scope.chooseItemTab1) {
            $rootScope.tipService.setMessage('请先选择品种管理信息', 'warning');
        } else {
            var json={
                commodityId:$scope.chooseItemTab1
            }
            VarietiesCtrlSer.passCheck(json)
                .then(function (res) {
                    if (res.data.code == '000000') {
                        localStorageService.clear('userIdChecked');
                        $rootScope.tipService.setMessage(res.data.message, 'warning');
                        $scope.search();
                    } else {
                        $rootScope.tipService.setMessage(res.data.message, 'warning');
                    }
                }, function (error) {
                    $rootScope.tipService.setMessage(error.data.message, 'warning');
                });
        }
    }
    $scope.fail=function() {
        if (!$scope.chooseItemTab1) {
            $rootScope.tipService.setMessage('请先选择品种管理信息', 'warning');
        } else {
            var json={
                commodityId:$scope.chooseItemTab1
            }
            VarietiesCtrlSer.failedCheck(json)
                .then(function (res) {
                    if (res.data.code == '000000') {
                        localStorageService.clear('userIdChecked');
                        $rootScope.tipService.setMessage(res.data.message, 'warning');
                        $scope.search();
                    } else {
                        $rootScope.tipService.setMessage(res.data.message, 'warning');
                    }
                }, function (error) {
                    $rootScope.tipService.setMessage(error.data.message, 'warning');
                });
        }
    }
    $scope.open=function() {
        if (!$scope.chooseItemTab1) {
            $rootScope.tipService.setMessage('请先选择品种管理信息', 'warning');
        } else {
            var json={
                commodityId:$scope.chooseItemTab1
            }
            VarietiesCtrlSer.open(json)
                .then(function (res) {
                    if (res.data.code == '000000') {
                        localStorageService.clear('userIdChecked');
                        $rootScope.tipService.setMessage(res.data.message, 'warning');
                        $scope.search();
                    } else {
                        $rootScope.tipService.setMessage(res.data.message, 'warning');
                    }
                }, function (error) {
                    $rootScope.tipService.setMessage(error.data.message, 'warning');
                });
        }
    }

    $scope.close=function() {
        if (!$scope.chooseItemTab1) {
            $rootScope.tipService.setMessage('请先选择品种管理信息', 'warning');
        } else {
            confirmService.set('确认提示', '确定要注销此品种管理信息?', function () {
                var json={
                    commodityId:$scope.chooseItemTab1
                }
                VarietiesCtrlSer.Close(json)
                    .then(function (res) {
                        if (res.data.code == '000000') {
                            localStorageService.clear('userIdChecked');
                            $rootScope.tipService.setMessage(res.data.message, 'warning');
                            $scope.search();
                        } else {
                            $rootScope.tipService.setMessage(res.data.message, 'warning');
                        }
                    }, function (error) {
                        $rootScope.tipService.setMessage(error.data.message, 'warning');
                    });
                confirmService.clear();
            });
        }
    }

    $scope.Timeaudit=function() {
        if (!$scope.chooseItemTab1) {
            $rootScope.tipService.setMessage('请先选择品种变更信息', 'warning');
        } else {
            $scope.commodityId=$scope.chooseItemTab1;
            VarietiesCtrlSer.Timegetdata($scope.commodityId)
                .then(function(res){
                    console.log(res)
                    if(res.data.code=="000000") {
                        var getData = JSON.parse(res.data.content);
                        console.log(getData)
                        $scope.addEditText = "申请时间变更";
                        $scope.Timeauditshow = true;
                        $scope.Datalists = [];
                        for (var i = 0, r = getData.timeSubs.length; i < r; i++) {
                            var channelist = {
                                startTime: getData.timeSubs[i].startTime,
                                endTime: getData.timeSubs[i].endTime,
                            }
                            $scope.Datalists.push(channelist);
                            console.log($scope.Datalists)
                        }
                        if (!channelist) {
                            $scope.Datalists = [];
                        }
                    }else {
                        $rootScope.tipService.setMessage(res.data.codeName, 'warning');
                    }
                })
        }
    }

    $scope.Datalists=[];
    $scope.addrule = function() {
         $scope.Dataorm={
             startTime: ($scope.startTime) ? timestamp.DateToSeconds($scope.startTime) * 1000 : '',
             endTime: ($scope.endTime) ? timestamp.DateToSeconds($scope.endTime) * 1000 : '',
        }
        $scope.Datalists.push($scope.Dataorm);
        console.log($scope.Datalists)
    }

    $scope.deletesd = function(index) {
        $scope.Datalists.splice(index, 1);
    }
    // 将毫秒转化为系统时间
    $scope.formatTime = function(parameter) {
        return timestamp.daySecondsToDate(parameter);
    };
    $scope.TimeauditData=function(){
        var commodityTradeTimeVIce={
            commodityId:$scope.commodityId,
                timeSubs:$scope.Datalists
        }
        var json={
            commodityTradeTimeVIce:commodityTradeTimeVIce
        }
        VarietiesCtrlSer.timeapply(json)
            .then(function (res) {
                console.log(res)
                if (res.data.code == '000000') {
                    $scope.Timeauditshow = false;
                    localStorageService.clear('userIdChecked');
                    $rootScope.tipService.setMessage(res.data.codeName, 'warning');
                    $scope.search();
                } else {
                    $rootScope.tipService.setMessage(res.data.codeName, 'warning');
                }
            },function(error) {
                $rootScope.tipService.setMessage(error.data.codeName, 'warning');
            })
    }

    $scope.Timeget=function(){
        if (!$scope.applyTradeTimeId) {
            $rootScope.tipService.setMessage('请先申请时间变更', 'warning');
        } else {
            var json={
                applyTradeTimeId:$scope.applyTradeTimeId
            }
            VarietiesCtrlSer.applyget(json)
                .then(function(res){
                    console.log(res)
                    if(res.data.code=="000000"){
                        var getData=JSON.parse(res.data.content);
                        $scope.getaduitDatalist=getData.commodityTradeTimeV;
                        console.log($scope.getaduitDatalist)
                        $scope.addEditText = "审核时间变更";
                        $scope.TimeGetshow = true;
                        $scope.commodityId=$scope.getaduitDatalist.commodityId; // 品种编号（唯一）
                        $scope.Datalists = [];
                        for (var i = 0, r = $scope.getaduitDatalist.timeSubs.length; i < r; i++) {
                            var channelist = {
                                startTime: $scope.getaduitDatalist.timeSubs[i].startTime,
                                endTime: $scope.getaduitDatalist.timeSubs[i].endTime,
                            }
                            $scope.Datalists.push(channelist);
                        }
                        if (!channelist) {
                            console.log(channelist)
                            $scope.Datalists = [];
                        }
                    }
                })
        }
    }

    $scope.TimeRoletrueData = function (tmpOpt) {
        var json = {
            applyTradeTimeId: $scope.applyTradeTimeId,
            auditRs: tmpOpt
        };
        VarietiesCtrlSer.TimeRoletruetion(json)
            .then(function (res) {
                if (res.data.code == '000000') {
                    $scope.TimeGetshow = false;
                    localStorageService.clear('userIdChecked');
                    $rootScope.tipService.setMessage(res.data.codeName, 'warning');
                    $scope.search();
                } else {
                    $rootScope.tipService.setMessage(res.data.codeName, 'warning');
                }
            },function(error) {
                $rootScope.tipService.setMessage(error.data.codeName, 'warning');
            })
    }
    $scope.TimeRolefalseData = function (tmpOpt) {
        var json = {
            applyTradeTimeId: $scope.applyTradeTimeId,
            auditRs: tmpOpt
        };
        VarietiesCtrlSer.TimeRoletruetion(json)
            .then(function (res) {
                if (res.data.code == '000000') {
                    $scope.TimeGetshow = false;
                    localStorageService.clear('userIdChecked');
                    $rootScope.tipService.setMessage(res.data.codeName, 'warning');
                    $scope.search();
                } else {
                    $rootScope.tipService.setMessage(res.data.codeName, 'warning');
                }
            },function(error) {
                $rootScope.tipService.setMessage(error.data.codeName, 'warning');
            })
    }
}])
    .factory('VarietiesCtrlSer', ['$http', 'localStorageService', 'myHttp', '$q', '$rootScope', function ($http, localStorageService, myHttp, $q, $rootScope) {
        return {
            //查询
            search: function (json) {
                var deferred = $q.defer();
                myHttp.post("admin/config/product/commodity/query/page", json)
                    .then(function (res) { // 调用承诺API获取数据 .resolve
                        deferred.resolve(res);
                    }, function (res) { // 处理错误 .reject
                        deferred.reject(res);
                    });
                return deferred.promise;
            },
            searchlist:function(){
                var deferred = $q.defer();
                myHttp.post("admin/config/product/commodity/query/list")
                    .then(function (res) { // 调用承诺API获取数据 .resolve
                        deferred.resolve(res);
                    }, function (res) { // 处理错误 .reject
                        deferred.reject(res);
                    });
                return deferred.promise;
            },
            marketlists:function(){
                var deferred = $q.defer();
                myHttp.post("admin/config/product/market/query/list")
                    .then(function (res) { // 调用承诺API获取数据 .resolve
                        deferred.resolve(res);
                    }, function (res) { // 处理错误 .reject
                        deferred.reject(res);
                    });
                return deferred.promise;

            },
            categorylists:function(){
                var deferred = $q.defer();
                myHttp.post("admin/config/product/category/query/list")
                    .then(function (res) { // 调用承诺API获取数据 .resolve
                        deferred.resolve(res);
                    }, function (res) { // 处理错误 .reject
                        deferred.reject(res);
                    });
                return deferred.promise;

            },
            Addsub: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'admin/config/product/commodity/create',
                    data: json
                }).then(function successCallback(response) {
                    console.log(response)
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
            editsub: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'admin/config/product/commodity/update',
                    data: json
                }).then(function successCallback(response) {
                    console.log(response)
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
            Apply: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'admin/config/product/commodity/apply',
                    data: json
                }).then(function successCallback(response) {
                    console.log(response)
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
            Get: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'admin/config/product/commodity/apply/get',
                    data: json
                }).then(function successCallback(response) {
                    console.log(response)
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
            Getaudit: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'admin/config/product/commodity/trade/apply/get',
                    data: json
                }).then(function successCallback(response) {
                    console.log(response)
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
            Roletruetion: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'admin/config/product/commodity/audit',
                    data: json
                }).then(function successCallback(response) {
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
            auditRoletruetion: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'admin/config/product/commodity/trade/audit',
                    data: json
                }).then(function successCallback(response) {
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
            tradeapply: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'admin/config/product/commodity/trade/apply',
                    data: json
                }).then(function successCallback(response) {
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
            Close: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'admin/config/product/commodity/close',
                    data: json
                }).then(function successCallback(response) {
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
            //通过
            passCheck: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'admin/config/product/commodity/pass',
                    data: json
                }).then(function successCallback(response) {
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
            //不通过
            failedCheck: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'admin/config/product/commodity/fail',
                    data: json
                }).then(function successCallback(response) {
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
            //重新提交
            open: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'admin/config/product/commodity/open',
                    data: json
                }).then(function successCallback(response) {
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
            timeapply:function(json){
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'admin/commodity/trade/time/apply',
                    data: json
                }).then(function successCallback(response) {
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
            applyget:function(json){
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'admin/commodity/trade/time/apply/get',
                    data: json
                }).then(function successCallback(response) {
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
            TimeRoletruetion:function(json){
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'admin/commodity/trade/time/audit',
                    data: json
                }).then(function successCallback(response) {
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
            Timegetdata:function(commodityId){
                var deferred = $q.defer();
                var json={
                    commodityId:commodityId
                }
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'admin/commodity/trade/time/get',
                    data: json
                }).then(function successCallback(response) {
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            }
        }
    }])