app.controller('OperationlogCtrl', ['$scope', '$state', '$rootScope', 'localStorageService', 'getPageNum', 'confirmService', 'timestamp', 'dataSer', function ($scope, $state, $rootScope, localStorageService, getPageNum, confirmService, timestamp, dataSer) {
    $scope.toggleTraderSearchState = false;
    $scope.Toggle = function() {
    	$scope.toggleTraderSearchState = !$scope.toggleTraderSearchState;
    	if ($scope.toggleTraderSearchState) {
    		$('.search_column').css('height', 'auto');
    	} else {
    		$('.search_column').css('height', '36px');
    	}
    };
/*
    $scope.loginName = "";
    $scope.TimeStartData = "";
    $scope.TimeEndData = "";
    //全部状态下所属机构
    dataSer.organizeQuerylistSer()
    	.then(function(res) {
    		$scope.meborgList = res;
    		//console.log($scope.orgList)
    	});
    $scope.getOrgVal = function(orgCode) {
    	if ($scope.meborgList) {
    		console.log($scope.meborgList)
    		for (var i = 0; i < $scope.meborgList.length; i++) {
    			if (orgCode == $scope.meborgList[i].orgCode) {
    				return $scope.meborgList[i].text;
    			}
    		}
    	}
    }

    //时间戳
    $scope.timestamp = function(stamp) {
    	return timestamp.timestampCoverHms(stamp, 'all')
    }
    $scope.search = function(type) {
    	$scope.toggleTraderSearchState=false;
    	$('.search_column').css('height', '36px');
    		if (type == 'search') {
    			pageInitialize()
    		};
    		//$scope.TimeStart = ($scope.TimeStartData == '') ? $scope.TimeStartData : Date.parse(new Date($scope.TimeStartData));
    		//$scope.TimeEnd = ($scope.TimeEndData == '') ? $scope.TimeEndData : Date.parse(new Date($scope.TimeEndData));
    		OperationlogCtrllSer.search($scope.showNum.showNum, $scope.currentPage, $scope.loginName, $scope.TimeStartData, $scope.TimeEndData)
    			.then(function(res) {
    				console.log(res)
    				if (res.code == '000000') {
    					$scope.showPage = true;
    					$scope.searchResult = JSON.parse(res.content).content;
    					console.log($scope.searchResult)
    					$scope.dataNum = JSON.parse(res.content).totalElements;
    					$scope.PageNum();
    				} else {
    					$rootScope.tipService.setMessage(res.message, 'warning');
    				}
    			}, function(error) {
    				$rootScope.tipService.setMessage(error.message, 'warning');
    			});
    	}
    	//分页功能实现
    var pageInitialize = function() {
    	$scope.dataNum = 0; //数据总条数
    	$scope.dataPage = 0; //分页数
    	$scope.currentPage = 1; //当前页数
    	$scope.jumpPageNum = '';
    }
    $scope.showDataChoose = getPageNum.pageNum(); //获取分页
    $scope.showNum = $scope.showDataChoose[0]; //初始显示刷具条数
    $scope.dataPageNumber = []; //生成页面数
    $scope.showPage = false;
    $scope.pageSelect = function(params) {
    	console.log(params);
    	$scope.showNum.showNum = params.showNum;
    	pageInitialize();
    	$scope.search();
    }
    $scope.changePageNumber = function(params) {
    	$scope.currentPage = params;
    	$scope.search();
    	$scope.PageNum();
    }
    $scope.PageNum = function() {
    	if ($scope.showNum.showNum < $scope.dataNum) {
    		$scope.dataPage = parseInt($scope.dataNum / $scope.showNum.showNum) + 1;
    	} else {
    		$scope.dataPage = 0;
    	}
    	$scope.dataPageNumber = [];
    	for (var i = 0; i < $scope.dataPage; i++) {
    		$scope.dataPageNumber.push(i + 1);
    	}
    }
    $scope.jumpPage = function(num) {
    	num = parseInt(num);
    	if (parseInt(num, 10) === num && num <= ($scope.dataPage + 1) && num > 0) {
    		$scope.currentPage = num;
    		$scope.PageNum();
    		$scope.search();
    	}
    }
    $scope.pageSlect = function(type) {
    	if (type == 'prev') {
    		if ($scope.currentPage != 1) {
    			$scope.currentPage--;
    			$scope.PageNum();
    			$scope.search();
    		}
    	} else {
    		if ($scope.currentPage < $scope.dataPage) {
    			$scope.currentPage++;
    			$scope.PageNum();
    			$scope.search();
    		}
    	}
    }
    pageInitialize();
*/


    var processContent,processTotal;
    var source = {
        type: 'POST',
        datatype: "json",
        datafields: [  //数据字段定义
            {name: 'loginName', type: 'string'},
            {name: 'orgName', type: 'string'},
            {name: 'actionIp', type: 'string'},
            {name: 'moduleName', type: 'string'},
            {name: 'actionName', type: 'string'},
            {name: 'actionCode', type: 'string'},
            {name: 'result', type: 'string'},
            {name: 'startTime', type: 'string'},
            {name: 'endTime', type: 'string'}

        ],
        url: $rootScope.baseUrl + 'log/query/as/page',
        root: "content",
        pagesize:10,
        processData: function (data) {
            console.log(data)
            data.page = (data.pagenum + 1)?(data.pagenum + 1):1;
            data.rows =(data.pagesize)?(data.pagesize):10;
            data.order =($scope.order)?$scope.order:'desc';
            data.sort =($scope.sort)?$scope.sort:'startTime';
            data.search_A_EQ_loginName = ($scope.loginName) ? $scope.loginName : '';
            data.search_A_GTE_startTime = ($scope.TimeStartData) ? $scope.TimeStartData : '';
            data.search_A_LTE_endTime = ($scope.TimeEndData) ? $scope.TimeEndData : '';
        }, //传递参数处理
        beforeLoadComplete: function (records) { //数据完全加载完执行绘制表格
            console.log(records)
            var start;
            for (var i in records) {
                start = parseInt(i);
                break;
            }
            for (var k = 0, r = processContent.length; k < r; k++) {
                records[start + k].loginName = processContent[k].loginName;
                records[start + k].orgName = processContent[k].orgName;
                records[start + k].actionIp = processContent[k].actionIp;
                records[start + k].moduleName = processContent[k].moduleName;
                records[start + k].actionName = processContent[k].actionName;
                records[start + k].actionCode = processContent[k].actionCode;

                records[start + k].result = processContent[k].result;
                records[start + k].startTime = processContent[k].startTime;
                records[start + k].endTime = processContent[k].endTime;
            }
        },
        beforeprocessing: function (data) { //处理总页数
            var processData = JSON.parse(data.content);
            processContent = processData.content;
            source.totalrecords = processData.totalElements == 0 ? 5 : processData.totalElements;
            processTotal = processData.totalElements;
        },
        loadComplete: function (records) {
            $scope.saveResult=JSON.parse(records.content);
            var data =  $scope.saveResult.totalElements;
            if (data == 0) {
                $('#contenttableentrustDetailGrid > div').remove();
            }
        },
        endUpdate: true
    };
    //创建数据适配器
    var dataAdapter = null;
    $scope.searchAjax = function () {
        $scope.toggleTraderSearchState = false;
        $('.search_column').css('height', '36px');
        if (dataAdapter == null) {
            dataAdapter = new $.jqx.dataAdapter(source);
            //创建表格
            $("#jqxgrid").jqxGrid({
                source: dataAdapter,
                columns: [  //表格数据域
                    {
                        text: '用户名称',
                        datafield: 'loginName',
                        minwidth: 12.5+ '%',//设置列min宽
                        align: 'center',//设置表头
                        cellsalign: 'center'
                    },
                    {
                        text: '机构信息',
                        datafield: 'orgName',
                        minwidth: 12.5 + '%',
                        align: 'center'
                    },
                    {
                        text: '操作IP',
                        datafield: 'actionIp',
                        minwidth: 12.5 + '%',
                        align: 'center'
                    },
                    {
                        text: '模块名称',
                        datafield: 'moduleName',
                        minwidth:12.5 + '%',
                        align: 'center'
                    },
                    {
                        text: '操作名称',
                        datafield: 'actionName',
                        minwidth: 12.5 + '%',
                        cellsalign: 'center',
                        align: 'center'
                    },
                    {
                        text: '操作代码',
                        datafield: 'actionCode',
                        minwidth: 12.5 + '%',
                        align: 'center'
                    },
                    {
                        text: '开始时间',
                        datafield: 'startTime',
                        minwidth: 12.5 + '%',
                        align: 'center',
                        cellsrenderer: function (row, columnfield, value, defaulthtml, columnproperties) {
                            return timestamp.timestampCoverHms(value, 'all');
                        }
                    },
                    {
                        text: '结束时间',
                        datafield: 'endTime',
                        minwidth: 12.5 + '%',
                        align: 'center',
                        cellsrenderer: function (row, columnfield, value, defaulthtml, columnproperties) {
                            return timestamp.timestampCoverHms(value, 'all');
                        }
                    }
                ],
                width: 100 + '%',
                height: 86 + '%',
                theme:'metrodark',
                virtualmode: true,
                rendergridrows: function (params) { //将数据渲染到页面
                    return params.data;
                },
                pageable: true,
                pagesizeoptions: ['10','30','100','200'],
                sortable: true,
                altrows: true,
                columnsresize: true,//列间距是否可调整
                selectionmode: 'singlecell',//选择模式
                clipboard: true,
            });
        }else {
            $("#jqxgrid").jqxGrid('updatebounddata', 'cells');
        }
    };
    //分页
    $("#jqxgrid").on("pagechanged", function (event) {
        console.log(event)
    });
    //排序
    $("#jqxgrid").on("sort", function (event) {
        var sortinformation = event.args.sortinformation;
        $scope.sort=sortinformation.sortcolumn;
        $scope.order=($scope.sort)?(sortinformation.sortdirection.ascending)?'asc':'desc':'asc';
        data={
            order:$scope.order,
            sort:$scope.sort
        };
        source.processData(data);
        $("#jqxgrid").jqxGrid('updatebounddata', 'sort');
    });

}])
    /*.factory('OperationlogCtrllSer', ['$http', 'localStorageService', 'myHttp', '$q', '$rootScope', function ($http, localStorageService, myHttp, $q, $rootScope) {
        return {
            //查询
            search: function (showNum, nowPage, loginName, TimeStartData, TimeEndData) {
                var json = {
                    page: nowPage,
                    rows: showNum,
                    order: 'desc',
                    sort: 'startTime',
                    search_A_EQ_loginName: loginName,
                    search_A_GTE_startTime: TimeStartData,
                    search_A_LTE_endTime: TimeEndData
                }

                var deferred = $q.defer();
                myHttp.post("log/query/as/page", json)
                    .then(function (res) { // 调用承诺API获取数据 .resolve
                        deferred.resolve(res);
                    }, function (res) { // 处理错误 .reject
                        deferred.reject(res);
                    });
                return deferred.promise;
            },

        }

    }])*/