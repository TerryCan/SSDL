app.controller('statisticSearchCtrl', ['$rootScope', '$scope', 'statisticSearchSer','$timeout', '$sce', 'getPageNum', 'timestamp', 'localStorageService','getCurrencyType', function ($rootScope, $scope, statisticSearchSer,$timeout, $sce, getPageNum,  timestamp, localStorageService,getCurrencyType) {
    $scope.toggleTraderSearchState=false;
    $scope.Toggle = function(){
        $scope.toggleTraderSearchState = !$scope.toggleTraderSearchState;
        if($scope.toggleTraderSearchState){
           $('.search_column').css('height','auto');
        }
        else{
           $('.search_column').css('height','36px');
        }
    };
    //数据转换
    $scope.timeSwitch = function (stamp) {
        return timestamp.timestampCoverHms(stamp, 'all')
    };
    // 货币转换
    getCurrencyType.then(function (res) {
        $scope.currencyList = JSON.parse(res.content);
    });

    //条件查询
    $scope.orgCodeNum = '';
    $scope.loginName = '';
    $scope.createTimeStart=timestamp.defaultDate('start');
    $scope.createTimeEnd=timestamp.defaultDate();
    $scope.currency='';
    $scope.search = function () {
        $scope.toggleTraderSearchState=false;
        $('.search_column').css('height','36px');
        if($scope.createTimeStart && $scope.createTimeEnd){
            var sumAccountIoParams = {
                loginName: $scope.loginName,
                currency:$scope.currency,
                createTimeS:($scope.createTimeStart)?($scope.createTimeStart.split(' ')[0]+"T"+$scope.createTimeStart.split(' ')[1]):'',
                createTimeE:($scope.createTimeEnd)?($scope.createTimeEnd.split(' ')[0]+"T"+$scope.createTimeEnd.split(' ')[1]):'',
                orgCode: ($scope.upOrgCode)?$scope.upOrgCode:'',
            };
            var json={
                sumAccountIoParams:sumAccountIoParams
            };
            statisticSearchSer.statisticSearch(json).then(function (response) {
                    if (response.code == "000000") {
                        $scope.searchResult = JSON.parse(response.content);
                        console.log($scope.searchResult);

                        var source = {
                            localdata: $scope.searchResult,
                            datatype: "array",
                            datafields: [
                                {name: 'ioInSumNumber', type: 'string'},
                                {name: 'ioOutSumNumber', type: 'string'},
                                {name: 'ioInOutSumNumber', type: 'string'},
                                {name: 'reversalInSumNumber', type: 'string'},
                                {name: 'reversalOutSumNumber', type: 'string'},

                                {name: 'currency', type: 'string'},
                                {name: 'appInSumNumber', type: 'string'},
                                {name: 'appOutSumNumber', type: 'string'},
                                {name: 'appIningSumNumber', type: 'string'},
                                {name: 'appOutingSumNumber', type: 'string'},

                                {name: 'appInOutingSumNumber', type: 'string'},
                                {name: 'poundageInSumNumber', type: 'string'},
                                {name: 'poundageOutSumNumber', type: 'string'},
                                {name: 'interestInSumNumber', type: 'string'},
                                {name: 'interestOutSumNumber', type: 'string'},

                                {name: 'floatProfitInSumNumber', type: 'string'},
                                {name: 'floatProfitOutSumNumber', type: 'string'},
                                {name: 'otherSumNumber', type: 'string'}
                            ]
                        };
                        var dataAdapter = new $.jqx.dataAdapter(source);
                        $("#entrustDetailGrid").jqxGrid(
                            {
                                width: 100 + '%',
                                height: 85 + '%',
                                theme: 'metrodark',
                                source: dataAdapter,//数据源
                                columnsresize: true,
                                selectionmode: 'singlecell',
                                clipboard: true,
                                columns: [  //表格数据域
                                    {
                                        text: '总汇入',
                                        datafield: 'ioInSumNumber',
                                        width: '5%',
                                        minwidth: 5 + '%',
                                        align: 'center'
                                    },
                                    {
                                        text: '总汇出',
                                        datafield: 'ioOutSumNumber',
                                        width: '5%',
                                        minwidth: 5 + '%',
                                        align: 'center'
                                    },
                                    {
                                        text: '净汇入',
                                        datafield: 'ioInOutSumNumber',
                                        width: '5%',
                                        minwidth: 5 + '%',
                                        align: 'center'
                                    },
                                    {
                                        text: '调入',
                                        datafield: 'reversalInSumNumber',
                                        width: '5%',
                                        minwidth: 5 + '%',
                                        align: 'center'
                                    },
                                    {
                                        text: '调入',
                                        datafield: 'reversalOutSumNumber',
                                        width: '5%',
                                        minwidth: 5 + '%',
                                        align: 'center'
                                    },

                                    {
                                        text: '币种',
                                        datafield: 'currency',
                                        width: '5%',
                                        minwidth: 5 + '%',
                                        align: 'center',
                                        cellsrenderer: function (row, columnfield, value, defaulthtml, columnproperties) {
                                            if ($scope.currencyList) {
                                                for (var i = 0; i < $scope.currencyList.length; i++) {
                                                    if (value == $scope.currencyList[i].currency) {
                                                        return $scope.currencyList[i].currencyName;
                                                    }
                                                }
                                            }
                                        }
                                    },
                                    {
                                        text: '入金',
                                        datafield: 'appInSumNumber',
                                        width: '5%',
                                        minwidth: 5 + '%',
                                        align: 'center'
                                    },
                                    {
                                        text: '出金',
                                        datafield: 'appOutSumNumber',
                                        width: '5%',
                                        minwidth: 5 + '%',
                                        align: 'center'
                                    },
                                    {
                                        text: '待入金',
                                        datafield: 'appIningSumNumber',
                                        width: '5%',
                                        minwidth: 5 + '%',
                                        align: 'center'
                                    },
                                    {
                                        text: '待出金',
                                        datafield: 'appOutingSumNumber',
                                        width: '5%',
                                        minwidth: 5 + '%',
                                        align: 'center'
                                    },

                                    {
                                        text: '待净汇入',
                                        datafield: 'appInOutingSumNumber',
                                        width: '6%',
                                        minwidth: 6 + '%',
                                        align: 'center'
                                    },
                                    {
                                        text: '手续费汇入',
                                        datafield: 'poundageInSumNumber',
                                        width: '7%',
                                        minwidth: 7 + '%',
                                        align: 'center'
                                    },
                                    {
                                        text: '手续费汇出',
                                        datafield: 'poundageOutSumNumber',
                                        width: '7%',
                                        minwidth: 7 + '%',
                                        align: 'center'
                                    },
                                    {
                                        text: '仓息汇入',
                                        datafield: 'interestInSumNumber',
                                        width: '6%',
                                        minwidth: 6 + '%',
                                        align: 'center'
                                    },
                                    {
                                        text: '仓息汇出',
                                        datafield: 'interestOutSumNumber',
                                        width: '6%',
                                        minwidth: 6 + '%',
                                        align: 'center'
                                    },

                                    {
                                        text: '盈亏汇入',
                                        datafield: 'floatProfitInSumNumber',
                                        width: '6%',
                                        minwidth: 6 + '%',
                                        align: 'center'
                                    },
                                    {
                                        text: '盈亏汇出',
                                        datafield: 'floatProfitOutSumNumber',
                                        width: '6%',
                                        minwidth: 6 + '%',
                                        align: 'center'
                                    },
                                    {
                                        text: '其他合计',
                                        datafield: 'otherSumNumber',
                                        width: '6%',
                                        minwidth: 6 + '%',
                                        align: 'center'
                                    }

                                ]
                            });
                    } else {
                        $rootScope.tipService.setMessage(response.message, 'warning');
                    }
                }, function (error) {
                    $rootScope.tipService.setMessage(error.message, 'warning');
                });
        }else{
            $rootScope.tipService.setMessage('请先选择起始时间!', 'warning');
        }
    };

}])
// Server
    .factory('statisticSearchSer', ['$http', 'localStorageService', 'myHttp', '$q', '$rootScope', function ($http, localStorageService, myHttp, $q, $rootScope) {
        return {
            statisticSearch: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + "account/account/io/query/sum",
                    data: json,
                    headers: {
                        'Content-Type': 'application/json;charset=UTF-8'
                    }
                }).success(function (res) {
                    deferred.resolve(res);
                }).error(function (res) {
                    deferred.reject(res);
                });
                return deferred.promise;

            }
        }
    }]);