app.controller('MailtemplatesettingsCtrl', ['$scope', '$state', '$rootScope', 'localStorageService', 'MailtemplatesettingsCtrllSer', 'getPageNum', 'confirmService', 'timestamp','dataSer', function($scope, $state, $rootScope, localStorageService, MailtemplatesettingsCtrllSer, getPageNum, confirmService, timestamp,dataSer){
	$scope.toggleTraderSearchState=false;
    $scope.Toggle = function(){
        $scope.toggleTraderSearchState = !$scope.toggleTraderSearchState;
        if($scope.toggleTraderSearchState){
           $('.search_column').css('height','auto');
        }
        else{
           $('.search_column').css('height','36px');
        }
    };
	dataSer.organizeQuerySer()
			.then(function(res) {
				$scope.orgList = res;
			});

	$scope.orgCodetext = function (orgCode) {
        for (var i = 0, r = $scope.orgList.length; i < r; i++) {
        	if(orgCode==$scope.orgList[i].orgCode){
					return $scope.orgList[i].text
        	}
        }
    };
    $scope.trunPage = function(url) {
		$state.go(url);
	}

	$scope.search = function(type) {
		 $scope.toggleTraderSearchState=false;
		 $('.search_column').css('height','36px');
		if (type == 'search') {
			pageInitialize()
		};
		MailtemplatesettingsCtrllSer.search($scope.showNum.showNum, $scope.currentPage)
			.then(function(res) {
				console.log(res)
				if (res.code == '000000') {
					$scope.showPage = true;
					$scope.searchResult = JSON.parse(res.content).content;
					$scope.dataNum = JSON.parse(res.content).totalElements;
					$scope.PageNum();
				} else {
					$rootScope.tipService.setMessage(res.message, 'warning');
				}
			}, function(error) {
				$rootScope.tipService.setMessage(error.message, 'warning');
			});
	}

	//单选
	$scope.choosemailTemplateId = null;
	$scope.checkedTab1 = function(index, emailTemplateId) {
		$scope.choosemailTemplateId = emailTemplateId;
		$scope.emailTemplateId = $scope.searchResult[index].emailTemplateId;
		$('#dataReport input[type=checkbox]').prop('checked', false);
		$('#dataReport input[type=checkbox]').eq(index).prop('checked', true);
		console.log($scope.choosemailTemplateId)
	}

	//修改
	$scope.edit = function(url) {
		if ($scope.choosemailTemplateId == null) {
			console.log()
			$rootScope.tipService.setMessage('请先选择邮件模块信息', 'warning');
		} else {
				localStorageService.update('MailemailTemp', $scope.choosemailTemplateId);
				//console.log(a)
				$state.go(url);
		}
	}
	$scope.typedata=[
		{val: '1', name: '开户邮件'},
		{val: '2', name: '忘记密码'},
		{val: '3', name: '重置资金密码'},
		{val: '4', name: '风险提示'},
		{val: '5', name: '爆仓'},
		{val: '6', name: '验证码'},
		]

		//类型互换
			$scope.getType = function(val) {
					for (var i = 0, r = $scope.typedata.length; i < r; i++) {
						if ($scope.typedata[i].val == val) {
							return $scope.typedata[i].name;

						}
					}
				}
	//删除
	$scope.delete = function(){
		if(!$scope.choosemailTemplateId){
				$rootScope.tipService.setMessage('请先选择邮件模板信息', 'warning');
		}
		else{
			confirmService.set('确认提示','确定要删除此邮件模板信息?',function(){
				MailtemplatesettingsCtrllSer.close($scope.choosemailTemplateId)
				.then(function(res){
					if(res.data.code=="000000"){
						$rootScope.tipService.setMessage(res.data.message, 'warning');
						$scope.search();
					}
				},function(error){
						$rootScope.tipService.setMessage(error.data.message, 'warning');
				});
				confirmService.clear();
			})
		}
	}
	/* 分页功能实现 */
		var pageInitialize = function() {
			$scope.dataNum = 0; //数据总条数
			$scope.dataPage = 0; //分页数
			$scope.currentPage = 1; //当前页数
			$scope.jumpPageNum = '';
		}
		$scope.showDataChoose = getPageNum.pageNum(); //获取分页
		$scope.showNum = $scope.showDataChoose[0]; //初始显示刷具条数
		$scope.dataPageNumber = []; //生成页面数
		$scope.showPage = false;
		$scope.pageSelect = function(params) {
			console.log(params);
			$scope.showNum.showNum = params.showNum;
			pageInitialize();
			$scope.search();
		}
		$scope.changePageNumber = function(params) {
			$scope.currentPage = params;
			$scope.search();
			$scope.PageNum();
		}
		$scope.PageNum = function() {
			if ($scope.showNum.showNum < $scope.dataNum) {
				$scope.dataPage = parseInt($scope.dataNum / $scope.showNum.showNum) + 1;
			} else {
				$scope.dataPage = 0;
			}
			$scope.dataPageNumber = [];
			for (var i = 0; i < $scope.dataPage; i++) {
				$scope.dataPageNumber.push(i + 1);
			}
		}
		$scope.jumpPage = function(num) {
			num = parseInt(num);
			if (parseInt(num, 10) === num && num <= ($scope.dataPage + 1) && num > 0) {
				$scope.currentPage = num;
				$scope.PageNum();
				$scope.search();
			}
		}
		$scope.pageSlect = function(type) {
			if (type == 'prev') {
				if ($scope.currentPage != 1) {
					$scope.currentPage--;
					$scope.PageNum();
					$scope.search();
				}
			} else {
				if ($scope.currentPage < $scope.dataPage) {
					$scope.currentPage++;
					$scope.PageNum();
					$scope.search();
				}
			}
		}
		pageInitialize();
}])
.factory('MailtemplatesettingsCtrllSer', ['$http', 'localStorageService', 'myHttp', '$q', '$rootScope', function($http, localStorageService, myHttp, $q, $rootScope) {
	return {
		//查询
			search: function(showNum, nowPage) {
				var json = {
					page: nowPage,
					rows: showNum,
					/*order: 'desc',
					sort: 'createTime',*/
				}

				var deferred = $q.defer();
				myHttp.post("email/template/query", json)
					.then(function(res) { // 调用承诺API获取数据 .resolve
						deferred.resolve(res);
					}, function(res) { // 处理错误 .reject
						deferred.reject(res);
					});
				return deferred.promise;
			},

			// 删除
			close:function(emailTemplateId){
					var json = {
					emailTemplateId:emailTemplateId
				}
				var deferred = $q.defer();
				$http({
					method: 'POST',
					url: $rootScope.baseUrl+'email/template/delete',
					data:json
					}).then(function successCallback(response) {
						deferred.resolve(response);
					}, function errorCallback(response) {
						deferred.reject(response);
				});
				return deferred.promise;
			},
			getNTInfo:function(emailTemplateId){
				var json = {
					emailTemplateId: emailTemplateId
				}
				var deferred = $q.defer();
				$http({
					method: 'POST',
					url: $rootScope.baseUrl + 'email/template/get',
					data: json
				}).then(function successCallback(response) {
					console.log(response)
					deferred.resolve(response);
				}, function errorCallback(response) {
					deferred.reject(response);
				});
				return deferred.promise;
			},

	}

}])