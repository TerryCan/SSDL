app.controller('marketMappingAddCtrl', ['$scope', '$rootScope','marketMappingAddCtrlSer','marketSourceManageCtrlSer','getPageNum','marketSourceProductManageCtrlSer', function($scope, $rootScope,marketMappingAddCtrlSer,marketSourceManageCtrlSer,getPageNum,marketSourceProductManageCtrlSer) {
//行情源账号
	marketSourceManageCtrlSer.search()
		.then(function(res){
				$scope.searchResult = res.list;
				console.log($scope.searchResult)
		});
//产品ID

marketMappingAddCtrlSer.prosearch(1,99999)
.then(function(res){
		$scope.prolist = JSON.parse(res.content);
		console.log($scope.prolist)
		});

//行情商品对应
	var QuotaBaseInfo = function(){
		$scope.productId = '';
		$scope.ratio = '';
		$scope.quotationslist = [];
		$scope.quotationId = '';
		$scope.quotationProductId = '';
		$scope.accurateDigit = '';
		$scope.premium = '';
	}
	$scope.baseProList = [];
	$scope.copyProList = [];
	marketSourceProductManageCtrlSer.search()
		.then(function(res){
			$scope.searchResult = res.list;
			console.log($scope.searchResult)
		for(var i=0,r=$scope.searchResult.length;i<r;i++){
			$scope.baseProList.push({key:$scope.searchResult[i].key,commodity:$scope.searchResult[i].commodity,exchange:$scope.searchResult[i].exchange,contract:$scope.searchResult[i].contract});
		}
		QuotaBaseInfo();
	});
	$scope.addPro = function(index){
		$scope.copyProList.unshift($scope.baseProList.splice(index,1)[0]);
	}
	$scope.backPro = function(index){
		$scope.baseProList.unshift($scope.copyProList.splice(index,1)[0]);
		console.log()
	}

	$scope.saveinfo=function(){
		for(var i=0,r=$scope.copyProList.length;i<r;i++){
			$scope.quotationslist.push($scope.copyProList[i].key);
		}
		marketMappingAddCtrlSer.addnew($scope.productId,$scope.quotationId,$scope.quotationslist,$scope.accurateDigit,$scope.premium,$scope.ratio)
		.then(function(res){
			console.log(res)
			if(res.data.code == '000000'){
				$rootScope.tipService.setMessage(res.data.message, 'warning');
			}
			else{
				$rootScope.tipService.setMessage(res.data.message, 'warning');
			}
		})
	}
}])

.factory('marketMappingAddCtrlSer',['$http','localStorageService','myHttp','$q','$rootScope',function($http,localStorageService,myHttp,$q,$rootScope){
	return {
		prosearch:function(nowPage,showNum){
			var json = {
				page:nowPage,
				rows:showNum,
				orders:'asc'
			};
			var deferred = $q.defer();
			myHttp.post("config/product/query/as/list",json)
				.then(function(res) {  // 调用承诺API获取数据 .resolve
					console.log(res)
					deferred.resolve(res);
				}, function(res) {  // 处理错误 .reject
					deferred.reject(res);
			});
			return deferred.promise;
		},
	addnew:function(productId,quotationId,quotationslist,accurateDigit,premium,ratio){
		var json = {
				"productQuotaconfig":{
        		"productId":productId,
       			 "quotations":[
           						 {
				                "quotationId":quotationId,
				                "quotationProductId":quotationslist,
				                "accurateDigit":accurateDigit,
				                "premium":premium,
				                "ratio":ratio
	            			}
      					 ]
    				}

			}
			var deferred = $q.defer();
			$http({
				method: 'POST',
				url: $rootScope.baseUrl+'config/product/save/productQuotaconfig',
				data:json
				}).then(function successCallback(response) {
					deferred.resolve(response);
				}, function errorCallback(response) {
					deferred.reject(response);
			});
			return deferred.promise;
		}
	};

}])