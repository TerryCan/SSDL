app.controller('PersonalizationgroupCtrl', ['$rootScope', '$scope', 'getPageNum', 'PersonalizationgroupCtrlSer', 'dataSer', 'localStorageService', 'confirmService','$timeout','VarietiesCtrlSer','getadminState', function ($rootScope, $scope, getPageNum, PersonalizationgroupCtrlSer , dataSer, localStorageService, confirmService,$timeout,VarietiesCtrlSer,getadminState) {
    $scope.toggleTraderSearchState = false;
    $scope.Toggle = function () {
        $scope.toggleTraderSearchState = !$scope.toggleTraderSearchState;
        if ($scope.toggleTraderSearchState) {
            $('.search_column').css('height', 'auto');
        }
        else {
            $('.search_column').css('height', '36px');
        }
    };
    localStorageService.clear('userIdChecked');
    $scope.tableshow = false;
    $scope.GroupName='';
    $scope.ToState='';
    $scope.search = function (type) {
        $scope.toggleTraderSearchState = false;
        $('.search_column').css('height', '36px');
        if (type == 'search') {
            pageInitialize()
        };
        $scope.orgCode=localStorageService.get('oldOrgCode');
        var json = {
            page: $scope.currentPage,
            rows: $scope.showNum.showNum,
            orders: 'asc',
            search_EQ_orgCode: ($scope.orgCode) ?  $scope.orgCode : '',
            search_EQ_state: $scope.ToState,
            search_EQ_commodityCustomizedGroupName: $scope.GroupName,

        };
        PersonalizationgroupCtrlSer.search(json)
            .then(function (res) {
                console.log(res)
                if (res.code == '000000') {
                    $scope.showPage = true;
                    var data = JSON.parse(res.content);
                    $scope.searchResult = data.content;
                    console.log($scope.searchResult);
                    $scope.dataNum = data.totalElements;
                    $scope.PageNum();

                    var checkedUserId=localStorageService.get('userIdChecked'); //获取上一次存储的id
                    $scope.switchUserId(checkedUserId,$scope.searchResult); //执行选中方法
                } else {
                    $rootScope.tipService.setMessage(res.message, 'warning');
                }
            }, function (error) {
                $rootScope.tipService.setMessage(error.message, 'warning');
            });
    }

    /**
     * 分页功能实现TerryMin
     * **/
    $scope.showDataChoose = getPageNum.pageNum(); //获取分页
    $scope.showNum = $scope.showDataChoose[0]; //初始显示刷具条数
    $scope.showPage = false;
    var pageInitialize = function () {
        $scope.dataNum = 0; //数据总条数
        $scope.dataPage = 0; //分页数
        $scope.currentPage = 1; //当前页数
        $scope.jumpPageNum = '';
    };
    pageInitialize();

    // x/y $scope.dataPage
    $scope.PageNum = function () {
        $scope.showPage = true;
        if ($scope.showNum.showNum < $scope.dataNum) {
            $scope.dataPage =Math.ceil($scope.dataNum / $scope.showNum.showNum);
        } else {
            $scope.dataPage = 0;
        }
    };
    //上页下页 $scope.currentPage
    $scope.pageSlect = function (type) {
        if (type == 'prev') {
            if ($scope.currentPage != 1) {
                $scope.currentPage--;
                $scope.PageNum();
                $scope.search();
            }
        } else {
            if ($scope.currentPage < $scope.dataPage) {
                $scope.currentPage++;
                $scope.PageNum();
                $scope.search();
            }
        }
    };
    // 每页条数单元
    $scope.pageSelect = function (params) {
        $scope.showNum.showNum = params.showNum;
        pageInitialize();
        $scope.search();
    };
    //页数跳转 currentPage
    $scope.jumpPage = function (num) {
        num = parseInt(num);
        if (parseInt(num, 10) === num && num <= ($scope.dataPage + 1) && num > 0) {
            $scope.currentPage = num;
            $scope.PageNum();
            $scope.search();
        }
    };
    dataSer.organizeQuerySer()
        .then(function (res) {
            $scope.orgList = res;
            console.log($scope.orgList)
        });

    $scope.addOrgValFTC = function (data) {
        console.log(data);
        $scope.orgId = data.orgId;
        $scope.orgCode = data.orgCode;
        $scope.addOrgVal = data.text;
    }
    //全部状态下所属机构
        dataSer.organizeQuerylistSer()
            .then(function (res) {
                $scope.orgAllList = res;
            });

        $scope.adjustText = function (orgId) {
            if ($scope.orgAllList) {
                for (var i = 0, r = $scope.orgAllList.length; i < r; i++) {
                    if ($scope.orgAllList[i].orgId == orgId) {
                        return $scope.orgAllList[i].text;
                    }
                }
            }
        }
    $scope.typeData = [
        {name: '仓息', val: '1'},
        {name: '维持保证金', val: '2'},
        {name: '正常保证金', val: '3'},
        {name: '结算保证金', val: '4'},
        {name: '定额手续费', val: '5'}
        ];
    $scope.typeText = function (val) {
        for (var i = 0, r = $scope.typeData.length; i < r; i++) {
            if (val == $scope.typeData[i].val) {
                return $scope.typeData[i].name;
            }
        }
    }
    $scope.allotTypeData=getadminState;
    $scope.allotTypeText = function(val) {
        for (var i = 0, r = $scope.allotTypeData.length; i < r; i++) {
            if (val == $scope.allotTypeData[i].id) {
                return $scope.allotTypeData[i].name;
            }
        }
    }
    //品种列表
    VarietiesCtrlSer.searchlist()
        .then(function (res) {
            console.log(res)
            if (res.code == '000000') {
                $scope.showPage = true;
                var data = JSON.parse(res.content);
                $scope.searchdatalist = data;
                console.log($scope.searchdatalist);
                $scope.searchdatalistty=function(commodityId){
                    for (var i = 0, r = $scope.searchdatalist.length; i < r; i++) {
                        if ($scope.searchdatalist[i].commodityId == commodityId) {
                            return $scope.searchdatalist[i].commodityName;
                        }
                    }
                }
            } else {
                $rootScope.tipService.setMessage(res.message, 'warning');
            }
        }, function (error) {
            $rootScope.tipService.setMessage(error.message, 'warning');
        });
    $scope.add = function () {
        $scope.tableshow = true;
        $scope.addEditText = '新增';
        $scope.commodityCustomizedGroupName='';
        $scope.commodityId='';
        $scope.addOrgVal='';
        $scope.type='';
        $scope.customizedValue='';

    }

    $scope.addSubmit = function () {
            var configCommodityCustomizedGroupVIce= {
                commodityCustomizedGroupName:$scope.commodityCustomizedGroupName,
                commodityId: $scope.commodityId,
                orgId: $scope.orgId,
                orgCode: $scope.orgCode,
                type: parseInt($scope.type),
                customizedValue: parseFloat($scope.customizedValue),
            }
            var json = {
                configCommodityCustomizedGroupVIce: configCommodityCustomizedGroupVIce
            }
        PersonalizationgroupCtrlSer.Addsub(json)
                .then(function (res) {
                        if (res.data.code == "000000") {
                            $scope.tableshow = false;
                            $rootScope.tipService.setMessage(res.data.message, 'warning');
                            localStorageService.clear('userIdChecked');
                            $scope.search();
                        } else {
                            $rootScope.tipService.setMessage(res.data.message, 'warning');
                        }
                    }, function (error) {
                        $rootScope.tipService.setMessage(error.data.message, 'warning');
                    })
        }

    $scope.hideRoleaut=true;
    $scope.showRoleaut=true;
    $scope.CYshowRoleaut=true;
    $scope.CYhideRoleaut=true;

// 选择
    $scope.checkedTab1 = function (index,applyId,applyRelationId,commodityCustomizedGroupId,commodityCustomizedGroupName,commodityId,state,orgCode,orgId,type,customizedValue){
        $scope.chooseUserData={
            applyId:applyId,
            applyRelationId:applyRelationId,
            commodityCustomizedGroupId:commodityCustomizedGroupId,
            commodityCustomizedGroupName:commodityCustomizedGroupName,
            commodityId:commodityId,
            state:state,
            orgCode:orgCode,
            orgId:orgId,
            type:type,
            customizedValue:customizedValue,
        };
        console.log($scope.chooseUserData)
        var userIdChecked = localStorageService.get('userIdChecked');
        $('#dataReport input[type=checkbox]').prop('checked', false);
        if (commodityCustomizedGroupId == userIdChecked) {
            localStorageService.clear('userIdChecked');
            $scope.chooseItemTab1 = '';
            $scope.applyId='';
            $scope.applyRelationId='';
            $scope.state='';
        } else {
            $('#dataReport input[type=checkbox]').eq(index).prop('checked', true);
            localStorageService.update('userIdChecked', commodityCustomizedGroupId);
            $scope.chooseItemTab1 = commodityCustomizedGroupId;
            $scope.applyId = applyId;
            $scope.applyRelationId=applyRelationId;
            $scope.state=state;
        }
        if ($scope.chooseUserData.applyId != null) {
            console.log($scope.chooseUserData.applyId)
            $scope.hideRoleaut=false;
            $scope.showRoleaut=false;
        }else{
            $scope.showRoleaut=true;
            $scope.hideRoleaut=true;
        };
        if ($scope.chooseUserData.applyRelationId != null) {
            console.log($scope.chooseUserData.applyRelationId)
            $scope.CYhideRoleaut=false;
            $scope.CYshowRoleaut=false;
        }else{
            $scope.CYshowRoleaut=true;
            $scope.CYhideRoleaut=true;
        };
    };
    // 存储选中
    $scope.switchUserId = function (parameter, responseData) {
        $timeout(function () {
            for (var i = 0; i < responseData.length; i++) {
                if (parameter == responseData[i].commodityCustomizedGroupId) {
                    $('#dataReport input[type=checkbox]').eq(i).prop('checked', true);
                    return;
                }
            }
        }, 1500)
    };

    $scope.apply = function () {
        if (!$scope.chooseItemTab1) {
            $rootScope.tipService.setMessage('请先选择个性化组', 'warning');
        } else {
            $scope.auditshow = true;
            $scope.addEditTexts = "申请变更"
            $scope.applyId= $scope.chooseUserData.applyId;
            $scope.commodityCustomizedGroupId= $scope.chooseUserData.commodityCustomizedGroupId;
            $scope.commodityCustomizedGroupName= $scope.chooseUserData.commodityCustomizedGroupName;
            $scope.commodityId= $scope.chooseUserData.commodityId;
            $scope.orgCode= $scope.chooseUserData.orgCode;
            $scope.orgId= $scope.chooseUserData.orgId;
            $scope.state= $scope.chooseUserData.state;
            $scope.type= $scope.chooseUserData.type;
            $scope.customizedValue= $scope.chooseUserData.customizedValue;
            //匹配机构代码
            var json = {
                page: 1,
                rows: 9999,
                search_A_EQ_state: 1
            };
            dataSer.getOrganize(json).then(function (res) {
                if (res.code == '000000') {
                    $scope.equalOrgCode = JSON.parse(res.content).content;
                    //console.log($scope.equalOrgCode);
                    for (var i = 0; i < $scope.equalOrgCode.length; i++) {
                        if ($scope.chooseUserData.orgId == $scope.equalOrgCode[i].orgId) {
                            $scope.addOrgVal = $scope.equalOrgCode[i].orgName + '(' + $scope.equalOrgCode[i].orgNum + ')';
                            //console.log($scope.addOrgVal)
                        }
                    }
                } else {
                    console.log(res);
                }
            });
        }
    }

    $scope.applySubmit=function(){
        var configCommodityCustomizedGroupVIce= {
            commodityCustomizedGroupId:$scope.commodityCustomizedGroupId,
            commodityCustomizedGroupName:$scope.commodityCustomizedGroupName,
            commodityId: $scope.commodityId,
            orgId: $scope.orgId,
            orgCode: $scope.orgCode,
            type: parseInt($scope.type),
            customizedValue: parseFloat($scope.customizedValue),
        }
        var json = {
            configCommodityCustomizedGroupVIce: configCommodityCustomizedGroupVIce
        }
        PersonalizationgroupCtrlSer.tradeapply(json)
            .then(function (res) {
                if (res.data.code == "000000") {
                    $scope.auditshow = false;
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                    localStorageService.clear('userIdChecked');
                    $scope.search();
                }else{
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                }
            },function(error){
                $rootScope.tipService.setMessage(error.data.message, 'warning');
            })
    }

    $scope.getaudit=function () {
        if (!$scope.applyId) {
            $rootScope.tipService.setMessage('请先申请个性化组变更', 'warning');
        } else {
            var json={
                applyId:$scope.applyId
            }
            PersonalizationgroupCtrlSer.Getaudit(json)
                .then(function(res){
                    console.log(res)
                    if(res.data.code=="000000"){
                        var getData=JSON.parse(res.data.content);
                        $scope.getaduitDatalist=getData.configCommodityCustomizedGroupV;
                        console.log($scope.getaduitDatalist)
                        $scope.addEditText = "审核变更";
                        $scope.auditGetshow = true;
                        $scope.commodityCustomizedGroupId= $scope.getaduitDatalist.commodityCustomizedGroupId;
                        $scope.commodityCustomizedGroupName= $scope.getaduitDatalist.commodityCustomizedGroupName;
                        $scope.commodityId= $scope.getaduitDatalist.commodityId;
                        $scope.orgId= $scope.getaduitDatalist.orgId;
                        $scope.orgCode= $scope.getaduitDatalist.orgCode;
                        $scope.type= $scope.getaduitDatalist.type;
                        $scope.customizedValue= $scope.getaduitDatalist.customizedValue;
                        $scope.state= $scope.getaduitDatalist.state;
                        //匹配机构代码
                        var json = {
                            page: 1,
                            rows: 9999,
                            search_A_EQ_state: 1
                        };
                        dataSer.getOrganize(json).then(function (res) {
                            if (res.code == '000000') {
                                $scope.equalOrgCode = JSON.parse(res.content).content;
                                //console.log($scope.equalOrgCode);
                                for (var i = 0; i < $scope.equalOrgCode.length; i++) {
                                    if ($scope.chooseUserData.orgId == $scope.equalOrgCode[i].orgId) {
                                        $scope.addOrgVal = $scope.equalOrgCode[i].orgName + '(' + $scope.equalOrgCode[i].orgNum + ')';
                                        //console.log($scope.addOrgVal)
                                    }
                                }
                            } else {
                                console.log(res);
                            }
                        });
                    }
                })

        }
    }

    $scope.auditRoletrueData = function (tmpOpt) {
        var json = {
            applyId: $scope.applyId,
            auditRs: tmpOpt
        };
        PersonalizationgroupCtrlSer.auditRoletruetion(json)
            .then(function (res) {
                if (res.data.code == '000000') {
                    $scope.auditGetshow = false;
                    localStorageService.clear('userIdChecked');
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                    $scope.search();
                } else {
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                }
            },function(error) {
                $rootScope.tipService.setMessage(error.data.message, 'warning');
            })
    }
    $scope.auditRolefalseData = function (tmpOpt) {
        var json = {
            applyId: $scope.applyId,
            auditRs: tmpOpt
        };
        PersonalizationgroupCtrlSer.auditRoletruetion(json)
            .then(function (res) {
                if (res.data.code == '000000') {
                    $scope.auditGetshow = false;
                    localStorageService.clear('userIdChecked');
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                    $scope.search();
                } else {
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                }
            },function(error) {
                $rootScope.tipService.setMessage(error.data.message, 'warning');
            })
    }

    $scope.addmember = function () {
        if (!$scope.chooseItemTab1) {
            $rootScope.tipService.setMessage('请先选择个性化组', 'warning');
        } else {
            $scope.Vacationtableshow = true;
            $scope.addEditText = "申请成员变更";
            $scope.type= "";
            $scope.addUesrVal="";
            $scope.addLrgVal="";
        }
    }

    $scope.VacationaddSubmit= function () {
        var configCustomizedGroupRelationVIce={
            commodityCustomizedGroupId:$scope.commodityCustomizedGroupId,
                members:[
                {
                    userId:$scope.userId,
                    orgId:$scope.orgId,
                    type:$scope.type
                }
            ]
        }
        var json={
            configCustomizedGroupRelationVIce:configCustomizedGroupRelationVIce
        }
        PersonalizationgroupCtrlSer.CustomizedData(json)
            .then(function (res){
                console.log(res)
            })
    }

    $scope.showWeek=true;
    $scope.hideTime=true;
    $scope.typeval=function(){
        if($scope.type==1){
            $scope.showWeek=false;
            $scope.hideTime=true;
            $scope.type=parseInt($scope.type);
            $scope.assignDay="";
        }else if($scope.type==2){
            $scope.hideTime=false;
            $scope.showWeek=true;
            $scope.type=parseInt($scope.type);
            $scope.weekDay="";
        }else{
            $scope.showWeek=true;
            $scope.hideTime=true;
        }

    }

    $scope.orgtypeData = [{
        name: '用户',
        val:'1'
    }, {
        name: '机构',
        val:'2'
    }];
    $scope.orgtypeText = function (val) {
        for (var i = 0, r = $scope.orgtypeData.length; i < r; i++) {
            if (val == $scope.orgtypeData[i].val) {
                return $scope.orgtypeData[i].name;
            }
        }
    }
    $scope.showtable=function(){
        $scope.Vacationtableshow = false;
        $scope.type= "";
        $scope.userId= "";
        $scope.orgId = "";
        $scope.addUesrVal="";
        $scope.addLrgVal="";
        localStorageService.clear('userIdChecked');
        $scope.search();
    }

    PersonalizationgroupCtrlSer.userIdshlist()
        .then(function(res){
            if(res.code=="000000"){
                console.log(res)
                $scope.userIdls=JSON.parse(res.content);
                console.log($scope.userIdls)
                $scope.userIdName=function(userId){
                    for (var i = 0, r = $scope.userIdls.length; i < r; i++) {
                        if (userId == $scope.userIdls[i].userId) {
                            return $scope.userIdls[i].loginName;
                        }
                    }

                }
            }else{
                $rootScope.tipService.setMessage(res.message, 'warning');
            }
        },function(error) {
            $rootScope.tipService.setMessage(error.message, 'warning');
        })


    $scope.addUesrValFTC= function (dd) {
        console.log(dd);
        $scope.userId = dd.userId;
        $scope.addUesrVal = dd.loginName;
    }


    $scope.addLrgValFTC = function (dl) {
        console.log(dl)
        console.log(dl);
        $scope.orgId = dl.orgId;
        $scope.orgCode = dl.orgCode;
        $scope.addLrgVal = dl.text;
    }

    $scope.members=[];
    $scope.addrule = function() {
        if($scope.type==1){
            var SingleRuleData={
                userId:$scope.userId,
                type:$scope.type,
            }
        }else if($scope.type==2){
            var SingleRuleData={
                orgId:$scope.orgId,
                type:$scope.type,
            }
        }

        console.log(SingleRuleData)
        $scope.members.push(SingleRuleData);
        console.log($scope.members)
    };

    $scope.deletesd = function(index) {
        $scope.members.splice(index, 1);
    };
    $scope.VacationaddSubmit = function () {
        var configCustomizedGroupRelationVIce = {
            commodityCustomizedGroupId: $scope.chooseItemTab1,
            members: $scope.members,
        }

        var json = {
            configCustomizedGroupRelationVIce: configCustomizedGroupRelationVIce
        }
        PersonalizationgroupCtrlSer.VacationAddsub(json)
            .then(function (res) {
                if (res.data.code == "000000") {
                    $scope.Vacationtableshow = false;
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                    localStorageService.clear('userIdChecked');
                    $scope.search();
                }else{
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                }
            }, function (error) {
                $rootScope.tipService.setMessage(error.data.message, 'warning');
            })
    }


    $scope.auditmember=function () {
        if (!$scope.applyRelationId) {
            $rootScope.tipService.setMessage('请先申请成员变更', 'warning');
        } else {
            var json={
                applyId:$scope.applyRelationId
            }
            PersonalizationgroupCtrlSer.memGetaudit(json)
                .then(function(res){
                    console.log(res)
                    if(res.data.code=="000000"){
                        var getData=JSON.parse(res.data.content);
                        $scope.getaduitDatalist=getData.relationVs;
                        console.log($scope.getaduitDatalist)
                        $scope.addEditText = "审核成员变更";
                        $scope.sxtableshow = true;
                        // $scope.commodityCustomizedGroupId= $scope.getaduitDatalist.commodityCustomizedGroupId;
                        // $scope.commodityCustomizedGroupName= $scope.getaduitDatalist.commodityCustomizedGroupName;
                        // $scope.commodityId= $scope.getaduitDatalist.commodityId;
                        // $scope.orgId= $scope.getaduitDatalist.orgId;
                        // $scope.orgCode= $scope.getaduitDatalist.orgCode;
                        // $scope.type= $scope.getaduitDatalist.type;
                        // $scope.customizedValue= $scope.getaduitDatalist.customizedValue;
                        // $scope.state= $scope.getaduitDatalist.state;
                        //匹配机构代码
                        var json = {
                            page: 1,
                            rows: 9999,
                            search_A_EQ_state: 1
                        };
                        dataSer.getOrganize(json).then(function (res) {
                            if (res.code == '000000') {
                                $scope.equalOrgCode = JSON.parse(res.content).content;
                                //console.log($scope.equalOrgCode);
                                for (var i = 0; i < $scope.equalOrgCode.length; i++) {
                                    if ($scope.chooseUserData.orgId == $scope.equalOrgCode[i].orgId) {
                                        $scope.addOrgVal = $scope.equalOrgCode[i].orgName + '(' + $scope.equalOrgCode[i].orgNum + ')';
                                        //console.log($scope.addOrgVal)
                                    }
                                }
                            } else {
                                console.log(res);
                            }
                        });
                    }
                })

        }
    }

    $scope.RoletrueData = function (tmpOpt) {
        var json = {
            applyId: $scope.applyRelationId,
            auditRs: tmpOpt
        };
        PersonalizationgroupCtrlSer.Roletruetion(json)
            .then(function (res) {
                if (res.data.code == '000000') {
                    $scope.sxtableshow = false;
                    localStorageService.clear('userIdChecked');
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                    $scope.search();
                } else {
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                }
            },function(error) {
                $rootScope.tipService.setMessage(error.data.message, 'warning');
            })
    }
    $scope.RolefalseData = function (tmpOpt) {
        var json = {
            applyId: $scope.applyRelationId,
            auditRs: tmpOpt
        };
        PersonalizationgroupCtrlSer.Roletruetion(json)
            .then(function (res) {
                if (res.data.code == '000000') {
                    $scope.sxtableshow = false;
                    localStorageService.clear('userIdChecked');
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                    $scope.search();
                } else {
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                }
            },function(error) {
                $rootScope.tipService.setMessage(error.data.message, 'warning');
            })
    }

    $scope.pass=function() {
        if (!$scope.chooseItemTab1) {
            $rootScope.tipService.setMessage('请先选择个性化组信息', 'warning');
        } else {
            var json={
                commodityCustomizedGroupId:$scope.chooseItemTab1
            }
            PersonalizationgroupCtrlSer.passCheck(json)
                .then(function (res) {
                    if (res.data.code == '000000') {
                        localStorageService.clear('userIdChecked');
                        $rootScope.tipService.setMessage(res.data.message, 'warning');
                        $scope.search();
                    } else {
                        $rootScope.tipService.setMessage(res.data.message, 'warning');
                    }
                }, function (error) {
                    $rootScope.tipService.setMessage(error.data.message, 'warning');
                });
        }
    }
    $scope.fail=function() {
        if (!$scope.chooseItemTab1) {
            $rootScope.tipService.setMessage('请先选择个性化组信息', 'warning');
        } else {
            var json={
                commodityCustomizedGroupId:$scope.chooseItemTab1
            }
            PersonalizationgroupCtrlSer.failedCheck(json)
                .then(function (res) {
                    if (res.data.code == '000000') {
                        localStorageService.clear('userIdChecked');
                        $rootScope.tipService.setMessage(res.data.message, 'warning');
                        $scope.search();
                    } else {
                        $rootScope.tipService.setMessage(res.data.message, 'warning');
                    }
                }, function (error) {
                    $rootScope.tipService.setMessage(error.data.message, 'warning');
                });
        }
    }
    $scope.open=function() {
        if (!$scope.chooseItemTab1) {
            $rootScope.tipService.setMessage('请先选择个性化组信息', 'warning');
        } else {
            var json={
                commodityCustomizedGroupId:$scope.chooseItemTab1
            }
            PersonalizationgroupCtrlSer.open(json)
                .then(function (res) {
                    if (res.data.code == '000000') {
                        localStorageService.clear('userIdChecked');
                        $rootScope.tipService.setMessage(res.data.message, 'warning');
                        $scope.search();
                    } else {
                        $rootScope.tipService.setMessage(res.data.message, 'warning');
                    }
                }, function (error) {
                    $rootScope.tipService.setMessage(error.data.message, 'warning');
                });
        }
    }

    $scope.close=function() {
        if (!$scope.chooseItemTab1) {
            $rootScope.tipService.setMessage('请先选择个性化组信息', 'warning');
        } else {
            confirmService.set('确认提示', '确定要注销此个性化组信息?', function () {
                var json={
                    commodityCustomizedGroupId:$scope.chooseItemTab1
                }
                PersonalizationgroupCtrlSer.Close(json)
                    .then(function (res) {
                        if (res.data.code == '000000') {
                            localStorageService.clear('userIdChecked');
                            $rootScope.tipService.setMessage(res.data.message, 'warning');
                            $scope.search();
                        } else {
                            $rootScope.tipService.setMessage(res.data.message, 'warning');
                        }
                    }, function (error) {
                        $rootScope.tipService.setMessage(error.data.message, 'warning');
                    });
                confirmService.clear();
            });
        }
    }

}])
    .factory('PersonalizationgroupCtrlSer', ['$http', 'localStorageService', 'myHttp', '$q', '$rootScope', function ($http, localStorageService, myHttp, $q, $rootScope) {
        return {
            //查询
            search: function (json) {
                var deferred = $q.defer();
                myHttp.post("admin/commodity/customized/group/query/page", json)
                    .then(function (res) { // 调用承诺API获取数据 .resolve
                        deferred.resolve(res);
                    }, function (res) { // 处理错误 .reject
                        deferred.reject(res);
                    });
                return deferred.promise;
            },
            searchlist:function(){
                var deferred = $q.defer();
                myHttp.post("admin/config/product/commodity/query/list")
                    .then(function (res) { // 调用承诺API获取数据 .resolve
                        deferred.resolve(res);
                    }, function (res) { // 处理错误 .reject
                        deferred.reject(res);
                    });
                return deferred.promise;
            },
            Addsub: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'admin/commodity/customized/group/create',
                    data: json
                }).then(function successCallback(response) {
                    console.log(response)
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
            tradeapply: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'admin/commodity/customized/group/apply',
                    data: json
                }).then(function successCallback(response) {
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
            Getaudit: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'admin/commodity/customized/group/apply/get',
                    data: json
                }).then(function successCallback(response) {
                    console.log(response)
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
            auditRoletruetion: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'admin/commodity/customized/group/audit',
                    data: json
                }).then(function successCallback(response) {
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
            CustomizedData: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'admin/commodity/customized/group/member/add',
                    data: json
                }).then(function successCallback(response) {
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },

            userIdshlist:function(){
                var deferred = $q.defer();
                myHttp.post("user/query/customer/as/list")
                    .then(function (res) { // 调用承诺API获取数据 .resolve
                        deferred.resolve(res);
                    }, function (res) { // 处理错误 .reject
                        deferred.reject(res);
                    });
                return deferred.promise;
            },
            VacationAddsub: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'admin/commodity/customized/group/member/add',
                    data: json
                }).then(function successCallback(response) {
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
            memGetaudit: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'admin/commodity/customized/group/member/add/apply/get',
                    data: json
                }).then(function successCallback(response) {
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
            Roletruetion: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'admin/commodity/customized/group/member/audit',
                    data: json
                }).then(function successCallback(response) {
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
            Close: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'admin/commodity/customized/group/close',
                    data: json
                }).then(function successCallback(response) {
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
            //通过
            passCheck: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'admin/commodity/customized/group/pass',
                    data: json
                }).then(function successCallback(response) {
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
            //不通过
            failedCheck: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'admin/commodity/customized/group/fail',
                    data: json
                }).then(function successCallback(response) {
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
            //重新提交
            open: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'admin/commodity/customized/group/open',
                    data: json
                }).then(function successCallback(response) {
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
        }
    }])
