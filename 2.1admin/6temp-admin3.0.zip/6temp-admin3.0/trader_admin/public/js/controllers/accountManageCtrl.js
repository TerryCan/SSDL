app.controller('accountManageCtrl', ['$rootScope', '$scope', 'accountManageAll', 'getPageNum', 'getBankState', 'confirmService', 'localStorageService', '$timeout', function ($rootScope, $scope, accountManageAll, getPageNum, getBankState, confirmService, localStorageService, $timeout) {
    $scope.toggleTraderSearchState = false;
    $scope.Toggle = function () {
        $scope.toggleTraderSearchState = !$scope.toggleTraderSearchState;
        if ($scope.toggleTraderSearchState) {
            $('.search_column').css('height', 'auto');
        }
        else {
            $('.search_column').css('height', '36px');
        }
    };

    localStorageService.clear('userIdChecked');
    //数据转换
    //机构码匹配
    var saveOrganizeData = localStorageService.get('organizeData');
    $scope.switchOrganize = function (parameter) {
        for (var i = 0; i < saveOrganizeData.length; i++) {
            if (parameter == saveOrganizeData[i].orgCode) {
                return saveOrganizeData[i].orgNum;
            }
        }
    };
    //获取银行
    $scope.getBankNum = function () {
        accountManageAll.mainBank()
            .then(function (res) {
                $scope.bankNameList = JSON.parse(res.content);
                console.log($scope.bankNameList);
            })
    };
    $scope.getBankNum();
    $scope.bankList = function (parameter) {
        for (i = 0; i < $scope.bankNameList.length; i++) {
            if (parameter == $scope.bankNameList[i].id) {
                return $scope.bankNameList[i].bankName
            }
        }
    };
    $scope.bankState = getBankState;
    $scope.getBank = function (parameter) {
        for (i = 0; i < getBankState.length; i++) {
            if (parameter == getBankState[i].id) {
                return getBankState[i].name
            }
        }
    };

    var processContent, processTotal;
    var source = {
        type: 'POST',
        datatype: "json",
        datafields: [  //数据字段定义
            {name: 'userId', type: 'string'},
            {name: 'userName', type: 'string'},
            {name: 'identityCard', type: 'string'},
            {name: 'cardName', type: 'string'},
            {name: 'cardNo', type: 'string'},

            {name: 'recvTgfi', type: 'string'},
            {name: 'recvBankNm', type: 'string'},
            {name: 'cusMobile', type: 'string'},
            {name: 'status', type: 'string'}
        ],
        url: $rootScope.baseUrl + 'exbank/bankaccount/signup/query/page',
        root: "content",
        pagesize: 10,
        processData: function (data) {
            data.page = (data.pagenum + 1) ? (data.pagenum + 1) : 1;
            data.rows = (data.pagesize) ? (data.pagesize) : 10;
            // data.order = ($scope.order) ? $scope.order : 'desc';
            // data.sort = ($scope.sort) ? $scope.sort : 'createTime';
            data.search_A_EQ_userId = ($scope.directiveUserId) ? $scope.directiveUserId : '';
            data.search_A_EQ_custBank = ($scope.custBankSign) ? $scope.custBankSign : '';
            data.search_A_LIKE_cardNo = ($scope.cardNo) ? $scope.cardNo : '';
            data.search_A_LIKE_cardName = ($scope.cardName) ? $scope.cardName : '';
            data.search_A_EQ_status = ($scope.signUpState) ? $scope.signUpState : '';
        }, //传递参数处理
        beforeLoadComplete: function (records) { //数据完全加载完执行绘制表格
            var start;
            for (var i in records) {
                start = parseInt(i);
                break;
            }
            for (var k = 0, r = processContent.length; k < r; k++) {
                records[start + k].userId = processContent[k].userId;
                records[start + k].userName = processContent[k].userName;
                records[start + k].identityCard = processContent[k].identityCard;
                records[start + k].cardName = processContent[k].cardName;
                records[start + k].cardNo = processContent[k].cardNo;

                records[start + k].recvTgfi = processContent[k].recvTgfi;
                records[start + k].recvBankNm = processContent[k].recvBankNm;
                records[start + k].cusMobile = processContent[k].cusMobile;
                records[start + k].status = processContent[k].status;
            }
        },
        beforeprocessing: function (data) { //处理总页数
            var processData = JSON.parse(data.content);
            console.log(processData)
            processContent = processData.content;
            source.totalrecords = processData.totalElements == 0 ? 5 : processData.totalElements;
            processTotal = processData.totalElements;
        },
        loadComplete: function (records) {
            $scope.saveResult = JSON.parse(records.content);
            var data = $scope.saveResult.totalElements;
            if (data == 0) {
                $('#contenttableentrustDetailGrid > div').remove();
            }
        },
        endUpdate: true
    };
    //创建数据适配器
    var dataAdapter = null;
    $scope.searchAjax = function () {
        $scope.featureShow = true;
        $scope.toggleTraderSearchState = false;
        $('.search_column').css('height', '36px');
        if (dataAdapter == null) {
            dataAdapter = new $.jqx.dataAdapter(source);
            //创建表格
            $("#entrustDetailGrid").jqxGrid({
                source: dataAdapter,
                columns: [  //表格数据域
                    {
                        text: '用户名',
                        datafield: 'userName',
                        width: '12%',
                        minwidth: 12 + '%',//设置列min宽
                        align: 'center'//设置表头
                    },
                    {
                        text: '身份证号',
                        datafield: 'identityCard',
                        minwidth: 12 + '%',
                        cellsalign: 'center',
                        align: 'center',
                        width: '12%'
                    },
                    {
                        text: '开户名',
                        datafield: 'cardName',
                        width: '12%',
                        minwidth: 12 + '%',
                        align: 'center'
                    },
                    {
                        text: '银行卡号',
                        datafield: 'cardNo',
                        width: '12%',
                        minwidth: 12 + '%',
                        align: 'center'
                    },
                    {
                        text: '支行行号',
                        datafield: 'recvTgfi',
                        width: '12%',
                        minwidth: 12 + '%',
                        align: 'center'
                    },
                    {
                        text: '签约银行',
                        datafield: 'recvBankNm',
                        width: '16%',
                        minwidth: 16 + '%',
                        align: 'center'
                    },
                    {
                        text: '手机号',
                        datafield: 'cusMobile',
                        width: '12%',
                        minwidth: 12 + '%',
                        align: 'center'
                    },
                    {
                        text: '签约状态',
                        datafield: 'status',
                        width: '12%',
                        minwidth: 12 + '%',
                        align: 'center',
                        cellsrenderer: function (row, columnfield, value, defaulthtml, columnproperties) {
                            if (getBankState) {
                                for (var i = 0; i < getBankState.length; i++) {
                                    if (value == getBankState[i].id) {
                                        return getBankState[i].name;
                                    }
                                }
                            }
                        }
                    },
                ],
                width: 100 + '%',
                height: 81 + '%',
                theme: 'metrodark',
                virtualmode: true,
                rendergridrows: function (params) { //将数据渲染到页面
                    return params.data;
                },
                pageable: true,
                pagesizeoptions: ['10', '30', '100', '200'],
                // sortable: true,
                columnsresize: true,//列间距是否可调整
                clipboard: true
            });
        } else {
            $("#entrustDetailGrid").jqxGrid('updatebounddata', 'cells');
        }
    };

    //分页
    $("#entrustDetailGrid").on("pagechanged", function (event) {
        console.log(event)
    });
    //排序
    $("#entrustDetailGrid").on("sort", function (event) {
        var sortinformation = event.args.sortinformation;
        $scope.sort = sortinformation.sortcolumn;
        $scope.order = ($scope.sort) ? (sortinformation.sortdirection.ascending) ? 'asc' : 'desc' : 'asc';
        data = {
            order: $scope.order,
            sort: $scope.sort
        };
        source.processData(data);
        $("#entrustDetailGrid").jqxGrid('updatebounddata', 'sort');
    });
    //选中
    $('#entrustDetailGrid').on('rowselect', function (event) {
        $scope.userId = event.args.row.userId;
    });


    $scope.forceSign = function () {
        if (!$scope.userId) {
            $rootScope.tipService.setMessage('请先选择用户', 'warning');
        } else {
            var json = {
                userId: $scope.userId
            };
            accountManageAll.forceUnSign(json)
                .then(function (res) {
                    $rootScope.tipService.setMessage(res.message, 'warning');
                    $scope.searchAjax();
                }, function (error) {
                    $rootScope.tipService.setMessage(error.message, 'warning');
                });
            confirmService.clear();
        }
    };
    $scope.signDetail = function () {
        if (!$scope.userId) {
            $rootScope.tipService.setMessage('请先选择用户', 'warning');
        } else {
            var json = {
                page: 1,
                rows: 9999,
                'search_LIKE_accountMain.userId': $scope.userId
            };
            accountManageAll.signDetail(json)
                .then(function (res) {
                    if (res.code == '000000') {
                        var signNum = JSON.parse(res.content);
                        if (signNum.content.length == 0) {
                            $rootScope.tipService.setMessage('该用户未签约!', 'warning');
                        } else {
                            $scope.signColumn = true;
                            console.log(JSON.parse(res.content));
                            $scope.signResult = JSON.parse(res.content).content[0];
                            $scope.searchAjax();
                        }
                    }
                }, function (error) {
                    $rootScope.tipService.setMessage(error.message, 'warning');
                });
            confirmService.clear();
        }
    };
    $scope.handSign = function () {
        if (!$scope.userId) {
            $rootScope.tipService.setMessage('请先选择用户', 'warning');
        } else {
            var json = {
                userId: $scope.userId
            };
            accountManageAll.handSign(json)
                .then(function (res) {
                    $rootScope.tipService.setMessage(res.message, 'warning');
                    $scope.searchAjax();
                }, function (error) {
                    $rootScope.tipService.setMessage(error.message, 'warning');
                });
            confirmService.clear();
        }
    }
}])

// Server  账户管理
    .factory('accountManageAll', ['$http', 'localStorageService', 'myHttp', '$q', '$rootScope', function ($http, localStorageService, myHttp, $q, $rootScope) {
        return {
            // 表单形式提交
            unitSearch: function (json) {
                var deferred = $q.defer();
                myHttp.post("exbank/bankaccount/signup/query/page", json)
                    .then(function (res) {
                        deferred.resolve(res);
                    }, function (res) {
                        deferred.reject(res);
                    });
                return deferred.promise;
            },
            handSign: function (json) {
                var deferred = $q.defer();
                $http({
                    method: "POST",
                    url: $rootScope.baseUrl + "exbank/sign/on/manual",
                    data: json,
                    headers: {
                        'Content-Type': 'application/json;charset=UTF-8'
                    }
                }).success(function (res) {
                    deferred.resolve(res);
                }).error(function (res) {
                    deferred.reject(res);
                });
                return deferred.promise;
            },
            signDetail: function (json) {
                var deferred = $q.defer();
                myHttp.post("exbank/bankaccount/signup/query/page", json)
                    .then(function (res) {
                        deferred.resolve(res);
                    }, function (res) {
                        deferred.reject(res);
                    });
                return deferred.promise;
            },
            forceUnSign: function (json) {
                var deferred = $q.defer();
                $http({
                    method: "POST",
                    url: $rootScope.baseUrl + "exbank/sign/Off/manual",
                    data: json,
                    headers: {
                        'Content-Type': 'application/json;charset=UTF-8'
                    }
                }).success(function (res) {
                    deferred.resolve(res);
                }).error(function (res) {
                    deferred.reject(res);
                });
                return deferred.promise;
            },
            mainBank: function () {
                var data = new Object();
                var deferred = $q.defer();
                $http({
                    method: 'GET',
                    url: $rootScope.baseUrl + 'bank/area/mainbank',
                    data: data,
                    headers: {
                        'Content-Type': 'application/json;charset=UTF-8'
                    }
                }).success(function (res) {
                    deferred.resolve(res);
                }).error(function (res) {
                    deferred.reject(res);
                });
                return deferred.promise;
            }
        }
    }]);