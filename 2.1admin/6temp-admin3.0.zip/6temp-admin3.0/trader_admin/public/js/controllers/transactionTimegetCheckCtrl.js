app.controller("transactionTimegetCheckCtrl", ['$scope', '$rootScope', 'getweekType', 'get24h', 'dataSer', 'productClassificationCtrlSer', 'tipService', '$state', 'transactionTimeCtrlSer', 'transactionTimegetCheckCtrlSer', 'localStorageService', function($scope, $rootScope, getweekType, get24h, dataSer, productClassificationCtrlSer, tipService, $state, transactionTimeCtrlSer, transactionTimegetCheckCtrlSer, localStorageService) {
		$scope.goBack = function() {
			$state.go('tabs.transactionTime');
		}
		$scope.getweekType = getweekType;
		$scope.get24h = get24h;


		$scope.changeWeekText = function(val) {
				for (var i = 0, r = $scope.getweekType.length; i < r; i++) {
					if (val == $scope.getweekType[i].val) {
						return $scope.getweekType[i].name;
					}
				}
			}
			//开闭市时间显示转换
		$scope.timeRecover = function(val) {
			var time = Date.parse(new Date(val)) + 28800000;
			time = time / 1000 / 60 / 60;
			return parseInt(time) + ":00";
		}

		$scope.tradeTimeSubs = [];

		//明细
		$scope.copyProList = [];

		var transactionTimeId = localStorageService.get('TimegetCheck');
		transactionTimegetCheckCtrlSer.GetCheck(transactionTimeId)
			.then(function(res) {
				if (res.data.code == '000000') {
					//产品管理
					productClassificationCtrlSer.search(999999, 1, '', '', '', '', '')
						.then(function(res_data) {
							$scope.proList = JSON.parse(res_data.content);
							$scope.listResult = JSON.parse(res.data.content);

							$scope.transactionTimeName = $scope.listResult.transactionTimeName;
							$scope.transactionTimeType = $scope.listResult.transactionTimeType;
							$scope.tradeTimeProduct = $scope.listResult.tradeTimeProducts;
							$scope.tradeTimeSubs = $scope.listResult.tradeTimeSubs;
							for (var i = 0, r = $scope.tradeTimeProduct.length; i < r; i++) {
								var text;
								for (var s = 0, k = $scope.proList.content.length; s < k; s++) {
									if ($scope.proList.content[s].productId == $scope.tradeTimeProduct[i].productId) {
										text = $scope.proList.content[s].productName;
									}
								}
								$scope.copyProList.push({
									productId: $scope.tradeTimeProduct[i].productId,
									name: text
								});
							}
							for (var i = 0, r = $scope.listResult.tradeTimeSubs.length; i < r; i++) {

								$scope.endNum = $scope.listResult.tradeTimeSubs[i].endNum;
								$scope.endTime = $scope.listResult.tradeTimeSubs[i].endTime;
								$scope.startNum = $scope.listResult.tradeTimeSubs[i].startNum;
								$scope.startTime = $scope.listResult.tradeTimeSubs[i].startTime;
							}
							console.log($scope.copyProList);
						})

				}
			}, function(error) {
				$rootScope.tipService.setMessage(error.data.message, 'warning');
			});
}])

.factory('transactionTimegetCheckCtrlSer', ['$http', 'localStorageService', 'myHttp', '$q', '$rootScope', function($http, localStorageService, myHttp, $q, $rootScope) {
	return {

		//明细
		GetCheck: function(transactionTimeId) {
			var deferred = $q.defer();
			$http({
				method: 'POST',
				url: $rootScope.baseUrl + 'config/tradetime/get',
				data: {
					"tradeTimeId": transactionTimeId
				}
			}).then(function successCallback(response) {
				//console.log(response)
				deferred.resolve(response);
			}, function errorCallback(response) {
				deferred.reject(response);
			});
			return deferred.promise;
		}
	}
}])