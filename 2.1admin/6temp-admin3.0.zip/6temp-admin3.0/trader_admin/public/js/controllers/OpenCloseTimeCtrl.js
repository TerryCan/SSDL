app.controller('OpenCloseTimeCtrl', ['$rootScope', '$scope', 'OpenCloseTimeCtrlSer', 'getPageNum', '$state', 'confirmService', 'tipService', 'localStorageService', 'dataSer', 'getadminState','$timeout','timestamp', function ($rootScope, $scope, OpenCloseTimeCtrlSer, getPageNum, $state, confirmService, tipService, localStorageService, dataSer, getadminState,$timeout,timestamp) {
    $scope.toggleTraderSearchState = false;
    $scope.Toggle = function () {
        $scope.toggleTraderSearchState = !$scope.toggleTraderSearchState;
        if ($scope.toggleTraderSearchState) {
            $('.search_column').css('height', 'auto');
        }
        else {
            $('.search_column').css('height', '36px');
        }
    };
    $scope.ToState='';
    localStorageService.clear('userIdChecked');
    dataSer.organizeQuerySer()
        .then(function (res) {
            $scope.orgList = res;
            console.log($scope.orgList)
        });

   /* $scope.addOrgValFTC = function (data) {
        console.log(data);
        //$scope.orgId = data.orgId;
        //$scope.orgCode = data.orgCode;
        $scope.addOrgVal = data.text;
    }*/

    //全部状态下所属机构
    dataSer.organizeQuerylistSer()
        .then(function (res) {
            $scope.orgAllList = res;
        });

    $scope.adjustText = function (orgId) {
        if ($scope.orgAllList) {
            for (var i = 0, r = $scope.orgAllList.length; i < r; i++) {
                if ($scope.orgAllList[i].orgId == orgId) {
                    return $scope.orgAllList[i].text;
                }
            }
        }
    }

    $scope.search = function (type) {
        $scope.toggleTraderSearchState = false;
        $('.search_column').css('height', '36px');
        if (type == 'search') {
            pageInitialize()
        };
        $scope.orgCode=localStorageService.get('oldOrgCode');
        var json = {
            page: $scope.currentPage,
            rows: $scope.showNum.showNum,
            orders: 'asc',
            search_EQ_orgCode: ($scope.orgCode) ?  $scope.orgCode : '',
            search_EQ_state: $scope.ToState,
        };
        OpenCloseTimeCtrlSer.search(json)
            .then(function (res) {
                if (res.code === '000000') {
                    $scope.showPage = true;
                    var data = JSON.parse(res.content);
                    $scope.searchResult = data.content;
                    console.log($scope.searchResult);
                    $scope.dataNum = data.totalElements;
                    $scope.PageNum();

                    var checkedUserId=localStorageService.get('userIdChecked'); //获取上一次存储的id
                    $scope.switchUserId(checkedUserId,$scope.searchResult); //执行选中方法
                } else {
                    $rootScope.tipService.setMessage(res.message, 'warning');
                }
            }, function (error) {
                $rootScope.tipService.setMessage(error.message, 'warning');
            });
    }

    $scope.transactionTimeTypeData = [{
        name: '交易时间 ',
        val: '1'
    }, {
        name: '开闭市时间',
        val: '2'
    }];
    // 将毫秒转化为系统时间
    $scope.formatTime = function(parameter) {
        return timestamp.daySecondsToDate(parameter);
    };
    // 将毫秒转化为系统时间
    $scope.formatTimedata = function(parameter) {
        return timestamp.timestampCoverHms(parameter);
    };
    $scope.allotTypeText = function (val) {
        for (var i = 0, r = $scope.transactionTimeTypeData.length; i < r; i++) {
            if (val == $scope.transactionTimeTypeData[i].val) {
                return $scope.transactionTimeTypeData[i].name;
            }
        }
    }

    $scope.ProStateList = getadminState;
    $scope.getProStateList = function (params) {
        for (var i = 0, r = $scope.ProStateList.length; i < r; i++) {
            if (params == $scope.ProStateList[i].id) {
                return $scope.ProStateList[i].name;
            }
        }
    }


    $scope.showtable = function () {
        $scope.tableshow = false;
        //$scope.addOrgVal = "";
        $scope.startTime = "";
        $scope.endTime = "";
        $scope.days = "";
    }
    //新增
    $scope.tableshow = false;
    $scope.add = function () {
        $scope.tableshow = true;
        $scope.addEditText = '新增';
    }

    $scope.showaudit=true;
    $scope.hideaudit=true;

    // 选择
    $scope.checkedTab1 = function (index,applyId,orgId,orgCode,startTime, endTime,state) {
        $scope.chooseUserData = {
            applyId:applyId,
            orgId: orgId,
            orgCode: orgCode,
            startTime: startTime,
            endTime: endTime,
            state:state
        };
        console.log($scope.chooseUserData)
        var userIdChecked = localStorageService.get('userIdChecked');
        $('#dataReport input[type=checkbox]').prop('checked', false);
        if (orgId == userIdChecked) {
            localStorageService.clear('userIdChecked');
            $scope.chooseItemTab1 = '';
            $scope.state='';
            $scope.applyId='';
        } else {
            $('#dataReport input[type=checkbox]').eq(index).prop('checked', true);
            localStorageService.update('userIdChecked', orgId);
            $scope.chooseItemTab1 = orgId;
            $scope.state=state;
            $scope.applyId=applyId;
        }
        if($scope.chooseUserData.applyId==null){
            $scope.showaudit=true;
            $scope.hideaudit=true;
        }else{
            $scope.showaudit=false;
            $scope.hideaudit=false;
        }
    };
    // 存储选中
    $scope.switchUserId = function (parameter, responseData) {
        $timeout(function () {
            for (var i = 0; i < responseData.length; i++) {
                if (parameter == responseData[i].orgId) {
                    $('#dataReport input[type=checkbox]').eq(i).prop('checked', true);
                    return;
                }
            }
        }, 1500)
    };
    //修改
    $scope.edit = function () {
        if (!$scope.chooseItemTab1) {
            $rootScope.tipService.setMessage('请选择开闭市时间信息', 'warning');
        } else {
            $scope.tableshow = true;
            $scope.addEditText = "修改";
            $scope.orgId = $scope.chooseUserData.orgId,
            $scope.orgCode = $scope.chooseUserData.orgCode,
            $scope.startTime = $scope.formatTimedata($scope.chooseUserData.startTime);
            $scope.endTime = $scope.formatTimedata($scope.chooseUserData.endTime);
            //匹配机构代码
            var json = {
                page: 1,
                rows: 9999,
                search_A_EQ_state: 1
            };
            dataSer.getOrganize(json).then(function (res) {
                if (res.code == '000000') {
                    $scope.equalOrgCode = JSON.parse(res.content).content;
                    for (var i = 0; i < $scope.equalOrgCode.length; i++) {
                        if ($scope.chooseUserData.orgId == $scope.equalOrgCode[i].orgId) {
                            $scope.addOrgVal = $scope.equalOrgCode[i].orgName + '(' + $scope.equalOrgCode[i].orgNum + ')';
                        }
                    }
                } else {
                    console.log(res);
                }
            });
        }
    }
    $scope.orgId = "1@";
    $scope.orgCode = "ORG_ADMIN";
    $scope.addSubmit = function () {
        if ($scope.addEditText == "新增") {
           /* if ($scope.addOrgVal == undefined || $scope.addOrgVal == '') {
                $rootScope.tipService.setMessage('请选择机构编号', 'warning');
            } else */if ($scope.startTime == undefined || $scope.startTime == '') {
                $rootScope.tipService.setMessage('请输入开始时间', 'warning');
            } else if ($scope.endTime == undefined || $scope.endTime == '') {
                $rootScope.tipService.setMessage('请输入结束时间', 'warning');
            }else{
            var openCloseTimeV = {
                orgId: $scope.orgId,
                orgCode: $scope.orgCode,
                startTime: ($scope.startTime) ? timestamp.DateToSeconds($scope.startTime)*1000 : '',
                endTime: ($scope.endTime) ? timestamp.DateToSeconds($scope.endTime)*1000 : '',
            }
            var json = {
                openCloseTimeV: openCloseTimeV
            }

            OpenCloseTimeCtrlSer.addsub(json)
                .then(function (res) {
                    console.log()
                    if (res.data.code == "000000") {
                        $scope.tableshow = false;
                        $rootScope.tipService.setMessage(res.data.message, 'warning');
                        localStorageService.clear('userIdChecked');
                        $scope.search();
                    } else {
                        $rootScope.tipService.setMessage(res.data.message, 'warning');
                    }
                }, function (error) {
                    $rootScope.tipService.setMessage(error.data.message, 'warning');
                })
            }
        } else if ($scope.addEditText == "修改") {
            if ($scope.addOrgVal == undefined || $scope.addOrgVal == '') {
                $rootScope.tipService.setMessage('请选择机构编号', 'warning');
            } else if ($scope.startTime == undefined || $scope.startTime == '') {
                $rootScope.tipService.setMessage('请输入开始时间', 'warning');
            } else if ($scope.endTime == undefined || $scope.endTime == '') {
                $rootScope.tipService.setMessage('请输入结束时间', 'warning');
            }else {
                var openCloseTimeV = {
                    orgId: $scope.orgId,
                    orgCode: $scope.orgCode,
                    startTime: ($scope.startTime) ? timestamp.DateToSeconds($scope.startTime) * 1000 : '',
                    endTime: ($scope.endTime) ? timestamp.DateToSeconds($scope.endTime) * 1000 : '',
                }
                var json = {
                    openCloseTimeV: openCloseTimeV
                }
                OpenCloseTimeCtrlSer.editsub(json)
                    .then(function (res) {
                        console.log()
                        if (res.data.code == "000000") {
                            $scope.tableshow = false;
                            $rootScope.tipService.setMessage(res.data.message, 'warning');
                            localStorageService.clear('userIdChecked');
                            $scope.search();
                        } else {
                            $rootScope.tipService.setMessage(res.data.message, 'warning');
                        }
                    }, function (error) {
                        $rootScope.tipService.setMessage(error.data.message, 'warning');
                    })
            }
        }
    }

    $scope.audit=function () {
        if (!$scope.applyId) {
            $rootScope.tipService.setMessage('请先申请变更', 'warning');
        } else {
            var json={
                applyId:$scope.applyId
            }
            OpenCloseTimeCtrlSer.Get(json)
                .then(function(res){
                    console.log(res)
                    if(res.data.code=="000000"){
                        var getData=JSON.parse(res.data.content);
                        $scope.getDatalist=getData.openCloseTimeV;
                        console.log($scope.getDatalist)
                        $scope.addEditText = "审核变更";
                        $scope.tableshowxq = true;
                        $scope.orgId=$scope.getDatalist.orgId;
                        //$scope.orgCode=$scope.getDatalist.orgCode;
                        //匹配机构代码
                        var json = {
                            page: 1,
                            rows: 9999,
                            search_A_EQ_state: 1
                        };
                        dataSer.getOrganize(json).then(function (res) {
                            if (res.code == '000000') {
                                $scope.equalOrgCode = JSON.parse(res.content).content;
                                //console.log($scope.equalOrgCode);
                                for (var i = 0; i < $scope.equalOrgCode.length; i++) {
                                    if ($scope.orgId== $scope.equalOrgCode[i].orgId) {
                                        $scope.addOrgVal = $scope.equalOrgCode[i].orgName + '(' + $scope.equalOrgCode[i].orgNum + ')';
                                        //console.log($scope.addOrgVal)
                                    }
                                }
                            } else {
                                console.log(res);
                            }
                        });
                        $scope.startTime=$scope.formatTimedata($scope.getDatalist.startTime);
                        $scope.endTime=$scope.formatTimedata($scope.getDatalist.endTime);
                    }
                })

        }
    }

    $scope.RoletrueData = function (tmpOpt) {
        var json = {
            applyId: $scope.applyId,
            auditRs: tmpOpt
        };
        OpenCloseTimeCtrlSer.Roletruetion(json)
            .then(function (res) {
                if (res.data.code == '000000') {
                    $scope.tableshowxq = false;
                    localStorageService.clear('userIdChecked');
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                    $scope.search();
                } else {
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                }
            },function(error) {
                $rootScope.tipService.setMessage(error.data.message, 'warning');
            })
    }
    $scope.RolefalseData = function (tmpOpt) {
        var json = {
            applyId: $scope.applyId,
            auditRs: tmpOpt
        };
        OpenCloseTimeCtrlSer.Roletruetion(json)
            .then(function (res) {
                if (res.data.code == '000000') {
                    $scope.tableshowxq = false;
                    localStorageService.clear('userIdChecked');
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                    $scope.search();
                } else {
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                }
            },function(error) {
                $rootScope.tipService.setMessage(error.data.message, 'warning');
            })
    }


    //销毁
    $scope.close = function () {
        if (!$scope.chooseItemTab1) {
            $rootScope.tipService.setMessage('请先选择开闭市时间信息', 'warning');
        } else {
            //console.log($scope.chooseItemTab1);
            confirmService.set('确认提示', '确定要销毁此信息吗?', function () {
                var json = {
                    orgId: $scope.chooseItemTab1
                };
                OpenCloseTimeCtrlSer.Close(json)
                    .then(function (res) {
                        console.log(res)
                        if (res.data.code == "000000") {
                            $rootScope.tipService.setMessage(res.data.message, 'warning');
                            localStorageService.clear('userIdChecked');
                            $scope.search()
                        } else {
                            $rootScope.tipService.setMessage(res.data.message, 'warning');
                        }
                    }, function (error) {
                        $rootScope.tipService.setMessage(error.data.message, 'warning');
                    });
                confirmService.clear();
                // $scope.chooseItemTab1 = null;
            });
        }
    };

    //通过审核
    $scope.passCheck = function () {
        if (!$scope.chooseItemTab1) {
            $rootScope.tipService.setMessage('请先选择开闭市时间信息', 'warning');
        } else {
            var json = {
                orgId: $scope.chooseItemTab1
            };
            OpenCloseTimeCtrlSer.passCheck(json)
                .then(function (res) {
                    if (res.data.code == '000000') {
                        $rootScope.tipService.setMessage(res.data.message, 'warning');
                        localStorageService.clear('userIdChecked');
                        $scope.search();
                    }
                    else {
                        $rootScope.tipService.setMessage(res.data.message, 'warning');
                    }
                }, function (error) {
                    $rootScope.tipService.setMessage(error.data.message, 'warning');
                });
        }
    };
    //审核驳回
    $scope.failedCheck = function () {
        if (!$scope.chooseItemTab1) {
            $rootScope.tipService.setMessage('请先选择开闭市时间信息', 'warning');
        } else {
            var json = {
                orgId: $scope.chooseItemTab1
            };
            OpenCloseTimeCtrlSer.failedCheck(json)
                .then(function (res) {
                    if (res.data.code == '000000') {
                        $rootScope.tipService.setMessage(res.data.message, 'warning');
                        localStorageService.clear('userIdChecked');
                        $scope.search();
                    }
                    else {
                        $rootScope.tipService.setMessage(res.data.message, 'warning');
                    }
                }, function (error) {
                    $rootScope.tipService.setMessage(error.data.message, 'warning');
                });
        }
    };
    //重新审核
    $scope.rePassCheck = function () {
        if (!$scope.chooseItemTab1) {
            $rootScope.tipService.setMessage('请先选择开闭市时间信息', 'warning');
        } else {
            var json = {
                orgId: $scope.chooseItemTab1
            };
            OpenCloseTimeCtrlSer.open(json)
                .then(function (res) {
                    console.log(res)
                    if (res.data.code == '000000') {
                        $rootScope.tipService.setMessage(res.data.message, 'warning');
                        localStorageService.clear('userIdChecked');
                        $scope.search();
                    }
                    else {
                        $rootScope.tipService.setMessage(res.data.message, 'warning');
                    }
                }, function (error) {
                    $rootScope.tipService.setMessage(error.data.message, 'warning');
                });
        }
    };


    /**
     * 分页功能实现TerryMin
     * **/
    $scope.showDataChoose = getPageNum.pageNum(); //获取分页
    $scope.showNum = $scope.showDataChoose[0]; //初始显示刷具条数
    $scope.showPage = false;
    var pageInitialize = function () {
        $scope.dataNum = 0; //数据总条数
        $scope.dataPage = 0; //分页数
        $scope.currentPage = 1; //当前页数
        $scope.jumpPageNum = '';
    };
    pageInitialize();

    // x/y $scope.dataPage
    $scope.PageNum = function () {
        $scope.showPage = true;
        if ($scope.showNum.showNum < $scope.dataNum) {
            $scope.dataPage =Math.ceil($scope.dataNum / $scope.showNum.showNum);
        } else {
            $scope.dataPage = 0;
        }
    };
    //上页下页 $scope.currentPage
    $scope.pageSlect = function (type) {
        if (type == 'prev') {
            if ($scope.currentPage != 1) {
                $scope.currentPage--;
                $scope.PageNum();
                $scope.search();
            }
        } else {
            if ($scope.currentPage < $scope.dataPage) {
                $scope.currentPage++;
                $scope.PageNum();
                $scope.search();
            }
        }
    };
    // 每页条数单元
    $scope.pageSelect = function (params) {
        $scope.showNum.showNum = params.showNum;
        pageInitialize();
        $scope.search();
    };
    //页数跳转 currentPage
    $scope.jumpPage = function (num) {
        num = parseInt(num);
        if (parseInt(num, 10) === num && num <= ($scope.dataPage + 1) && num > 0) {
            $scope.currentPage = num;
            $scope.PageNum();
            $scope.search();
        }
    };
        $scope.OrgcleanVal=function(){
            $scope.addOrgVal='';
            $scope.orgCode='';
            $scope.orgId='';
        }
}])

    .factory('OpenCloseTimeCtrlSer', ['$http', 'localStorageService', 'myHttp', '$q', '$rootScope', function ($http, localStorageService, myHttp, $q, $rootScope) {
        return {
            search: function (json) {
                var deferred = $q.defer();
                myHttp.post("admin/config/openclose/time/page/query", json)
                    .then(function (res) { // 调用承诺API获取数据 .resolve
                        deferred.resolve(res);
                    }, function (res) { // 处理错误 .reject
                        deferred.reject(res);
                    });
                return deferred.promise;
            },
            // 新增
            addsub: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'admin/config/openclose/time/create',
                    data: json
                }).then(function successCallback(response) {
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
            // 修改
            editsub: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'admin/config/openclose/time/apply',
                    data: json
                }).then(function successCallback(response) {
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
            //销毁
            Close: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'admin/config/openclose/time/close',
                    data: json
                }).then(function successCallback(response) {
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
           /* //冻结
            freeze:function (json) {
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: $rootScope.baseUrl + 'admin/config/openclose/time/freeze',
                data: json
            }).then(function successCallback(response) {
                deferred.resolve(response);
            }, function errorCallback(response) {
                deferred.reject(response);
            });
            return deferred.promise;
        },
        //解冻
        unfreeze:function (json) {
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: $rootScope.baseUrl + 'admin/config/openclose/time/unfreeze',
                data: json
            }).then(function successCallback(response) {
                deferred.resolve(response);
            }, function errorCallback(response) {
                deferred.reject(response);
            });
            return deferred.promise;
        },*/
        //通过
        passCheck: function (json) {
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: $rootScope.baseUrl + 'admin/config/openclose/time/pass',
                data: json
            }).then(function successCallback(response) {
                deferred.resolve(response);
            }, function errorCallback(response) {
                deferred.reject(response);
            });
            return deferred.promise;
        },
        //不通过
        failedCheck: function (json) {
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: $rootScope.baseUrl + 'admin/config/openclose/time/fail',
                data: json
            }).then(function successCallback(response) {
                deferred.resolve(response);
            }, function errorCallback(response) {
                deferred.reject(response);
            });
            return deferred.promise;
        },
        //重新提交
        open: function (json) {
            var deferred = $q.defer();
            $http({
                method: 'POST',
                url: $rootScope.baseUrl + 'admin/config/openclose/time/open',
                data: json
            }).then(function successCallback(response) {
                deferred.resolve(response);
            }, function errorCallback(response) {
                deferred.reject(response);
            });
            return deferred.promise;
        },
            Get: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'admin/config/openclose/time/apply/get',
                    data: json
                }).then(function successCallback(response) {
                    console.log(response)
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
            Roletruetion: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'admin/config/openclose/time/audit',
                    data: json
                }).then(function successCallback(response) {
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
     }
    }])
