app.controller("prevSourceTradeProductCtrl", ['$rootScope', '$q', '$http', '$timeout', 'myHttp', '$scope', 'tradeProductSerAll', 'confirmService', 'getTradeStatus', 'getPageNum', 'localStorageService', function ($rootScope, $q, $http, $timeout, myHttp, $scope, tradeProductSerAll, confirmService, getTradeStatus, getPageNum, localStorageService) {
    localStorageService.clear('userIdChecked');
    // 状态
    $scope.tradeStatus = getTradeStatus;
    $scope.getTradeState = function (parameter) {
        for (var i = 0; i < $scope.tradeStatus.length; i++) {
            if (parameter == $scope.tradeStatus[i].id) {
                return $scope.tradeStatus[i].name;
            }
        }
    };
    //上手账号
    tradeProductSerAll.accountSearch().then(function (response) {
        if (response.retMsg.code == '000000') {
            $scope.accountList = response.list;
            console.log($scope.accountList);
        }
    });
    $scope.switchPreAccount = function (parameter) {
        for (var i = 0; i < $scope.accountList.length; i++) {
            if (parameter == $scope.accountList[i].key) {
                return $scope.accountList[i].key+'-'+$scope.accountList[i].name;
            }
        }
    };
    //可交易商品
    tradeProductSerAll.productSearch().then(function (res) {
        if (res.retMsg.code == '000000') {
            $scope.productList = res.list;
            console.log($scope.productList)
        }
    });
    $scope.switchProduct = function (parameter) {
        if($scope.productList){
            for (var i = 0; i < $scope.productList.length; i++) {
                if (parameter == $scope.productList[i].key) {
                    return $scope.productList[i].market+'-'+$scope.productList[i].commodity+'-'+$scope.productList[i].contract;
                }
            }
        }
    };

    //查询
    $scope.pre_account = '';
    $scope.tradeProduct = function () {
        tradeProductSerAll.Search()
            .then(function (response) {
                if (response.retMsg.code === '000000') {
                    $scope.tradeList = response.list;
                    console.log($scope.tradeList);
                    $scope.protocolSearchOther = $scope.pre_account;
                    pageJump($scope.tradeList);
                    var checkedUserId = localStorageService.get('userIdChecked');
                    $scope.switchUserId(checkedUserId, $scope.tradeList);
                } else {
                    $rootScope.tipService.setMessage(response.retMsg.message, 'warning');
                }
            }, function (error) {
                $rootScope.tipService.setMessage(error.message, 'warning');
            });
    };

    // 单选
    // 存储选中
    $scope.switchUserId = function (parameter, responseData) {
        $timeout(function () {
            for (var i = 0; i < responseData.length; i++) {
                if (parameter == responseData[i].key) {
                    $scope.chooseItemTab1 = parameter;
                    $('#dataReport input[type=checkbox]').eq(i).prop('checked', true);
                    return;
                }
            }
        }, 300)
    };
    $scope.tradeCheck = function (index, key) {
        // $('#dataReport input[type=checkbox]').prop('checked', false);
        // $('#dataReport input[type=checkbox]').eq(index).prop('checked', true);

        var userIdChecked = localStorageService.get('userIdChecked');
        $('#dataReport input[type=checkbox]').prop('checked', false);
        if (key == userIdChecked) {
            localStorageService.clear('userIdChecked');
            $scope.chooseItemTab1 = '';
        } else {
            $('#dataReport input[type=checkbox]').eq(index).prop('checked', true);
            localStorageService.update('userIdChecked', key);
            $scope.chooseItemTab1 = key;
        }
    };
    //上手可交易新增
    $scope.addEditText = '';
    $scope.newUserShow = false;
    $scope.addNewUser = function () {
        $scope.newUserShow = true;
        $scope.addEditText = '新增';
        $scope.account = '';
        $scope.product = '';
        $scope.state1 = '';
        $scope.state2 = '';
        $scope.tradeState = '';
    };
    $scope.addEditUserSubmit = function () {
        console.log($scope.product);
        var productArr = $scope.product.split("-");
        var symbol = productArr[0];
        var market = productArr[1];
        var commodity = productArr[2];
        var contract = productArr[3];
        if ($scope.state1 == true && $scope.state2 == true) {
            $scope.tradeState = 3;
        } else if ($scope.state1 == true) {
            $scope.tradeState = 1;
        } else if ($scope.state2 == true) {
            $scope.tradeState = 2;
        } else {
            $scope.tradeState = 0
        }
        $scope.addEditText == '新增'
        var upAccountSymbol = {
            key: '',
            account: $scope.account,
            symbol: symbol,
            market: market,
            commodity: commodity,
            contract: contract,
            state: $scope.tradeState
        };
        var json = {
            upAccountSymbol: upAccountSymbol
        };
        if (toValidate('#formAdd')) {
            tradeProductSerAll.Add(json)
                .then(function (res) {
                    $scope.newUserShow = false;
                    $rootScope.tipService.setMessage(res.message, 'warning');
                    $scope.copyDataArray = '';
                    $scope.tradeProduct();
                }, function (error) {
                    $rootScope.tipService.setMessage(error.message, 'warning');
                });
        }
    };
    //删除
    $scope.cancel = function () {
        if (!$scope.chooseItemTab1) {
            $rootScope.tipService.setMessage('请先选择商品!', 'warning');
        } else {
            confirmService.set('确认提示', '确定要删除此条记录吗?', function () {
                var json = {
                    key: $scope.chooseItemTab1
                };
                tradeProductSerAll.cancel(json)
                    .then(function (res) {
                        $rootScope.tipService.setMessage(res.message, 'warning');
                        $scope.copyDataArray = '';
                        $scope.tradeProduct();
                    }, function (error) {
                        $rootScope.tipService.setMessage(error.message, 'warning');
                    });
                confirmService.clear();
            });
        }
    };

    var pageJump = function (tmpArrList) {
        $timeout(function () {
            if (tmpArrList != undefined) {
                $scope.currentPage = 1; //当前页数
                $scope.dataNum = tmpArrList.length;
                $scope.showDataChoose = getPageNum.pageNum(); //获取分页
                $scope.showNum = $scope.showDataChoose[0]; //初始显示刷具条数
                $scope.showPage = false;
                $timeout(function () {
                    $scope.showPage = true;
                    $scope.copyDataArray = tmpArrList.slice(0, 14); //初始15条数据
                }, 10);
                $scope.dataPage = Math.ceil($scope.dataNum / $scope.showNum.showNum);

                //上下页
                $scope.pageSlect = function (type) {
                    if (type == 'prev') {
                        if ($scope.currentPage != 1) {
                            $scope.currentPage--;
                            $scope.turnPage();
                        } else {
                            $scope.copyDataArray = tmpArrList.slice(0, 14); //初始15条数据
                        }
                    } else {
                        if ($scope.currentPage < $scope.dataPage) {
                            $scope.currentPage++;
                            $scope.turnPage();
                        }
                    }
                };
                //每页数据量
                $scope.baseDataArray = [];
                $scope.copyDataArray = [];
                $scope.pageSelect = function (params) {
                    $scope.showNum.showNum = params.showNum;
                    $scope.copyDataArray = tmpArrList.slice(0, (params.showNum - 1));
                    $scope.dataPage = Math.ceil($scope.dataNum / $scope.showNum.showNum);
                    $scope.currentPage = 1;
                };
                $scope.turnPage = function () {
                    $scope.copyDataArray = tmpArrList.slice((($scope.currentPage - 1) * 15), (($scope.currentPage + 1) * 15 - 1));
                };
                //固定页面跳转
                $scope.jumpPage = function (num) {
                    num = parseInt(num);
                    if (parseInt(num, 10) === num && num <= ($scope.dataPage + 1) && num > 0) {
                        $scope.currentPage = num;
                        $scope.jumpPageNum = '';
                        $scope.turnPage();
                    } else {
                        $scope.copyDataArray = tmpArrList.slice(0, 14); //初始15条数据
                    }
                }
            } else {
                pageJump(tmpArrList);
            }
        }, 200);
    };
}])
    .factory('tradeProductSerAll', ['$q', '$http', '$rootScope', function ($q, $http, $rootScope) {
        return {
            Search: function () {
                var data = new Object();
                var deferred = $q.defer();
                $http({
                    method: "POST",
                    url: $rootScope.baseUrl + "c/up/account/symbol/query/all",
                    data: data,
                    headers: {
                        'Content-Type': 'application/json;charset=UTF-8'
                    }
                }).success(function (res) {
                    deferred.resolve(res);
                }).error(function (res) {
                    deferred.reject(res);
                });
                return deferred.promise;
            },
            Add: function (json) {
                var deferred = $q.defer();
                $http({
                    method: "POST",
                    url: $rootScope.baseUrl + "c/up/account/symbol/insert",
                    data: json,
                    headers: {
                        'Content-Type': 'application/json;charset=UTF-8'
                    }
                }).success(function (res) {
                    deferred.resolve(res);
                }).error(function (res) {
                    deferred.reject(res);
                });
                return deferred.promise;
            },
            cancel: function (json) {
                var deferred = $q.defer();
                $http({
                    method: "POST",
                    url: $rootScope.baseUrl + "c/up/account/symbol/delete",
                    data: json,
                    headers: {
                        'Content-Type': 'application/json;charset=UTF-8'
                    }
                }).success(function (res) {
                    deferred.resolve(res);
                }).error(function (res) {
                    deferred.reject(res);
                });
                return deferred.promise;
            },
            accountSearch: function () {
                var data = new Object();
                var deferred = $q.defer();
                $http({
                    method: "GET",
                    url: $rootScope.baseUrl + "c/up/account/query/all",
                    data: data,
                    headers: {
                        'Content-Type': 'application/json;charset=UTF-8'
                    }
                }).success(function (res) {
                    deferred.resolve(res);
                }).error(function (res) {
                    deferred.reject(res);
                });
                return deferred.promise;
            },
            productSearch: function () {
                var deferred = $q.defer();
                var data = new Object();
                $http({
                    method: "GET",
                    url: $rootScope.baseUrl + "c/up/symbol/query/all",
                    data: data,
                    headers: {
                        'Content-Type': 'application/json;charset=UTF-8'
                    }
                }).success(function (res) {
                    deferred.resolve(res);
                }).error(function (res) {
                    deferred.reject(res);
                });
                return deferred.promise;
            }
        }
    }]);