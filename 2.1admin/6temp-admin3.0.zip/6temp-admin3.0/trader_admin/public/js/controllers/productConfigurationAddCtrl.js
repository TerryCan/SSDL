app.controller('productConfigurationAddCtrl', ['$scope', '$rootScope', '$state', 'dataSer', 'getCurrencyType', 'getPageNum', 'tipService', 'confirmService', 'getProductScope', 'productConfigurationAddCtrlSer','getweekType', 'get24h', 'CurrencysettingsCtrlSer','memberMangerCtrlSer','CommissionallocationAddCtrlSer', function($scope, $rootScope, $state, dataSer, getCurrencyType, getPageNum, tipService, confirmService, getProductScope, productConfigurationAddCtrlSer, getweekType, get24h, CurrencysettingsCtrlSer,memberMangerCtrlSer,CommissionallocationAddCtrlSer) {
			$scope.getweekType = getweekType;
			$scope.get24h = get24h;
			//$scope.customizedType = true;
			//$scope.mySel = true;
			//$scope.hidetime= true;
			//机构列表

			$scope.addOrgVal = ''; //显示值
			$scope.addOptOrgVal = '';
			$scope.orgCode = '';
			$scope.orgOptCode = '';
			$scope.orgId = ''; //选择值
			$scope.orgOptId = '';
			$scope.startNum= '';
			$scope.startTime = "";
			$scope.endNum = "";
			$scope.endTime = "";
			$scope.CSTimes = "";
			//绑定参数
			$scope.productId = ''; //产品ID
			$scope.productCustomizedId = '';
			$scope.interest = ''; //仓息
			$scope.poundage = ''; //手续费
			$scope.keepDeposit = ''; //维持保证金
			$scope.interestCurrency = ''; //仓息币种
			$scope.poundageCurrency = ''; //手续费币种
			$scope.keepDepositCurrency = ''; //维持保证金币种
			$scope.tradeFlag = ''; //可交易标识位（1为可以交易，-1为不可交易）
			$scope.openForbidenDang = ''; //当市价在止盈止损价X档内禁止开仓
			$scope.operationTimesDuring = ''; //挂/撤单操作次数间隔（秒）
			$scope.operationTimesLimit = ''; //挂/撤单操作次数
			$scope.positionLimit = ''; //最大持仓量不得大于X
			$scope.orderCreateLimit = ''; //单笔交易量不得大于X
			$scope.orderEntrantDang = ''; //当市价在挂单上下X档内允许进场
			$scope.custonchange = function() {
				if ($scope.customizedType == "true") {
					$scope.addwtime = false;
					$scope.startNum= '';
					$scope.startTime = "";
					$scope.endNum = "";
					$scope.endTime = "";
					$scope.CSTimes = 0;
				} else if ($scope.customizedType == "false") {
					$scope.addwtime = true;
					$scope.CSTimes = '1970-01-01';
				} else {
					$scope.addwtime = false;
					$scope.CSTimes = 0;
				}
			}

			$scope.UniqueData = [{
				name: '是',
				val: true
			}, {
				name: '否',
				val: false
			}];
			dataSer.organizeQuerySer()
				.then(function(res) {
					$scope.orgList = res;
					console.log($scope.orgList)
				});
			$scope.addOrgValFTC = function(d) {
				$scope.addOrgVal = d.text;
				$scope.allottoOrgIdNum = d.orgId;
				$scope.orgCode = d.orgCode;
				//产品ID
				CommissionallocationAddCtrlSer.productListdata($scope.allottoOrgIdNum)
				.then(function(res) {
					console.log(res)
					if(res.code=="000000"){
					var prolistdt = JSON.parse(res.content);
					$scope.prolist = [];
					for (var i = 0, r = prolistdt.length; i < r; i++) {
							$scope.prolist.push(prolistdt[i]);
					}
				}else{
						$rootScope.tipService.setMessage(res.message, 'warning')
					}
				}),function(error){
						$rootScope.tipService.setMessage(error.message, 'warning')
					}
				}
				$scope.addOrgVal1= function() {
					$scope.prolist ="";
					$scope.addOrgVal ="";
					$scope.orgCode ="";
				}
			$scope.addOrgOptValFTC = function(d) {
					$scope.addOptOrgVal = d.text;
					$scope.orgOptId = d.orgId;
					$scope.orgOptCode = d.orgCode;
				}
				//获取币种
			getCurrencyType
				.then(function(res) {
					$scope.getCurrencybz = JSON.parse(res.content);
					//console.log($scope.getCurrencybz)
				});
			$scope.getCurrency = function(parameter) {
				for (var i = 0; i < $scope.getCurrencybz.length; i++) {
					if (parameter == $scope.getCurrencybz[i].id) {
						return $scope.getCurrencybz[i].name;
					}
				}
			}
			CurrencysettingsCtrlSer.search(999999, 1, '', '')
				.then(function(res) {
					$scope.CurrencyTypelist = JSON.parse(res.content);
				})
			$scope.CurrencyTypeText = function(val) {
					//console.log(val)
					if ($scope.CurrencyTypelist) {
						for (var i = 0, r = $scope.CurrencyTypelist.length; i < r; i++) {
							if (val == $scope.CurrencyTypelist[i].currency) {
								return $scope.CurrencyTypelist[i].currencyName;

							}
						}
					}
				}
			memberMangerCtrlSer.search(9999,1,'','','')
			.then(function(res){
				$scope.meborgList = JSON.parse(res.content).content;
				console.log($scope.meborgList)
			})

			$scope.getOrgVal = function(orgCode) {
				if($scope.meborgList){
				for (var i = 0; i < $scope.meborgList.length; i++) {
					if (orgCode == $scope.meborgList[i].orgCode) {
						return $scope.meborgList[i].orgNum;
					}
					}
				}
			}
			/*	//产品ID
			productConfigurationAddCtrlSer.productListdata()
				.then(function(res) {
				if(res.code="000000"){
					var prolistdt = JSON.parse(res.content);
					$scope.prolist = [];
					for (var i = 0, r = prolistdt.length; i < r; i++) {
						if (prolistdt[i].state == 1 || prolistdt[i].state == 8000) {
							$scope.prolist.push(prolistdt[i]);
						}
					}
					}
					console.log($scope.prolist)
				});
*/
			$scope.changeWeekText = function(val) {
				console.log(val)
				for (var i = 0, r = $scope.getweekType.length; i < r; i++) {
					if (val == $scope.getweekType[i].val) {
						return $scope.getweekType[i].name;
					}
				}
			}


			//动态添加减少数据
			$scope.addrule = function() {
				console.log($scope.customizedType,$scope.lockFlag)
				if ($scope.poundage == undefined || $scope.poundage == '') {
					$rootScope.tipService.setMessage('请填写手续费', 'warning');
				} else if ($scope.keepDeposit == undefined || $scope.keepDeposit == '') {
					$rootScope.tipService.setMessage('请填写维持保证金', 'warning');
				} else if ($scope.interest == undefined || $scope.interest == '') {
					$rootScope.tipService.setMessage('请填写仓息', 'warning');
				} else if ($scope.lockFlag == undefined || $scope.lockFlag == '') {
					$rootScope.tipService.setMessage('请选择是否可以锁仓', 'warning');
				} else if ($scope.poundageCurrency == undefined || $scope.poundageCurrency == '') {
					$rootScope.tipService.setMessage('请选择手续费币种', 'warning');
				} else if ($scope.keepDepositCurrency == undefined || $scope.keepDepositCurrency == '') {
					$rootScope.tipService.setMessage('请选择维持保证金币种', 'warning');
				} else if ($scope.interestCurrency == undefined || $scope.interestCurrency == '') {
					$rootScope.tipService.setMessage('请选择仓息币种', 'warning');
				} else {
					if($scope.customizedSubs!=""||$scope.productId!=""){
					$("select[name='productName']").attr('disabled',true);
					$("input[name='addOrgVal']").attr('disabled',true);
					$(".w100p a").hide();
					$(".w100p div").hide();
					}else{
					 $("select[name='productName']").attr('disabled',false);
					 $("iniput[name='addOrgVal']").attr('disabled',false);
					 $(".w100p a").show();
					 $(".w100p div").show();
					};


					//var customizedType=$scope.customizedType;
					var customizedType= eval($scope.customizedType.toLowerCase());
					var lockFlag= eval($scope.lockFlag.toLowerCase());
					var startTimes = $scope.CSTimes + ' ' + $scope.startTime;
					console.log(startTimes)
					var startTimeNum = 0;
					if ($scope.CSTimes != "" || $scope.startTime != '') {
						startTimeNum = Date.parse(new Date(startTimes)).toString();
						console.log(startTimeNum)
					}

					var endTimes = $scope.CSTimes + ' ' + $scope.endTime;
					var endTimeNum = 0;
					if ($scope.CSTimes != "" || $scope.endTime != '') {
						endTimeNum = Date.parse(new Date(endTimes)).toString();
					}

					var SingleRule = {
						productCustomizedId: $scope.productCustomizedId,
						interest: parseFloat($scope.interest),
						poundage: parseFloat($scope.poundage),
						keepDeposit: parseFloat($scope.keepDeposit),
						interestCurrency: parseInt($scope.interestCurrency),
						poundageCurrency: parseInt($scope.poundageCurrency),
						keepDepositCurrency: parseInt($scope.keepDepositCurrency),
						tradeFlag: parseInt($scope.tradeFlag),
						customizedType:customizedType, //默认配置标识位
						lockFlag:lockFlag,
						openForbidenDang: parseInt($scope.openForbidenDang),
						operationTimesDuring: parseInt($scope.operationTimesDuring),
						operationTimesLimit: parseInt($scope.positionLimit),
						positionLimit: parseInt($scope.positionLimit),
						orderCreateLimit: parseInt($scope.orderCreateLimit),
						orderEntrantDang: parseInt($scope.orderEntrantDang),
						startNum: $scope.startNum,
						startTime: startTimeNum,
						endNum: $scope.endNum,
						endTime: endTimeNum
					}

					$scope.customizedSubs.push(SingleRule);
					console.log(SingleRule)
				}
			}
			$scope.delete = function(index) {
				$scope.customizedSubs.splice(index, 1);
				if($scope.customizedSubs!=""){
					$("select[name='productName']").attr('disabled',true);
					$("input[name='addOrgVal']").attr('disabled',true);
					$(".w100p a").hide();
					$(".w100p div").hide();

					}else{
					 $("select[name='productName']").attr('disabled',false);
					 $("input[name='addOrgVal']").attr('disabled',true);
					 $(".w100p a").show();
					 $(".w100p div").show();
					};
			}
			$scope.customizedSubs = [];

			$scope.addproductCust = function() {

				var productCustomized = {
					productCustomizedId: $scope.productCustomizedId,
					productId: $scope.productId,
					orgId: $scope.allottoOrgIdNum,
					orgCode: $scope.orgCode,
					customizedSubs: $scope.customizedSubs
				}

				productConfigurationAddCtrlSer.add(productCustomized)
					.then(function(res) {
						if (res.data.code == '000000') {
							$rootScope.tipService.setMessage(res.data.message, 'warning');
							$state.go('tabs.productConfiguration');
						} else {
							$rootScope.tipService.setMessage(res.data.message, 'warning');
						}
					});
			}
			$scope.goBack = function() {
				$state.go('tabs.productConfiguration');
			}
	}])
	.factory('productConfigurationAddCtrlSer', ['$http', 'localStorageService', 'myHttp', '$q', '$rootScope', function($http, localStorageService, myHttp, $q, $rootScope) {
		return {
			add: function(productCustomized) {
				var deferred = $q.defer();
				$http({
					method: 'POST',
					url: $rootScope.baseUrl + 'config/product/save/productCustomizeds',
					data: {
						"productCustomized": productCustomized
					}
				}).then(function successCallback(response) {
					deferred.resolve(response);
				}, function errorCallback(response) {
					deferred.reject(response);
				});
				return deferred.promise;
			},
			productListdata:function(){
			var deferred = $q.defer();
			var url = $rootScope.baseUrl+"config/product/query/as/list/with/config";
			$http({
				method: "POST",
				url: url
			}).success(function (res) {
				deferred.resolve(res);
			}).error(function (res) {
				deferred.reject(res);
			});
			return deferred.promise;
			}
		}
	}])