app.controller('orginConfigCtrl', ['$rootScope', '$scope', 'getPageNum', 'orginConfigCtrllSer', 'getadminState', 'dataSer', 'localStorageService', 'confirmService','$timeout', function ($rootScope, $scope, getPageNum, orginConfigCtrllSer, getadminState, dataSer, localStorageService, confirmService,$timeout) {
    $scope.toggleTraderSearchState = false;
    $scope.Toggle = function () {
        $scope.toggleTraderSearchState = !$scope.toggleTraderSearchState;
        if ($scope.toggleTraderSearchState) {
            $('.search_column').css('height', 'auto');
        }
        else {
            $('.search_column').css('height', '36px');
        }
    };
    $scope.ToState='';
    localStorageService.clear('userIdChecked');
    $scope.tableshow = false;
    $scope.search = function (type) {
        $scope.toggleTraderSearchState = false;
        $('.search_column').css('height', '36px');
        if (type == 'search') {
            pageInitialize()
        };
        $scope.orgCode=localStorageService.get('oldOrgCode');
        console.log($scope.orgCode)
        var json = {
            page: $scope.currentPage,
            rows: $scope.showNum.showNum,
            orders: 'asc',
            search_EQ_orgCode: ($scope.orgCode) ?  $scope.orgCode : '',
            search_EQ_state: $scope.ToState,
        };
        orginConfigCtrllSer.search(json)
            .then(function (res) {
                console.log(res)
                if (res.code == '000000') {
                    $scope.showPage = true;
                    var data = JSON.parse(res.content);
                    $scope.searchResult = data.content;
                    console.log($scope.searchResult);
                    $scope.dataNum = data.totalElements;
                    $scope.PageNum();

                    var checkedUserId=localStorageService.get('userIdChecked'); //获取上一次存储的id
                    $scope.switchUserId(checkedUserId,$scope.searchResult); //执行选中方法
                } else {
                    $rootScope.tipService.setMessage(res.message, 'warning');
                }
            }, function (error) {
                $rootScope.tipService.setMessage(error.message, 'warning');
            });
    }
    $scope.ProStateList = getadminState;
    console.log($scope.ProStateList)
    $scope.getProStateList = function (params) {
        for (var i = 0, r = $scope.ProStateList.length; i < r; i++) {
            if (params == $scope.ProStateList[i].id) {
                return $scope.ProStateList[i].name;
            }
        }
    }
    dataSer.organizeQuerySer()
        .then(function (res) {
            $scope.orgList = res;
            console.log($scope.orgList)
        });

     $scope.addOrgValFTC = function (data) {
         console.log(data);
         $scope.orgId = data.orgId;
         $scope.orgCode = data.orgCode;
         $scope.addOrgVal = data.text;
     }
    /*$scope.orgId = localStorageService.get('oldOrgId');
    console.log($scope.orgId)
    $scope.orgCode = localStorageService.get('oldOrgCode');
    console.log($scope.orgCode)*/
    //$scope.addOrgVal=localStorageService.get('oldOrgCode');
    //全部状态下所属机构
    dataSer.organizeQuerylistSer()
        .then(function (res) {
            $scope.orgAllList = res;
        });

    $scope.adjustText = function (orgId) {
        if ($scope.orgAllList) {
            for (var i = 0, r = $scope.orgAllList.length; i < r; i++) {
                if ($scope.orgAllList[i].orgId == orgId) {
                    return $scope.orgAllList[i].text;
                }
            }
        }
    }
    $scope.basicData = [{
        name: '是',
        val: true
    }, {
        name: '否',
        val: false
    }];
    $scope.basicText = function (val) {
        for (var i = 0, r = $scope.basicData.length; i < r; i++) {
            if (val == $scope.basicData[i].val) {
                return $scope.basicData[i].name;
            }
        }
    }
    /**
     * 分页功能实现TerryMin
     * **/
    $scope.showDataChoose = getPageNum.pageNum(); //获取分页
    $scope.showNum = $scope.showDataChoose[0]; //初始显示刷具条数
    $scope.showPage = false;
    var pageInitialize = function () {
        $scope.dataNum = 0; //数据总条数
        $scope.dataPage = 0; //分页数
        $scope.currentPage = 1; //当前页数
        $scope.jumpPageNum = '';
    };
    pageInitialize();

    // x/y $scope.dataPage
    $scope.PageNum = function () {
        $scope.showPage = true;
        if ($scope.showNum.showNum < $scope.dataNum) {
            $scope.dataPage =Math.ceil($scope.dataNum / $scope.showNum.showNum);
        } else {
            $scope.dataPage = 0;
        }
    };
    //上页下页 $scope.currentPage
    $scope.pageSlect = function (type) {
        if (type == 'prev') {
            if ($scope.currentPage != 1) {
                $scope.currentPage--;
                $scope.PageNum();
                $scope.search();
            }
        } else {
            if ($scope.currentPage < $scope.dataPage) {
                $scope.currentPage++;
                $scope.PageNum();
                $scope.search();
            }
        }
    };
    // 每页条数单元
    $scope.pageSelect = function (params) {
        $scope.showNum.showNum = params.showNum;
        pageInitialize();
        $scope.search();
    };
    //页数跳转 currentPage
    $scope.jumpPage = function (num) {
        num = parseInt(num);
        if (parseInt(num, 10) === num && num <= ($scope.dataPage + 1) && num > 0) {
            $scope.currentPage = num;
            $scope.PageNum();
            $scope.search();
        }
    };

    $scope.orgId = '';
    $scope.orgCode = '';
    $scope.state = '';
    $scope.hideRoleaut=true;
    $scope.showRoleaut=true;
    $scope.uphideRoleaut=true;
    $scope.upshowRoleaut=true;

    // 选择
    $scope.checkedTab1 = function (index,applyOpponentId,applyId,orgId, orgCode, innerMap,ormType,outMap,state){
        $scope.chooseUserData = {
            applyOpponentId:applyOpponentId,
            applyId:applyId,
            orgId: orgId,
            orgCode: orgCode,
            innerMap: innerMap,
            ormType: ormType,
            outMap: outMap,
            state:state
        };
        console.log($scope.chooseUserData);
        var userIdChecked = localStorageService.get('userIdChecked');
        $('#dataReport input[type=checkbox]').prop('checked', false);
        if (orgId == userIdChecked) {
            localStorageService.clear('userIdChecked');
            $scope.chooseItemTab1 = '';
            $scope.state='';
            $scope.applyId='';
            $scope.applyOpponentId='';
        } else {
            $('#dataReport input[type=checkbox]').eq(index).prop('checked', true);
            localStorageService.update('userIdChecked', orgId);
            $scope.chooseItemTab1 = orgId;
            $scope.state=state;
            $scope.applyId=applyId;
            $scope.applyOpponentId=applyOpponentId;
        }
        if ($scope.chooseUserData.applyId != null) {
            console.log($scope.chooseUserData.applyId,$scope.chooseUserData.applyOpponentId)
            $scope.hideRoleaut=false;
            $scope.showRoleaut=false;
            $scope.uphideRoleaut=false;
            $scope.upshowRoleaut=false;
        }else{
            $scope.showRoleaut=true;
            $scope.hideRoleaut=true;
            $scope.uphideRoleaut=true;
            $scope.upshowRoleaut=true;
        };
        if($scope.chooseUserData.applyOpponentId!=null){
            $scope.uphideRoleaut=false;
            $scope.upshowRoleaut=false;
        }else{
            $scope.uphideRoleaut=true;
            $scope.upshowRoleaut=true;
        };
    };
    // 存储选中
    $scope.switchUserId = function (parameter, responseData) {
        $timeout(function () {
            for (var i = 0; i < responseData.length; i++) {
                if (parameter == responseData[i].orgId) {
                    $('#dataReport input[type=checkbox]').eq(i).prop('checked', true);
                    return;
                }
            }
        }, 1500)
    };

    $scope.ormTypelist= [{
        name: '内映射',
        val: "2"
    }, {
        name: '外映射',
        val: "1"
    }];
    $scope.add = function () {
            $scope.tableshow = true;
            $scope.addEditText = '新增';
            $scope.addOrgVal = "";
            //.innerMap = "";
            //$scope.outMap = "";
            $scope.ormType= "";
    }

    $scope.edit = function () {
        if (!$scope.chooseItemTab1) {
            $rootScope.tipService.setMessage('请先选择机构配置信息', 'warning');
        } else {
            $scope.addEditText = '修改';
            $scope.tableshow = true;
            //$scope.innerMap = $scope.chooseUserData.innerMap;
            //$scope.outMap = $scope.chooseUserData.outMap;
            $scope.orgId = $scope.chooseUserData.orgId;
            $scope.ormType= $scope.chooseUserData.ormType;
            $scope.orgCode = $scope.chooseUserData.orgCode;
            console.log($scope.orgCode)
            // //匹配机构代码
             var json = {
                 page: 1,
                rows: 9999,
                 search_A_EQ_state: 1
             };
             dataSer.getOrganize(json).then(function (res) {
                 if (res.code == '000000') {
                     $scope.equalOrgCode = JSON.parse(res.content).content;
                     //console.log($scope.equalOrgCode);
                     for (var i = 0; i < $scope.equalOrgCode.length; i++) {
                         if ($scope.chooseUserData.orgId == $scope.equalOrgCode[i].orgId) {
                             $scope.addOrgVal = $scope.equalOrgCode[i].orgName + '(' + $scope.equalOrgCode[i].orgNum + ')';
                            //console.log($scope.addOrgVal)
                         }
                     }
                 } else {
                     console.log(res);
                 }
             });
        }
    }
    //上手账号机构查询
    orginConfigCtrllSer.accountSer()
        .then(function(res) {
            console.log(res)
            if(res.data.retMsg.code=="000000"){
            $scope.organizelist = res.data.list;
            console.log($scope.organizelist)
            }
        }, function(error) {
            console.log(error);
        })
    $scope.addPsOrgValFTC = function(d) {
        //console.log(d);
        $scope.opponentOrgId = d.OrgId;
        $scope.opponentOrgCode = d.OrgCode;
        $scope.upAccountOrganizeId = d.key
        $scope.addPsOrgVal = d.text;
    }
    $scope.upedit=function(){
        if (!$scope.chooseItemTab1) {
            $rootScope.tipService.setMessage('请先选择机构配置信息', 'warning');
        } else {
            $scope.addEditText = '申请上手机构变更';
            $scope.uptableshow = true;
            $scope.orgId = $scope.chooseUserData.orgId;
            $scope.ormType= $scope.chooseUserData.ormType;
            $scope.orgCode = $scope.chooseUserData.orgCode;
            console.log($scope.orgCode)
            // //匹配机构代码
            var json = {
                page: 1,
                rows: 9999,
                search_A_EQ_state: 1
            };
            dataSer.getOrganize(json).then(function (res) {
                if (res.code == '000000') {
                    $scope.equalOrgCode = JSON.parse(res.content).content;
                    //console.log($scope.equalOrgCode);
                    for (var i = 0; i < $scope.equalOrgCode.length; i++) {
                        if ($scope.chooseUserData.orgId == $scope.equalOrgCode[i].orgId) {
                            $scope.addOrgVal = $scope.equalOrgCode[i].orgName + '(' + $scope.equalOrgCode[i].orgNum + ')';
                            //console.log($scope.addOrgVal)
                        }
                    }
                } else {
                    console.log(res);
                }
            });
        }

    }

    $scope.Datalists=[];
    $scope.addrule = function() {
        $scope.Datalists.push($scope.addPsOrgVal);
        console.log($scope.Datalists)
    }

    $scope.deletesd = function(index) {
        $scope.Datalists.splice(index, 1);
    }

    $scope.upaddSubmit = function () {
            var orgOpponentVIce = {
                orgId: $scope.orgId,
                opponentOrgIds:$scope.Datalists,
            }
            var json = {
                orgOpponentVIce: orgOpponentVIce
            }
            orginConfigCtrllSer.upAddsub(json)
                .then(function (res) {
                    console.log(res)
                        if (res.data.code == "000000") {
                            $scope.uptableshow = false;
                            $rootScope.tipService.setMessage(res.data.message, 'warning');
                            localStorageService.clear('userIdChecked');
                            $scope.search();
                        }else{
                            $rootScope.tipService.setMessage(res.data.message, 'warning');
                        }
                    },function(error){
                        $rootScope.tipService.setMessage(error.data.message, 'warning');
                    }
                )
        }

    $scope.getinnerMap = function () {
        if($scope.innerMap == true){
            $scope.outMap=false;
        }
    };
    $scope.getoutMap = function () {
        if($scope.outMap==true){
            $scope.innerMap=false;
        }
    };
    $scope.addSubmit = function () {
        if ($scope.addEditText == "新增") {
           /* if($scope.innerMap==true && $scope.outMap==false){
                $scope.innerMapval=$scope.innerMap;
                $scope.outMapval=$scope.outMap;
            }
            if($scope.innerMap==false && $scope.outMap==true){
                $scope.outMapval=$scope.outMap;
                $scope.innerMapval=$scope.innerMap;
            }*/
            var OrgResourceVIce = {
				orgId: $scope.orgId,
                //orgCode: $scope.orgCode,
                //orgId: localStorageService.get('oldOrgId'),
                //orgCode: localStorageService.get('oldOrgCode'),
                //innerMap: $scope.innerMapval,
                //outMap: $scope.outMapval,
                ormType:$scope.ormType,
            }
            var json = {
                orgResource: OrgResourceVIce
            }
            orginConfigCtrllSer.Addsub(json)
                .then(function (res) {
                    if (res.data.code == "000000") {
                        $scope.tableshow = false;
                        $rootScope.tipService.setMessage(res.data.message, 'warning');
                        localStorageService.clear('userIdChecked');
                        $scope.search();
                    }else{
                        $rootScope.tipService.setMessage(res.data.message, 'warning');
                        }
                    },function(error){
                        $rootScope.tipService.setMessage(error.data.message, 'warning');
                    }
                )
        } else if ($scope.addEditText == "修改") {
           /* if($scope.innerMap==true && $scope.outMap==false){
                $scope.innerMapval=$scope.innerMap;
                $scope.outMapval=$scope.outMap;
            }
            if($scope.innerMap==false && $scope.outMap==true){
                $scope.outMapval=$scope.outMap;
                $scope.innerMapval=$scope.innerMap;
            }*/
            var OrgResourceVIce = {
                orgId: $scope.orgId,
                /*orgCode: $scope.orgCode,
                innerMap: $scope.innerMap,
                outMap: $scope.outMap,*/
                //state:$scope.state,
                ormType:$scope.ormType,
            }
            var json = {
                orgResource: OrgResourceVIce
            }
            orginConfigCtrllSer.apply(json)
                .then(function (res) {
                    if (res.data.code == "000000") {
                        $scope.tableshow = false;
                        $rootScope.tipService.setMessage(res.data.message, 'warning');
                        localStorageService.clear('userIdChecked');
                        $scope.search();
                    }
                    else {
                        $rootScope.tipService.setMessage(res.data.message, 'warning');
                    }
            },function(error){
                $rootScope.tipService.setMessage(error.data.message, 'warning')
            })
        }
    }

    //删除
    $scope.delete = function () {
        if (!$scope.chooseItemTab1) {
            $rootScope.tipService.setMessage('请先选择机构配置信息', 'warning');
        } else {
            //console.log($scope.chooseItemTab1);
            confirmService.set('确认提示', '确定要删除此信息吗?', function () {
                var json = {
                    orgId: $scope.chooseItemTab1
                };
                orginConfigCtrllSer.Delete(json)
                    .then(function (res) {
                        console.log(res)
                        if (res.data.code == "000000") {
                            $rootScope.tipService.setMessage(res.data.message, 'warning');
                            localStorageService.clear('userIdChecked');
                            $scope.search()
                        } else {
                            $rootScope.tipService.setMessage(res.data.message, 'warning');
                        }
                    }, function (error) {
                        $rootScope.tipService.setMessage(error.data.message, 'warning');
                    });
                confirmService.clear();
                // $scope.chooseItemTab1 = null;
            });
        }
    };

    $scope.get=function () {
        if (!$scope.applyId) {
            $rootScope.tipService.setMessage('请先申请变更', 'warning');
        } else {
            var json={
                applyId:$scope.applyId
            }
            orginConfigCtrllSer.Get(json)
                .then(function(res){
                    console.log(res)
                    if(res.data.code=="000000"){
                        var getData=JSON.parse(res.data.content);
                        $scope.getDatalist=getData.configOrgResourceV;
                        console.log($scope.getDatalist)
                        $scope.addEditText = "审核变更";
                        $scope.tableshowxq = true;
                        $scope.ormType=$scope.getDatalist.ormType,
                        $scope.orgId=$scope.getDatalist.orgId;
                        //$scope.orgCode=$scope.getDatalist.orgCode;
                        //匹配机构代码
                        var json = {
                            page: 1,
                            rows: 9999,
                            search_A_EQ_state: 1
                        };
                        dataSer.getOrganize(json).then(function (res) {
                            if (res.code == '000000') {
                                $scope.equalOrgCode = JSON.parse(res.content).content;
                                //console.log($scope.equalOrgCode);
                                for (var i = 0; i < $scope.equalOrgCode.length; i++) {
                                    if ($scope.orgId== $scope.equalOrgCode[i].orgId) {
                                        $scope.addOrgVal = $scope.equalOrgCode[i].orgName + '(' + $scope.equalOrgCode[i].orgNum + ')';
                                        //console.log($scope.addOrgVal)
                                    }
                                }
                            } else {
                                console.log(res);
                            }
                        });
                        $scope.state=$scope.getDatalist.state;
                        $scope.innerMap=$scope.getDatalist.innerMap;
                        $scope.outMap=$scope.getDatalist.outMap;
                        //$scope.applyId=$scope.getDatalist.applyId;
                    }
                })

        }
    }

    $scope.upget=function () {
        if (!$scope.chooseUserData.applyOpponentId) {
            $rootScope.tipService.setMessage('请先申请上手机构变更', 'warning');
        } else {
            var json={
                applyOpponentId:$scope.chooseUserData.applyOpponentId
            }
            orginConfigCtrllSer.upGet(json)
                .then(function(res){
                    console.log(res)
                    if(res.data.code=="000000"){
                        var getData=JSON.parse(res.data.content);
                        $scope.getDatalist=getData.changeData;
                        console.log($scope.getDatalist)
                        $scope.addEditText = "审核上手机构变更";
                        $scope.upgettableshow = true;
                        //$scope.ormType=$scope.getDatalist.ormType,
                        $scope.orgId=$scope.getDatalist.orgId;
                        for (var i = 0; i < $scope.getDatalist.opponentOrgIds.length; i++) {
                            console.log( $scope.getDatalist.opponentOrgIds.length, $scope.getDatalist.opponentOrgIds)
                            $scope.Datalists.push($scope.getDatalist.opponentOrgIds[i]);
                            console.log($scope.Datalists)
                        }

                        //$scope.orgCode=$scope.getDatalist.orgCode;
                        //匹配机构代码
                        var json = {
                            page: 1,
                            rows: 9999,
                            search_A_EQ_state: 1
                        };
                        dataSer.getOrganize(json).then(function (res) {
                            if (res.code == '000000') {
                                $scope.equalOrgCode = JSON.parse(res.content).content;
                                //console.log($scope.equalOrgCode);
                                for (var i = 0; i < $scope.equalOrgCode.length; i++) {
                                    if ($scope.orgId== $scope.equalOrgCode[i].orgId) {
                                        $scope.addOrgVal = $scope.equalOrgCode[i].orgName + '(' + $scope.equalOrgCode[i].orgNum + ')';
                                        //console.log($scope.addOrgVal)
                                    }
                                }
                            } else {
                                console.log(res);
                            }
                        });
                        $scope.state=$scope.getDatalist.state;
                        $scope.innerMap=$scope.getDatalist.innerMap;
                        $scope.outMap=$scope.getDatalist.outMap;
                        //$scope.applyId=$scope.getDatalist.applyId;
                    }
                })

        }
    }

    $scope.RoletrueData = function (tmpOpt) {
        var json = {
            applyId: $scope.applyId,
            auditRs: tmpOpt
        };
        orginConfigCtrllSer.Roletruetion(json)
            .then(function (res) {
                if (res.data.code == '000000') {
                    $scope.tableshowxq = false;
                    localStorageService.clear('userIdChecked');
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                    $scope.search();
                } else {
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                }
            },function(error) {
                $rootScope.tipService.setMessage(error.data.message, 'warning');
            })
    }
    $scope.RolefalseData = function (tmpOpt) {
        var json = {
            applyId: $scope.applyId,
            auditRs: tmpOpt
        };
        orginConfigCtrllSer.Roletruetion(json)
            .then(function (res) {
                if (res.data.code == '000000') {
                    $scope.tableshowxq = false;
                    localStorageService.clear('userIdChecked');
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                    $scope.search();
                } else {
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                }
            },function(error) {
                $rootScope.tipService.setMessage(error.data.message, 'warning');
            })
    }
    $scope.upRoletrueData = function (tmpOpt) {
        var json = {
            applyOpponentId: $scope.applyOpponentId,
            auditRs: tmpOpt
        };
        orginConfigCtrllSer.upRoletruetion(json)
            .then(function (res) {
                if (res.data.code == '000000') {
                    $scope.upgettableshow = false;
                    localStorageService.clear('userIdChecked');
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                    $scope.search();
                } else {
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                }
            },function(error) {
                $rootScope.tipService.setMessage(error.data.message, 'warning');
            })
    }
    $scope.upRolefalseData = function (tmpOpt) {
        var json = {
            applyOpponentId: $scope.applyOpponentId,
            auditRs: tmpOpt
        };
        orginConfigCtrllSer.upRoletruetion(json)
            .then(function (res) {
                if (res.data.code == '000000') {
                    $scope.upgettableshow = false;
                    localStorageService.clear('userIdChecked');
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                    $scope.search();
                } else {
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                }
            },function(error) {
                $rootScope.tipService.setMessage(error.data.message, 'warning');
            })
    }

    //销毁
    $scope.close = function () {
        if (!$scope.chooseItemTab1) {
            $rootScope.tipService.setMessage('请先选择机构配置信息', 'warning');
        } else {
            //console.log($scope.chooseItemTab1);
            confirmService.set('确认提示', '确定要注销此信息吗?', function () {
                var json = {
                    orgId: $scope.chooseItemTab1
                };
                orginConfigCtrllSer.Close(json)
                    .then(function (res) {
                        console.log(res)
                        if (res.data.code == "000000") {
                            $rootScope.tipService.setMessage(res.data.message, 'warning');
                            localStorageService.clear('userIdChecked');
                            $scope.search()
                        } else {
                            $rootScope.tipService.setMessage(res.data.message, 'warning');
                        }
                    }, function (error) {
                        $rootScope.tipService.setMessage(error.data.message, 'warning');
                    });
                confirmService.clear();
                // $scope.chooseItemTab1 = null;
            });
        }
    };

    //通过审核
    $scope.passCheck = function () {
        if (!$scope.chooseItemTab1) {
            $rootScope.tipService.setMessage('请先选择机构配置信息', 'warning');
        } else {
            var json = {
                orgId: $scope.chooseItemTab1
            };
            orginConfigCtrllSer.passCheck(json)
                .then(function (res) {
                    if (res.data.code == '000000') {
                        $rootScope.tipService.setMessage(res.data.message, 'warning');
                        localStorageService.clear('userIdChecked');
                        $scope.search();
                    }
                    else {
                        $rootScope.tipService.setMessage(res.data.message, 'warning');
                    }
                }, function (error) {
                    $rootScope.tipService.setMessage(error.data.message, 'warning');
            });
        }
    };
    //审核驳回
    $scope.failedCheck = function () {
        if (!$scope.chooseItemTab1) {
            $rootScope.tipService.setMessage('请先选择机构配置信息', 'warning');
        } else {
            var json = {
                orgId: $scope.chooseItemTab1
            };
            orginConfigCtrllSer.failedCheck(json)
                .then(function (res) {
                    if (res.data.code == '000000') {
                        $rootScope.tipService.setMessage(res.data.message, 'warning');
                        localStorageService.clear('userIdChecked');
                        $scope.search();
                    }
                    else {
                        $rootScope.tipService.setMessage(res.data.message, 'warning');
                    }
                }, function (error) {
                    $rootScope.tipService.setMessage(error.data.message, 'warning');
            });
        }
    };
    //重新审核
    $scope.rePassCheck = function () {
        if (!$scope.chooseItemTab1) {
            $rootScope.tipService.setMessage('请先选择机构配置信息', 'warning');
        } else {
            var json = {
                orgId: $scope.chooseItemTab1
            };
            orginConfigCtrllSer.open(json)
                .then(function (res) {
                    console.log(res)
                    if (res.data.code == '000000') {
                        $rootScope.tipService.setMessage(res.data.message, 'warning');
                        localStorageService.clear('userIdChecked');
                        $scope.search();
                    }
                    else {
                        $rootScope.tipService.setMessage(res.data.message, 'warning');
                    }
                }, function (error) {
                    $rootScope.tipService.setMessage(error.data.message, 'warning');
            });
        }
    };

    $scope.showRoleaudit = true;
    $scope.hideRoleaut = true;

}])
    .factory('orginConfigCtrllSer', ['$http', 'localStorageService', 'myHttp', '$q', '$rootScope', function ($http, localStorageService, myHttp, $q, $rootScope) {
        return {
            //查询
            search: function (json) {
                var deferred = $q.defer();
                myHttp.post("admin/config/orgresource/page/query", json)
                    .then(function (res) { // 调用承诺API获取数据 .resolve
                        deferred.resolve(res);
                    }, function (res) { // 处理错误 .reject
                        deferred.reject(res);
                    });
                return deferred.promise;
            },

            // 删除
            Delete: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'admin/config/orgresource/delete',
                    data: json
                }).then(function successCallback(response) {
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
            Close: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'admin/config/orgresource/close',
                    data: json
                }).then(function successCallback(response) {
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
            Addsub: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'admin/config/orgresource/create',
                    data: json
                }).then(function successCallback(response) {
                    console.log(response)
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
            upAddsub: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'admin/config/orgresource/opponent/apply',
                    data: json
                }).then(function successCallback(response) {
                    console.log(response)
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
            //冻结
            freeze: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'admin/config/orgresource/freeze',
                    data: json
                }).then(function successCallback(response) {
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
            //解冻
            unfreeze: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'admin/config/orgresource/unfreeze',
                    data: json
                }).then(function successCallback(response) {
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
            //通过
            passCheck: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'admin/config/orgresource/pass',
                    data: json
                }).then(function successCallback(response) {
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
            //不通过
            failedCheck: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'admin/config/orgresource/fail',
                    data: json
                }).then(function successCallback(response) {
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
            //重新提交
            open: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'admin/config/orgresource/open',
                    data: json
                }).then(function successCallback(response) {
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
            //重新提交
            apply: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'admin/config/orgresource/apply',
                    data: json
                }).then(function successCallback(response) {
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
            Get: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'admin/config/orgresource/apply/get',
                    data: json
                }).then(function successCallback(response) {
                    console.log(response)
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
            upGet: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'admin/config/orgresource/opponent/apply/get',
                    data: json
                }).then(function successCallback(response) {
                    console.log(response)
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
            Roletruetion: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'admin/config/orgresource/audit',
                    data: json
                }).then(function successCallback(response) {
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
            upRoletruetion: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'admin/config/orgresource/opponent/audit',
                    data: json
                }).then(function successCallback(response) {
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
            accountSer: function() { //所属机构
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'c/up/account/organize/query/all',
                }).then(function successCallback(response) {
                    console.log(response)
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
        }
    }])