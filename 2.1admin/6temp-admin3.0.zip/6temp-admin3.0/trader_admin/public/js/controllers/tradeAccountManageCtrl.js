app.controller('tradeAccountManageCtrl', ['$scope', '$rootScope', 'tipService', 'tradeAccountDetail', 'getPageNum', 'localStorageService', 'getCurrencyType', 'getIoType', 'getTradeType', 'timestamp', function ($scope, $rootScope, tipService, tradeAccountDetail, getPageNum, localStorageService, getCurrencyType, getIoType, getTradeType, timestamp) {
    $scope.currency = '';
    $scope.tradeDetailSearch = function (type) {
        $scope.changeState('tabs.tradeAccountManage');
        var json = {
            page: $scope.currentPage,
            rows: $scope.showNum.showNum,
            order: 'desc',
            sort: 'createTime',
            search_EQ_currency: $scope.currency
        };
        tradeAccountDetail.tradeDetail(json)
            .then(function (response) {
                if (response.code == "000000") {
                    if (type == 'btnSearch') {
                        pageInitialize();
                    }
                    var data = JSON.parse(response.content);
                    $scope.tradeResult = data.content;
                    console.log($scope.tradeResult);
                    $scope.showPage = true;
                    $scope.searchResult = data.content;
                    $scope.dataNum = data.totalElements;
                    $scope.PageNum();
                } else {
                    $rootScope.tipService.setMessage(response.message, 'warning');
                }
            }, function (error) {
                $rootScope.tipService.setMessage(error.message, 'warning');
            });
    };
    $scope.goBack = function () {
        $scope.changeState('tabs.home');
    };
//数据转换
    //时间戳
    $scope.timeSwitch = function (stamp) {
        return timestamp.timestampCoverHms(stamp, 'all')
    };
    $scope.ioType = getIoType;
    $scope.getIoKind = function (params) {
        for (var i = 0, r = getIoType.length; i < r; i++) {
            if (params == getIoType[i].id) {
                return getIoType[i].name;
            }
        }
    };
    $scope.tradeType = getTradeType;
    $scope.getTradeType = function (params) {
        for (var i = 0, r = $scope.tradeType.length; i < r; i++) {
            if (params == $scope.tradeType[i].id) {
                return $scope.tradeType[i].name;
            }
        }
    };
    // 货币转换
    getCurrencyType.then(function (res) {
        $scope.currencyList = JSON.parse(res.content);
        // console.log($scope.currencyList);
    });
    $scope.getCurrency = function (parameter) {
        if ($scope.currencyList) {
            for (var i = 0; i < $scope.currencyList.length; i++) {
                if (parameter == $scope.currencyList[i].currency) {
                    return $scope.currencyList[i].currencyName;
                }
            }
        }
    };
    /**
     * 分页功能实现TerryMin
     * **/
    $scope.showDataChoose = getPageNum.pageNum(); //获取分页
    $scope.showNum = $scope.showDataChoose[0]; //初始显示刷具条数

    $scope.showPage = false;
    var pageInitialize = function () {
        $scope.dataNum = 0; //数据总条数
        $scope.dataPage = 0; //分页数
        $scope.currentPage = 1; //当前页数
        $scope.jumpPageNum = '';
    };
    pageInitialize();
    // x/y $scope.dataPage
    $scope.PageNum = function () {
        if ($scope.showNum.showNum < $scope.dataNum) {
            $scope.dataPage =Math.ceil($scope.dataNum / $scope.showNum.showNum);
        } else {
            $scope.dataPage = 0;
        }
        if($scope.dataPage>1 && $scope.currentPage>0){
            if($scope.dataPage<$scope.currentPage){
                $scope.currentPage=1;
                $scope.tradeDetailSearch();
            }
        }
    };
    //上页下页 $scope.currentPage
    $scope.pageSlect = function (type) {
        if (type == 'prev') {
            if ($scope.currentPage != 1) {
                $scope.currentPage--;
                $scope.PageNum();
                $scope.tradeDetailSearch();
            }
        } else {
            if ($scope.currentPage < $scope.dataPage) {
                $scope.currentPage++;
                $scope.PageNum();
                $scope.tradeDetailSearch();
            }
        }
    };
    // 每页条数单元
    $scope.pageSelect = function (params) {
        $scope.showNum.showNum = params.showNum;
        pageInitialize();
        $scope.tradeDetailSearch();
    };
    //页数跳转 currentPage
    $scope.jumpPage = function (num) {
        num = parseInt(num);
        if (parseInt(num, 10) === num && num <= ($scope.dataPage + 1) && num > 0) {
            $scope.currentPage = num;
            $scope.PageNum();
            $scope.tradeDetailSearch();
        }
    };
}])
//交易账户之前查询
    .factory('tradeAccountDetail', ['$http', '$rootScope', 'localStorageService', 'myHttp', '$q', function ($http, $rootScope, localStorageService, myHttp, $q) {
        return {
            tradeDetail: function (json) {
                var deferred = $q.defer();
                myHttp.post("account/user/io/query/page", json)
                    .then(function (res) {
                        deferred.resolve(res);
                    }, function (res) {
                        deferred.reject(res);
                    })
                return deferred.promise;
            }
        }
    }])