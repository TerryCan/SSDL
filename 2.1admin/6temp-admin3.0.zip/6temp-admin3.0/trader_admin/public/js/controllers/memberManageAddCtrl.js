app.controller("memberManageAddCtrl", function($scope, $state, $rootScope, tipService, confirmService, getUserStates, dataSer, timestamp, memberMangerCtrlSer, localStorageService, $timeout) {
        $scope.typeName = '机构角色';
        $scope.orgId = null;
        $scope.orgListDisplay = false;
        $scope.orgExtendToggle = false;
        $scope.contactUserToggle = false;

        dataSer.organizeQuerySer()
            .then(function(res) {
                $scope.orgList = res;
            });

        $scope.goBack = function() {
            $state.go('tabs.memberManage');
        };
        //获取机构扩展信息 行业
        dataSer.readIndustry()
            .then(function(res) {
                $scope.getOrgInfoIndustryData = res.industry;
            });
        //获取机构性质
        dataSer.readOccupation()
            .then(function(res) {
                $scope.getReadOccupationData = res.occupation;
            });
        //获取学历数据
        dataSer.readEducation()
            .then(function(res) {
                $scope.getReadEducationData = res.education;
            });
        //投资者性质
        dataSer.readProperty()
            .then(function(res) {
                $scope.getReadPropertyData = res.property;
            });
        //国家 城市 地区 选择
        $scope.isChooseCountry = function() {
            if ($scope.userExtendInfoCountry) {
                dataSer.provinceQuerySer($scope.userExtendInfoCountry)
                    .then(function(res) {
                        if (res.code == '000000') {
                            $scope.provincesData = res.results;
                        }
                    });
            }
        };
        $scope.isChooseProvinces = function() {
            if ($scope.userExtendInfoProvinces) {
                dataSer.cityQuerySer($scope.userExtendInfoProvinces)
                    .then(function(res) {
                        if (res.code == '000000') {
                            $scope.cityData = res.results;
                        }
                    });
            }
        };
        $scope.isChooseCity = function() {
            if ($scope.userExtendInfoCity) {
                dataSer.areaQuerySer($scope.userExtendInfoCity)
                    .then(function(res) {
                        if (res.code == '000000') {
                            $scope.areaData = res.results;
                        }
                    });
            }
        };
        //获取证件类型
        dataSer.readCertificateType()
            .then(function(res) {
                $scope.certificateList = res.certificateType;
            });
        $scope.addOrgValFTC = function(data) {
            console.log(data);
            $scope.orgId = data.orgId;
            $scope.superOrgId = data.orgId;
            $scope.addOrgVal = data.text;
            var json = {
                orgId: $scope.orgId,
                roleType: 1
            };
            memberMangerCtrlSer.getRoleType(json)
                .then(function(res) {
                    if (res.data.code == '000000') {
                        $scope.userList = JSON.parse(res.data.content);
                    } else {
                        $rootScope.tipService.setMessage(res.data.message, 'warning');
                    }
                }, function(error) {
                    $rootScope.tipService.setMessage(error.data.message, 'warning');
                })
        };
        $scope.cutover = function() {
            console.log(123213)
            console.log($scope.natureOrgRealInfo)
            if ($scope.natureOrgRealInfo == 1) {
                console.log($scope.natureOrgRealInfo == 1);
                $('.qy_info.location_input validate').removeClass('validate');
                console.log($('.qy_info.location_input.validate'))
                $('.jg_info.location_input').addClass('validate');
            } else if ($scope.natureOrgRealInfo == 2) {
                console.log($scope.natureOrgRealInfo == 2)
                $('.jg_info.location_input.validate').removeClass('validate');
                $('.qy_info.location_input ').addClass('validate');
            }
        }
        $scope.addOrgInfo = function() {
            //机构基本信息
            var createOrganizeRelationV = {
                superOrgId: $scope.superOrgId,
                orgCode: $scope.orgCode,
                orgNum: $scope.orgCode,
                orgName: $scope.orgName,
                roleId: $scope.roleId
            };
            //机构实名信息 OrgRealInfo
            var organizeRealInfoV = {
                nature: $scope.natureOrgRealInfo, //企业性质
                corporateName: $scope.corporateNameOrgRealInfo, //法人名称
                corporateCertificateType: $scope.corporateCertificateTypeOrgRealInfo, //法人证件类型
                corporateCertificateNo: $scope.corporateCertificateNoOrgRealInfo, //法人证件号
                ccpFId: $scope.ccpFIdOrgRealInfo, //正面
                ccbFId: $scope.ccbFIdOrgRealInfo, //背面
                cchFId: $scope.cchFIdOrgRealInfo, //手持
                licenseFId: $scope.licenseFIdOrgRealInfo, //营业执照附件编号
                license: $scope.licenseOrgRealInfo, //营业执照
                codeFId: $scope.codeFIdOrgRealInfo, //组织机构代码证附件编号
                code: $scope.codeOrgRealInfo, //组织机构代码证
                creditCodeFId: $scope.creditCodeFIdOrgRealInfo, //机构信用代码证附件编号
                creditCode: $scope.creditCodeOrgRealInfo, //机构信用代码证
                openingFId: $scope.openingFIdOrgRealInfo, //开户许可证附件编号
                opening: $scope.openingOrgRealInfo, //开户许可证
                taxFId: $scope.taxFIdOrgRealInfo, //税务证附件编号
                tax: $scope.taxOrgRealInfo, //税务证
                otherFId: $scope.otherFIdOrgRealInfo, //其他证附件编号
                other: $scope.otherOrgRealInfo //其他证
            };
            //机构超极管理员信息
            var createUserSecurityV = {
                email: $scope.smiEmail,
                loginName: $scope.smiLoginName,
                phone: $scope.smiPhone,
                password: $scope.smiPassword
            };
            //机构扩展信息
            var organizeInfoV = {
                area: $scope.area, //区域
                briefIntroduction: $scope.briefIntroduction, //公司简介
                businessScope: $scope.businessScope, //经营范围
                city: $scope.city, //城市
                country: $scope.country, //国家
                industry: $scope.industry, //行业
                netWorth: $scope.netWorth, //净资产
                property: $scope.property, //机构性质
                provinces: $scope.provinces, //省份
                registeredCapital: $scope.registeredCapital, //注册资金
                websiteAddress: $scope.websiteAddress //公司网址
            };
            //联系人信息列表
            var contactsVs = [{
                name: $scope.contactsListName,
                telephone: $scope.contactsListLocalPhone,
                mobileTelephone: $scope.contactsListMobilePhone,
                email: $scope.contactsListEmail,
                address: $scope.contactsListAdress,
                postcode: $scope.contactsListPostCode,
                sex: $scope.contactsListGender,
                fax: $scope.contactsListFax
            }];
            //if(toValidate('#memberAdd')) {
            memberMangerCtrlSer.add(createOrganizeRelationV, organizeRealInfoV, organizeInfoV, createUserSecurityV, contactsVs)
                .then(function(res) {
                    if (res.data.code == '000000') {
                        $rootScope.tipService.setMessage(res.data.message, 'warning');
                        $state.go('tabs.memberManage');
                    } else {
                        $rootScope.tipService.setMessage(res.data.message, 'warning');
                    }
                });
           //}
        };
        //图片上传
        uploadImg = function(id, num) {
            var urlUpload = $rootScope.baseUrl + 'file/upload';
            upload_img(urlUpload, id, function(data, status) {
                if (data.code === '000000') {
                    console.log(data);
                    var data = JSON.parse(data.content);
                    var ImgId = data[0].fileId;
                    switch (num) {
                        case 1:
                            $scope.ccpFIdOrgRealInfo = ImgId;
                            $('#uploadImg1').attr('src', "" + $rootScope.baseUrl + "/file/download?fileId=" + ImgId + "");
                            break;
                        case 2:
                            $scope.ccbFIdOrgRealInfo = ImgId;
                            $('#uploadImg2').attr('src', "" + $rootScope.baseUrl + "/file/download?fileId=" + ImgId + "");
                            break;
                        case 3:
                            $scope.cchFIdOrgRealInfo = ImgId;
                            $('#uploadImg3').attr('src', "" + $rootScope.baseUrl + "/file/download?fileId=" + ImgId + "");
                            break;
                        case 4:
                            $scope.licenseOrgRealInfo = ImgId;
                            $('#uploadImg4').attr('src', "" + $rootScope.baseUrl + "/file/download?fileId=" + ImgId + "");
                            break;
                        case 5:
                            $scope.codeOrgRealInfo = ImgId;
                            $('#uploadImg5').attr('src', "" + $rootScope.baseUrl + "/file/download?fileId=" + ImgId + "");
                            break;
                        case 6:
                            $scope.creditCodeOrgRealInfo = ImgId;
                            $('#uploadImg6').attr('src', "" + $rootScope.baseUrl + "/file/download?fileId=" + ImgId + "");
                            break;
                        case 7:
                            $scope.openingOrgRealInfo = ImgId;
                            $('#uploadImg7').attr('src', "" + $rootScope.baseUrl + "/file/download?fileId=" + ImgId + "");
                            break;
                        case 8:
                            $scope.taxOrgRealInfo = ImgId;
                            $('#uploadImg8').attr('src', "" + $rootScope.baseUrl + "/file/download?fileId=" + ImgId + "");
                            break;
                        case 9:
                            $scope.otherOrgRealInfo = ImgId;
                            $('#uploadImg9').attr('src', "" + $rootScope.baseUrl + "/file/download?fileId=" + ImgId + "");
                            break;
                    }
                }
            });
        };
        // 上传图片
        // url:后台访问路径 fileId:input file按钮id, btn:点击的按钮id, fileInput:接收上传图片的id
        function upload_img(url, fileId, callback) {
            $.ajaxFileUpload({
                url: url,
                type: 'post',
                secureuri: false,
                fileElementId: fileId, // file标签的id
                dataType: 'json', // 返回数据的类型
                data: {
                    name: fileId
                },
                success: function(data, status) {
                    callback(data, status)
                },
                error: function(data, status, e) {
                    console.log(data, status, e)
                }
            });
        }
         //放大图片
    $('.example img').zoomify();
   /* var imgs = document.getElementsByTagName("img");
    var lens = imgs.length;
    var popup = document.getElementById("popup");

    for (var i = 0; i < lens; i++) {
        imgs[i].onclick = function (event) {
            event = event || window.event;
            var target = document.elementFromPoint(event.clientX, event.clientY);
            showBig(target.src);
        }
    }
    popup.onclick = function () {
        popup.style.display = "none";
    };

    function showBig(src) {
        popup.getElementsByTagName("img")[0].src = src;
        popup.style.display = "block";
    }*/
});