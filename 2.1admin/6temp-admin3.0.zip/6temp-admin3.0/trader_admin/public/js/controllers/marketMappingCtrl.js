app.controller('marketMappingCtrl', ['$scope', '$rootScope', 'marketMappingCtrlSer', 'getPageNum', '$state', 'marketSourceProductManageCtrlSer', 'tipService','confirmService', function($scope, $rootScope, marketMappingCtrlSer, getPageNum, $state, marketSourceProductManageCtrlSer, tipService,confirmService) {
			$scope.tableshow = false;
			$scope.marketstate = false;
			//行情商品对应
			$scope.productId = '';
			$scope.ratio = '';
			$scope.quotationId = '';
			$scope.quotationProductId = '';
			$scope.productQuotaconfigId= '';
			$scope.accurateDigit = '';
			$scope.premium = '';
			$scope.addmarket = function() {
				$scope.tableshow = true;
				$scope.marketstate = false;
				$scope.addEditText = "新增";
				$scope.productId = '';
				$scope.ratio = '';
				$scope.quotationId = '';
				$scope.quotationProductId = '';
				$scope.accurateDigit = '';
				$scope.premium = '';
			}
			$scope.chooseItemTab1 = null;
			$scope.editmarket = function() {
				if (!$scope.chooseItemTab1) {
					$rootScope.tipService.setMessage('请先选择产品ID', 'warning');
				} else {
					$scope.tableshow = true;
					$scope.addEditText = "修改";
				}
			}
			$scope.search = function() {
				marketMappingCtrlSer.search($scope.showNum.showNum, $scope.currentPage, $scope.productId)
					.then(function(res) {
						if (res.code === '000000') {
							var data = JSON.parse(res.content);
							$scope.chooseProId = null;
							console.log(data)
							$scope.searchResult = data.content;
							$scope.showPage = true;
							$scope.dataNum = data.totalElements;
							$scope.PageNum();
						} else {
							$rootScope.tipService.setMessage(res.message, 'warning');
						}
					}, function(error) {
						$rootScope.tipService.setMessage(error.message, 'warning');
					});
			}
			marketSourceProductManageCtrlSer.search()
				.then(function(response) {
					//console.log(response);
					$scope.productList = response.list;
					console.log($scope.productList)
				}, function(error) {
					//console.log(error)
				})
			$scope.accountText = function(quotationProductId) {
					for (var i = 0, r = $scope.productList.length; i < r; i++) {
						if (quotationProductId == $scope.productList[i].key) {
							return $scope.productList[i].exchange + '-' + $scope.productList[i].commodity + '-' + $scope.productList[i].contract;
						}
					}
				}
				//单选
			$scope.positionCheck = function(index,productId,quotationName,quotationProductId,productQuotaconfigId) {
				$scope.chooseItemTab1 = productQuotaconfigId;
				$scope.productId = $scope.searchResult[index].productId;
				$scope.quotationName= $scope.searchResult[index].quotationName;
				$scope.quotationProductId = $scope.searchResult[index].quotationProductId;
				$scope.productQuotaconfigId = $scope.searchResult[index].productQuotaconfigId;
				$scope.quotationId = $scope.searchResult[index].quotationId;
				$scope.accurateDigit = $scope.searchResult[index].accurateDigit;
				$scope.premium = $scope.searchResult[index].premium;
				$scope.ratio = $scope.searchResult[index].ratio;

				$('#dataReport input[type=checkbox]').prop('checked', false);
				$('#dataReport input[type=checkbox]').eq(index).prop('checked', true);
				console.log($scope.productQuotaconfigId);

			}

			//正常、冻结状态产品ID
			marketMappingCtrlSer.prosearch(1, 99999, '')
				.then(function(res) {
					//console.log(res)
					var prolistdt = JSON.parse(res.content);
					$scope.prolist = [];
					for (var i = 0, r = prolistdt.length; i < r; i++) {
						if (prolistdt[i].state == 1 || prolistdt[i].state == 8000) {
							$scope.prolist.push(prolistdt[i]);
						}
					}
					//console.log($scope.prolist)
				});
			//所有状态产品ID
			marketMappingCtrlSer.prosearch(1, 99999, '')
				.then(function(res) {
					//console.log(res)
					var prolistdt = JSON.parse(res.content);
					$scope.proAlllist = [];
					for (var i = 0, r = prolistdt.length; i < r; i++) {
							$scope.proAlllist.push(prolistdt[i]);
					}
					console.log($scope.proAlllist)
				});

			$scope.PtText = function(productId) {
				if ($scope.proAlllist) {
					for (var i = 0, r = $scope.proAlllist.length; i < r; i++) {
						//console.log($scope.prolist[i])
						if ($scope.proAlllist[i].productId == productId) {
							return $scope.proAlllist[i].productName;
						}
					}
				}
			}

			marketMappingCtrlSer.quosearch()
				.then(function(res) {
					$scope.quolist = res.list;
					//console.log($scope.quolist)
				});
			//行情源账号
			$scope.selectAction = function() {
				console.log($scope.quotationId);
				marketMappingCtrlSer.symbolsearch($scope.quotationId)
					.then(function(res) {
						//console.log(res)
						$scope.ProductIdResult = res.data.list;
						//console.log($scope.ProductIdResult)
					});

			}

			$scope.saveinfo = function() {
				$scope.accurateDigitNum = parseInt($scope.accurateDigit);
				$scope.premiumNum = parseFloat($scope.premium);
				$scope.ratioNum = parseFloat($scope.ratio);
				if (toValidate('#marketMapp')) {
					marketMappingCtrlSer.addnew($scope.productQuotaconfigId, $scope.productId, $scope.quotationId, $scope.quotationProductId, $scope.accurateDigitNum, $scope.premiumNum, $scope.ratioNum)
						.then(function(res) {
							console.log(res)
							if (res.data.code == '000000') {
								$scope.tableshow = false;
								$rootScope.tipService.setMessage(res.data.message, 'warning');
								$scope.productId="";
								$scope.search();
							} else {
								$rootScope.tipService.setMessage(res.data.message, 'warning');
							}
						})
				}
			}
			//删除
			$scope.delete = function() {
					if (!$scope.chooseItemTab1) {
						$rootScope.tipService.setMessage('请先选择行情映射信息', 'warning');
					} else {
						confirmService.set('确认提示', '确定要删除此行情映射信息?', function() {
							marketMappingCtrlSer.Delete($scope.chooseItemTab1)
								.then(function(res) {
									if (res.data.code == "000000") {
									$rootScope.tipService.setMessage(res.data.message, 'warning');
									$scope.search();
									} else {
										$rootScope.tipService.setMessage(res.data.message, 'warning');
									}
								}, function(error) {
									$rootScope.tipService.setMessage(error.data.message, 'warning');
								});
							confirmService.clear();
						});
					}
				}

			/* 分页功能实现 */
			var pageInitialize = function() {
				$scope.dataNum = 0; //数据总条数
				$scope.dataPage = 0; //分页数
				$scope.currentPage = 1; //当前页数
				$scope.jumpPageNum = '';
			}
			$scope.showDataChoose = getPageNum.pageNum(); //获取分页
			$scope.showNum = $scope.showDataChoose[0]; //初始显示刷具条数
			$scope.dataPageNumber = []; //生成页面数
			$scope.showPage = false;
			$scope.pageSelect = function(params) {
				$scope.showNum.showNum = params.showNum;
				pageInitialize();
				$scope.search();
			}
			$scope.changePageNumber = function(params) {
				$scope.currentPage = params;
				$scope.search();
				$scope.PageNum();
			}
			$scope.PageNum = function() {
				if ($scope.showNum.showNum < $scope.dataNum) {
					$scope.dataPage = parseInt($scope.dataNum / $scope.showNum.showNum) + 1;
				} else {
					$scope.dataPage = 0;
				}
				$scope.dataPageNumber = [];
				for (var i = 0; i < $scope.dataPage; i++) {
					$scope.dataPageNumber.push(i + 1);
				}
			}
			$scope.jumpPage = function(num) {
				num = parseInt(num);
				if (parseInt(num, 10) === num && num <= ($scope.dataPage + 1) && num > 0) {
					$scope.currentPage = num;
					$scope.PageNum();
					$scope.search();
				}
			}
			$scope.pageSlect = function(type) {
				if (type == 'prev') {
					if ($scope.currentPage != 1) {
						$scope.currentPage--;
						$scope.PageNum();
						$scope.search();
					}
				} else {
					if ($scope.currentPage < $scope.dataPage) {
						$scope.currentPage++;
						$scope.PageNum();
						$scope.search();
					}
				}
			}
			pageInitialize();
			//$scope.search();
	}])
	.factory('marketMappingCtrlSer', ['$http', 'localStorageService', 'myHttp', '$q', '$rootScope', function($http, localStorageService, myHttp, $q, $rootScope) {
		return {
			prosearch: function(nowPage, showNum) {
				var json = {
					page: nowPage,
					rows: showNum,
					orders: 'asc'
				};
				var deferred = $q.defer();
				myHttp.post("config/product/query/as/list", json)
					.then(function(res) { // 调用承诺API获取数据 .resolve
						deferred.resolve(res);
					}, function(res) { // 处理错误 .reject
						deferred.reject(res);
					});
				return deferred.promise;
			},
			quosearch: function() {
				var deferred = $q.defer();
				myHttp.post("c/quote/accounts/query/all/enable")
					.then(function(res) { // 调用承诺API获取数据 .resolve
						deferred.resolve(res);
					}, function(res) { // 处理错误 .reject
						deferred.reject(res);
					});
				return deferred.promise;
			},
			symbolsearch: function(quotationId) {
				var json = {
					"account": quotationId
				}
				var deferred = $q.defer();
				$http({
					method: 'POST',
					url: $rootScope.baseUrl + 'c/quote/account/symbol/query/by/account',
					data: json
				}).then(function successCallback(response) {
					//console.log(response)
					deferred.resolve(response);
				}, function errorCallback(response) {
					deferred.reject(response);
				});
				return deferred.promise;
			},
			search: function(showNum, nowPage, productId) {
				var json = {
					page: nowPage,
					rows: showNum,
					orders: 'asc',
					search_A_LIKE_productId: productId
				}
				var deferred = $q.defer();
				myHttp.post("config/product/query/productQuotaconfig/as/page", json)
					.then(function(res) { // 调用承诺API获取数据 .resolve
						deferred.resolve(res);
					}, function(res) { // 处理错误 .reject
						deferred.reject(res);
					});
				return deferred.promise;
			},

			addnew: function(productQuotaconfigId, productId, quotationId, quotationProductId, accurateDigitNum, premiumNum, ratioNum) {
				var json = {
					"productQuotaconfig": {
						"productQuotaconfigId": productQuotaconfigId,
						"productId": productId,
						"quotations": [{
							"quotationId": quotationId,
							"quotationProductId": quotationProductId,
							"accurateDigit": accurateDigitNum,
							"premium": premiumNum,
							"ratio": ratioNum
						}]
					}

				}
				var deferred = $q.defer();
				$http({
					method: 'POST',
					url: $rootScope.baseUrl + 'config/product/save/productQuotaconfig',
					data: json
				}).then(function successCallback(response) {
					deferred.resolve(response);
				}, function errorCallback(response) {
					deferred.reject(response);
				});
				return deferred.promise;
			},
			Delete: function(chooseItemTab1) {
			var deferred = $q.defer();
			$http({
				method: 'POST',
				url: $rootScope.baseUrl + 'config/product/delete/productQuotaconfig',
				data: {
					"productQuotaconfigId": chooseItemTab1
				}
			}).then(function successCallback(response) {
				deferred.resolve(response);
			}, function errorCallback(response) {
				deferred.reject(response);
			});
			return deferred.promise;
		}
		}
	}])