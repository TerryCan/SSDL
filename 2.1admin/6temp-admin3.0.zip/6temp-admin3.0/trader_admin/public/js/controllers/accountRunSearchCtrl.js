app.controller('accountRunSearchCtrl', ['$rootScope', '$scope', 'accountRunSearchSer', '$timeout', '$sce', 'getPageNum',  'getIoType', 'getCurrencyType', 'timestamp', 'getAccountTradeType','getBankOpState','localStorageService', function ($rootScope, $scope, accountRunSearchSer,$timeout, $sce, getPageNum, getIoType, getCurrencyType, timestamp, getAccountTradeType,getBankOpState,localStorageService) {
    //数据转化
    //交易类型
    $scope.toggleTraderSearchState=false;
    $scope.Toggle = function(){
        $scope.toggleTraderSearchState = !$scope.toggleTraderSearchState;
        if($scope.toggleTraderSearchState){
           $('.search_column').css('height','auto');
        }
        else{
           $('.search_column').css('height','36px');
        }
    };
    //流水类型
    $scope.ioTypeNum = getIoType;
    //交易类型
    $scope.accountTradeType = getAccountTradeType;
    // 货币转换
    getCurrencyType.then(function (res) {
        $scope.currencyList = JSON.parse(res.content);
    });

    var processContent, processTotal;
    var source = {
        type: 'POST',
        datatype: "json",
        datafields: [  //数据字段定义
            {name: 'loginName', type: 'string'},
            {name: 'bankMerchantName', type: 'string'},
            {name: 'ioType', type: 'string'},
            {name: 'transType', type: 'string'},
            {name: 'bankOpState', type: 'string'},
            {name: 'currency', type: 'string'},

            {name: 'ioNumber', type: 'string'},
            {name: 'createTime', type: 'string'}
        ],
        url: $rootScope.baseUrl + 'exbank/query/exaccountios/page',
        root: "content",
        pagesize: 10,
        processData: function (data) {
            console.log(data)
            data.page = (data.pagenum + 1) ? (data.pagenum + 1) : 1;
            data.rows = (data.pagesize) ? (data.pagesize) : 10;
            data.order = ($scope.order) ? $scope.order : 'desc';
            data.sort = ($scope.sort) ? $scope.sort : 'createTime';
            data.search_A_EQ_userId = ($scope.directiveUserId) ? $scope.directiveUserId : '';
            data.search_EQ_ioType =($scope.ioType)?$scope.ioType:'';
            data.search_EQ_currency =($scope.currency)?$scope.currency:'';
            data.search_EQ_tradeType =($scope.transType)?$scope.transType:'';
            data.search_GTE_createTime = ($scope.createTimeStartNum) ? Date.parse(new Date(timestamp.formatTimeKind($scope.createTimeStartNum))) : '';
            data.search_LTE_createTime = ($scope.createTimeEndNum) ? Date.parse(new Date(timestamp.formatTimeKind($scope.createTimeEndNum))) : ''

            $scope.orgCode = localStorageService.get('oldOrgCode');
            if ($scope.organizeValue == true && $scope.downOrganizeValue == true) {
                data.search_A_LLIKE_orgCode = ($scope.orgCode) ? $scope.orgCode : '';
            }
            if ($scope.organizeValue == true && $scope.downOrganizeValue == false) {
                data.search_A_EQ_orgCode = ($scope.orgCode) ? $scope.orgCode : '';
            }
            if ($scope.organizeValue == false && $scope.downOrganizeValue == true) {
                data.search_A_LLIKE_orgCode = ($scope.orgCode) ? $scope.orgCode + '-' : '';
            }
        }, //传递参数处理
        beforeLoadComplete: function (records) { //数据完全加载完执行绘制表格
            console.log(records)
            var start;
            for (var i in records) {
                start = parseInt(i);
                break;
            }
            for (var k = 0, r = processContent.length; k < r; k++) {
                records[start + k].loginName = processContent[k].loginName;
                records[start + k].bankMerchantName = processContent[k].bankMerchantName;
                records[start + k].ioType = processContent[k].ioType;
                records[start + k].transType = processContent[k].transType;
                records[start + k].bankOpState = processContent[k].bankOpState;
                records[start + k].currency = processContent[k].currency;

                records[start + k].ioNumber = processContent[k].ioNumber;
                records[start + k].createTime = processContent[k].createTime;
            }
        },
        beforeprocessing: function (data) { //处理总页数
            var processData = JSON.parse(data.content);
            processContent = processData.content;
            source.totalrecords = processData.totalElements == 0 ? 5 : processData.totalElements;
            processTotal = processData.totalElements;
        },
        loadComplete: function (records) {
            $scope.saveResult = JSON.parse(records.content);
            var data = $scope.saveResult.totalElements;
            if (data == 0) {
                $('#contenttableentrustDetailGrid > div').remove();
            }
        },
        endUpdate: true
    };
    //创建数据适配器
    var dataAdapter = null;
    $scope.searchAjax = function () {
        $scope.toggleTraderSearchState = false;
        $('.search_column').css('height', '36px');
        if (dataAdapter == null) {
            dataAdapter = new $.jqx.dataAdapter(source);
            //创建表格
            $("#entrustDetailGrid").jqxGrid({
                source: dataAdapter,
                columns: [  //表格数据域
                    {
                        text: '用户名',
                        datafield: 'loginName',
                        width: '12%',
                        minwidth: 12 + '%',
                        align: 'center'
                    },
                    {
                        text: '商户号',
                        datafield: 'bankMerchantName',
                        minwidth: 12 + '%',
                        cellsalign: 'center',
                        align: 'center',
                        width: '12%'
                    },
                    {
                        text: '流水类型',
                        datafield: 'ioType',
                        width: '12%',
                        minwidth: 12 + '%',
                        align: 'center',
                        cellsrenderer: function (row, columnfield, value, defaulthtml, columnproperties) {
                            if (getIoType) {
                                for (var i = 0; i < getIoType.length; i++) {
                                    if (value == getIoType[i].id) {
                                        return getIoType[i].name;
                                    }
                                }
                            }
                        }
                    },
                    {
                        text: '交易类型',
                        datafield: 'transType',
                        minwidth: 12 + '%',
                        cellsalign: 'center',
                        align: 'center',
                        width: '12%',
                        cellsrenderer: function (row, columnfield, value, defaulthtml, columnproperties) {
                            if (getAccountTradeType) {
                                for (var i = 0; i < getAccountTradeType.length; i++) {
                                    if (value == getAccountTradeType[i].id) {
                                        return getAccountTradeType[i].name;
                                    }
                                }
                            }
                        }
                    },
                    {
                        text: '银行反馈',
                        datafield: 'bankOpState',
                        minwidth: 12 + '%',
                        align: 'center',
                        width: '12%',
                        cellsrenderer: function (row, columnfield, value, defaulthtml, columnproperties) {
                            if (getBankOpState) {
                                for (var i = 0; i < getBankOpState.length; i++) {
                                    if (value ==getBankOpState[i].id) {
                                        return getBankOpState[i].name;
                                    }
                                }
                            }
                        }
                    },
                    {
                        text: '币种',
                        datafield: 'currency',
                        minwidth: 12 + '%',
                        cellsalign: 'center',
                        align: 'center',
                        width: '12%',
                        cellsrenderer: function (row, columnfield, value, defaulthtml, columnproperties) {
                            if ($scope.currencyList) {
                                for (var i = 0; i < $scope.currencyList.length; i++) {
                                    if (value == $scope.currencyList[i].currency) {
                                        return $scope.currencyList[i].currencyName;
                                    }
                                }
                            }
                        }
                    },
                    {
                        text: '金额',
                        datafield: 'ioNumber',
                        minwidth: 12 + '%',
                        width: '12%',
                        align: 'center'
                    },
                    {
                        text: '日期',
                        datafield: 'createTime',
                        minwidth: 16 + '%',
                        cellsalign: 'center',
                        align: 'center',
                        width: '16%',
                        cellsrenderer: function (row, columnfield, value, defaulthtml, columnproperties) {
                            return timestamp.timestampCoverHms(value, 'all');
                        }
                    }
                ],
                width: 100 + '%',
                height: 87 + '%',
                theme: 'metrodark',
                virtualmode: true,
                rendergridrows: function (params) { //将数据渲染到页面
                    return params.data;
                },
                pageable: true,
                pagesizeoptions: ['10', '30', '100', '200'],
                // sortable: true,
                columnsresize: true,//列间距是否可调整
                selectionmode: 'singlecell',//选择模式
                clipboard: true
            });
        } else {
            $("#entrustDetailGrid").jqxGrid('updatebounddata', 'cells');
        }
    };
    //分页
    $("#entrustDetailGrid").on("pagechanged", function (event) {
        console.log(event)
    });
    //排序
    $("#entrustDetailGrid").on("sort", function (event) {
        var sortinformation = event.args.sortinformation;
        $scope.sort = sortinformation.sortcolumn;
        $scope.order = ($scope.sort) ? (sortinformation.sortdirection.ascending) ? 'asc' : 'desc' : 'asc';
        data = {
            order: $scope.order,
            sort: $scope.sort
        };
        source.processData(data);
        $("#entrustDetailGrid").jqxGrid('updatebounddata', 'sort');
    });

}])

// Server
    .factory('accountRunSearchSer', ['$http', 'localStorageService', 'myHttp', '$q', '$rootScope', function ($http, localStorageService, myHttp, $q, $rootScope) {
        return {
            accountRunSearch: function (json) {
                var deferred = $q.defer();
                myHttp.post("exbank/query/exaccountios/page", json)
                    .then(function (res) { // 调用承诺API获取数据 .resolve
                        deferred.resolve(res);
                    }, function (res) { // 处理错误 .reject
                        deferred.reject(res);
                    });
                return deferred.promise;
            }

        }
    }])