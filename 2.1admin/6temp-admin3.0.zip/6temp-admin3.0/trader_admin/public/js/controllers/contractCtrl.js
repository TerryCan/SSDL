app.controller('contractCtrl', ['$rootScope', '$scope', 'getPageNum','dataSer', 'localStorageService', 'confirmService','$timeout','contractCtrllSer','timestamp','VarietiesCtrlSer','getadminState', function ($rootScope, $scope, getPageNum, dataSer, localStorageService, confirmService,$timeout,contractCtrllSer,timestamp,VarietiesCtrlSer,getadminState) {
    $scope.toggleTraderSearchState = false;
    $scope.Toggle = function () {
        $scope.toggleTraderSearchState = !$scope.toggleTraderSearchState;
        if ($scope.toggleTraderSearchState) {
            $('.search_column').css('height', 'auto');
        }
        else {
            $('.search_column').css('height', '36px');
        }
    };
    localStorageService.clear('userIdChecked');
    $scope.tableshow = false;
    //时间戳
    $scope.timestamp = function(stamp) {
        return timestamp.timestampCoverHms(stamp, 'all')
    }
    $scope.contractNames='';
    $scope.ToState='';
    $scope.search = function (type) {
        $scope.toggleTraderSearchState = false;
        $('.search_column').css('height', '36px');
        if (type == 'search') {
            pageInitialize()
        };
        var json = {
            page: $scope.currentPage,
            rows: $scope.showNum.showNum,
            orders: 'asc',
            search_EQ_contractState: $scope.ToState,
            search_EQ_contractName: $scope.contractNames,

        };
        contractCtrllSer.search(json)
            .then(function (res) {
                console.log(res)
                if (res.code == '000000') {
                    $scope.showPage = true;
                    var data = JSON.parse(res.content);
                    $scope.searchResult = data.content;
                    console.log($scope.searchResult);
                    $scope.dataNum = data.totalElements;
                    $scope.PageNum();

                    var checkedUserId=localStorageService.get('userIdChecked'); //获取上一次存储的id
                    $scope.switchUserId(checkedUserId,$scope.searchResult); //执行选中方法
                } else {
                    $rootScope.tipService.setMessage(res.message, 'warning');
                }
            }, function (error) {
                $rootScope.tipService.setMessage(error.message, 'warning');
            });
    }

    VarietiesCtrlSer.searchlist()
        .then(function(res){
            console.log(res)
            if(res.code=="000000"){
                $scope.Varietieslist=JSON.parse(res.content);
                $scope.adjustText = function (commodityId) {
                    if ($scope.Varietieslist) {
                        for (var i = 0, r = $scope.Varietieslist.length; i < r; i++) {
                            if ($scope.Varietieslist[i].commodityId == commodityId) {
                                return $scope.Varietieslist[i].commodityName;
                            }
                        }
                    }
                }
            }
        })

    /**
     * 分页功能实现TerryMin
     * **/
    $scope.showDataChoose = getPageNum.pageNum(); //获取分页
    $scope.showNum = $scope.showDataChoose[0]; //初始显示刷具条数
    $scope.showPage = false;
    var pageInitialize = function () {
        $scope.dataNum = 0; //数据总条数
        $scope.dataPage = 0; //分页数
        $scope.currentPage = 1; //当前页数
        $scope.jumpPageNum = '';
    };
    pageInitialize();

    // x/y $scope.dataPage
    $scope.PageNum = function () {
        $scope.showPage = true;
        if ($scope.showNum.showNum < $scope.dataNum) {
            $scope.dataPage =Math.ceil($scope.dataNum / $scope.showNum.showNum);
        } else {
            $scope.dataPage = 0;
        }
    };
    //上页下页 $scope.currentPage
    $scope.pageSlect = function (type) {
        if (type == 'prev') {
            if ($scope.currentPage != 1) {
                $scope.currentPage--;
                $scope.PageNum();
                $scope.search();
            }
        } else {
            if ($scope.currentPage < $scope.dataPage) {
                $scope.currentPage++;
                $scope.PageNum();
                $scope.search();
            }
        }
    };
    // 每页条数单元
    $scope.pageSelect = function (params) {
        $scope.showNum.showNum = params.showNum;
        pageInitialize();
        $scope.search();
    };
    //页数跳转 currentPage
    $scope.jumpPage = function (num) {
        num = parseInt(num);
        if (parseInt(num, 10) === num && num <= ($scope.dataPage + 1) && num > 0) {
            $scope.currentPage = num;
            $scope.PageNum();
            $scope.search();
        }
    };

    // 选择
    $scope.checkedTab1 = function (index,contractId,marketId,commodityId,categoryId,contractName,contractCode,contractSort,dueDate,finalDate,noticeDate,contractState,year,month,week){
        $scope.chooseUserData={
            contractId: contractId,
            marketId: marketId,
            commodityId: commodityId,
            categoryId: categoryId,
            contractName: contractName,
            contractCode: contractCode,
            contractSort: contractSort,
            dueDate: dueDate,
            finalDate: finalDate,
            noticeDate: noticeDate,
            contractState:contractState,
            year:year,  //年
            month:month,  //月
            week:week,	 //周
        };
        console.log($scope.chooseUserData)
        var userIdChecked = localStorageService.get('userIdChecked');
        $('#dataReport input[type=checkbox]').prop('checked', false);
        if (contractId == userIdChecked) {
            localStorageService.clear('userIdChecked');
            $scope.chooseItemTab1 = '';
            $scope.contractState='';
        } else {
            $('#dataReport input[type=checkbox]').eq(index).prop('checked', true);
            localStorageService.update('userIdChecked', contractId);
            $scope.chooseItemTab1 = contractId;
            $scope.contractState=contractState;
        }
    };
    // 存储选中
    $scope.switchUserId = function (parameter, responseData) {
        $timeout(function () {
            for (var i = 0; i < responseData.length; i++) {
                if (parameter == responseData[i].contractId) {
                    $('#dataReport input[type=checkbox]').eq(i).prop('checked', true);
                    return;
                }
            }
        }, 1500)
    };


    contractCtrllSer.Varietylists()
        .then(function(res){
            console.log(res)
            if(res.code="000000"){
                $scope.Marketresults=JSON.parse(res.content);
                console.log($scope.Marketresults)
                $scope.marketNamety=function(commodityId){
                    for (var i = 0, r = $scope.Marketresults.length; i < r; i++) {
                        if ($scope.Marketresults[i].commodityId == commodityId) {
                            return $scope.Marketresults[i].marketName;
                        }
                    }
                }
            }
        })
    $scope.add = function () {
        $scope.tableshow = true;
        $scope.addEditText = '新增';
        $scope.commodityIds = '';   //品种编码
        $scope.contractName	 = '';	//合约名称
        $scope.contractCode = '';	//合约简码
        $scope.contractSort	 = '';	//合约排序
        $scope.dueDate = '';  //合约到期日
        $scope.finalDate = '';  //最后交易日
        $scope.noticeDate = '';	 //首次通知日
        $scope.year = '';  //年
        $scope.month = '';  //月
        $scope.week = '';	 //周



    }

    $scope.edit = function () {
        if (!$scope.chooseItemTab1) {
            $rootScope.tipService.setMessage('请先选择合约信息', 'warning');
        } else {
            $scope.addEditText = '修改';
            $scope.tableshow = true;
            $scope.contractId=$scope.chooseUserData.contractId;
            $scope.commodityIds=$scope.chooseUserData.commodityId;
            $scope.contractName=$scope.chooseUserData.contractName;
            $scope.contractCode=$scope.chooseUserData.contractCode;
            $scope.contractSort=parseInt($scope.chooseUserData.contractSort);
            $scope.dueDate=$scope.timestamp($scope.chooseUserData.dueDate);
            $scope.finalDate=$scope.timestamp($scope.chooseUserData.finalDate);
            $scope.noticeDate=$scope.timestamp($scope.chooseUserData.noticeDate);
            $scope.year=parseInt($scope.chooseUserData.year); //年
            $scope.month=parseInt($scope.chooseUserData.month); //月
            $scope.week=parseInt($scope.chooseUserData.week); //周

        }
    }
    $scope.addSubmit = function () {
        if ($scope.addEditText == "新增") {
            $scope.dueDates=Date.parse(new Date($scope.dueDate));
            $scope.finalDates=Date.parse(new Date($scope.finalDate));
            $scope.noticeDates=Date.parse(new Date($scope.noticeDate));
            var contractVIce={
                commodityId:$scope.commodityIds,   //品种编码
                contractName:$scope.contractName,	//合约名称
                contractCode:$scope.contractCode,	//合约简码
                contractSort:parseInt($scope.contractSort),	//合约排序
                dueDate:parseInt($scope.dueDates),  //合约到期日
                finalDate:parseInt($scope.finalDates),  //最后交易日
                noticeDate:parseInt($scope.noticeDates),	 //首次通知日
                year:parseInt($scope.year),  //年
                month:parseInt($scope.month),  //月
                week:parseInt($scope.week),	 //周
            };
            var json = {
                contractVIce: contractVIce
            }
            contractCtrllSer.Addsub(json)
                .then(function (res) {
                        if (res.data.code == "000000") {
                            $scope.tableshow = false;
                            $rootScope.tipService.setMessage(res.data.message, 'warning');
                            localStorageService.clear('userIdChecked');
                            $scope.search();
                        }else{
                            $rootScope.tipService.setMessage(res.data.message, 'warning');
                        }
                    },function(error){
                        $rootScope.tipService.setMessage(error.data.message, 'warning');
                    }
                )
        } else if ($scope.addEditText == "修改") {
            $scope.dueDates=Date.parse(new Date($scope.dueDate));
            $scope.finalDates=Date.parse(new Date($scope.finalDate));
            $scope.noticeDates=Date.parse(new Date($scope.noticeDate));
            var contractVIce={
                contractId:$scope.contractId,
                commodityId:$scope.commodityIds,   //品种编码
                contractName:$scope.contractName,	//合约名称
                contractCode:$scope.contractCode,	//合约简码
                contractSort:parseInt($scope.contractSort),	//合约排序
                dueDate:parseInt($scope.dueDates),  //合约到期日
                finalDate:parseInt($scope.finalDates),  //最后交易日
                noticeDate:parseInt($scope.noticeDates),	 //首次通知日
                year:parseInt($scope.year),  //年
                month:parseInt($scope.month),  //月
                week:parseInt($scope.week),	 //周
            };
            var json = {
                contractVIce: contractVIce
            }
            contractCtrllSer.editsub(json)
                .then(function (res) {
                    if (res.data.code == "000000") {
                        $scope.tableshow = false;
                        $rootScope.tipService.setMessage(res.data.message, 'warning');
                        localStorageService.clear('userIdChecked');
                        $scope.search();
                    }
                    else {
                        $rootScope.tipService.setMessage(res.data.message, 'warning');
                    }
                },function(error){
                    $rootScope.tipService.setMessage(error.data.message, 'warning')
                })
        }
    }

    $scope.allotTypeData=getadminState;
    $scope.allotTypeText = function(val) {
        for (var i = 0, r = $scope.allotTypeData.length; i < r; i++) {
            if (val == $scope.allotTypeData[i].id) {
                return $scope.allotTypeData[i].name;
            }
        }
    }
    $scope.pass=function() {
        if (!$scope.chooseItemTab1) {
            $rootScope.tipService.setMessage('请先选择合约管理信息', 'warning');
        } else {
            var json={
                contractId:$scope.chooseItemTab1
            }
            contractCtrllSer.passCheck(json)
                .then(function (res) {
                    if (res.data.code == '000000') {
                        localStorageService.clear('userIdChecked');
                        $rootScope.tipService.setMessage(res.data.message, 'warning');
                        $scope.search();
                    } else {
                        $rootScope.tipService.setMessage(res.data.message, 'warning');
                    }
                }, function (error) {
                    $rootScope.tipService.setMessage(error.data.message, 'warning');
                });
        }
    }
    $scope.fail=function() {
        if (!$scope.chooseItemTab1) {
            $rootScope.tipService.setMessage('请先选择合约管理信息', 'warning');
        } else {
            var json={
                contractId:$scope.chooseItemTab1
            }
            contractCtrllSer.failedCheck(json)
                .then(function (res) {
                    if (res.data.code == '000000') {
                        localStorageService.clear('userIdChecked');
                        $rootScope.tipService.setMessage(res.data.message, 'warning');
                        $scope.search();
                    } else {
                        $rootScope.tipService.setMessage(res.data.message, 'warning');
                    }
                }, function (error) {
                    $rootScope.tipService.setMessage(error.data.message, 'warning');
                });
        }
    }
    $scope.open=function() {
        if (!$scope.chooseItemTab1) {
            $rootScope.tipService.setMessage('请先选择合约管理信息', 'warning');
        } else {
            var json={
                contractId:$scope.chooseItemTab1
            }
            contractCtrllSer.open(json)
                .then(function (res) {
                    if (res.data.code == '000000') {
                        localStorageService.clear('userIdChecked');
                        $rootScope.tipService.setMessage(res.data.message, 'warning');
                        $scope.search();
                    } else {
                        $rootScope.tipService.setMessage(res.data.message, 'warning');
                    }
                }, function (error) {
                    $rootScope.tipService.setMessage(error.data.message, 'warning');
                });
        }
    }

    $scope.close=function() {
        if (!$scope.chooseItemTab1) {
            $rootScope.tipService.setMessage('请先选择合约管理信息', 'warning');
        } else {
            confirmService.set('确认提示', '确定要注销此合约管理信息?', function () {
                var json={
                    contractId:$scope.chooseItemTab1
                }
                contractCtrllSer.Close(json)
                    .then(function (res) {
                        if (res.data.code == '000000') {
                            localStorageService.clear('userIdChecked');
                            $rootScope.tipService.setMessage(res.data.message, 'warning');
                            $scope.search();
                        } else {
                            $rootScope.tipService.setMessage(res.data.message, 'warning');
                        }
                    }, function (error) {
                        $rootScope.tipService.setMessage(error.data.message, 'warning');
                    });
                confirmService.clear();
            });
        }
    }

}])
    .factory('contractCtrllSer', ['$http', 'localStorageService', 'myHttp', '$q', '$rootScope', function ($http, localStorageService, myHttp, $q, $rootScope) {
        return {
            //查询
            search: function (json) {
                var deferred = $q.defer();
                myHttp.post("admin/config/product/contract/query/page", json)
                    .then(function (res) { // 调用承诺API获取数据 .resolve
                        deferred.resolve(res);
                    }, function (res) { // 处理错误 .reject
                        deferred.reject(res);
                    });
                return deferred.promise;
            },
            Varietylists: function () {
                var deferred = $q.defer();
                myHttp.post("admin/config/product/commodity/query/list")
                    .then(function (res) { // 调用承诺API获取数据 .resolve
                        deferred.resolve(res);
                    }, function (res) { // 处理错误 .reject
                        deferred.reject(res);
                    });
                return deferred.promise;

            },

            Addsub: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'admin/config/product/contract/create',
                    data: json
                }).then(function successCallback(response) {
                    console.log(response)
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
            editsub: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'admin/config/product/contract/update',
                    data: json
                }).then(function successCallback(response) {
                    console.log(response)
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
            Close: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'admin/config/product/contract/close',
                    data: json
                }).then(function successCallback(response) {
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
            //通过
            passCheck: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'admin/config/product/contract/pass',
                    data: json
                }).then(function successCallback(response) {
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
            //不通过
            failedCheck: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'admin/config/product/contract/fail',
                    data: json
                }).then(function successCallback(response) {
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
            //重新提交
            open: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'admin/config/product/contract/open',
                    data: json
                }).then(function successCallback(response) {
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
        }
    }])
