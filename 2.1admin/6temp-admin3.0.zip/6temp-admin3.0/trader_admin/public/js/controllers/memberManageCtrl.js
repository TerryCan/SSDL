app.controller("memberManageCtrl", ["$scope", "dataSer", "getUserStates", "memberMangerCtrlSer", "getPageNum", "localStorageService", "$timeout", '$state', "$rootScope", "$sce", "userJurisdictionCtrlSer", 'timestamp', function ($scope, dataSer, getUserStates, memberMangerCtrlSer, getPageNum, localStorageService, $timeout, $state, $rootScope, $sce, userJurisdictionCtrlSer, timestamp) {
    $scope.toggleTraderSearchState=false;
    $scope.Toggle = function(){
        $scope.toggleTraderSearchState = !$scope.toggleTraderSearchState;
        if($scope.toggleTraderSearchState){
           $('.search_column').css('height','auto');
        }
        else{
           $('.search_column').css('height','36px');
        }
    };
    //修改权限
    var jurisdictionList = sessionStorage.getItem('nav');
    var realInfoState = (/ORGANIZE_ORGANIZE_SAVE_REAL_INFO/gi).test(jurisdictionList);
    var saveInfoState = (/ORGANIZE_ORGANIZE_SAVE_INFO/gi).test(jurisdictionList);
    if(realInfoState && saveInfoState) {
        $scope.modifyColumn = true;
    } else {
        $scope.modifyColumn = false;
    }
    //查询
    var processContent, processTotal;
    var source = {
        type: 'POST',
        datatype: "json",
        datafields: [  //数据字段定义
            {name: 'role', type: 'object'},
            {name: 'orgId', type: 'string'},
            {name: 'userSecurity', type: 'object'},
            {name: 'orgNum', type: 'string'},
            {name: 'orgName', type: 'string'},
            {name: 'superOrganize', type: 'object'},

            {name: 'state', type: 'string'},
            {name: 'userUnique', type: 'string'},
            {name: 'roleAuthoriseds', type: 'string'},
            {name: 'userAuthoriseds', type: 'string'},
            {name: 'createTime', type: 'string'}
        ],
        url: $rootScope.baseUrl + 'organize/query/as/page',
        root: "content",
        pagesize: 10,
        processData: function (data) {
            data.page = (data.pagenum + 1) ? (data.pagenum + 1) : 1;
            data.rows = (data.pagesize) ? (data.pagesize) : 10;
            // data.order = ($scope.order) ? $scope.order : 'desc';
            // data.sort = ($scope.sort) ? $scope.sort : 'createTime';
            data.search_A_LIKE_orgNum = ($scope.orgNum) ? $scope.orgNum : '';
            data.search_A_LIKE_orgName = ($scope.orgName) ? $scope.orgName : '';
            data.search_A_EQ_state = ($scope.chooseCustomerState) ? $scope.chooseCustomerState : '';
            data['search_A_EQ_sysUserSecuritys.loginName'] = ($scope.loginName) ? $scope.loginName : '';
        }, //传递参数处理
        beforeLoadComplete: function (records) { //数据完全加载完执行绘制表格
            var start;
            for (var i in records) {
                start = parseInt(i);
                break;
            }
            for (var k = 0, r = processContent.length; k < r; k++) {
                records[start + k].role = processContent[k].role;
                records[start + k].orgId = processContent[k].orgId;
                records[start + k].userSecurity = processContent[k].userSecurity;
                records[start + k].orgNum = processContent[k].orgNum;
                records[start + k].orgName = processContent[k].orgName;
                records[start + k].superOrganize = processContent[k].superOrganize;

                records[start + k].state = processContent[k].state;
                records[start + k].userUnique = processContent[k].userUnique;
                records[start + k].roleAuthoriseds = processContent[k].role.roleAuthoriseds;
                records[start + k].userAuthoriseds = processContent[k].role.userAuthoriseds;
                records[start + k].createTime = processContent[k].createTime;
            }
        },
        beforeprocessing: function (data) { //处理总页数
            var processData = JSON.parse(data.content);
            console.log(processData)
            processContent = processData.content;
            source.totalrecords = processData.totalElements == 0 ? 5 : processData.totalElements;
            processTotal = processData.totalElements;
        },
        loadComplete: function (records) {
            $scope.saveResult = JSON.parse(records.content);
            var data = $scope.saveResult.totalElements;
            if (data == 0) {
                $('#contenttableentrustDetailGrid > div').remove();
            }
        },
        endUpdate: true
    };
    //创建数据适配器
    var dataAdapter = null;
    $scope.searchAjax = function () {
        $scope.featureShow = true;
        $scope.toggleTraderSearchState = false;
        $('.search_column').css('height', '36px');
        if (dataAdapter == null) {
            dataAdapter = new $.jqx.dataAdapter(source);
            //创建表格
            $("#entrustDetailGrid").jqxGrid({
                source: dataAdapter,
                columns: [  //表格数据域
                    {
                        text: '用户名',
                        datafield: 'userSecurity',
                        width: '11%',
                        minwidth: 11 + '%',//设置列min宽
                        align: 'center',//设置表头
                        cellsrenderer: function (row, columnfield, value, defaulthtml, columnproperties) {
                            if (value) {
                                return value.loginName
                            }
                        }
                    },
                    {
                        text: '机构编号',
                        datafield: 'orgNum',
                        minwidth: 11 + '%',
                        cellsalign: 'center',
                        align: 'center',
                        width: '11%'
                    },
                    {
                        text: '机构名称',
                        datafield: 'orgName',
                        width: '11%',
                        minwidth: 11 + '%',
                        align: 'center'
                    },
                    {
                        text: '上级机构',
                        datafield: 'superOrganize',
                        width: '11%',
                        minwidth: 11 + '%',
                        align: 'center',
                        cellsrenderer: function (row, columnfield, value, defaulthtml, columnproperties) {
                            if (value) {
                                return value.orgName
                            }
                        }
                    },
                    {
                        text: '状态',
                        datafield: 'state',
                        width: '11%',
                        minwidth: 11 + '%',
                        align: 'center',
                        cellsrenderer: function (row, columnfield, value, defaulthtml, columnproperties) {
                            if ($scope.customerStateList) {
                                for (var i in $scope.customerStateList) {
                                    if (value == i) {
                                        return $scope.customerStateList[i];
                                    }
                                }
                            }
                        }
                    },
                    {
                        text: '用户唯一',
                        datafield: 'userUnique',
                        width: '11%',
                        minwidth: 11 + '%',
                        align: 'center',
                        cellsrenderer: function (row, columnfield, value, defaulthtml, columnproperties) {
                            if ($scope.UniqueData) {
                                for (var i = 0; i < $scope.UniqueData.length; i++) {
                                    if (value == $scope.UniqueData[i].val) {
                                        return $scope.UniqueData[i].name;
                                    }
                                }
                            }
                        }
                    },
                    {
                        text: '授权数',
                        datafield: 'roleAuthoriseds',
                        width: '11%',
                        minwidth: 11 + '%',
                        align: 'center'
                    },
                    {
                        text: '授予用户数',
                        datafield: 'userAuthoriseds',
                        width: '11%',
                        minwidth: 11 + '%',
                        align: 'center'
                    },
                    {
                        text: '注册时间',
                        datafield: 'createTime',
                        width: '12%',
                        minwidth: 12 + '%',
                        align: 'center',
                        cellsrenderer: function (row, columnfield, value, defaulthtml, columnproperties) {
                            if (value) {
                                return timestamp.timestampCoverHms(value, 'all')
                            }
                        }
                    }
                ],
                width: 100 + '%',
                height: 81 + '%',
                theme: 'metrodark',
                virtualmode: true,
                rendergridrows: function (params) { //将数据渲染到页面
                    return params.data;
                },
                pageable: true,
                pagesizeoptions: ['10', '30', '100', '200'],
                sortable: true,
                columnsresize: true,//列间距是否可调整
                clipboard: true
            });
        } else {
            $("#entrustDetailGrid").jqxGrid('updatebounddata', 'cells');
        }
    };

    //分页
    $("#entrustDetailGrid").on("pagechanged", function (event) {
        console.log(event)
    });
    //排序
    $("#entrustDetailGrid").on("sort", function (event) {
        var sortinformation = event.args.sortinformation;
        $scope.sort = sortinformation.sortcolumn;
        $scope.order = ($scope.sort) ? (sortinformation.sortdirection.ascending) ? 'asc' : 'desc' : 'asc';
        data = {
            order: $scope.order,
            sort: $scope.sort
        };
        source.processData(data);
        $("#entrustDetailGrid").jqxGrid('updatebounddata', 'sort');
    });
    //选中
    $scope.Roleaudit = true;
    $scope.Roleauthority = true;
    $scope.chooseOrgData = {
        orgId: null,
        roleId: null,
        state: null,
        authApplyId: null
    };
    $('#entrustDetailGrid').on('rowselect', function (event) {
        console.log(event.args.row);
        if (event.args.row.role.authApplyId != null) {
            $scope.Roleaudit = false;
            $scope.Roleauthority = true;
        } else {
            $scope.Roleauthority = false;
            $scope.Roleaudit = true;
        }
        $scope.chooseOrgData.orgId = event.args.row.orgId;
        $scope.chooseOrgData.roleId = event.args.row.role.roleId;
        $scope.chooseOrgData.authApplyId = event.args.row.role.authApplyId;
        localStorageService.update('userIdChecked',$scope.chooseOrgData.orgId);
        console.log($scope.chooseOrgData.orgId);
        $scope.state = event.args.row.state;
        $scope.chooseOrgData.state = event.args.row.state;
        $scope.$apply()
    });

    //时间戳
    $scope.timestamp = function (stamp) {
        return timestamp.timestampCoverHms(stamp, 'all')
    };
    //冻结
    $scope.freeze = function () {
        if ($scope.chooseOrgData.orgId) {
                memberMangerCtrlSer.freeze($scope.chooseOrgData.orgId)
                    .then(function (res) {
                        if (res.data.code == '000000') {
                            $rootScope.tipService.setMessage(res.data.message, 'warning');
                            $scope.searchAjax();
                        }
                        else {
                            $rootScope.tipService.setMessage(res.data.message, 'warning');
                        }
                    }, function (error) {
                        $rootScope.tipService.setMessage(error.data.message, 'warning');
                    });
        } else {
            $rootScope.tipService.setMessage('请先选择用户!', 'warning');
        }
    };
    //解冻
    $scope.unFreeze = function () {
        if ($scope.chooseOrgData.orgId) {
                memberMangerCtrlSer.unfreeze($scope.chooseOrgData.orgId)
                    .then(function (res) {
                        if (res.data.code == '000000') {
                            $rootScope.tipService.setMessage(res.data.message, 'warning');
                            $scope.searchAjax();
                        }
                        else {
                            $rootScope.tipService.setMessage(res.data.message, 'warning');
                        }
                    }, function (error) {
                        $rootScope.tipService.setMessage(error.data.message, 'warning');
                    });
        } else {
            $rootScope.tipService.setMessage('请先选择用户!', 'warning');
        }
    };
    //通过审核
    $scope.passCheck = function () {
        if ($scope.chooseOrgData.orgId) {
                memberMangerCtrlSer.passCheck($scope.chooseOrgData.orgId)
                    .then(function (res) {
                        if (res.data.code == '000000') {
                            $rootScope.tipService.setMessage(res.data.message, 'warning');
                            $scope.searchAjax();
                        }
                        else {
                            $rootScope.tipService.setMessage(res.data.message, 'warning');
                        }
                    }, function (error) {
                        $rootScope.tipService.setMessage(error.data.message, 'warning');
                    });

        } else {
            $rootScope.tipService.setMessage('请先选择用户!', 'warning');
        }
    };
    //审核驳回
    $scope.failedCheck = function () {
        if ($scope.chooseOrgData.orgId) {
                memberMangerCtrlSer.failedCheck($scope.chooseOrgData.orgId)
                    .then(function (res) {
                        if (res.data.code == '000000') {
                            $rootScope.tipService.setMessage(res.data.message, 'warning');
                            $scope.searchAjax();
                        }
                        else {
                            $rootScope.tipService.setMessage(res.data.message, 'warning');
                        }
                    }, function (error) {
                        $rootScope.tipService.setMessage(error.data.message, 'warning');
                    });
        } else {
            $rootScope.tipService.setMessage('请先选择用户!', 'warning');
        }
    };
    //重新审核
    $scope.rePassCheck = function () {
        if ($scope.chooseOrgData.orgId) {
                memberMangerCtrlSer.open($scope.chooseOrgData.orgId)
                    .then(function (res) {
                        if (res.data.code == '000000') {
                            $rootScope.tipService.setMessage(res.data.message, 'warning');
                            $scope.searchAjax();
                        }
                        else {
                            $rootScope.tipService.setMessage(res.data.message, 'warning');
                        }
                    }, function (error) {
                        $rootScope.tipService.setMessage(error.data.message, 'warning');
                    });
        } else {
            $rootScope.tipService.setMessage('请先选择用户!', 'warning');
        }
    };
    //注销
    $scope.removeShow = function () {
        if (!$scope.chooseOrgData.orgId) {
            $rootScope.tipService.setMessage('请先选择会员', 'warning');
        } else {
            $scope.removeShowing = true;
        }
    };
    $scope.cancel = function () {
        memberMangerCtrlSer.close($scope.chooseOrgData.orgId)
            .then(function (res) {
                if (res.data.code == '000000') {
                    $scope.removeShowing = false;
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                    $scope.searchAjax();
                }
                else {
                    $scope.removeShowing = false;
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                    $scope.searchAjax();
                }
            }, function (error) {
                $scope.removeShowing = false;
                $rootScope.tipService.setMessage(error.data.message, 'warning');
            });
    };
//角色授权
    //角色授权弹框
    $scope.jurisdictionShow = false;
    $scope.editJurisdiction = function () {
        if (!$scope.chooseOrgData.orgId) {
            $rootScope.tipService.setMessage('请先选择用户', 'warning');
        } else {
            $scope.jurisdictionShow = true;
            console.log($scope.chooseOrgData.roleId);
            $scope.getCanJurisdiction($scope.chooseOrgData.roleId);
            $scope.getIsJurisdiction($scope.chooseOrgData.roleId);
        }
    };

    //可授权列表
    $scope.getCanJurisdiction = function (roleId) {
        userJurisdictionCtrlSer.canJurisdiction(roleId)
            .then(function (res) {
                if (res.data.code === '000000') {
                    $scope.canJurisdictionData = [];
                    var data = JSON.parse(res.data.content);
                    console.log(data);  //可授权数据
                    for (var i = 0, r = data.length; i < r; i++) {
                        data[i].filterId = i;
                        $scope.canJurisdictionData.push(data[i]);
                    }
                }
            });
    };

    //已授权列表
    $scope.getIsJurisdiction = function (roleId) {
        userJurisdictionCtrlSer.isJurisdiction(roleId)
            .then(function (res) {
                if (res.data.code === '000000') {
                    $scope.isJurisdictionData = JSON.parse(res.data.content);
                    console.log($scope.isJurisdictionData)  //已授权数据
                }
            }, function (error) {

            });
    };
    //选中授权记录
    $scope.authorization = function () {
        $scope.baseAuthorizationList = [];
        for (var i = 0, r = $scope.userManageMultiple.length; i < r; i++) {
            var tmp = parseInt($scope.userManageMultiple[i]);
            console.log(tmp);
            $scope.baseAuthorizationList.push($scope.canJurisdictionData[tmp]);
        }
    };
    //授权点击事件
    $scope.toAuthorization = function () {
        for (var i = 0, r = $scope.baseAuthorizationList.length; i < r; i++) {
            //$scope.baseAuthorizationList[i].roleAuthorisedId = ''; //清空重新分配
            $scope.baseAuthorizationList[i].freezingValid = false; //冻结默认关闭
            $scope.isJurisdictionData.push($scope.baseAuthorizationList[i]);
        }
        //$scope.postJurisdiction();
        $scope.baseAuthorizationList = [];
    };

    //提交授权
    /*$scope.postJurisdiction = function (tmpOpt) {
        userJurisdictionCtrlSer.postJurisdiction($scope.chooseOrgData.roleId, $scope.isJurisdictionData)
            .then(function (res) {
                if (res.data.code === '000000') {
                    $scope.getIsJurisdiction($scope.chooseOrgData.roleId);
                } else {
                    $scope.getIsJurisdiction($scope.chooseOrgData.roleId);
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                }
            }, function (error){
                $rootScope.tipService.setMessage(error.data.message, 'warning');
            });
        if (tmpOpt) {  //确定提交
            $scope.jurisdictionShow = false;
            $scope.search();
        }
    };*/

    $scope.postJurisdiction = function (tmpOpt) {
        console.log(tmpOpt)
        userJurisdictionCtrlSer.postJurisdiction($scope.chooseOrgData.roleId, $scope.isJurisdictionData)
            .then(function (res) {
                console.log(res)
                if (res.data.code === '000000') {
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                    localStorageService.clear('userIdChecked');
                    $scope.searchAjax();
                    $scope.getIsJurisdiction($scope.chooseOrgData.roleId);
                } else {
                    $scope.getIsJurisdiction($scope.chooseOrgData.roleId);
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                }
            }, function (error) {
                $rootScope.tipService.setMessage(error.data.message, 'warning');
            });
        if (tmpOpt) {
            $scope.jurisdictionShow = false;
            $scope.searchAjax();
        }
    };
    //删除单条授权记录
    /*$scope.delJurisdictionData = function (roleAuthorisedId) {
        userJurisdictionCtrlSer.delJurisdictionData(roleAuthorisedId)
            .then(function (res) {
                if (res.data.code != '000000') {
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                }
                $scope.getIsJurisdiction($scope.chooseOrgData.roleId);
            }, function (error) {
                $rootScope.tipService.setMessage(error.data.message, 'warning');
                $scope.getIsJurisdiction($scope.chooseOrgData.roleId);
            });
    };*/
    $scope.delJurisdictionData = function ($index) {
        $scope.isJurisdictionData.splice($index, 1)
        //$scope.getIsJurisdiction();
    };

    //删除所有已授权
    $scope.deleteAauthorization = function () {
        for (var i = 0, r = $scope.isJurisdictionData.length; i < r; i++) {
            $scope.isJurisdictionData[i].delete = true;
        }
        $scope.isJurisdictionData =[];
    };

    //修改
    $scope.edit = function (url) {
        if ($scope.chooseOrgData.orgId) {
            $state.go(url);
        }
        else {
            $rootScope.tipService.setMessage('请先选择会员', 'warning');
        }
    };
    //新增
    $scope.trunPage = function (url) {
        $state.go(url);
    }
    $scope.UniqueData = [{
        name: '是',
        val: true
    }, {
        name: '否',
        val: false
    }];

    $scope.getuserUnique = function (val) {
        for (var i = 0, r = $scope.UniqueData.length; i < r; i++) {
            if (val == $scope.UniqueData[i].val) {
                return $scope.UniqueData[i].name;
            }
        }
    };
    getUserStates.userState().then(function (res) {
        $scope.customerStateList = res;
    });
    $scope.getState = function (params) {
        for (var i in $scope.customerStateList) {
            if (params == i) {
                return $scope.customerStateList[i];
            }
        }
    };

    $scope.detaillist = function () {
        if($scope.chooseOrgData.orgId){
            localStorageService.update('memberEditOrgId', $scope.chooseOrgData.orgId);
            $state.go('tabs.memberManagedetails');
        }else{
            $rootScope.tipService.setMessage('请先选择机构!', 'warning');
        }

    };

    //权限审核
    $scope.RoleauditdictionShow = false;
    $scope.RoleJurisdiction = function () {
        if (!$scope.chooseOrgData.orgId) {
            $rootScope.tipService.setMessage('请先选择用户', 'warning');
        } else {
            $scope.RoleauditdictionShow = true;
            $scope.RoleCanJurisdiction($scope.chooseOrgData.authApplyId);
            //.RolegetJurisdiction($scope.chooseUserData.authApplyId);
        }
    };
    //读取可审核列表
    $scope.RoleCanJurisdiction = function (authApplyId) {
        //$scope.RolegetJurisdiction();
        userJurisdictionCtrlSer.RoleJurisdiction(authApplyId)
            .then(function (res) {
                console.log(res)
                if (res.data.code == '000000') {
                    $scope.RoleJurisdictionData = [];
                    $scope.originalsData = [];
                    $scope.Rdata = JSON.parse(res.data.content);
                    var data = $scope.Rdata;
                    console.log(data);  //可授权数据
                    for (var i = 0, r = data.changes.length; i < r; i++) {
                        $scope.RoleJurisdictionData.push(data.changes[i]);
                        //console.log($scope.RoleJurisdictionData);
                    }

                    var data2 = JSON.parse(res.data.content);
                    //console.log(data2);  //可授权数据
                    for (var i = 0, r = data2.originals.length; i < r; i++) {
                        $scope.originalsData.push(data2.originals[i]);
                        //console.log($scope.originalsData)
                    }

                } else {
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                }
            });
    };
    $scope.RoletrueData = function (tmpOpt) {
        var json = {
            applyId: $scope.Rdata.applyId,
            auditRs: tmpOpt
        };
        userJurisdictionCtrlSer.Roletruetion(json)
            .then(function (res) {
                if (res.data.code === '000000') {
                    $scope.RoleauditdictionShow = false;
                    localStorageService.clear('userIdChecked');
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                    $scope.searchAjax();
                } else {
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                }
            },function(error) {
                $rootScope.tipService.setMessage(error.data.message, 'warning');
            })
    }
    $scope.RolefalseData = function (tmpOpt) {
        var json = {
            applyId: $scope.Rdata.applyId,
            auditRs: tmpOpt
        };
        userJurisdictionCtrlSer.Roletruetion(json)
            .then(function (res) {
                if (res.data.code === '000000') {
                    $scope.RoleauditdictionShow = false;
                    localStorageService.clear('userIdChecked');
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                    $scope.searchAjax();
                } else {
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                }
            },function(error) {
                $rootScope.tipService.setMessage(error.data.message, 'warning');
            })
    }
}]);
