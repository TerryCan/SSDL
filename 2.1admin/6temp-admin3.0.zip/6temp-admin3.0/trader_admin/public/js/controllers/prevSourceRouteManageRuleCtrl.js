app.controller("prevSourceRouteManageRuleCtrl", ['$rootScope', '$timeout', '$q', '$http', 'myHttp', '$scope', 'getprevSourceRouteManageRuleData', 'dataSer', 'productClassificationCtrlSer', 'routeManagementSer', 'confirmService', 'timestamp', 'tipService', 'getPageNum','CommissionallocationAddCtrlSer', function ($rootScope, $timeout, $q, $http, myHttp, $scope, getprevSourceRouteManageRuleData, dataSer, productClassificationCtrlSer, routeManagementSer, confirmService, timestamp, tipService, getPageNum,CommissionallocationAddCtrlSer) {
    // 分页
    var pageJump = function (tmpArrList) {
        $timeout(function () {
            if (tmpArrList != undefined) {
                //console.log(tmpArrList);
                $scope.currentPage = 1; //当前页数
                $scope.dataNum = tmpArrList.length;
                $scope.showDataChoose = getPageNum.pageNum(); //获取分页
                $scope.showNum = $scope.showDataChoose[0]; //初始显示刷具条数
                $scope.showPage = false;
                $timeout(function () {
                    $scope.showPage = true;
                    $scope.copyDataArray = tmpArrList.slice(0, 14); //初始15条数据
                }, 10)
                $scope.dataPage = Math.ceil($scope.dataNum / $scope.showNum.showNum);

                //上下页
                $scope.pageSlect = function (type) {
                    if (type == 'prev') {
                        if ($scope.currentPage != 1) {
                            $scope.currentPage--;
                            $scope.turnPage();
                        } else {
                            $scope.copyDataArray = tmpArrList.slice(0, 14); //初始15条数据
                        }
                    } else {
                        if ($scope.currentPage < $scope.dataPage) {
                            $scope.currentPage++;
                            $scope.turnPage();
                        }
                    }
                }
                //每页数据量
                $scope.baseDataArray = [];
                $scope.copyDataArray = [];
                $scope.pageSelect = function (params) {
                    $scope.showNum.showNum = params.showNum;
                    $scope.copyDataArray = tmpArrList.slice(0, (params.showNum - 1));
                    $scope.dataPage = Math.ceil($scope.dataNum / $scope.showNum.showNum);
                    $scope.currentPage = 1;
                }
                $scope.turnPage = function () {
                    $scope.copyDataArray = tmpArrList.slice((($scope.currentPage - 1) * 15), (($scope.currentPage + 1) * 15 - 1));
                }
                //固定页面跳转
                $scope.jumpPage = function (num) {
                    num = parseInt(num);
                    if (parseInt(num, 10) === num && num <= ($scope.dataPage + 1) && num > 0) {
                        $scope.currentPage = num;
                        $scope.jumpPageNum = '';
                        $scope.turnPage();
                    } else {
                        $scope.copyDataArray = tmpArrList.slice(0, 14); //初始15条数据
                    }
                }
            } else {
                pageJump(tmpArrList);
            }
        }, 200);
    };
    dataSer.organizeQuerySer()
        .then(function (res) {
            $scope.orgList = res;
            //console.log($scope.orgList)
        });

    $scope.addOrgValFTC = function (data) {
        //console.log(data);
        $scope.superOrgId = data.orgId;
        $scope.superorgCode = data.orgCode;
        $scope.addOrgVal = data.text;
        //产品ID
        CommissionallocationAddCtrlSer.productListdata($scope.superOrgId)
            .then(function(res) {
                console.log(res)
                if(res.code=="000000"){
                    var prolistdt = JSON.parse(res.content);
                    $scope.productList = [];
                    for (var i = 0, r = prolistdt.length; i < r; i++) {
                        $scope.productList.push(prolistdt[i]);
                    }
                }else{
                    $rootScope.tipService.setMessage(res.message, 'warning')
                }
            }),function(error){
            $rootScope.tipService.setMessage(error.message, 'warning')
        }
    }
    $scope.addOrgVal1= function() {
        $scope.prolist ="";
        $scope.addOrgVal ="";
        $scope.orgCode ="";
        $scope.newcreateOrderShow=false;
    }

    /*productClassificationCtrlSer.search(99999, 1, '', '', '', '', '')
        .then(function (res) {
            var prolistdt = JSON.parse(res.content).content;
            $scope.productList = [];
            for (var i = 0, r = prolistdt.length; i < r; i++) {
                if (prolistdt[i].state == 1 || prolistdt[i].state == 8000) {
                    $scope.productList.push(prolistdt[i]);
                }
            }
            console.log($scope.productList)
        })*/

    routeManagementSer.routeSearch()
        .then(function (res) {
            $scope.list = res.list;
            //console.log($scope.list)
        })
    //查询所有指定
    $scope.search = function () {
        getprevSourceRouteManageRuleData.search()
            .then(function (res) {
                console.log(res)
                if (res.retMsg.code == "000000") {
                    $scope.searchResult = res.assignList;
                    pageJump($scope.searchResult);
                } else {
                    $rootScope.tipService.setMessage(res.retMsg.message, 'warning');
                }
            }, function (error) {
                $rootScope.tipService.setMessage(error.retMsg.message, 'warning');
            });
    },
        //$scope.search();

        $scope.rptext=function(product){
        if($scope.searchResult){
            console.log(product)
           if (product ==='*') {
                for (var i = 0, r = $scope.searchResult.length; i < r; i++) {
                    if (product == $scope.searchResult[i].product) {
                        return $scope.searchResult[i].name;
                        console.log($scope.searchResult[i].name)
                    }
                }
            } else {
               if($scope.productList){
                for (var i = 0, r = $scope.productList.length; i < r; i++) {
                    if (product == $scope.productList[i].productId) {
                        return $scope.productList[i].productName;
                        }
                    }
                    }
                }
            }
        }
    $scope.formatTime = function (parameter) {
        var h = Math.floor(parameter / 3600);
        var minute = Math.floor((parameter - h * 3600) / 60);
        var second = parameter - h * 3600 - minute * 60;
        return h + ':' + minute + ':' + second;
    }
    $scope.key = "";
    $scope.superorgCode = "";
    $scope.product = "";
    $scope.routeKey = "";
    $scope.startTimeNum = "";
    $scope.endTimeNum = "";

    //新增
    $scope.chooseItemTab1 = null;
    $scope.newcreateOrderShow = false;
    addEditText = "";
    $scope.addNewData = function () {
        $scope.newcreateOrderShow = true;
        $scope.key = '0'; //编号(主键，自动生成)
        $scope.addEditText = '新增';
    }
    //单选
    $scope.checkedTab1 = function (index, key) {
        $scope.chooseItemTab1 = key;
        $scope.key = $scope.searchResult[index].key;
        $scope.user = $scope.searchResult[index].user;
        $scope.name = $scope.searchResult[index].name;
        $scope.product = $scope.searchResult[index].productName;
        $scope.startTime = $scope.searchResult[index].startTime;
        $scope.endTime = $scope.searchResult[index].endTime;
        $scope.routeKey = $scope.searchResult[index].routeKey;
        $('#dataReportTab1 input[type=checkbox]').not('.start_using').prop('checked', false);
        $('#dataReportTab1 input[type=checkbox]').not('.start_using').eq(index).prop('checked', true);
        //console.log($scope.key);
    }

    //修改
    $scope.editNewData = function () {
        if (!$scope.chooseItemTab1) {
            $rootScope.tipService.setMessage('请先选择编号', 'warning');
        } else {
            $scope.addEditText = '修改';
            $scope.newcreateOrderShow = true;
            $scope.key = $scope.chooseItemTab1;
        }
    }

    $scope.createTimeStart = "";
    $scope.createTimeEnd = "";
    $scope.addSubmit = function () {
        if ($scope.addEditText == '新增') {
            if ($scope.addOrgVal == '') {
                $rootScope.tipService.setMessage('请先输入名称', 'warning');
            } else {
                $scope.dateTime = function (parameter) {
                    var str1 = parameter.split("");
                    console.log(str1)
                    var hours = str1.slice(0, 2);
                    var hour = hours.join("");
                    var h = parseInt(hour, 10) * 3600;

                    var minutes = str1.slice(3, 5);
                    var minute = minutes.join("");
                    var m = parseInt(minute, 10) * 60;

                    var seconds = str1.slice(6, 8);
                    var second = seconds.join("");
                    var s = parseInt(second, 10);
                    return h + m + s;
                }

                $scope.createTimeStartNum = $scope.dateTime($scope.createTimeStart);
                $scope.createTimeEndNum = $scope.dateTime($scope.createTimeEnd);
                //console.log($scope.createTimeStartNum)
                var routeAssign = {
                    key: $scope.key,
                    user: $scope.superorgCode,
                    name: $scope.name,
                    product: $scope.productName,
                    routeKey: $scope.routeKey,
                    startTime: $scope.createTimeStartNum,
                    endTime: $scope.createTimeEndNum,
                }
                json = {
                    routeAssign: routeAssign
                }
                if (toValidate('#RouteRule')) {
                    getprevSourceRouteManageRuleData.addNewinsert(json)
                        .then(function (res) {
                            console.log(res)
                        if(res.code=="000000"){
                            $scope.keyshow = false;
                            $scope.newcreateOrderShow = false;
                            $rootScope.tipService.setMessage(res.message, 'warning');
                            $scope.search();
                        }else {
                                $rootScope.tipService.setMessage(res.message, 'warning');
                            }
                        }, function (error) {
                            $rootScope.tipService.setMessage(error.message, 'warning');
                        })
                }
            }
        } else if ($scope.addEditText == '修改') {
            if ($scope.addOrgVal == '') {
                $rootScope.tipService.setMessage('请填写修改名称', 'warning');
            } else {
                $scope.dateTime = function (parameter) {
                    var str1 = parameter.split("");
                    var hours = str1.slice(11, 13);
                    var hour = hours.join("");
                    var h = parseInt(hour, 10) * 3600;

                    var minutes = str1.slice(14, 16);
                    var minute = minutes.join("");
                    var m = parseInt(minute, 10) * 60;

                    var seconds = str1.slice(17, 19);
                    var second = seconds.join("");
                    var s = parseInt(second, 10);
                    return h + m + s;
                }
                $scope.startTimeNum = $scope.dateTime($scope.createTimeStart);
                $scope.endTimeNum = $scope.dateTime($scope.createTimeEnd);
                //console.log($scope.startTimeNum)
                var routeAssign = {
                    key: $scope.key,
                    user: $scope.addOrgVal,
                    name: $scope.name,
                    product: $scope.product,
                    routeKey: $scope.routeKey,
                    startTime: $scope.startTimeNum,
                    endTime: $scope.endTimeNum,
                }
                var json = {
                    routeAssign: routeAssign
                }
                if (toValidate('#RouteRule')) {
                    getprevSourceRouteManageRuleData.EditNewinsert(json)
                        .then(function (res) {
                            if(res.code=="000000"){
                            $scope.keyshow = false;
                            $scope.newAgreementShow = false;
                            $rootScope.tipService.setMessage(res.message, 'warning');
                            $scope.search();
                             }else {
                                $rootScope.tipService.setMessage(res.message, 'warning');
                            }
                        }, function (error) {
                            $$rootScope.tipService.setMessage(error.message, 'warning');
                        })
                }
            }
        }
    }

    //注销
    $scope.cancel = function () {
        if (!$scope.chooseItemTab1) {
            $rootScope.tipService.setMessage('请先选择账户', 'warning');
        } else {

            confirmService.set('确认提示', '确定要删除用户?', function () {
                getprevSourceRouteManageRuleData.close($scope.chooseItemTab1)
                    .then(function (res) {
                        console.log(res)
                        if(res.retMsg.code=="000000"){
                        $rootScope.tipService.setMessage(res.retMsg.message, 'warning');
                        $scope.search();
                         }else {
                        $rootScope.tipService.setMessage(res.retMsg.message, 'warning');
                    }
                    }, function (error) {
                        $rootScope.tipService.setMessage(error.retMsg.message, 'warning');
                    });
                confirmService.clear();
            })
        }
    }


}])
    .factory('getprevSourceRouteManageRuleData', ['$rootScope', '$http', '$q', function ($rootScope, $http, $q) {
        return {
            //查询
            search: function () {
                var deferred = $q.defer();
                $http({
                    method: "POST",
                    url: $rootScope.baseUrl + "c/up/route/assign/query/all"
                }).success(function (res) {
                    deferred.resolve(res);
                }).error(function (res) {
                    deferred.reject(res);
                });
                return deferred.promise;
            },
            //添加
            addNewinsert: function (json) {
                var deferred = $q.defer();
                $http({
                    method: "POST",
                    url: $rootScope.baseUrl + "c/up/route/assign/insert",
                    data: json,

                }).success(function (res) {
                    deferred.resolve(res);
                }).error(function (res) {
                    deferred.reject(res);
                });
                return deferred.promise;
            },
            //修改
            EditNewinsert: function (json) {
                var deferred = $q.defer();
                $http({
                    method: "POST",
                    url: $rootScope.baseUrl + "c/up/route/assign/modify",
                    data: json,

                }).success(function (res) {
                    deferred.resolve(res);
                }).error(function (res) {
                    deferred.reject(res);
                });
                return deferred.promise;
            },

            // 注销
            close: function (key) {
                var json = {
                    key: key
                }
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'c/up/route/assign/delete',
                    data: json
                }).then(function successCallback(response) {
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;


            }
        }
    }])