app.controller("navCtrl",function($scope,$http,$location,$state,localStorageService,tipService,confirmService,$rootScope,$timeout){
	$scope.nav = [
		{"name":"首页","url":"tabs.home","class":"fa fa-home fa-lg","visit":false},
		{"name":"交易管理","child":[
			{"name":"客户管理","grandChild":[
				{"name":"委托明细","url":"tabs.CustomerEntrust","visit":false},
				{"name":"成交明细","url":"tabs.CustomerDeal","visit":false},
				{"name":"持仓合计","url":"tabs.CustomerPosition","visit":false},
				{"name":"持仓明细","url":"tabs.CustomerPositionDetail","visit":false},
				{"name":"补录单明细","url":"tabs.Singlemakeup","visit":false},
				{"name":"委托统计","url":"tabs.Entrustedstatistics","visit":false},
				{"name":"成交统计","url":"tabs.Transactionstatistics","visit":false},
				{"name":"持仓统计","url":"tabs.Dealstatistics","visit":false}
			],"visit":false},
			{"name":"上手管理","grandChild":[
				{"name":"委托明细","url":"tabs.PreviousEntrust","visit":false},
				{"name":"成交明细","url":"tabs.PreviousDeal","visit":false},
				{"name":"持仓明细","url":"tabs.PreviousPosition","visit":false}
			],"visit":false},
			{"name":"机构户","grandChild":[
				{"name":"成交明细","url":"tabs.OrganizeDeal","visit":false},
				{"name":"持仓明细","url":"tabs.OrganizeHold","visit":false},
				{"name":"持仓统计","url":"tabs.OrganizePositionstatistics","visit":false},
				{"name":"成交统计","url":"tabs.OrganizeDealstatistics","visit":false}
			],"visit":false}
		],"class":"fa fa-exchange fa-lg","visit":false},
		{"name":"风控管理","child":[
			{"name":"风控规则","url":"tabs.riskRegulation","visit":false},
			{"name":"风控规则指派","url":"tabs.riskRegulationAppoint","visit":false},
			{"name":"风控强平","url":"tabs.riskKyohei","visit":false},
			{"name":"交易规则","url":"tabs.tradeRegulation","visit":false},
			{"name":"交易规则指派","url":"tabs.tradeRegulationAppoint","visit":false},
		],"class":"fa fa-sort-amount-asc fa-lg","visit":false},
		{"name":"资金管理","child":[
                {"name":"交易账户","grandChild":[
                        {"name":"出入金","url":"tabs.exchangeMoney","visit":false},
                        {"name":"银行调账","url":"tabs.bankAdjust","visit":false},
                        {"name":"实时资金","url":"tabs.currentCapital","visit":false},
                        {"name":"交易流程","url":"tabs.tradeProcess","visit":false},
                        {"name":"流水查询","url":"tabs.runSearch","visit":false},
                        {"name":"异常处理","url":"tabs.accountUnusualManage","visit":false},
                        {"name":"统计查询","url":"tabs.statisticSearch","visit":false}
                    ],"class":"fa fa-angle-double-right fa-lg","visit":false},
                {"name":"附属账户","grandChild":[
                        {"name":"账户管理","url":"tabs.accountManage","visit":false},
                        {"name":"实时资金","url":"tabs.accountCurrentCapital","visit":false},
                        {"name":"流水查询","url":"tabs.accountRunSearch","visit":false},
                        {"name":"统计查询","url":"tabs.accountStatisticSearch","visit":false}
                    ],"class":"fa fa-angle-double-right fa-lg","visit":false},
                {"name":"支付通道","grandChild":[
                        {"name":"通道管理","url":"tabs.accessManage","visit":false},
                        {"name":"商户管理","url":"tabs.merchantManage","visit":false},
                        {"name":"流水查询","url":"tabs.payRunSearch","visit":false},
                        {"name":"异常处理","url":"tabs.payUnusualManage","visit":false}
                    ],"class":"fa fa-angle-double-right fa-lg","visit":false},
            ],"class":"fa fa-money fa-lg","visit":false},
		{"name":"上手管理","child":[
			{"name":"账号管理","grandChild":[
				{"name":"协议管理","url":"tabs.prevSourceAgreementManage","visit":false},
				{"name":"账号管理","url":"tabs.prevSourceAccountManage","visit":false},
				{"name":" 可选对手机构","url":"tabs.prevSourceOptionalopponentmechanism","visit":false},
			],"class":"fa fa-angle-double-right fa-lg","visit":false},
			{"name":"商品管理","grandChild":[
				{"name":"商品管理","url":"tabs.prevSourceProductManage","visit":false},
				{"name":"可交易商品","url":"tabs.prevSourceTradeProduct","visit":false},
				{"name":"行情源交易商品映射","url":"tabs.Marketsourcecommodity","visit":false},
				{"name":"保证金参数","url":"tabs.prevSourceDeposit","visit":false},
				{"name":"手续费参数","url":"tabs.prevSourceFee","visit":false},
			],"class":"fa fa-angle-double-right fa-lg","visit":false},
			{"name":"资金管理","grandChild":[
				{"name":"资金调整","url":"tabs.prevSourceCapitalManage","visit":false},
				{"name":"资金审批","url":"tabs.prevSourceFundingapproval","visit":false},
				{"name":"实时资金","url":"tabs.prevSourceRealtimefunds","visit":false},
				{"name":"流水查询","url":"tabs.prevSourcePipelinequery","visit":false},
				{"name":"统计查询","url":"tabs.prevSourceStatisticalquery","visit":false}
			],"class":"fa fa-angle-double-right fa-lg","visit":false},
			{"name":"持仓管理","url":"tabs.prevSourcePositionsManage","visit":false},
			{"name":"路由管理","grandChild":[
				{"name":"路由管理","url":"tabs.prevSourceRouteManage","visit":false},
				{"name":"路由规则指定","url":"tabs.prevSourceRouteManageRule","visit":false},
			],"class":"fa fa-angle-double-right fa-lg","visit":false},
		],"class":"fa fa-hand-pointer-o fa-lg","visit":false},
		{"name":"参数配置","child":[
                /*{"name":"分配规则","url":"tabs.commissionSplit","visit":false},*/
			{"name":"分配规则","url":"tabs.Distributionrules","visit":false},
			{"name":"机构配置","url":"tabs.orginConfig","visit":false},
            {"name":"开闭市时间","url":"tabs.OpenCloseTime","visit":false},
			{"name":"币种汇率","grandChild":[
					{"name":"币种组","url":"tabs.Currencygroup","visit":false},
					{"name":"币种管理","url":"tabs.currencyManagement","visit":false},
				],"class":"fa fa-angle-double-right fa-lg","visit":false},
			{"name":"市场管理","grandChild":[
				{"name":"市场管理","url":"tabs.MarketManagement","visit":false},
				{"name":"品种分类","url":"tabs.VarietyClassification","visit":false},
				{"name":"品种管理","url":"tabs.Varieties","visit":false},
				{"name":"品种映射","url":"tabs.VarietInmapping","visit":false},
				{"name":"合约管理","url":"tabs.contract","visit":false},
			],"class":"fa fa-angle-double-right fa-lg","visit":false},
                {"name":"个性化组","url":"tabs.Personalizationgroup","visit":false},
                {"name":"黑名单","url":"tabs.Blacklist","visit":false},
			{"name":"上手帐号映射","url":"tabs.upaccountmap","visit":false}
		],"class":"fa fa-life-ring fa-lg","visit":false},
		{"name":"用户管理","child":[
			{"name":"客户管理","url":"tabs.customerManage","visit":false},
			{"name":"机构管理","url":"tabs.memberManage","visit":false},
		],"class":"fa fa-users fa-lg","visit":false},
		{"name":"产品管理","child":[
			{"name":"行情源管理","grandChild":[
				{"name":"历史行情源补录","url":"tabs.marketMakeup","visit":false},
				{"name":"行情源协议管理","url":"tabs.marketAgreementManage","visit":false},
				{"name":"行情源账号管理","url":"tabs.marketSourceManage","visit":false},
				{"name":"行情源商品管理","url":"tabs.marketSourceProductManage","visit":false},
				{"name":"行情源账号可采用商品","url":"tabs.marketAccountgood","visit":false}
			],"visit":false},
			{"name":"产品管理","url":"tabs.productClassification","visit":false},
			{"name":"个性化配置","url":"tabs.productConfiguration","visit":false},
			{"name":"行情映射","url":"tabs.marketMapping","visit":false},
			{"name":"交易映射","url":"tabs.transactionMapping","visit":false}
		],"class":"fa fa-cubes fa-lg","visit":false},
		{"name":"系统管理","child":[
			{"name":"管理员管理","url":"tabs.adminManage","visit":false},
			{"name":"角色管理","url":"tabs.userManage","visit":false},
			{"name":"角色批量管理","url":"tabs.userManageAll","visit":false},
			{"name":"公告管理","url":"tabs.Noticequery","visit":false},
			{"name":"自定义设置","url":"tabs.PersonalizedOrganization","visit":false},
			{"name":"二维码设置","url":"tabs.Twodimensionalcodequery","visit":false},
			{"name":"邮件管理","grandChild":[
				{"name":"邮件设置","url":"tabs.MailSettings","visit":false},
				{"name":"邮件模板设置","url":"tabs.Mailtemplatesettings","visit":false},
			],"class":"fa fa-angle-double-right fa-lg","visit":false},
			{"name":"操作日志","url":"tabs.Operationlog","visit":false},
		],"class":"fa fa-cogs fa-lg","visit":false},
        {"name":"结算管理","child":[
                {"name":"结算价管理","url":"tabs.Settlepricemanagement","visit":false},
                {"name":"结算历史信息","grandChild":[
                {"name":"历史结算账户","url":"tabs.Histaccounts","visit":false},
                {"name":"历史持仓","url":"tabs.Histhold","visit":false},
                {"name":"历史成交","url":"tabs.Histtransaction","visit":false},
                {"name":"历史分配规则","url":"tabs.HistRules","visit":false},
                {"name":"交易合约","url":"tabs.HistTransactioncontract","visit":false},
                {"name":"审核流水","url":"tabs.Histrunwater","visit":false},
			],"class":"fa fa-angle-double-right fa-lg","visit":false},
                {"name":"结算&报表导出","url":"tabs.HistReportexport","visit":false},
		],"class":"fa fa-money fa-lg","visit":false}
	];
	$scope.navHasLoad = false;

	var navAuthorFun = function(navAuthorised){
		//首页
		$scope.nav[0].visit = true;
		//交易
		//客户
		//委托查询
		if($.inArray('TRADE_ADMIN_ORDER_QUERY',navAuthorised) >= 0){
			$scope.nav[1].child[0].grandChild[0].visit = true;
		}
		//成交查询
		if($.inArray('TRADE_ADMIN_MATCH_QUERY',navAuthorised) >= 0){
			$scope.nav[1].child[0].grandChild[1].visit = true;
		}
		//查询持仓合计/明细
		if($.inArray('TRADE_ADMIN_POSITION_QUERY',navAuthorised) >= 0){
			$scope.nav[1].child[0].grandChild[2].visit = true;
			$scope.nav[1].child[0].grandChild[3].visit = true;
		}

		//补录单查询
		if($.inArray('TRADE_RECOVER_QUERY',navAuthorised) >= 0){
			$scope.nav[1].child[0].grandChild[4].visit = true;
		}
		//交易_客户_委托统计_查询
		if($.inArray('TRADE_ORDER_COUNT_QUERY',navAuthorised) >= 0){
			$scope.nav[1].child[0].grandChild[5].visit = true;
		}

		//交易_客户_成交统计_查询
		if($.inArray('TRADE_MATCH_COUNT_QUERY',navAuthorised) >= 0){
			$scope.nav[1].child[0].grandChild[6].visit = true;
		}

		//交易_客户_持仓统计_查询
		if($.inArray('TRADE_POSITION_COUNT_QUERY',navAuthorised) >= 0){
			$scope.nav[1].child[0].grandChild[7].visit = true;
		}

		if($scope.nav[1].child[0].grandChild[0].visit || $scope.nav[1].child[0].grandChild[1].visit || $scope.nav[1].child[0].grandChild[2].visit || $scope.nav[1].child[0].grandChild[3].visit || $scope.nav[1].child[0].grandChild[4].visit || $scope.nav[1].child[0].grandChild[5].visit || $scope.nav[1].child[0].grandChild[6].visit || $scope.nav[1].child[0].grandChild[7].visit){
			$scope.nav[1].child[0].visit = true;
		}
		//上手管理
		//查询委托
		if($.inArray('UPMGR_ORDER_QUERY',navAuthorised) >= 0){
			$scope.nav[1].child[1].grandChild[0].visit = true;
		}
		//查询成交
		if($.inArray('UPMGR_MATCH_QUERY',navAuthorised) >= 0){
			$scope.nav[1].child[1].grandChild[1].visit = true;
		}
		//查询持仓
		if($.inArray('UPMGR_POSITION_QUERY',navAuthorised) >= 0){
			$scope.nav[1].child[1].grandChild[2].visit = true;
		}
		if($scope.nav[1].child[1].grandChild[0].visit || $scope.nav[1].child[1].grandChild[1].visit || $scope.nav[1].child[1].grandChild[2].visit){
			$scope.nav[1].child[1].visit = true;
		}

		//机构户成交查询
		if($.inArray('TRADE_ORG_MATCH_QUERY',navAuthorised) >= 0){
			$scope.nav[1].child[2].grandChild[0].visit = true;
		}
		//机构户持仓查询
		if($.inArray('TRADE_ORG_POSITION_QUERY',navAuthorised) >= 0){
			$scope.nav[1].child[2].grandChild[1].visit = true;
		}

		//机构户持仓统计查询
		if($.inArray('TRADE_ORG_POSITION_COUNT_QUERY',navAuthorised) >= 0){
			$scope.nav[1].child[2].grandChild[2].visit = true;
		}

		//机构户成交统计查询
		if($.inArray('TRADE_ORG_MATCH_COUNT_QUERY',navAuthorised) >= 0){
			$scope.nav[1].child[2].grandChild[3].visit = true;
		}

		if($scope.nav[1].child[2].grandChild[0].visit || $scope.nav[1].child[2].grandChild[1].visit || $scope.nav[1].child[2].grandChild[2].visit || $scope.nav[1].child[2].grandChild[3].visit){
			$scope.nav[1].child[2].visit = true;
		}
		if($scope.nav[1].child[0].visit || $scope.nav[1].child[1].visit || $scope.nav[1].child[2].visit || $scope.nav[1].child[3].visit){
			$scope.nav[1].visit = true;
		}
		//风控
		//风控规则
		if($.inArray('RISKMGR_RISKRULE_QUERY',navAuthorised) >= 0){
			$scope.nav[2].child[0].visit = true;
		}
		//风控规则指派
		if($.inArray('RISKMGR_RISKRULE_ASSIGN_QUERY',navAuthorised) >= 0){
			$scope.nav[2].child[1].visit = true;
		}
		//风控强平
		if($.inArray('RISKMGR_TRADERULE_TIME_QUERY',navAuthorised) >= 0){
			$scope.nav[2].child[2].visit = true;
		}
		//交易规则
		if($.inArray('RISKMGR_TRADERULE_QUERY',navAuthorised) >= 0){
			$scope.nav[2].child[3].visit = true;
		}
		//交易规则指派
		if($.inArray('RISKMGR_TRADERULE_ASSIGN_QUERY',navAuthorised) >= 0){
			$scope.nav[2].child[4].visit = true;
		}
		if($scope.nav[2].child[0].visit || $scope.nav[2].child[1].visit || $scope.nav[2].child[2].visit || $scope.nav[2].child[3].visit || $scope.nav[2].child[4].visit){
			$scope.nav[2].visit = true;
		}
		//资金管理
		//交易账户
		//出入金
		if($.inArray('CAM_ACCOUNT_IO_INOUT_QUERY',navAuthorised) >= 0){
			$scope.nav[3].child[0].grandChild[0].visit = true;
		}
		//银行调账
		if($.inArray('CAM_ACCOUNT_ADJUST_QUERY',navAuthorised) >= 0){
			$scope.nav[3].child[0].grandChild[1].visit = true;
		}
		//实时资金
		if($.inArray('CAM_ACCOUNT_CURRENT_QUERY',navAuthorised) >= 0){
			$scope.nav[3].child[0].grandChild[2].visit = true;
		}
        //交易流程
        if($.inArray('CAM_ACCOUNT_PROCESS_QUERY',navAuthorised) >= 0){
            $scope.nav[3].child[0].grandChild[3].visit = true;
        }
		//流水查询
		if($.inArray('CAM_ACCOUNT_IO_DETAIL_QUERY',navAuthorised) >= 0){
			$scope.nav[3].child[0].grandChild[4].visit = true;
		}
		//异常处理
		if($.inArray('CAM_ACCOUNT_IO_REPAIRE',navAuthorised) >= 0){
			$scope.nav[3].child[0].grandChild[5].visit = true;
		}
		//统计查询
		if($.inArray('CAM_ACCOUNT_IO_QUERYSUM',navAuthorised) >= 0){
			$scope.nav[3].child[0].grandChild[6].visit = true;
		}
		if($scope.nav[3].child[0].grandChild[0].visit || $scope.nav[3].child[0].grandChild[1].visit || $scope.nav[3].child[0].grandChild[2].visit || $scope.nav[3].child[0].grandChild[3].visit || $scope.nav[3].child[0].grandChild[4].visit || $scope.nav[3].child[0].grandChild[5].visit || $scope.nav[3].child[0].grandChild[6].visit){
			$scope.nav[3].child[0].visit = true;
		}
		//附属账户
		//账户管理
		if($.inArray('CAM_ACCOUNT_SIGNUP_QUERY',navAuthorised) >= 0){
			$scope.nav[3].child[1].grandChild[0].visit = true;
		}
		//实时资金
		if($.inArray('CAM_EX_BANK_SIGNUP_QUERY',navAuthorised) >= 0){
			$scope.nav[3].child[1].grandChild[1].visit = true;
		}
		//流水查询
		if($.inArray('CAM_EX_BANK_IO_QUERY',navAuthorised) >= 0){
			$scope.nav[3].child[1].grandChild[2].visit = true;
		}
		//统计查询
		if($.inArray('CAM_EX_BANK_IO_QUERYSUM',navAuthorised) >= 0){
			$scope.nav[3].child[1].grandChild[3].visit = true;
		}
		if($scope.nav[3].child[1].grandChild[0].visit || $scope.nav[3].child[1].grandChild[1].visit || $scope.nav[3].child[1].grandChild[2].visit ||　$scope.nav[3].child[1].grandChild[3].visit){
			$scope.nav[3].child[1].visit = true;
		}
		//支付通道
		//通道管理
		if($.inArray('CAM_EX_BANK_CHANNEL_QUERY',navAuthorised) >= 0){
			$scope.nav[3].child[2].grandChild[0].visit = true;
		}
		//商户管理
		if($.inArray('CAM_EX_BANK_MERCHANT_QUERY',navAuthorised) >= 0){
			$scope.nav[3].child[2].grandChild[1].visit = true;
		}
		//流水查询
		if($.inArray('CAM_EX_BANK_TRANSRECORD_QUERY',navAuthorised) >= 0){
			$scope.nav[3].child[2].grandChild[2].visit = true;
		}
		//异常处理
		if($.inArray('CAM_EX_BANK_IO_REPAIRE',navAuthorised) >= 0){
			$scope.nav[3].child[2].grandChild[3].visit = true;
		}
		if($scope.nav[3].child[2].grandChild[0].visit || $scope.nav[3].child[2].grandChild[1].visit || $scope.nav[3].child[2].grandChild[2].visit || $scope.nav[3].child[2].grandChild[3].visit){
			$scope.nav[3].child[2].visit = true;
		}
		if($scope.nav[3].child[0].visit ||　$scope.nav[3].child[1].visit || $scope.nav[3].child[2].visit){
			$scope.nav[3].visit = true;
		}
		//上手管理
		//上手账号管理
		//上手协议管理
		if($.inArray('UPMGR_PROTOCOL_QUERY',navAuthorised) >= 0){
			$scope.nav[4].child[0].grandChild[0].visit = true;
		}
		//上手账号管理
		if($.inArray('UPMGR_ACCOUNT_QUERY',navAuthorised) >= 0){
			$scope.nav[4].child[0].grandChild[1].visit = true;
		}
		//上手可选对手机构
		if($.inArray('UPMGR_ACCOUNT_ORGANIZE_QUERY',navAuthorised) >= 0){
			$scope.nav[4].child[0].grandChild[2].visit = true;
		}
		if($scope.nav[4].child[0].grandChild[0].visit || $scope.nav[4].child[0].grandChild[1].visit || $scope.nav[4].child[0].grandChild[2].visit){
			$scope.nav[4].child[0].visit = true;
		}
		//上手商品管理
		//上手商品管理
		if($.inArray('UPMGR_SYMBOL_QUERY',navAuthorised) >= 0){
			$scope.nav[4].child[1].grandChild[0].visit = true;
		}
		//上手可交易商品
		if($.inArray('UPMGR_ACCOUNT_SYMBOL_QUERY',navAuthorised) >= 0){
			$scope.nav[4].child[1].grandChild[1].visit = true;
		}
		//行情源与交易商品映射
		if($.inArray('UPMGR_QUOTE_QUERY',navAuthorised) >= 0){
			$scope.nav[4].child[1].grandChild[2].visit = true;
		}
		//上手保证金参数
		if($.inArray('UPMGR_MARGIN_QUERY',navAuthorised) >= 0){
			$scope.nav[4].child[1].grandChild[3].visit = true;
		}
		//上手手续费参数
		if($.inArray('UPMGR_COMMISSION_QUERY',navAuthorised) >= 0){
			$scope.nav[4].child[1].grandChild[4].visit = true;
		}
		if($scope.nav[4].child[1].grandChild[0].visit || $scope.nav[4].child[1].grandChild[1].visit || $scope.nav[4].child[1].grandChild[2].visit || $scope.nav[4].child[1].grandChild[3].visit || $scope.nav[4].child[1].grandChild[4].visit){
			$scope.nav[4].child[1].visit = true;
		}
		//上手资金管理
		//资金调整
		if($.inArray('UPMGR_CAPITAL_ADJUST_QUERY',navAuthorised) >= 0){
			$scope.nav[4].child[2].grandChild[0].visit = true;
		}
		//资金审批
		if($.inArray('UPMGR_CAPITAL_ADJUST_REVIEW',navAuthorised) >= 0){
			$scope.nav[4].child[2].grandChild[1].visit = true;
		}
		//实时资金
		if($.inArray('UPMGR_CAPITAL_QUERY',navAuthorised) >= 0){
			$scope.nav[4].child[2].grandChild[2].visit = true;
		}
		//流水查询
		if($.inArray('UPMGR_CAPITAL_HISTORY_QUERY',navAuthorised) >= 0){
			$scope.nav[4].child[2].grandChild[3].visit = true;
		}
		//统计查询
		if($.inArray('UPMGR_CAPITAL_STATISTICS_QUERY',navAuthorised) >= 0){
			$scope.nav[4].child[2].grandChild[4].visit = true;
		}
		if($scope.nav[4].child[2].grandChild[0].visit || $scope.nav[4].child[2].grandChild[1].visit || $scope.nav[4].child[2].grandChild[2].visit || $scope.nav[4].child[2].grandChild[3].visit || $scope.nav[4].child[2].grandChild[4].visit){
			$scope.nav[4].child[2].visit = true;
		}
		//上手持仓管理
		if($.inArray('UPMGR_POSITION_QUERY',navAuthorised) >= 0){
			$scope.nav[4].child[3].visit = true;
		}
		//上手路由管理
		//上手路由管理
		if($.inArray('UPMGR_ROUTE_QUERY',navAuthorised) >= 0){
			$scope.nav[4].child[4].grandChild[0].visit = true;
		}
		//上手路由规则指定
		if($.inArray('UPMGR_ROUTE_ASSIGN_QUERY',navAuthorised) >= 0){
			$scope.nav[4].child[4].grandChild[1].visit = true;
		}
		if($scope.nav[4].child[4].grandChild[0].visit || $scope.nav[4].child[4].grandChild[1].visit){
			$scope.nav[4].child[4].visit = true;
		}
		if($scope.nav[4].child[0].visit || $scope.nav[4].child[1].visit || $scope.nav[4].child[2].visit || $scope.nav[4].child[3].visit || $scope.nav[4].child[4].visit){
			$scope.nav[4].visit = true;
		}
		//额度
		//参数配置
		if($.inArray('CONFIG_COMMISSION_QUERY',navAuthorised) >= 0){
			$scope.nav[5].child[0].visit = true;
		}
		//机构配置
		if($.inArray('CONFIG_ORG_RESOURCE_QUERY',navAuthorised) >= 0){
			$scope.nav[5].child[1].visit = true;
		}
        //开闭市时间
        if($.inArray('CONFIG_OPEN_CLOSE_TIME_QUERY',navAuthorised) >= 0){
            $scope.nav[5].child[2].visit = true;
        }
        //币种组
       	if($.inArray('CONFIG_CURRENCY_GROUP_QUERY',navAuthorised) >= 0){
            $scope.nav[5].child[3].grandChild[0].visit = true;
        }
        //币种管理
        if($.inArray('CONFIG_CURRENCY_QUERY',navAuthorised) >= 0){
            $scope.nav[5].child[3].grandChild[1].visit = true;
        }
        if($scope.nav[5].child[3].grandChild[0].visit || $scope.nav[5].child[3].grandChild[1].visit){
            $scope.nav[5].child[3].visit = true;
        }

        //市场管理
        if($.inArray('CONFIG_PRODUCT_QUERY',navAuthorised) >= 0){
            $scope.nav[5].child[4].grandChild[0].visit = true;
        }
        //品种分类
        if($.inArray('CONFIG_PRODUCT_QUERY',navAuthorised) >= 0){
            $scope.nav[5].child[4].grandChild[1].visit = true;
        }
        //品种
        if($.inArray('CONFIG_PRODUCT_QUERY',navAuthorised) >= 0){
            $scope.nav[5].child[4].grandChild[2].visit = true;
        }
        //品种内映射
        if($.inArray('CONFIG_PRODUCT_QUERY',navAuthorised) >= 0){
            $scope.nav[5].child[4].grandChild[3].visit = true;
        }
        //合约
        if($.inArray('CONFIG_PRODUCT_QUERY',navAuthorised) >= 0){
            $scope.nav[5].child[4].grandChild[4].visit = true;
        }

        if($scope.nav[5].child[4].grandChild[0].visit || $scope.nav[5].child[4].grandChild[1].visit || $scope.nav[5].child[4].grandChild[2].visit || $scope.nav[5].child[4].grandChild[3].visit || $scope.nav[5].child[4].grandChild[4].visit){
            $scope.nav[5].child[4].visit = true;
		}
        //个性化组
        if($.inArray('CONFIG_PRODUCT_QUERY',navAuthorised) >= 0){
            $scope.nav[5].child[5].visit = true;
        }
        //黑名单
        if($.inArray('CONFIG_PRODUCT_QUERY',navAuthorised) >= 0){
            $scope.nav[5].child[6].visit = true;
        }
        //上手账号映射
        if($.inArray('CONFIG_ORG_PHCHANNEL_MAP_QUERY',navAuthorised) >= 0){
             $scope.nav[5].child[7].visit = true;
         }

		if($scope.nav[5].child[0].visit || $scope.nav[5].child[1].visit || $scope.nav[5].child[2].visit || $scope.nav[5].child[3].visit || $scope.nav[5].child[4].visit || $scope.nav[5].child[5].visit || $scope.nav[5].child[6].visit || $scope.nav[5].child[7].visit){
			$scope.nav[5].visit = true;
		}


		//用户管理
		//客户
		if($.inArray('ORGANIZE_CUSTOMER_QUERY',navAuthorised) >= 0){
			$scope.nav[6].child[0].visit = true;
		}
		//机构
		if($.inArray('ORGANIZE_ORGANIZE_QUERY',navAuthorised) >= 0){
			$scope.nav[6].child[1].visit = true;
		}
		if($scope.nav[6].child[0].visit || $scope.nav[6].child[1].visit){
			$scope.nav[6].visit = true;
		}
		//产品管理
		//行情源管理
		//行情源协议管理
		if($.inArray('QUOTEMGR_PROTOCOL_QUERY',navAuthorised) >= 0){
			$scope.nav[7].child[0].grandChild[0].visit = true;
		}
		//行情源账号管理
		if($.inArray('QUOTEMGR_ACCOUNT_QUERY',navAuthorised) >= 0){
			$scope.nav[7].child[0].grandChild[1].visit = true;
		}
		//行情源商品管理
		if($.inArray('QUOTEMGR_SYMBOL_QUERY',navAuthorised) >= 0){
			$scope.nav[7].child[0].grandChild[2].visit = true;
		}
		//行情源账号可采用商品
		if($.inArray('QUOTEMGR_ACCOUNT_SYMBOL_QUERY',navAuthorised) >= 0){
			$scope.nav[7].child[0].grandChild[3].visit = true;
		}
		//历史行情源补录
		if($.inArray('QUOTEMGR_ACCOUNT_HISTORYQUOTE_INSERT',navAuthorised) >= 0){
			$scope.nav[7].child[0].grandChild[4].visit = true;
		}
		if($scope.nav[7].child[0].grandChild[0].visit || $scope.nav[7].child[0].grandChild[1].visit || $scope.nav[7].child[0].grandChild[2].visit || $scope.nav[7].child[0].grandChild[3].visit||$scope.nav[7].child[0].grandChild[4].visit){
			$scope.nav[7].child[0].visit = true;
		}
		//产品管理
		if($.inArray('CONFIG_PRODUCT_QUERY',navAuthorised) >= 0){
			$scope.nav[7].child[1].visit = true;
		}
		//个性化配置
		if($.inArray('CONFIG_PRODUCT_CUSTOMIZED_QUERY',navAuthorised) >= 0){
			$scope.nav[7].child[2].visit = true;
		}
		//行情映射
		if($.inArray('CONFIG_PRODUCT_QUOTACONFIG_QUERY',navAuthorised) >= 0){
			$scope.nav[7].child[3].visit = true;
		}
		//交易映射
		if($.inArray('CONFIG_PRODUCT_CHANNELMAP_QUERY',navAuthorised) >= 0){
			$scope.nav[7].child[4].visit = true;
		}
		if($scope.nav[7].child[0].visit || $scope.nav[7].child[1].visit || $scope.nav[7].child[2].visit || $scope.nav[7].child[3].visit || $scope.nav[7].child[4].visit){
			$scope.nav[7].visit = true;
		}
		//系统管理
		//管理员
		if($.inArray('ORGANIZE_ADMIN_QUERY',navAuthorised) >= 0){
			$scope.nav[8].child[0].visit = true;
		}
		//角色
		if($.inArray('ORGANIZE_ROLE_QUERY',navAuthorised) >= 0){
			$scope.nav[8].child[1].visit = true;
		}
        //批量角色
        if($.inArray('ORGANIZE_ROLE_AUTHORISED_QUERY',navAuthorised) >= 0){
            $scope.nav[8].child[2].visit = true;
        }
		//公告
		if($.inArray('SUPPORT_NOTICE_USER_QUERY',navAuthorised) >= 0 || $.inArray('SUPPORT_NOTICE_ORG_QUERY',navAuthorised) >= 0 || $.inArray('SUPPORT_NOTICE_ORG_ALL_QUERY',navAuthorised) >= 0){
			$scope.nav[8].child[3].visit = true;
		}
		//机构个性化配置
		if($.inArray('SUPPORT_CUSTOMIZE_QUERY_ALL_ORG',navAuthorised) >= 0){
			$scope.nav[8].child[4].visit = true;
		}
		//二维码设置
		if($.inArray('SUPPORT_QRCODE_QUERY',navAuthorised) >= 0){
			$scope.nav[8].child[5].visit = true;
		}
		//邮箱管理
		//邮箱管理管理
		if($.inArray('SUPPORT_EMAIL_QUERY',navAuthorised) >= 0){
			$scope.nav[8].child[6].grandChild[0].visit = true;
		}
		//邮箱模块管理
		if($.inArray('SUPPORT_EMAIL_TEMPLATE_QUERY',navAuthorised) >= 0){
			$scope.nav[8].child[6].grandChild[1].visit = true;
		}
		//操作日志
		if($.inArray('SUPPORT_LOG_QUERY',navAuthorised) >= 0){
			$scope.nav[8].child[7].visit = true;
		}
		if($scope.nav[8].child[6].grandChild[0].visit || $scope.nav[8].child[6].grandChild[1].visit){
			$scope.nav[8].child[6].visit = true;
		}

		if($scope.nav[8].child[0].visit || $scope.nav[8].child[1].visit || $scope.nav[8].child[2].visit || $scope.nav[8].child[3].visit || $scope.nav[8].child[4].visit || $scope.nav[8].child[5].visit||$scope.nav[8].child[6].visit||$scope.nav[8].child[7].visit){
			$scope.nav[8].visit = true;
		}
        if($.inArray('SUPPORT_LOG_QUERY',navAuthorised) >= 0){
            $scope.nav[9].child[0].visit = true;
        }
        if($.inArray('SUPPORT_LOG_QUERY',navAuthorised) >= 0){
            $scope.nav[9].child[1].grandChild[0].visit = true;
        }
        if($.inArray('SUPPORT_LOG_QUERY',navAuthorised) >= 0){
            $scope.nav[9].child[1].grandChild[1].visit = true;
        }
        if($.inArray('SUPPORT_LOG_QUERY',navAuthorised) >= 0){
            $scope.nav[9].child[1].grandChild[2].visit = true;
        }
        if($.inArray('SUPPORT_LOG_QUERY',navAuthorised) >= 0){
            $scope.nav[9].child[1].grandChild[3].visit = true;
        }
        if($.inArray('SUPPORT_LOG_QUERY',navAuthorised) >= 0){
            $scope.nav[9].child[1].grandChild[4].visit = true;
        }
        if($.inArray('SUPPORT_LOG_QUERY',navAuthorised) >= 0){
            $scope.nav[9].child[1].grandChild[5].visit = true;
        }
        if($.inArray('SUPPORT_LOG_QUERY',navAuthorised) >= 0){
            $scope.nav[9].child[2].visit = true;
        }
        if($scope.nav[9].child[1].grandChild[0].visit || $scope.nav[9].child[1].grandChild[1].visit || $scope.nav[9].child[1].grandChild[2].visit || $scope.nav[9].child[1].grandChild[3].visit || $scope.nav[9].child[1].grandChild[4].visit || $scope.nav[9].child[1].grandChild[5].visit){
            $scope.nav[9].child[1].visit = true;
        }


        if($scope.nav[9].child[0].visit || $scope.nav[9].child[1].visit || $scope.nav[9].child[2].visit){
            $scope.nav[9].visit = true;
        }

		$scope.navHasLoad = true;
	};
	function getNav(){
		var nav = sessionStorage.getItem('nav');
		if(nav == null){
			setTimeout(function(){
				getNav();
			},100);
		}else{
            // console.log(nav);
			nav = nav.split(',');
			// console.log(nav);
			navAuthorFun(nav);
		}
	}
	getNav();

	$scope.navActive = localStorageService.get('navState');
	if($scope.navActive != null){
		$scope.nav1 = $scope.navActive.nav1;
		$scope.nav2 = $scope.navActive.nav2;
		$scope.nav3 = $scope.navActive.nav3;
	}
	else{
		$scope.navActive = {};
		$scope.navActive.nav1 = 0;
	}
	$scope.changeTabs = function(name,navNum,index,secIndex){
		switch(navNum){
			case 1:
				$scope.nav1 = index;
				break;
			case 2:
				$scope.nav2 = index;
				break;
			case 3:
				$scope.nav2 = secIndex;
				$scope.nav3 = index;
				break;
		}
		if(name){
			$scope.changeState(name);
			var obj = {
				nav1:$scope.nav1,
				nav2:$scope.nav2,
				nav3:$scope.nav3
			};
			localStorageService.clear('navState');
			localStorageService.update('navState',obj);
			$scope.navActive = localStorageService.get('navState');
		}
	};
});
app.controller("headerCtrl",function($scope,$http,$location,$state,localStorageService,tipService,confirmService,$rootScope,$timeout,loginCtrlDataSer,home){
	$rootScope.checkLogin();
	$scope.loginOut = function(){
		confirmService.set('退出确认','是否要退出后台管理系统?',function(){
			$http({
				method: 'POST',
				url: $rootScope.baseUrl+'logout'
			})
			.then(function successCallback(response) {
				$scope.changeState('login');
				localStorageService.clear('selfInfo');
				sessionStorage.clear();
				confirmService.clear();
			});
		});
	};
	//获取用户登陆信息
	home.get()
	.then(function (res) {
		var getSelfInfo = JSON.parse(res.content);
		localStorageService.update('selfInfo', getSelfInfo);
		$rootScope.getSelfInfo = getSelfInfo;
		$rootScope.getUserInfo();
	});
	$rootScope.getUserInfo = function(){
		$scope.userInfo = localStorageService.get('selfInfo');
		var json ={
			orgCode:$scope.userInfo.organize.orgCode,
		};
		loginCtrlDataSer.customized(json)
		.then(function (res) {
			if (res.code == '000000') {
				if(res.content!=""){
				var data=JSON.parse(res.content);
				}else{
					return;
				}
			$scope.customized = {
				orgAdminLogoFileId:data.orgAdminLogoFileId,
				adminSysName:data.adminSysName,
				adminSysEnglishName:data.adminSysEnglishName,
				orgAdminServiceHotline:data.orgAdminServiceHotline,
			};
			$('#traderuploadfile').attr('src',""+$rootScope.baseUrl+"/file/download?fileId="+$scope.customized.orgAdminLogoFileId+"");
			}else{
				$rootScope.tipService.setMessage(res.message, 'warning');
			}
		});
	};
	function justify_Let(obj){
	var obj=$(obj);
	var lengths=[];
	obj.each(function(){
		lengths.push($(this).text().length);
		console.log(lengths)
	});
	//var smax=Math.max(lengths);
	if(lengths.length==0){return;}
	for(var i=0,smax=lengths[0],len=lengths.length;i<len;i++){
		if(lengths[i]>smax){
			smax=lengths[i];
		}
	}

	for(var i=0,len=lengths.length;i<len;i++){
		var currlen=lengths[i];
		if(currlen==smax){continue;}
		obj.eq(i).css({"letter-spacing": ((smax-currlen)/(currlen-1))+"em"});
	}
	}
	justify_Let(".t1")
});