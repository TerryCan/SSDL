app.controller('HistrunwaterCtrl', ['$scope','getPageNum', 'localStorageService', '$state', 'getPrevSourceAgreementData', '$rootScope','getCollectionState', function ($scope,getPageNum, localStorageService, $state, getPrevSourceAgreementData, $rootScope,getCollectionState) {

    var processContent,processTotal;
    var source = {
        type: 'POST',
        datatype: "json",
        datafields: [  //数据字段定义
            {name: 'recoverId', type: 'string'},
            {name: 'channelType', type: 'string'},
            {name: 'state', type: 'string'},
            {name: 'remark', type: 'string'}
        ],
        url: $rootScope.baseUrl + 'settle/accountio/query/list',
        root: "content",
        pagesize:10,
        processData: function (data) {
            console.log(data)
            data.page = (data.pagenum + 1)?(data.pagenum + 1):1;
            data.rows =(data.pagesize)?(data.pagesize):10;
            data.order =($scope.order)?$scope.order:'desc';
            data.sort =($scope.sort)?$scope.sort:'createTime';
        }, //传递参数处理
        beforeLoadComplete: function (records) { //数据完全加载完执行绘制表格
            var start;
            for (var i in records) {
                start = parseInt(i);
                break;
            }
            for (var k = 0, r = processContent.length; k < r; k++) {
                records[start + k].recoverId = processContent[k].recoverId;
                records[start + k].channelType = processContent[k].channelType;
                records[start + k].state = processContent[k].state;
                records[start + k].remark = processContent[k].remark;
            }
        },
        beforeprocessing: function (data) { //处理总页数
            console.log(data)
            var processData = JSON.parse(data.content);
            processContent = processData.content;
            source.totalrecords = processData.totalElements == 0 ? 5 : processData.totalElements;
            processTotal = processData.totalElements;
        },
        loadComplete: function (records) {
            $scope.saveResult=JSON.parse(records.content);
            var data =  $scope.saveResult.totalElements;
            if (data == 0) {
                $('#contenttableentrustDetailGrid > div').remove();
            }
        },
        endUpdate: true
    };
    //创建数据适配器
    var dataAdapter = null;
    $scope.searchAjax = function () {
        $scope.toggleTraderSearchState = false;
        $('.search_column').css('height', '36px');
        if (dataAdapter == null) {
            dataAdapter = new $.jqx.dataAdapter(source);
            //创建表格
            $("#entrustDetailGrid").jqxGrid({
                source: dataAdapter,
                columns: [  //表格数据域
                    {
                        text: '通道类型',
                        datafield: 'channelType',
                        width: '30%',
                        minwidth: 30 + '%',//设置列min宽
                        align: 'center'//设置表头
                    },
                    {
                        text: '状态',
                        datafield: 'state',
                        minwidth: 33 + '%',
                        cellsalign: 'center',
                        align: 'center',
                        width: '33%',
                        cellsrenderer: function (row, columnfield, value, defaulthtml, columnproperties) {
                            if (getCollectionState) {
                                for (var i = 0; i <getCollectionState.length; i++) {
                                    if (value ==getCollectionState[i].id) {
                                        return getCollectionState[i].name;
                                    }
                                }
                            }
                        }
                    },
                    {
                        text: '备注',
                        datafield: 'remark',
                        width:'37%',
                        minwidth: 37 + '%',
                        align: 'center'
                    }
                ],
                width: 100 + '%',
                height: 87 + '%',
                theme:'metrodark',
                virtualmode: true,
                rendergridrows: function (params) { //将数据渲染到页面
                    return params.data;
                },
                pageable: true,
                pagesizeoptions: ['10','30','100','200'],
                sortable: true,
                columnsresize: true,//列间距是否可调整
                // selectionmode: 'singlecell',//选择模式
                clipboard: true,
                // selectionmode: 'checkbox',//复选框
            });
        }else {
            $("#entrustDetailGrid").jqxGrid('updatebounddata', 'cells');
        }
    };

    //分页
    $("#entrustDetailGrid").on("pagechanged", function (event) {
        console.log(event)
    });
    //排序
    $("#entrustDetailGrid").on("sort", function (event) {
        var sortinformation = event.args.sortinformation;
        $scope.sort=sortinformation.sortcolumn;
        $scope.order=($scope.sort)?(sortinformation.sortdirection.ascending)?'asc':'desc':'asc';
        data={
            order:$scope.order,
            sort:$scope.sort
        };
        source.processData(data);
        $("#entrustDetailGrid").jqxGrid('updatebounddata', 'sort');
    });
    //选中
    $('#entrustDetailGrid').on('rowselect', function (event) {
        $scope.chooseNoticeId = event.args.row.recoverId;
        console.log( $scope.chooseNoticeId)
    });
}])