app.controller('preManageConfigureCtrl',['$rootScope','$scope',function($rootScope,$scope){

}])
