app.controller("prevSourceFundingapprovalCtrl", ['$scope', '$timeout','prevSourceFundingapprovalCtrlSel', 'getPageNum', 'plateType', 'memberMangerCtrlSer', '$rootScope', 'timestamp', 'confirmService', 'dataSer', 'home', 'localStorageService','getAmountState','accountManagementSer', function($scope,$timeout, prevSourceFundingapprovalCtrlSel, getPageNum, plateType, memberMangerCtrlSer, $rootScope, timestamp, confirmService, dataSer, home, localStorageService,getAmountState,accountManagementSer) {
    $scope.toggleTraderSearchState = false;
		$scope.Toggle = function() {
			$scope.toggleTraderSearchState = !$scope.toggleTraderSearchState;
			if ($scope.toggleTraderSearchState) {
				$('.search_column').css('height', 'auto');
			} else {
				$('.search_column').css('height', '36px');
			}
		};
    //分页
    var pageJump = function (tmpArrList) {
        $timeout(function () {
            if (tmpArrList != undefined) {
                $scope.currentPage = 1;//当前页数
                $scope.dataNum = tmpArrList.length;
                $scope.showDataChoose = getPageNum.pageNum();//获取分页
                $scope.showNum = $scope.showDataChoose[0];//初始显示刷具条数
                $scope.showPage = false;
                $timeout(function () {
                    $scope.showPage = true;
                    $scope.copyDataArray = tmpArrList.slice(0, 14); //初始15条数据
                }, 10)
                $scope.dataPage = Math.ceil($scope.dataNum / $scope.showNum.showNum);

                //上下页
                $scope.pageSlect = function (type) {
                    if (type == 'prev') {
                        if ($scope.currentPage != 1) {
                            $scope.currentPage--;
                            $scope.turnPage();
                        } else {
                            $scope.copyDataArray = tmpArrList.slice(0, 14); //初始15条数据
                        }
                    }
                    else {
                        if ($scope.currentPage < $scope.dataPage) {
                            $scope.currentPage++;
                            $scope.turnPage();
                        }
                    }
                }
                //每页数据量
                $scope.baseDataArray = [];
                $scope.copyDataArray = [];
                $scope.pageSelect = function (params) {
                    $scope.showNum.showNum = params.showNum;
                    $scope.copyDataArray = tmpArrList.slice(0, (params.showNum - 1));
                    $scope.dataPage = Math.ceil($scope.dataNum / $scope.showNum.showNum);
                    $scope.currentPage = 1;
                }
                $scope.turnPage = function () {
                    $scope.copyDataArray = tmpArrList.slice((($scope.currentPage - 1) * 15), (($scope.currentPage + 1) * 15 - 1));
                }
                //固定页面跳转
                $scope.jumpPage = function (num) {
                    num = parseInt(num);
                    if (parseInt(num, 10) === num && num <= ($scope.dataPage + 1) && num > 0) {
                        $scope.currentPage = num;
                        $scope.jumpPageNum = '';
                        $scope.turnPage();
                    } else {
                        $scope.copyDataArray = tmpArrList.slice(0, 14); //初始15条数据
                    }
                }
            } else {
                pageJump(tmpArrList);
            }
        }, 200);
    };

		$scope.account = "";
		$scope.DirectNum= "";
		$scope.Reviewer = "";

			//获取状态显示
		$scope.StateLists=getAmountState
		$scope.getwaterState = function(parameter) {
		for(var i=0;i<$scope.StateLists.length;i++){
              if(parameter==$scope.StateLists[i].val){
                  return $scope.StateLists[i].name;
              }
        }
    	}
    		accountManagementSer.accountSearch()
			.then(function(response) {
				var accountList = response.list;
				$scope.accountList = accountList;
				console.log($scope.accountList);
			})
		$scope.accountType = function(key) {
				for (var i = 0, r = $scope.accountList.length; i < r; i++) {
					if (key == $scope.accountList[i].key) {
						return $scope.accountList[i].name
					}

				}
			}

			//额度调整查询
		$scope.search = function() {
			$('.search_column').css('height', '36px');
			var startTime = $scope.startTime;
			var endTime = $scope.endTime;
			var startTimeNum = Date.parse(new Date(startTime))/1000;
			var endTimeNum = Date.parse(new Date(endTime))/1000;
			prevSourceFundingapprovalCtrlSel.search($scope.account, $scope.Direct, startTimeNum, endTimeNum)
				.then(function(res) {
					console.log(res)
					if (res.data.retMsg.code =='000000') {
						$scope.adjustlsit = res.data.list;
                        pageJump($scope.adjustlsit);
					}else {
								$rootScope.tipService.setMessage(res.data.retMsg.message, 'warning');
							}
						}, function(error) {
							$rootScope.tipService.setMessage(error.data.retMsg.message, 'warning');
						});
		}
        //$scope.search();
		$scope.adjustText = function(OrgCode) {
			if ($scope.orgList) {
				//console.log($scope.adjustlsit)
				for (var i = 0, r = $scope.orgList.length; i < r; i++) {
					//console.log($scope.adjustlsit.length)
					if ($scope.orgList[i].orgCode == OrgCode) {
						return $scope.orgList[i].orgName;
					}
				}
			}
		}
		//数据转换
		$scope.ioType = [{
			id: '0',
			name: '入金'
		}, {
			id: '1',
			name: '出金'
		}];
		$scope.getIoType = function(params) {
			for (var i = 0, r = $scope.ioType.length; i < r; i++) {
				if (params == $scope.ioType[i].id) {
					return $scope.ioType[i].name;
				}
			}
		}
		//获取用户自己的基本信息
		home.get().then(function(res) {
			$scope.getSelfInfo = JSON.parse(res.content);
			//console.log($scope.getSelfInfo);
			$scope.Operator = $scope.getSelfInfo.loginName
			console.log($scope.Operator);
		})

		//时间戳
		$scope.timestamp = function(stamp) {
			return timestamp.timestampCoverHms(stamp*1000, 'all')
		}

		$scope.chooseItemTab1 = null;
		//单选
		$scope.checked = function(index, Key) {
			$scope.chooseItemTab1 = Key;
			$scope.Key = $scope.adjustlsit[index].Key;
			$('#dataReport input[type=checkbox]').prop('checked', false);
			$('#dataReport input[type=checkbox]').eq(index).prop('checked', true);
			console.log($scope.Key);
		}

		//审核
		$scope.psaaCheck = function() {
				if (!$scope.chooseItemTab1) {
					$rootScope.tipService.setMessage('请先选择账户', 'warning');
				} else {
					var json = {
						key: $scope.Key,
						pass: true
					}
					prevSourceFundingapprovalCtrlSel.PASSCheck(json)
						.then(function(res) {
							console.log(res)
							if (res.data.code == '000000') {
								$rootScope.tipService.setMessage(res.data.message, 'warning');
								$scope.search();
								$scope.chooseItemTab1 = null;
							} else {
								$rootScope.tipService.setMessage(res.data.message, 'warning');
							}
						}, function(error) {
							$rootScope.tipService.setMessage(error.data.message, 'warning');
						});
				}
			}
			//驳回
		$scope.unPASSCheck = function() {
			if (!$scope.chooseItemTab1) {
				$rootScope.tipService.setMessage('请先选择账户', 'warning');
			} else {
				var json = {
					key: $scope.Key,
					pass: false
				}
				prevSourceFundingapprovalCtrlSel.UNPASSCheck(json)
					.then(function(res) {
						console.log(res)
						if (res.data.code == '000000') {
							$rootScope.tipService.setMessage(res.data.message, 'warning');
							$scope.search();
							$scope.chooseItemTab1 = null;
						} else {
							$rootScope.tipService.setMessage(res.data.message, 'warning');
						}
					}, function(error) {
						$rootScope.tipService.setMessage(error.data.message, 'warning');
					});
			}
		}
	}])
	.factory('prevSourceFundingapprovalCtrlSel', ['$http', 'localStorageService', 'myHttp', '$q', '$rootScope', function($http, localStorageService, myHttp, $q, $rootScope) {
		return {
			search: function(account, Direct, startTimeNum, endTimeNum) {
				var deferred = $q.defer();
				$http({
						method: 'POST',
						url: $rootScope.baseUrl + '/c/up/capital/adjust/query',
						data: {
							"condlist": [{
									"field": "Account",
									"value": account,
									"condition": 0
								}, {
									"field": "Direct",
									"value": Direct,
									"condition": 0
								}, {
									"field": "Time",
									"value": startTimeNum,
									"condition": 3
								}, {
									"field": "Time",
									"value": endTimeNum,
									"condition": 4
								}

							]
						}
					})
					.then(function(res) { // 调用承诺API获取数据 .resolve
						deferred.resolve(res);
					}, function(res) { // 处理错误 .reject
						deferred.reject(res);
					});
				return deferred.promise;
			},
			//审核
			PASSCheck: function(json) {
				var deferred = $q.defer();
				$http({
						method: 'POST',
						url: $rootScope.baseUrl + 'c/up/capital/adjust/review',
						data: json
					})
					.then(function(res) { // 调用承诺API获取数据 .resolve
						deferred.resolve(res);
					}, function(res) { // 处理错误 .reject
						deferred.reject(res);
					});
				return deferred.promise;
			},
			//驳回
			UNPASSCheck: function(json) {
				var deferred = $q.defer();
				$http({
						method: 'POST',
						url: $rootScope.baseUrl + 'c/up/capital/adjust/review',
						data: json
					})
					.then(function(res) { // 调用承诺API获取数据 .resolve
						deferred.resolve(res);
					}, function(res) { // 处理错误 .reject
						deferred.reject(res);
					});
				return deferred.promise;
			}
		}
	}])