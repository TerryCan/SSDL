app.controller('riskKyoheiCtrl', ['$scope', '$state', '$rootScope', 'localStorageService', 'timestamp', 'dataSer', 'riskKyoheiCtrlSer', 'productClassificationCtrlSer', '$timeout', 'getPageNum', 'confirmService', 'CommissionallocationAddCtrlSer', 'productClassificationCtrlSer', function ($scope, $state, $rootScope, localStorageService, timestamp, dataSer, riskKyoheiCtrlSer, productClassificationCtrlSer, $timeout, getPageNum, confirmService, CommissionallocationAddCtrlSer, productClassificationCtrlSer) {
    localStorageService.clear('userIdChecked');
    $scope.timeRuleName = "";
    $scope.addOrgVal = "";
    $scope.productIds = "";
    $scope.startTime = "";
    $scope.endTime = "";

    //机构列表
    $scope.addOrgVal = ''; //显示值
    $scope.orgId = ''; //选择值
    dataSer.organizeQuerySer().then(function (res) {
            $scope.orgList = res;
        });
    $scope.addOrgVal1 = function () {
        $scope.baseProList = [];
        $scope.copyProList = [];
        $scope.addOrgVal = "";
        $scope.orgCode = "";
    };
    $scope.addOrgValFTC = function (d) {
        $scope.allotOrgId = d.orgId;
        $scope.superorgCode = d.orgCode;
        $scope.addOrgVal = d.text;

        //产品ID
        CommissionallocationAddCtrlSer.productListdata($scope.allotOrgId)
            .then(function (res) {
                if (res.code == "000000") {
                    var prolistdt = JSON.parse(res.content);
                    for (var i = 0, r = prolistdt.length; i < r; i++) {
                        $scope.baseProList.push({
                            productIds: prolistdt[i].productId,
                            productName: prolistdt[i].productName
                        });
                    }
                } else {
                    $rootScope.tipService.setMessage(res.message, 'warning')
                }
            })
    };
    $scope.orgCodetext = function (orgCode) {
        for (var i = 0, r = $scope.orgList.length; i < r; i++) {
            if (orgCode == $scope.orgList[i].orgCode) {
                return $scope.orgList[i].text
            }
        }
    };
    // 将毫秒转化为系统时间
    $scope.formatTime = function (parameter) {
        return timestamp.daySecondsToDate(parameter);
    };
    $scope.baseProList = [];
    $scope.copyProList = [];

    $scope.addPro = function (index) {
        $scope.copyProList.unshift($scope.baseProList.splice(index, 1)[0]);
    };
    $scope.backPro = function (index) {
        $scope.baseProList.unshift($scope.copyProList.splice(index, 1)[0]);
    };

    $scope.searchAjax = function () {
        riskKyoheiCtrlSer.riskSearch()
            .then(function (res) {
                if (res.retMsg.code == '000000' && res.list.length > 0){
                    $scope.productIdszy = [];
                    $scope.riskList = res.list;
                    console.log($scope.riskList);
                    $scope.featureShow = true;
                    var source = {
                        localdata: $scope.riskList,
                        datatype: "array",
                        datafields: [  //数据字段定义
                            {name: 'id', type: 'string'},
                            {name: 'productId', type: 'string'},
                            {name: 'userName', type: 'string'},
                            {name: 'orgCode', type: 'string'},
                            {name: 'startTime', type: 'string'},
                            {name: 'endTime', type: 'string'}
                        ]
                    };
                    var dataAdapter = new $.jqx.dataAdapter(source);
                    $("#entrustDetailGrid").jqxGrid(
                        {
                            width: 100 + '%',
                            height: 80 + '%',
                            theme: 'metrodark',
                            source: dataAdapter,//数据源
                            pageable: true,//是否分页
                            pagesize: 10,
                            // sortable: true,//是否排序
                            columnsresize: true,//列间距是否可调整
                            clipboard: false,//屏蔽jqxGrid的复制功能
                            pagesizeoptions: ['10', '30', '100', '200'],
                            columns: [  //表格数据域
                                {
                                    text: '定时名称',
                                    datafield: 'timeRuleName',
                                    sortable: false,
                                    align: 'center',//设置表头
                                    width: '25%'
                                },
                                {
                                    text: '机构信息',
                                    datafield: 'orgCode',
                                    sortable: false,
                                    cellsalign: 'center',
                                    align: 'center',
                                    width: '25%',
                                    cellsrenderer: function (row, columnfield, value, defaulthtml, columnproperties) {
                                        if ($scope.orgList) {
                                            for (var i = 0, r = $scope.orgList.length; i < r; i++) {
                                                if (value == $scope.orgList[i].orgCode) {
                                                    return $scope.orgList[i].text
                                                }
                                            }
                                        }
                                    }
                                },
                                {
                                    text: '开始时间',
                                    datafield: 'startTime',
                                    sortable: false,
                                    width: '25%',
                                    align: 'center',
                                    cellsrenderer: function (row, columnfield, value, defaulthtml, columnproperties) {
                                        return timestamp.daySecondsToDate(value, 'all');
                                    }
                                },
                                {
                                    text: '结束时间',
                                    datafield: 'endTime',
                                    sortable: false,
                                    cellsalign: 'center',
                                    align: 'center',
                                    width: '25%',
                                    cellsrenderer: function (row, columnfield, value, defaulthtml, columnproperties) {
                                        return timestamp.daySecondsToDate(value, 'all');
                                    }
                                }
                            ]
                        });
                }else{
                    $rootScope.tipService.setMessage(res.retMsg.message, 'warning');
                }
            }, function (error) {
                $rootScope.tipService.setMessage(error.message, 'warning');
            })
    };
    //分页
    $("#entrustDetailGrid").on("pagechanged", function (event) {
        console.log(event)
    });
    //排序
    $("#entrustDetailGrid").on("sort", function (event) {
        var sortinformation = event.args.sortinformation;
        $scope.sort = sortinformation.sortcolumn;
        $scope.order = ($scope.sort) ? (sortinformation.sortdirection.ascending) ? 'asc' : 'desc' : 'asc';
        data = {
            order: $scope.order,
            sort: $scope.sort
        };
        source.processData(data);
        $("#entrustDetailGrid").jqxGrid('updatebounddata', 'sort');
    });
    //选中
    $('#entrustDetailGrid').on('rowselect', function (event) {
        $scope.chooseItemTab1 = event.args.row.id;
        $scope.chooseUserData = {
            id: event.args.row.id,
            timeRuleName: event.args.row.timeRuleName,
            orgCode: event.args.row.orgCode,
            productId: event.args.row.productId,
            startTime: event.args.row.startTime,
            endTime: event.args.row.endTime
        };
        $scope.$apply()
    });

    $scope.addNewUser = function () {
        $scope.newUserShow = true;
        $scope.addEditText = '新增';
        $scope.timeRuleName = "";
        $scope.addOrgVal = "";
        $scope.productIds = "";
        $scope.startTime = "";
        $scope.endTime = "";
        $scope.copyProList = [];
    };

    //产品管理
    productClassificationCtrlSer.search(999999, 1, '', '', '', '', '').then(function (res) {
            $scope.proListall = JSON.parse(res.content).content;
        });

    $scope.editUser = function () {
        $scope.baseProList = [];
        $scope.copyProList = [];
        if (!$scope.chooseItemTab1) {
            $rootScope.tipService.setMessage('请先选择用户', 'warning');
        } else {
            $scope.addEditText = '修改';
            $scope.newUserShow = true;
            $scope.id = $scope.chooseUserData.id;
            $scope.timeRuleName = $scope.chooseUserData.timeRuleName;
            $scope.orgCode = $scope.chooseUserData.orgCode;
            //匹配机构代码
            var json = {
                page: 1,
                rows: 9999,
                search_A_EQ_state: 1
            };
            dataSer.getOrganize(json).then(function (res) {
                if (res.code == '000000') {
                    $scope.equalOrgCode = JSON.parse(res.content).content;
                    for (var i = 0; i < $scope.equalOrgCode.length; i++) {
                        if ($scope.chooseUserData.orgCode == $scope.equalOrgCode[i].orgCode) {
                            $scope.addOrgVal = $scope.equalOrgCode[i].orgName + '(' + $scope.equalOrgCode[i].orgNum + ')';
                        }
                    }
                }
            });
            $scope.startTime = $scope.formatTime($scope.chooseUserData.startTime);
            $scope.endTime = $scope.formatTime($scope.chooseUserData.endTime);
            $scope.productIds = $scope.chooseUserData.productId;
            var productIdedit = $scope.productIds.split(",");
            for (var i = 0, r = productIdedit.length; i < r; i++) {
                var text;
                for (var s = 0, k = $scope.proListall.length; s < k; s++) {
                    if ($scope.proListall[s].productId == productIdedit[i]) {
                        text = $scope.proListall[s].productName;
                    }
                }
                $scope.copyProList.push({
                    productIds: productIdedit[i],
                    productName: text
                });
            }
        }
    };
    //数据清空
    $scope.remove = function () {
        $scope.timeRuleName = "";
        $scope.addOrgVal = "";
        $scope.productIds = "";
        $scope.startTime = "";
        $scope.endTime = "";
        $scope.newUserShow = false;
    };
    $scope.addSubmit = function () {
        if ($scope.addEditText == '新增') {
            $scope.productIdadd = [];
            for (var i = 0, r = $scope.copyProList.length; i < r; i++) {
                $scope.productIdadd.push($scope.copyProList[i].productIds);
                var productIdadds = $scope.productIdadd.join(',');

            }
            var timeRule = {
                timeRuleName: $scope.timeRuleName,
                orgCode: $scope.superorgCode,
                productId: productIdadds,
                startTime: ($scope.startTime) ? timestamp.DateToSeconds($scope.startTime) : '',
                endTime: ($scope.endTime) ? timestamp.DateToSeconds($scope.endTime) : '',
            };
            var json = {
                timeRule: timeRule
            };
            riskKyoheiCtrlSer.insertSubmit(json)
                .then(function (res) {
                    console.log(res)
                    if (res.data.code == '000000') {
                        $scope.remove();
                        $rootScope.tipService.setMessage(res.data.message, 'warning')
                        $scope.searchAjax();
                    } else {
                        $rootScope.tipService.setMessage(res.data.message, 'warning');
                    }
                }, function (error) {
                    $rootScope.tipService.setMessage(error.data.message, 'warning');
                });
        } else if ($scope.addEditText == '修改') {
            $scope.productIded = [];
            for (var i = 0, r = $scope.copyProList.length; i < r; i++) {
                $scope.productIded.push($scope.copyProList[i].productIds);
                var proVal = $scope.productIded;
                $scope.productIdss = proVal.join(',');
            }

            var timeRule = {
                id: $scope.id,
                timeRuleName: $scope.timeRuleName,
                orgCode: ($scope.superorgCode == undefined) ? $scope.orgCode : $scope.superorgCode,
                productId: $scope.productIdss,
                startTime: ($scope.startTime) ? timestamp.DateToSeconds($scope.startTime) : '',
                endTime: ($scope.endTime) ? timestamp.DateToSeconds($scope.endTime) : '',
            };
            var json = {
                timeRule: timeRule
            };
            console.log(json)
            riskKyoheiCtrlSer.EditSubmit(json)
                .then(function (res) {
                    if (res.data.code == '000000') {
                        $scope.remove();
                        $scope.searchAjax();
                    } else {
                        $rootScope.tipService.setMessage(res.data.message, 'warning');
                    }
                }, function (error) {
                    $rootScope.tipService.setMessage(error.data.message, 'warning');
                });
        }
    }

    //删除
    $scope.delete = function () {
        if (!$scope.chooseItemTab1) {
            $rootScope.tipService.setMessage('请先选择信息', 'warning');
        } else {
            confirmService.set('确认提示', '确定要删除此信息吗?', function () {
                var json = {
                    id: $scope.chooseItemTab1
                };
                riskKyoheiCtrlSer.delete(json)
                    .then(function (res) {
                        if (res.code == "000000") {
                            $rootScope.tipService.setMessage(res.message, 'warning');
                            $scope.searchAjax()
                        }
                    }, function (error) {
                        $rootScope.tipService.setMessage(error.message, 'warning');
                    });
                confirmService.clear();
            });
        }
    };

}])
    .factory('riskKyoheiCtrlSer', ['$http', 'localStorageService', 'myHttp', '$q', '$rootScope', function ($http, localStorageService, myHttp, $q, $rootScope) {
        return {
            //查询
            riskSearch: function () {
                var deferred = $q.defer();
                $http({
                    method: "POST",
                    url: $rootScope.baseUrl + "c/time/riskctrl/query/all"
                }).success(function (res) {
                    deferred.resolve(res);
                }).error(function (res) {
                    deferred.reject(res);
                });
                return deferred.promise;
            },
            riskfieldSearch: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'c/time/riskctrl/query/filter',
                    data: json
                }).then(function successCallback(response) {
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
            insertSubmit: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'c/time/riskctrl/insert',
                    data: json
                }).then(function successCallback(response) {
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
            EditSubmit: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'c/time/riskctrl/modify',
                    data: json
                }).then(function successCallback(response) {
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
            delete: function (json) {
                var deferred = $q.defer();
                $http({
                    method: "POST",
                    url: $rootScope.baseUrl + "c/time/riskctrl/delete",
                    data: json
                }).success(function (res) {
                    deferred.resolve(res);
                }).error(function (res) {
                    deferred.reject(res);
                });
                return deferred.promise;
            }
        }
    }])