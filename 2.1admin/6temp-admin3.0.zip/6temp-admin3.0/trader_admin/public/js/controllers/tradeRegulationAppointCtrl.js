app.controller('tradeRegulationAppointCtrl', ['$scope', '$rootScope', 'tradeRegulationAppointAll', 'memberMangerCtrlSer', 'tipService', 'getTradeRuleType', 'getTradeRuleConditionType', 'confirmService', 'riskRegulationAll', '$timeout', 'productClassificationCtrlSer','getPageNum', 'localStorageService', 'timestamp','dataSer', function ($scope, $rootScope, tradeRegulationAppointAll, memberMangerCtrlSer, tipService, getTradeRuleType, getTradeRuleConditionType, confirmService, riskRegulationAll, $timeout, productClassificationCtrlSer,getPageNum, localStorageService,timestamp,dataSer) {
    $scope.toggleTraderSearchState=false;
    $scope.Toggle = function(){
        $scope.toggleTraderSearchState = !$scope.toggleTraderSearchState;
        if($scope.toggleTraderSearchState){
           $('.search_column').css('height','auto');
        }
        else{
           $('.search_column').css('height','36px');
        }
    };
    $scope.formatTime = function (parameter) {
        return timestamp.daySecondsToDate(parameter);
    };
    //交易规则查询
    $scope.tradeRegulationSearch = function () {
        var json = {
            qryConditionList: [{
                field: "Type",
                value: ($scope.type)?$scope.type:''
            }, {
                field: "Operator",
                value: ($scope.OperatorType)?$scope.OperatorType:''
            }, {
                field: "Enable",
                value: ($scope.EnableType)?$scope.EnableType:''
            }]
        };
        tradeRegulationAppointAll.riskSearch(json)
            .then(function (res) {
                if(res.retMsg.code=='000000'){
                    $scope.tradeList = res.list;
                    console.log($scope.tradeList);
                }
            }, function (error) {
                console.log(error);
            })
    };
    $scope.tradeRegulationSearch();

    // 会员管理查询
    $scope.ManageSearch = function () {
        $scope.showNum = 9999;
        $scope.currentPage = 1;
        memberMangerCtrlSer.search($scope.showNum, $scope.currentPage)
            .then(function (res) {
                if(res.code=='000000'){
                    $scope.orgManageResult = JSON.parse(res.content).content;
                    console.log($scope.orgManageResult)
                }
            }, function (error) {
                console.log(error)
            });
    };
    $scope.ManageSearch();

    // 产品管理
    $scope.search_productName = '';
    $scope.search_state = '';
    $scope.search_productCurrency = '';
    $scope.search_productCode = '';
    $scope.search_effectType = '';
    $scope.productSearch = function () {
        $scope.showNum = 1000;
        $scope.currentPage = 1;
        productClassificationCtrlSer.search($scope.showNum, $scope.currentPage, $scope.search_productName, $scope.search_state, $scope.search_productCurrency, $scope.search_productCode, $scope.search_effectType)
            .then(function (res) {
                if(res.code=='000000'){
                    var data = JSON.parse(res.content);
                    $scope.productResult = data.content;
                    console.log($scope.productResult)
                }
            }, function (error) {
                console.log(error);
            });
    };
    $scope.productSearch();

    //交易规则指派查询
    $scope.tradeRegulationAppointSearch = function () {
         $scope.toggleTraderSearchState=false;
        $('.search_column').css('height','36px');
        var json = {
            qryConditionList: [{
                field: "OrgCode",
                value: ($scope.OrgCode)?$scope.OrgCode:''
            }, {
                field: "Operator",
                value: ($scope.Operator)?$scope.Operator:''
            }, {
                field: "ProductId",
                value: ($scope.ProductId)?$scope.ProductId:''
            }, {
                field: "RuleKey",
                value: ($scope.RuleKey)?$scope.RuleKey:''
            }]
        };
        tradeRegulationAppointAll.riskFilterSearch(json)
            .then(function (res) {
                if(res.retMsg.code=='000000'){
                    $scope.tradeAppointList = res.list;
                    console.log($scope.tradeAppointList);
                    var tempData = portData($scope.tradeAppointList);
                    if(tempData){
                        console.log(tempData)
                        $scope.featureShow = true;
                        var source = {
                            localdata: tempData,
                            datatype: "array",
                            datafields: [
                                {name: 'Key', type: 'string'},
                                {name: 'orgName', type: 'string'},
                                {name: 'OrgCode', type: 'string'},
                                {name: 'RuleKey', type: 'string'},

                                {name: 'orgNum', type: 'string'},
                                {name: 'productName', type: 'string'},
                                {name: 'tradeName', type: 'string'},
                                {name: 'Type', type: 'string'},
                                {name: 'Condition', type: 'string'},

                                {name: 'Para1', type: 'string'},
                                {name: 'Para2', type: 'string'},
                                {name: 'StartTime', type: 'string'},
                                {name: 'EndTime', type: 'string'}
                            ]
                        };
                        var dataAdapter = new $.jqx.dataAdapter(source);
                        $("#entrustDetailGrid").jqxGrid(
                            {
                                width: 100 + '%',
                                height: 80 + '%',
                                theme: 'metrodark',
                                source: dataAdapter,//数据源
                                pageable: true,//是否分页
                                pagesize: 10,
                                // sortable: true,//是否排序
                                columnsresize: true,//列间距是否可调整
                                clipboard: false,//屏蔽jqxGrid的复制功能
                                pagesizeoptions: ['10', '30', '100', '200'],
                                columns: [
                                    {
                                        text: '机构编号',
                                        datafield: 'orgNum',
                                        width: 14 + '%',
                                        minwidth: 14 + '%',
                                        align: 'center',
                                        cellsalign: 'center'
                                    },
                                    {
                                        text: '商品名',
                                        datafield: 'productName',
                                        width: 14 + '%',
                                        minwidth: 14 + '%',
                                        align: 'center',
                                        cellsalign: 'center'
                                    },
                                    {
                                        text: '交易规则',
                                        datafield: 'tradeName',
                                        width: 14 + '%',
                                        minwidth: 14 + '%',
                                        align: 'center',
                                        cellsalign: 'center'
                                    },
                                    {
                                        text: '交易类型',
                                        datafield: 'Type',
                                        width: 14 + '%',
                                        minwidth: 14 + '%',
                                        align: 'center',
                                        cellsalign: 'center',
                                        cellsrenderer: function (row, columnfield, value, defaulthtml, columnproperties) {
                                            for (i = 0; i < $scope.TradeRuleType.length; i++) {
                                                if (value == $scope.TradeRuleType[i].id) {
                                                    return $scope.TradeRuleType[i].name;
                                                }
                                            }

                                        }
                                    },
                                    {
                                        text: '交易条件',
                                        datafield: 'Condition',
                                        width: 14 + '%',
                                        minwidth: 14 + '%',
                                        align: 'center',
                                        cellsalign: 'center',
                                        cellsrenderer: function (row, columnfield, value, defaulthtml, columnproperties) {
                                            if (tempData) {
                                                console.log(tempData)
                                                if (value == 0) {
                                                    return 'x>' + tempData[row].Para1;
                                                }
                                                if (value == 1) {
                                                    return 'x>=' + tempData[row].Para1;
                                                }
                                                if (value == 2) {
                                                    return 'x<' + tempData[row].Para1;
                                                }
                                                if (value == 3) {
                                                    return 'x<=' + tempData[row].Para1;
                                                }
                                                if (value == 4) {
                                                    return tempData[row].Para1 + '<x<' + tempData[row].Para2;
                                                }
                                                if (value == 5) {
                                                    return tempData[row].Para1 + '<=x<=' + tempData[row].Para2;
                                                }
                                            }
                                        }
                                    },
                                    {
                                        text: '开始时间',
                                        datafield: 'StartTime',
                                        width: 15 + '%',
                                        minwidth: 15 + '%',
                                        align: 'center',
                                        cellsalign: 'center',
                                        cellsrenderer: function (row, columnfield, value, defaulthtml, columnproperties) {
                                            if (value) {
                                                return timestamp.daySecondsToDate(value);
                                            }
                                        }
                                    },
                                    {
                                        text: '结束时间',
                                        datafield: 'EndTime',
                                        width: 15 + '%',
                                        minwidth: 15 + '%',
                                        align: 'center',
                                        cellsalign: 'center',
                                        cellsrenderer: function (row, columnfield, value, defaulthtml, columnproperties) {
                                            if (value) {
                                                return timestamp.daySecondsToDate(value);
                                            }
                                        }
                                    }
                                ]
                            });
                        //分页
                        $("#entrustDetailGrid").on("pagechanged", function (event) {
                            console.log(event)
                        });
                    }
                }else{
                    $rootScope.tipService.setMessage(res.retMsg.message, 'warning');
                }
            }, function (error) {
                $rootScope.tipService.setMessage(error.message, 'warning');
            });
    };
    var portData = function (parameter) {
        if ($scope.orgManageResult && $scope.tradeList && $scope.productResult) {
            var reportArray = [];
            for (var i = 0, r = parameter.length; i < r; i++) {
                var tmpArr = {
                    orgNum: '',
                    orgName: '',
                    OrgCode: '',
                    productName: '',
                    EndTime: '',
                    StartTime: '',
                    tradeName: '',
                    Type: '',
                    Condition: '',
                    Operator: '',
                    Key: '',
                    productId: '',
                    Para1: '',
                    Para2: '',
                    RuleKey: ''
                };
                tmpArr.RuleKey =parameter[i].RuleKey;
                tmpArr.EndTime =parameter[i].EndTime;
                tmpArr.StartTime =parameter[i].StartTime;
                tmpArr.Operator =parameter[i].Operator;
                tmpArr.Key =parameter[i].Key;
                tmpArr.OrgCode =parameter[i].OrgCode;
                var productIds =parameter[i].ProductId.split(",");
                var productName = [];
                for (var n = 0; n < $scope.productResult.length; n++) {
                    for (var m = 0; m < productIds.length; m++) {
                        if ($scope.productResult[n].productId == productIds[m]) {
                            productName.push($scope.productResult[n].productName);
                            tmpArr.productName = productName.join('|');
                        }
                    }
                }
                for (var k = 0, s = $scope.orgManageResult.length; k < s; k++) {
                    if ($scope.orgManageResult[k].orgCode ==parameter[i].OrgCode) {
                        tmpArr.orgNum = $scope.orgManageResult[k].orgNum;
                        tmpArr.orgName = $scope.orgManageResult[k].orgName;
                    }
                }
                for (var j = 0; j < $scope.tradeList.length; j++) {
                    if ($scope.tradeList[j].Key ==parameter[i].RuleKey) {
                        tmpArr.Type = $scope.tradeList[j].Type;
                        tmpArr.Condition = $scope.tradeList[j].Condition;
                        tmpArr.tradeName = $scope.tradeList[j].Name;
                        tmpArr.Para1 = $scope.tradeList[j].Para1;
                        tmpArr.Para2 = $scope.tradeList[j].Para2;
                    }
                }
                reportArray.push(tmpArr);
            }
            return reportArray;
        } else {
            $rootScope.tipService.setMessage('请求数据为空!', 'warning');
        }
    };


    //机构列表
    $scope.addOrgValOne = ''; //显示值
    $scope.addOrgChooseValOne = ''; //选择值
    dataSer.organizeQuerySer().then(function (res) {
            $scope.orgList = res;
        });
    $scope.addOrgValFTCOne = function (orgId, text,orgCode) {
        $scope.addOrgChooseValOne = orgId;
        $scope.addOrgValOne = text;
        $scope.orgCode = orgCode;
    };
    $scope.clearOrg=function(){
        console.log( $scope.addOrgValOne);
        $scope.addOrgValOne = '';
    };
    $scope.hideOrgListOne = function () {
        $scope.isShowOrgList = false;
        $(".OrgList").blur();
    };
    //规则类型
    $scope.TradeRuleType = getTradeRuleType;
    $scope.getTradeRule = function (parameter) {
        for (i = 0; i < $scope.TradeRuleType.length; i++) {
            if (parameter == $scope.TradeRuleType[i].id) {
                return $scope.TradeRuleType[i].name;
            }
        }
    };
    //交易—规则条件
    $scope.TradeRuleConditionType = getTradeRuleConditionType;
    $scope.getTradeRuleCondition = function (Condition, Para1, Para2) {
        switch (Condition) {
            case 0:
                return 'x>' + Para1;
                break;
            case 1:
                return 'x>=' + Para1;
                break;
            case 2:
                return 'x<' + Para1;
                break;
            case 3:
                return 'x<=' + Para1;
                break;
            case 4:
                return Para1 + '<x<' + Para2;
                break;
            default:
                return Para1 + '<=x<=' + Para2;
        }
    };

    //数据联动
    $scope.riskRegulationFunc = function () {
        var getTradeRule = function (parameter) {
            for (i = 0; i < $scope.TradeRuleType.length; i++) {
                if (parameter == $scope.TradeRuleType[i].id) {
                    return $scope.TradeRuleType[i].name;
                }
            }
        };
        var getTradeRuleCondition = function (Condition, Para1, Para2) {
            if (Condition == 0) {
                return 'x>' + Para1;
            }
            if (Condition == 1) {
                return 'x>=' + Para1;
            }
            if (Condition == 2) {
                return 'x<' + Para1;
            }
            if (Condition == 3) {
                return 'x<=' + Para1;
            }
            if (Condition == 4) {
                return Para1 + '<x<' + Para2;
            }
            if (Condition == 5) {
                return Para1 + '<=x<=' + Para2;
            }
        };
        for (var i = 0, r = $scope.tradeList.length; i < r; i++) {
            console.log($scope.riskRule);
            console.log($scope.tradeList);
            if ($scope.riskRule.split(':')[0] == $scope.tradeList[i].Key) {
                $scope.tradeCondition = getTradeRuleCondition($scope.tradeList[i].Condition, $scope.tradeList[i].Para1, $scope.tradeList[i].Para2);
                $scope.tradeType = getTradeRule($scope.tradeList[i].Type);
            }
        }
    };
    // 品种追加
    $scope.productResultClone =new Array();
    $scope.productAdd = function (index) {
        var tmp_arr = $scope.productResult[index];
        console.log(tmp_arr);
        console.log( $scope.productResultClone);
        if($scope.productResultClone instanceof Array){
            $scope.productResultClone.unshift(tmp_arr);  //将选择的品种添加到已选品种列表首部
        }else{
            $scope.productResultClone=[];
            $scope.productResultClone.unshift(tmp_arr);  //将选择的品种添加到已选品种列表首部
        }
        delete $scope.productResult[index];  //品种列表删除该记录
        //遍历去除index为空的记录
        var tmp_productResult = $scope.productResult.concat();
        $scope.productResult = [];
        for (var i = 0; i < tmp_productResult.length; i++) {
            if (tmp_productResult[i] != undefined) {
                $scope.productResult.push(tmp_productResult[i]);
            }
        }
    };
    $scope.productDelete = function (index) {
        var tmpArr = $scope.productResultClone[index];
        $scope.productResult.unshift(tmpArr);  //将删除的记录添加到已选品种列表
        delete $scope.productResultClone[index];
        var tmp_productResult1 = $scope.productResultClone.concat();
        //遍历去除index为空的记录
        $scope.productResultClone = [];
        for (var j = 0; j < tmp_productResult1.length; j++) {
            if (tmp_productResult1[j] != undefined) {
                $scope.productResultClone.push(tmp_productResult1[j]);
            }
        }
    };

    $scope.remove = function () {
        $scope.newUserShow = false;
        $scope.addOrgValOne='';
        $scope.riskRule='';
        $scope.createTimeStart = '';
        $scope.createTimeEnd = '';
        $scope.tradeType = '';
        $scope.tradeCondition = '';
        $scope.productResultClone = '';
    };

    //新增
    $scope.addEditText = '';
    $scope.newUserShow = false;
    $scope.addNewUser = function () {
        $scope.newUserShow = true;
        $scope.addEditText = '新增';
    };

    //修改
    $('#entrustDetailGrid').on('rowselect', function (event) {
        $scope.chooseItemTab1 = event.args.row.Key;
        $scope.chooseUserData = {
            RuleKey: event.args.row.RuleKey,
            Key: event.args.row.Key,
            orgName: event.args.row.orgName,
            orgNum: event.args.row.orgNum,
            OrgCode: event.args.row.OrgCode,
            riskRule: event.args.row.tradeName,
            StartTime: event.args.row.StartTime,
            EndTime: event.args.row.EndTime,
            Type: event.args.row.Type,
            Condition: event.args.row.Condition,
            Para1: event.args.row.Para1,
            Para2: event.args.row.Para2
        };
    });
    $scope.editUser = function () {
        if (!$scope.chooseItemTab1) {
            $rootScope.tipService.setMessage('请先选择用户', 'warning');
        } else {
            $scope.addEditText = '修改';
            $scope.newUserShow = true;
            $scope.chooseUserData.key = $scope.chooseItemTab1;
            $scope.addOrgValOne =$scope.chooseUserData.orgName+'('+$scope.chooseUserData.orgNum+')';
            $scope.riskRule = $scope.chooseUserData.RuleKey + ':' + $scope.chooseUserData.riskRule;
            $scope.createTimeStart = $scope.formatTime($scope.chooseUserData.StartTime);
            $scope.createTimeEnd = $scope.formatTime($scope.chooseUserData.EndTime);
            $scope.tradeType = $scope.getTradeRule($scope.chooseUserData.Type);
            $scope.tradeCondition = $scope.getTradeRuleCondition($scope.chooseUserData.Condition, $scope.chooseUserData.Para1, $scope.chooseUserData.Para2);
            console.log($scope.addOrgValOne)
        }
    };
    $scope.addEditUserSubmit = function () {
        var productStr = [];
        for (var i = 0; i < $scope.productResultClone.length; i++) {
            productStr.push($scope.productResultClone[i].productId)
        }
        var productArrStr = productStr.join();
        if ($scope.addEditText == '新增') {
            if ($scope.productResultClone == '') {
                $rootScope.tipService.setMessage('产品不能为空!', 'warning');
            } else {
                $scope.newUserShow = false;
                console.log(timestamp.DateToSeconds($scope.createTimeStart));
                var tradeRuleAssign = {
                    Key: '',
                    OrgCode:$scope.orgCode,
                    RuleKey: $scope.riskRule.split(':')[0],
                    StartTime:($scope.createTimeStart)?timestamp.DateToSeconds($scope.createTimeStart):'',
                    EndTime:($scope.createTimeEnd)?timestamp.DateToSeconds($scope.createTimeEnd):'',
                    ProductId: productArrStr,
                    Operator: localStorageService.get('selfInfo').loginName
                };
                var json = {
                    tradeRuleAssign: tradeRuleAssign
                };
                tradeRegulationAppointAll.riskAdd(json)
                    .then(function (res) {
                        $scope.remove();
                        $rootScope.tipService.setMessage(res.message, 'warning');
                        $scope.ManageSearch();
                        $scope.tradeRegulationAppointSearch();
                        portNum();
                    }, function (error) {
                        $rootScope.tipService.setMessage(error.message, 'warning');
                    });
            }
        } else if ($scope.addEditText == '修改') {
            if (!$scope.chooseItemTab1) {
                $rootScope.tipService.setMessage('请填写角色名', 'warning');
            } else {
                console.log($scope.createTimeStart);
                console.log($scope.createTimeEnd)
                var tradeRuleAssign = {
                    Key: $scope.chooseUserData.key,
                    OrgCode:($scope.orgCode==undefined)?$scope.chooseUserData.OrgCode:$scope.orgCode,
                    RuleKey: $scope.riskRule.split(':')[0],
                    StartTime:($scope.createTimeStart)?timestamp.DateToSeconds($scope.createTimeStart):'',
                    EndTime: ($scope.createTimeEnd)?timestamp.DateToSeconds($scope.createTimeEnd):'',
                    ProductId: productArrStr,
                    Operator: localStorageService.get('selfInfo').loginName
                };
                var json = {
                    tradeRuleAssign: tradeRuleAssign
                };
                tradeRegulationAppointAll.riskModify(json)
                    .then(function (res) {
                        $scope.remove();
                        $rootScope.tipService.setMessage(res.message, 'warning');
                        $scope.ManageSearch();
                        $scope.tradeRegulationAppointSearch();
                        portNum();
                    }, function (error) {
                        $rootScope.tipService.setMessage(error.message, 'warning');
                    });
            }
        }
    };

    //注销
    $scope.cancel = function () {
        if (!$scope.chooseItemTab1) {
            $rootScope.tipService.setMessage('请先选择用户', 'warning');
        } else {
            confirmService.set('确认提示', '确定要注销此用户?', function () {
                var json = {
                    key: $scope.chooseItemTab1
                }
                tradeRegulationAppointAll.cancel(json)
                    .then(function (res) {
                        $rootScope.tipService.setMessage(res.message, 'warning');
                        $scope.ManageSearch();
                        $scope.tradeRegulationAppointSearch();
                        portNum();
                    }, function (error) {
                        $rootScope.tipService.setMessage(error.message, 'warning');
                    });
                confirmService.clear();
            });
        }
    };
}])
// server
    .factory('tradeRegulationAppointAll', ['$q', '$http', '$rootScope', function ($q, $http, $rootScope) {
        return {
            riskFilterSearch: function (json) {
                var deferred = $q.defer();
                $http({
                    method: "POST",
                    url: $rootScope.baseUrl + "admin/trade/ruleAssign/query/filter",
                    data: json,
                    headers: {
                        'Content-Type': 'application/json;charset=UTF-8'
                    }
                }).success(function (res) {
                    deferred.resolve(res);
                }).error(function (res) {
                    deferred.reject(res);
                });
                return deferred.promise;
            },
            riskAdd: function (json) {
                var deferred = $q.defer();
                $http({
                    method: "POST",
                    url: $rootScope.baseUrl + "admin/trade/ruleAssign/insert",
                    data: json,
                    headers: {
                        'Content-Type': 'application/json;charset=UTF-8'
                    }
                }).success(function (res) {
                    deferred.resolve(res);
                }).error(function (res) {
                    deferred.reject(res);
                });
                return deferred.promise;
            },
            riskModify: function (json) {
                var deferred = $q.defer();
                $http({
                    method: "POST",
                    url: $rootScope.baseUrl + "admin/trade/ruleAssign/modify",
                    data: json,
                    headers: {
                        'Content-Type': 'application/json;charset=UTF-8'
                    }
                }).success(function (res) {
                    deferred.resolve(res);
                }).error(function (res) {
                    deferred.reject(res);
                });
                return deferred.promise;
            },
            cancel: function (json) {
                var deferred = $q.defer();
                $http({
                    method: "POST",
                    url: $rootScope.baseUrl + "admin/trade/ruleAssign/delete",
                    data: json,
                    headers: {
                        'Content-Type': 'application/json;charset=UTF-8'
                    }
                }).success(function (res) {
                    deferred.resolve(res);
                }).error(function (res) {
                    deferred.reject(res);
                });
                return deferred.promise;
            },
            riskSearch: function (json) {
                var deferred = $q.defer();
                $http({
                    method: "POST",
                    url: $rootScope.baseUrl + "admin/trade/rule/query/filter",
                    data: json,
                    headers: {
                        'Content-Type': 'application/json;charset=UTF-8'
                    }
                }).success(function (res) {
                    deferred.resolve(res);
                }).error(function (res) {
                    deferred.reject(res);
                });
                return deferred.promise;
            }
        }
    }]);