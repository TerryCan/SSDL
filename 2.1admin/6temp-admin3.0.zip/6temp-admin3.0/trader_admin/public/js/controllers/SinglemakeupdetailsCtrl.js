app.controller('SinglemakeupdetailsCtrl', ['$scope', 'SinglemakeupCtrlSel', 'getPageNum', '$state', 'localStorageService', 'SinglemakeupdetailsCtrlSel', 'EntrustType', '$rootScope', 'dataSer', 'timestamp', function ($scope, SinglemakeupCtrlSel, getPageNum, $state, localStorageService, SinglemakeupdetailsCtrlSel, EntrustType, $rootScope, dataSer, timestamp) {
    $scope.goBack = function () {
        $state.go('tabs.Singlemakeup');
    }
    //成交委托类型 0委托  1成交
    $scope.EntrustTypeList = EntrustType;

    $scope.EntrustTypeListText = function (val) {
        for (var i = 0, r = $scope.EntrustTypeList.length; i < r; i++) {
            if (val == $scope.EntrustTypeList[i].val) {
                return $scope.EntrustTypeList[i].name;
            }
        }
    }
    //全部状态下所属机构
    dataSer.organizeQuerylistSer().then(function (res) {
            $scope.meborgList = res;
            //console.log($scope.orgList)
        });

    $scope.getOrgVal = function (orgId) {
        console.log(orgId)
        if ($scope.meborgList) {
            console.log($scope.meborgList)
            for (var i = 0; i < $scope.meborgList.length; i++) {
                if (orgId == $scope.meborgList[i].orgId) {
                    return $scope.meborgList[i].text;
                }
            }
        }
    };
    //选择
    $scope.entrustDealTab = function () {
        if ($scope.calcType == 1) {
            $scope.collectionDealGrid=true;
            $scope.entrustDetailGrid=false;
            $scope.searchAjaxDeal();
        } else if ($scope.calcType == 0) {
            $scope.collectionDealGrid=false;
            $scope.entrustDetailGrid=true;
            $scope.searchAjaxEntrust();
        }
    };
    //委托
    $scope.calcType = 0;
    $scope.featureShow=false;
    var processContent,processTotal;
    var source = {
        type: 'POST',
        datatype: "json",
        datafields: [  //数据字段定义
            {name: 'recoverOrderId', type: 'string'},
            {name: 'userName', type: 'string'},
            {name: 'orgNum', type: 'string'},
            {name: 'productName', type: 'string'},
            {name: 'productCode', type: 'string'},
            {name: 'orderDirect', type: 'string'},

            {name: 'orderVolume', type: 'string'},
            {name: 'orderPrice', type: 'string'},
            {name: 'orderType', type: 'string'},
            {name: 'errorMessage', type: 'string'},
            {name: 'limitTime', type: 'string'}
        ],
        url: $rootScope.baseUrl + 'admin/trade/recover/query/order/as/page',
        root: "content",
        pagesize:10,
        processData: function (data) {
            data.page = (data.pagenum + 1)?(data.pagenum + 1):1;
            data.rows =(data.pagesize)?(data.pagesize):10;
            data.order =($scope.order)?$scope.order:'desc';
            data.sort =($scope.sort)?$scope.sort:'limitTime';
            data.search_A_EQ_recoverId =localStorageService.get('REchooseNoticeId');
        }, //传递参数处理
        beforeLoadComplete: function (records) { //数据完全加载完执行绘制表格
            var start;
            for (var i in records) {
                start = parseInt(i);
                break;
            }
            for (var k = 0, r = processContent.length; k < r; k++) {
                records[start + k].recoverOrderId = processContent[k].recoverOrderId;
                records[start + k].userName = processContent[k].userName;
                records[start + k].orgNum = processContent[k].orgNum;
                records[start + k].productName = processContent[k].productName;
                records[start + k].productCode = processContent[k].productCode;
                records[start + k].orderDirect = processContent[k].orderDirect;
                records[start + k].orderVolume = processContent[k].orderVolume;

                records[start + k].orderPrice = processContent[k].orderPrice;
                records[start + k].orderType = processContent[k].orderType;
                records[start + k].errorMessage = processContent[k].errorMessage;
                records[start + k].limitTime = processContent[k].limitTime;
            }
        },
        beforeprocessing: function (data) { //处理总页数
            var processData = JSON.parse(data.content);
            console.log(processData)
            processContent = processData.content;
            source.totalrecords = processData.totalElements == 0 ? 5 : processData.totalElements;
            processTotal = processData.totalElements;
        },
        loadComplete: function (records) {
            $scope.saveResult=JSON.parse(records.content);
            var data =  $scope.saveResult.totalElements;
            if (data == 0) {
                $('#contenttableentrustDetailGrid > div').remove();
            }
        },
        endUpdate: true
    };
    //创建数据适配器
    var dataAdapter = null;
    $scope.searchAjaxEntrust = function () {
        $scope.featureShow=true;
        $scope.collectionDealGrid=false;
        $scope.entrustDetailGrid=true;
        if (dataAdapter == null) {
            dataAdapter = new $.jqx.dataAdapter(source);
            //创建表格
            $("#entrustDetailGrid").jqxGrid({
                source: dataAdapter,
                columns: [  //表格数据域
                    {
                        text: '用户名',
                        datafield: 'userName',
                        width: '10%',
                        minwidth: 10 + '%',//设置列min宽
                        align: 'center'//设置表头
                    },
                    {
                        text: '机构编号',
                        datafield: 'orgNum',
                        minwidth: 10 + '%',
                        cellsalign: 'center',
                        align: 'center',
                        width: '10%'
                    },
                    {
                        text: '商品名',
                        datafield: 'productName',
                        width:'10%',
                        minwidth: 10 + '%',
                        align: 'center'
                    },
                    {
                        text: '商品代码',
                        datafield: 'productCode',
                        width:'10%',
                        minwidth: 10 + '%',
                        align: 'center'
                    },
                    {
                        text: '买卖方向',
                        datafield: 'orderDirect',
                        width:'10%',
                        minwidth: 10 + '%',
                        align: 'center'
                    },
                    {
                        text: '委托数量',
                        datafield: 'orderVolume',
                        width:'10%',
                        minwidth: 10 + '%',
                        align: 'center'
                    },
                    {
                        text: '委托价格',
                        datafield: 'orderPrice',
                        width:'10%',
                        minwidth: 10 + '%',
                        align: 'center'
                    },
                    {
                        text: '委托类型',
                        datafield: 'orderType',
                        width:'10%',
                        minwidth: 10 + '%',
                        align: 'center'
                    },
                    {
                        text: '错误原因',
                        datafield: 'errorMessage',
                        width:'10%',
                        minwidth: 10 + '%',
                        align: 'center'
                    },
                    {
                        text: '下单时间',
                        datafield: 'limitTime',
                        width:'10%',
                        minwidth: 10 + '%',
                        align: 'center',
                        cellsrenderer: function (row, columnfield, value, defaulthtml, columnproperties) {
                            return timestamp.timestampCoverHms(value, 'all');
                        }
                    }
                ],
                width: 100 + '%',
                height: 81 + '%',
                theme:'metrodark',
                virtualmode: true,
                rendergridrows: function (params) { //将数据渲染到页面
                    return params.data;
                },
                pageable: true,
                pagesizeoptions: ['10','30','100','200'],
                sortable: true,
                columnsresize: true,//列间距是否可调整
                // selectionmode: 'singlecell',//选择模式
                clipboard: true,
                // selectionmode: 'checkbox',//复选框
            });
        }else {
            $("#entrustDetailGrid").jqxGrid('updatebounddata', 'cells');
        }
    };

    $("#entrustDetailGrid").on("pagechanged", function (event) {
        console.log(event)
    });

    $("#entrustDetailGrid").on("sort", function (event) {
        var sortinformation = event.args.sortinformation;
        $scope.sort=sortinformation.sortcolumn;
        $scope.order=($scope.sort)?(sortinformation.sortdirection.ascending)?'asc':'desc':'asc';
        data={
            order:$scope.order,
            sort:$scope.sort
        };
        source.processData(data);
        $("#entrustDetailGrid").jqxGrid('updatebounddata', 'sort');
    });

    $('#entrustDetailGrid').on('rowselect', function (event) {
        console.log(event)
        $scope.chooseNoticeId = event.args.row.recoverOrderId;
        console.log($scope.chooseNoticeId)
    });

//**********************************************************//
    //成交
    var processContentDeal,processTotalDeal;
    var sourceDeal = {
        type: 'POST',
        datatype: "json",
        datafields: [  //数据字段定义
            {name: 'recoverMatchId', type: 'string'},
            {name: 'clientNo', type: 'string'},
            {name: 'marketNo', type: 'string'},
            {name: 'contractNo', type: 'string'},
            {name: 'orderDirect', type: 'string'},

            {name: 'matchVolume', type: 'string'},
            {name: 'matchPrice', type: 'string'},
            {name: 'matchFee', type: 'string'},
            {name: 'matchNo', type: 'string'},
            {name: 'errorMessage', type: 'string'},
            {name: 'matchTime', type: 'string'}
        ],
        url: $rootScope.baseUrl + 'admin/trade/recover/query/match/as/page',
        root: "content",
        pagesize:10,
        processData: function (data) {
            data.page = (data.pagenum + 1)?(data.pagenum + 1):1;
            data.rows =(data.pagesize)?(data.pagesize):10;
            data.order =($scope.order)?$scope.order:'desc';
            // data.sort =($scope.sort)?$scope.sort:'limitTime';
            data.search_A_EQ_recoverId =localStorageService.get('REchooseNoticeId');
        }, //传递参数处理
        beforeLoadComplete: function (records) { //数据完全加载完执行绘制表格
            var start;
            for (var i in records) {
                start = parseInt(i);
                break;
            }
            for (var k = 0, r = processContentDeal.length; k < r; k++) {
                records[start + k].recoverMatchId = processContentDeal[k].recoverMatchId;
                records[start + k].clientNo = processContentDeal[k].clientNo;
                records[start + k].marketNo = processContentDeal[k].marketNo;
                records[start + k].contractNo = processContentDeal[k].contractNo;
                records[start + k].orderDirect = processContentDeal[k].orderDirect;
                records[start + k].matchVolume = processContentDeal[k].matchVolume;
                records[start + k].matchPrice = processContentDeal[k].matchPrice;

                records[start + k].matchFee = processContentDeal[k].matchFee;
                records[start + k].matchNo = processContentDeal[k].matchNo;
                records[start + k].errorMessage = processContentDeal[k].errorMessage;
                records[start + k].matchTime = processContentDeal[k].matchTime;
            }
        },
        beforeprocessing: function (data) { //处理总页数
            var processData = JSON.parse(data.content);
            console.log(processData)
            processContentDeal = processData.content;
            sourceDeal.totalrecords = processData.totalElements == 0 ? 5 : processData.totalElements;
            processTotalDeal = processData.totalElements;
        },
        loadComplete: function (records){
            $scope.saveResult=JSON.parse(records.content);
            var data =  $scope.saveResult.totalElements;
            if (data == 0) {
                $('#collectionDealGrid > div').remove();
            }
        },
        endUpdate: true
    };

    var dataAdapterDeal = null;
    $scope.searchAjaxDeal = function () {
        $scope.featureShow=true;
        $scope.collectionDealGrid=true;
        $scope.entrustDetailGrid=false;
        if (dataAdapterDeal == null) {
            dataAdapterDeal = new $.jqx.dataAdapter(sourceDeal);
            $("#collectionDealGrid").jqxGrid({
                source: dataAdapterDeal,
                columns: [  //表格数据域
                    {
                        text: '客户账号',
                        datafield: 'clientNo',
                        width: '10%',
                        minwidth: 10 + '%',//设置列min宽
                        align: 'center'//设置表头
                    },
                    {
                        text: '市场编号',
                        datafield: 'marketNo',
                        minwidth: 10 + '%',
                        cellsalign: 'center',
                        align: 'center',
                        width: '10%'
                    },
                    {
                        text: '合约编号',
                        datafield: 'contractNo',
                        width:'10%',
                        minwidth: 10 + '%',
                        align: 'center'
                    },
                    {
                        text: '买卖方向',
                        datafield: 'orderDirect',
                        width:'8%',
                        minwidth: 8 + '%',
                        align: 'center'
                    },
                    {
                        text: '成交数量',
                        datafield: 'matchVolume',
                        width:'8%',
                        minwidth: 8 + '%',
                        align: 'center'
                    },
                    {
                        text: '成交价格',
                        datafield: 'matchPrice',
                        width:'10%',
                        minwidth: 10 + '%',
                        align: 'center'
                    },
                    {
                        text: '手续费',
                        datafield: 'matchFee',
                        width:'8%',
                        minwidth: 8 + '%',
                        align: 'center'
                    },
                    {
                        text: '成交编号',
                        datafield: 'matchNo',
                        width:'10%',
                        minwidth: 10 + '%',
                        align: 'center'
                    },
                    {
                        text: '错误原因',
                        datafield: 'errorMessage',
                        width:'10%',
                        minwidth: 10 + '%',
                        align: 'center'
                    },
                    {
                        text: '成交时间',
                        datafield: 'matchTime',
                        width:'16%',
                        minwidth: 16 + '%',
                        align: 'center',
                        cellsrenderer: function (row, columnfield, value, defaulthtml, columnproperties) {
                            return timestamp.timestampCoverHms(value, 'all');
                        }
                    }
                ],
                width: 100 + '%',
                height: 81 + '%',
                theme:'metrodark',
                virtualmode: true,
                rendergridrows: function (params) { //将数据渲染到页面
                    return params.data;
                },
                pageable: true,
                pagesizeoptions: ['10','30','100','200'],
                sortable: true,
                columnsresize: true,//列间距是否可调整
                // selectionmode: 'singlecell',//选择模式
                clipboard: true,
                // selectionmode: 'checkbox',//复选框
            });
        }else {
            $("#collectionDealGrid").jqxGrid('updatebounddata', 'cells');
        }
    };

    $("#collectionDealGrid").on("pagechanged", function (event) {
        console.log(event)
    });

    $("#collectionDealGrid").on("sort", function (event) {
        var sortinformation = event.args.sortinformation;
        $scope.sort=sortinformation.sortcolumn;
        $scope.order=($scope.sort)?(sortinformation.sortdirection.ascending)?'asc':'desc':'asc';
        data={
            order:$scope.order,
            sort:$scope.sort
        };
        source.processData(data);
        $("#entrustDetailGrid").jqxGrid('updatebounddata', 'sort');
    });

    $('#collectionDealGrid').on('rowselect', function (event) {
        $scope.chooseNoticeId = event.args.row.recoverMatchId;
        console.log($scope.chooseNoticeId)
    });

    //新增
    $scope.addShow = function () {
        if ($scope.calcType == 0) {
            $state.go('tabs.SinglemakeupEntrust');
        } else if ($scope.calcType == 1) {
            $state.go('tabs.SinglemakeupDeal');
        }
    };
    //修改
    $scope.editShow = function () {
        if ($scope.chooseNoticeId == null) {
            $rootScope.tipService.setMessage('请先选择补录单信息', 'warning');
        } else if ($scope.calcType == 1) {
            localStorageService.update('EDNoticeId', $scope.chooseNoticeId);
            $state.go('tabs.SinglemakeupDealEdit');
        } else {
            localStorageService.update('EDNoticeId', $scope.chooseNoticeId);
            $state.go('tabs.SinglemakeupEntrustEdit');
        }
    };

}])
    .factory('SinglemakeupdetailsCtrlSel', ['$http', 'localStorageService', 'myHttp', '$q', '$rootScope', function ($http, localStorageService, myHttp, $q, $rootScope) {
        return {
            //委托修改
            getNTInfo: function(chooseNoticeId) {
                var json = {
                    recoverOrderId: chooseNoticeId
                }
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'admin/trade/recover/get/order',
                    data: json
                }).then(function successCallback(response) {
                    console.log(response)
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
            //成交修改
            getCJNTInfo: function(chooseNoticeId) {
                var json = {
                    recoverMatchId: chooseNoticeId
                }
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'admin/trade/recover/get/match',
                    data: json
                }).then(function successCallback(response) {
                    console.log(response)
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            }
        }
    }]);