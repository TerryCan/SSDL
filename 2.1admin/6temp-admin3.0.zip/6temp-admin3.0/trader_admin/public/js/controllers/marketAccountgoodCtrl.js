app.controller("marketAccountgoodCtrl", ['$rootScope', '$timeout', '$q', '$http', 'myHttp', '$scope', 'tipService', 'marketAccountgoodCtrlSel', 'marketSourceManageCtrlSer', 'marketSourceProductManageCtrlSer', 'confirmService', 'getPageNum', function($rootScope, $timeout, $q, $http, myHttp, $scope, tipService, marketAccountgoodCtrlSel, marketSourceManageCtrlSer, marketSourceProductManageCtrlSer, confirmService, getPageNum) {
		// 分页
		var pageJump = function(tmpArrList) {
			$timeout(function() {
				if (tmpArrList != undefined) {
					console.log(tmpArrList);
					$scope.currentPage = 1; //当前页数
					$scope.dataNum = tmpArrList.length;
					$scope.showDataChoose = getPageNum.pageNum(); //获取分页
					$scope.showNum = $scope.showDataChoose[0]; //初始显示刷具条数
					$scope.showPage = false;
					$timeout(function() {
						$scope.showPage = true;
						$scope.copyDataArray = tmpArrList.slice(0, 14); //初始15条数据
					}, 10)
					$scope.dataPage = Math.ceil($scope.dataNum / $scope.showNum.showNum);

					//上下页
					$scope.pageSlect = function(type) {
							if (type == 'prev') {
								if ($scope.currentPage != 1) {
									$scope.currentPage--;
									$scope.turnPage();
								} else {
									$scope.copyDataArray = tmpArrList.slice(0, 14); //初始15条数据
								}
							} else {
								if ($scope.currentPage < $scope.dataPage) {
									$scope.currentPage++;
									$scope.turnPage();
								}
							}
						}
						//每页数据量
					$scope.baseDataArray = [];
					$scope.copyDataArray = [];
					$scope.pageSelect = function(params) {
						$scope.showNum.showNum = params.showNum;
						$scope.copyDataArray = tmpArrList.slice(0, (params.showNum - 1));
						$scope.dataPage = Math.ceil($scope.dataNum / $scope.showNum.showNum);
						$scope.currentPage = 1;
					}
					$scope.turnPage = function() {
							$scope.copyDataArray = tmpArrList.slice((($scope.currentPage - 1) * 15), (($scope.currentPage + 1) * 15 - 1));
						}
						//固定页面跳转
					$scope.jumpPage = function(num) {
						num = parseInt(num);
						if (parseInt(num, 10) === num && num <= ($scope.dataPage + 1) && num > 0) {
							$scope.currentPage = num;
							$scope.jumpPageNum = '';
							$scope.turnPage();
						} else {
							$scope.copyDataArray = tmpArrList.slice(0, 14); //初始15条数据
						}
					}
				} else {
					pageJump(tmpArrList);
				}
			}, 200);
		};
		console.log(1233)
		$scope.key = "";
		$scope.account = "";
		$scope.symbol = "";
		$scope.name = "";
		$scope.enable = true;
		$scope.isMaster = true;
		$scope.timeout = "";
		$scope.tableshow = false;


		//行情源账号管理
		marketSourceManageCtrlSer.search()
			.then(function(res) {
				$scope.searchResult = res.list;
				//console.log(res)
			});
		$scope.marketaccount = function(account) {
			for (var i = 0, r = $scope.searchResult.length; i < r; i++) {
				if ($scope.searchResult[i].key == account) {
					return $scope.searchResult[i].name;
				}
			}
		}

		marketSourceProductManageCtrlSer.search()
			.then(function(res) {
				$scope.ProductManagelist = res.list;
				//console.log(res)
			});
		$scope.marketsymbol = function(symbol) {
				for (var i = 0, r = $scope.ProductManagelist.length; i < r; i++) {
					if ($scope.ProductManagelist[i].key == symbol) {
						return $scope.ProductManagelist[i].exchange + '-' + $scope.ProductManagelist[i].commodity + '-' + $scope.ProductManagelist[i].contract;
					}
				}
			}
			//查询全部
		$scope.search = function() {
			marketAccountgoodCtrlSel.search()
				.then(function(res) {
					console.log(res)
					if(res.retMsg.code == "000000") {
					$scope.searchalllist = res.list;
					pageJump($scope.searchalllist);
					$scope.alllist = true;
					$scope.searchkey = false;
					//console.log(res)
					} else {
							$rootScope.tipService.setMessage(res.retMsg.message, 'warning');
						}
					}, function(error) {
						$rootScope.tipService.setMessage(error.message, 'warning');
					})
		}

		//点击查询
		$scope.searchFilter = function() {
			if ($scope.account == "") {
				$scope.search();
			} else {

				marketAccountgoodCtrlSel.searchFilter($scope.account)
					.then(function(res) {
							console.log(res)
						if (res.data.code == "000000") {
							$scope.alllist = false;
							$scope.searchkey = true;
							$scope.searchkeylist = res.data.list;
							//console.log($scope.searchkeylist)
							$rootScope.tipService.setMessage(res.data.message, 'warning');
						} else {
							$rootScope.tipService.setMessage(res.data.message, 'warning');
						}
					}, function(error) {
						$rootScope.tipService.setMessage(error.data.message, 'warning');
					})
			}
		}

		$scope.addShow = function() {
			$scope.tableshow = true;
			$scope.addEditText = "添加"
		}
		$scope.editShow = function() {
			if (!$scope.chooseItemTab1) {
				$rootScope.tipService.setMessage('请先选择编号', 'warning');
			} else {
				$scope.addEditText = '修改';
				$scope.tableshow = true;
			}
		}
		$scope.addSubmit = function() {

				if ($scope.addEditText == '添加') {
					if ($scope.name == '') {
						$rootScope.tipService.setMessage('请先输入名称', 'warning');
					} else {

						var sQuoteAccountSymbol = {
							key: $scope.key,
							account: $scope.account,
							symbol: $scope.symbol,
							name: $scope.name,
							enable: $scope.enable,
							isMaster: $scope.isMaster,
							timeout: $scope.timeout
						}
						var json = {
							sQuoteAccountSymbol: sQuoteAccountSymbol
						}
						if (toValidate('#marketAccount')) {
							marketAccountgoodCtrlSel.add(json)
								.then(function(res) {
									console.log(res)
									if (res.data.code = "000000") {
										$scope.tableshow = false;
										$rootScope.tipService.setMessage(res.data.message, 'warning');
										$scope.search();
									} else {
										$rootScope.tipService.setMessage(res.data.message, 'warning');
									}
								}, function(error) {
									$rootScope.tipService.setMessage(error.data.message, 'warning');
								})
						}
					}
				} else if ($scope.addEditText == '修改') {
					if ($scope.name == '') {
						$rootScope.tipService.setMessage('请填写修改名称', 'warning');
					} else {
						var sQuoteAccountSymbol = {
							key: $scope.key,
							account: $scope.account,
							symbol: $scope.symbol,
							name: $scope.name,
							enable: $scope.enable,
							isMaster: $scope.isMaster,
							timeout: $scope.timeout
						}
						var json = {
							key: $scope.key,
							sQuoteAccountSymbol: sQuoteAccountSymbol
						}
						if (toValidate('#marketAccount')) {
							marketAccountgoodCtrlSel.edit(json)
								.then(function(res) {
									console.log(res)
									if (res.data.code = "000000") {
										$scope.tableshow = false;
										$rootScope.tipService.setMessage(res.data.message, 'warning');
										$scope.search();
									} else {
										$rootScope.tipService.setMessage(res.data.message, 'warning');
									}
								}, function(error) {
									$rootScope.tipService.setMessage(error.data.message, 'warning');
								})
						}
					}
				}
			}
			//单选
		$scope.checked = function(index, key) {
			$scope.chooseItemTab1 = key;
			$scope.key = $scope.searchalllist[index].key;
			$scope.account = $scope.searchalllist[index].account;
			$scope.symbol = $scope.searchalllist[index].symbol;
			$scope.name = $scope.searchalllist[index].name;
			$scope.enable = $scope.searchalllist[index].enable;
			$scope.isMaster = $scope.searchalllist[index].isMaster;
			$scope.timeout = $scope.searchalllist[index].timeout;
			$('#dataReport input[type=checkbox]').prop('checked', false);
			$('#dataReport input[type=checkbox]').eq(index).prop('checked', true);
			console.log($scope.key)
		}

		//删除
		$scope.removeShow = function() {
			if (!$scope.chooseItemTab1) {
				$rootScope.tipService.setMessage('请先选择账户', 'warning');
			} else {
				confirmService.set('确认提示', '确定要删除此账户?', function() {
					marketAccountgoodCtrlSel.delete($scope.chooseItemTab1)
						.then(function(res) {
							$rootScope.tipService.setMessage(res.data.message, 'warning');
							$scope.search();
						}, function(error) {
							$rootScope.tipService.setMessage(error.data.message, 'warning');
						});
					confirmService.clear();
				})
			}
		}
	}])
	.factory('marketAccountgoodCtrlSel', ['$http', 'dataFilter', 'localStorageService', 'myHttp', '$q', '$rootScope', function($http, dataFilter, localStorageService, myHttp, $q, $rootScope) {
		return {
			search: function() {
				var deferred = $q.defer();
				myHttp.post("c/quote/account/symbol/query/all")
					.then(function(res) { // 调用承诺API获取数据 .resolve
						deferred.resolve(res);
					}, function(res) { // 处理错误 .reject
						deferred.reject(res);
					});
				return deferred.promise;
			},

			searchFilter: function(account) {
				var deferred = $q.defer();
				$http({
					method: 'POST',
					url: $rootScope.baseUrl + 'c/quote/account/symbol/query/by/account',
					data: {
						account: account
					}
				}).then(function successCallback(res) {
					deferred.resolve(res);
				}, function errorCallback(res) {
					deferred.reject(res);
				});
				return deferred.promise;
			},
			add: function(json) {
				var deferred = $q.defer();
				$http({
					method: 'POST',
					url: $rootScope.baseUrl + 'c/quote/account/symbol/insert',
					data: json
				}).then(function successCallback(res) {
					deferred.resolve(res);
				}, function errorCallback(res) {
					deferred.reject(res);
				});
				return deferred.promise;
			},
			edit: function(json) {
				var deferred = $q.defer();
				$http({
					method: 'POST',
					url: $rootScope.baseUrl + 'c/quote/account/symbol/modify/full',
					data: json
				}).then(function successCallback(res) {
					deferred.resolve(res);
				}, function errorCallback(res) {
					deferred.reject(response);
				});
				return deferred.promise;
			},
			delete: function(key) {
				var deferred = $q.defer();
				$http({
					method: 'POST',
					url: $rootScope.baseUrl + 'c/quote/account/symbol/delete',
					data: {
						key: key
					}
				}).then(function successCallback(res) {
					deferred.resolve(res);
				}, function errorCallback(res) {
					deferred.reject(res);
				});
				return deferred.promise;
			}
		}

	}])