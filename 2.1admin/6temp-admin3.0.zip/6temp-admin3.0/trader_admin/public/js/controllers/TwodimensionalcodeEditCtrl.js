app.controller('TwodimensionalcodeEditCtrl', ['$scope', 'dataSer','$state', '$rootScope','TwodimensionalcodeEditCtrlSel','getPageNum','TwodimensionalcodequeryCtrlSel','localStorageService', function($scope, dataSer, $state, $rootScope,TwodimensionalcodeEditCtrlSel,getPageNum,TwodimensionalcodequeryCtrlSel,localStorageService) {
         $scope.goBack = function() {
                $state.go('tabs.Twodimensionalcodequery');
            }
        dataSer.organizeQuerySer()
            .then(function(res) {
                console.log(res)
                $scope.orgList = res;
                //console.log($scope.orgList)
            });
            $scope.addOrgValFTC = function(d) {
                //console.log(data);
                $scope.orgId = d.orgId;
                $scope.orgCode = d.orgCode;
                $scope.addOrgVal = d.text;
            }
            var chooseProId = localStorageService.get('chooseTwochooseProId');
                console.log(chooseProId)
                TwodimensionalcodequeryCtrlSel.getTwooInfo(chooseProId)
                    .then(function(res) {
                        console.log(res)
                        if (res.data.code == '000000') {
                            var dataVal = JSON.parse(res.data.content);
                            console.log(dataVal);
                            $scope.backcolor=dataVal.backcolor;
                            $scope.createTime=dataVal.createTime;
                            $scope.failover=dataVal.failover;
                            $scope.forecolor=dataVal.forecolor;
                            $scope.format=dataVal.format;
                            $scope.height=dataVal.height;
                            $scope.logoHeight=dataVal.logoHeight;
                            $scope.logoWidth=dataVal.logoWidth;
                            $scope.orgCode=dataVal.orgCode;
                            $scope.orgId=dataVal.orgId;
                            $scope.TwoorgLogoFileIdImg2=dataVal.orgLogoFileId;
                            $scope.orgQrcodeId=dataVal.orgQrcodeId;
                            $scope.orgQrcodeId=dataVal.orgQrcodeId;
                            $scope.title=dataVal.title;
                            $scope.qrcodeBase64=dataVal.qrcodeBase64;
                            $scope.remark=dataVal.remark;
                            $scope.width=dataVal.width;
                            $scope.size=$scope.width;
                            $scope.popularizeUrl=dataVal.popularizeUrl;
                            $('#Twouploadfile2').attr('src',""+$rootScope.baseUrl+"/file/download?fileId="+$scope.TwoorgLogoFileIdImg2+"");

                        }
                    });
                    //匹配机构代码
            var json = {
                page: 1,
                rows: 9999,
                search_A_EQ_state: 1
            };
            dataSer.getOrganize(json).then(function (res) {
                if (res.code == '000000') {
                    $scope.equalOrgCode = JSON.parse(res.content).content;
                    console.log($scope.equalOrgCode);
                    for (var i = 0; i < $scope.equalOrgCode.length; i++) {
                        if ($scope.orgId== $scope.equalOrgCode[i].orgId) {
                            $scope.addOrgVal =$scope.equalOrgCode[i].orgName+'('+$scope.equalOrgCode[i].orgNum+')';
                            console.log($scope.addOrgVal)
                        }
                    }
                } else {
                    console.log(res);
                }
            });

            $scope.addInfo=function(){
                if ($scope.popularizeUrl == undefined || $scope.popularizeUrl == '') {
                    $rootScope.tipService.setMessage('请选择推广链接', 'warning');
                } else if ($scope.failover == undefined || $scope.failover == '') {
                    $rootScope.tipService.setMessage('请选择容错', 'warning');
                } else if ($scope.size == undefined || $scope.size == '') {
                    $rootScope.tipService.setMessage('请选择图片大小', 'warning');
                } else if ($scope.format == undefined || $scope.format == '') {
                    $rootScope.tipService.setMessage('请选择二维码格式', 'warning');
                }else{
                var supportOrgQrcodeVIce = {
                    orgQrcodeId: $scope.orgQrcodeId,
                    title:$scope.title,
                    orgId: $scope.orgId,
                    orgCode: $scope.orgCode,
                    popularizeUrl: $scope.popularizeUrl,
                    orgLogoFileId: $scope.TwoorgLogoFileIdImg2,
                    failover: $scope.failover,
                    forecolor: $scope.forecolor,
                    backcolor:$scope.backcolor,
                    width:$scope.size,
                    height:$scope.size,
                    format:$scope.format,
                    remark:$scope.remark,
                }
                var json={
                    supportOrgQrcodeVIce:supportOrgQrcodeVIce
                }
                TwodimensionalcodeEditCtrlSel.Edit(json)
                .then(function(res){
                    if (res.data.code == '000000') {
                            $rootScope.tipService.setMessage(res.data.message, 'warning');
                            $state.go('tabs.Twodimensionalcodequery');
                        } else {
                            $rootScope.tipService.setMessage(res.data.message, 'warning');
                        }
                })
                }
            }
                   //图片上传
        uploadImg = function(id, num) {
            console.log(id,num);
            var urlUpload = $rootScope.baseUrl + 'file/upload';
            upload_img(urlUpload, id, function(res, status) {
                if (res.code === '000000') {
                    var data = JSON.parse(res.content);
                    console.log(data);
                    var ImgId = data[0].fileId;
                    console.log(ImgId)
                    switch (num) {
                        case 1:
                            $scope.TwoorgLogoFileIdImg2 = ImgId;
                            console.log($scope.TwoorgLogoFileIdImg2)
                            $('#Twouploadfile2').attr('src', "" + $rootScope.baseUrl + "/file/download?fileId=" + ImgId + "");
                            break;
                    }
                }
            });
        };

        // 上传图片
        // url:后台访问路径 fileId:input file按钮id, btn:点击的按钮id, fileInput:接收上传图片的id
        function upload_img(url, fileId, callback) {
            $.ajaxFileUpload({
                url: url,
                type: 'post',
                secureuri: false,
                fileElementId: fileId, // file标签的id
                dataType: 'json', // 返回数据的类型
                data: {
                    name: fileId
                },
                success: function(data, status) {
                    callback(data, status);
                },
                error: function(data, status, e) {
                    console.log(data, status, e);
                }
            });
        }
     $('.example img').zoomify();
}])
.factory('TwodimensionalcodeEditCtrlSel', ['$http', 'localStorageService', 'myHttp', '$q', '$rootScope', function($http, localStorageService, myHttp, $q, $rootScope) {
	return {
		Edit: function(json) {
			var deferred = $q.defer();
			$http({
					method: 'POST',
					url: $rootScope.baseUrl + 'customize/org/qrcode/save',
					data: json
				})
				.then(function(res) { // 调用承诺API获取数据 .resolve
					deferred.resolve(res);
				}, function(res) { // 处理错误 .reject
					deferred.reject(res);
				});
			return deferred.promise;
		}
	}
}])