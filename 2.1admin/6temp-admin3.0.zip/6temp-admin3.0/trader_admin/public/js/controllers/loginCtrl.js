var loginPage = angular.module("login_page", ["Encrypt"])
    .controller('loginCtrl', function ($scope, $http, $location, $state, loginCtrlDataSer, $rootScope, localStorageService, Md5, Base64, Sha1, $timeout, PersonalizedOrganizationCtrlSer) {
        $scope.readRisk = true;
        $scope.hasClickSavePassword = false;
        $scope.topErrorMsg = "";
        $scope.showErrorMsg = false;
        $scope.submitted = false;
        var timeClear = null;

        $scope.changeLine = function () {
            localStorageService.update("baseUrl", $scope.line);
            $rootScope.baseUrl = $scope.line;
            localStorageService.update('saveLine',$scope.line);
        };
        //表单提交
        $scope.submit_form = function (form) {
            if (!$scope.readRisk) {
                $scope.errorMsgDisplay("请先阅读风险提示");
            }
            //验证
            $scope.submitted = true;
            $timeout(function () {
                $scope.submitted = false;
            }, 3000);
            if (form.$valid && $scope.readRisk) {
                loginCtrlDataSer.login($scope.username, $scope.password, $scope.loginOrgCode)
                    .then(function (res) {
                        if (res.code === '000000') {
                            var userInfo = {
                                email: res.user.email,
                                loginName: res.user.loginName,
                                orgCode: res.user.orgCode,
                                orgId: res.user.orgId,
                                phone: res.user.phone,
                                state: res.user.userState,
                                userId: res.user.userId,
                                roleType: res.user.roleType
                            };
                            //清除缓存
                            sessionStorage.removeItem('nav');
                            localStorageService.update("userInfo", userInfo);
                            if (res.user.userState == -1) {
                                $rootScope.tipService.setMessage('该用户是注销状态不能正常登陆!', 'warning');
                            } else if (res.user.userState == -2) {
                                $rootScope.tipService.setMessage('该用户是开户待审核状态不能正常登陆!', 'warning');
                            } else if (res.user.userState == -3) {
                                $rootScope.tipService.setMessage('该用户是开户驳回状态不能正常登陆!', 'warning');
                            } else {
                                if ($scope.hasClickSavePassword) {
                                    localStorageService.update('j_username', $scope.username);
                                    localStorageService.update('j_password', Base64.encode($scope.password));
                                    localStorageService.update('j_orgcode', $scope.loginOrgCode);
                                } else {
                                    localStorageService.update('j_username', null);
                                    localStorageService.update('j_password', null);
                                    localStorageService.update('j_orgcode', null);
                                }
                                loginCtrlDataSer.getAuthorised() //获取用户权限
                                    .then(function (res) {
                                        if (res.code == '000000') {
                                            if (res.content) {
                                                var data = JSON.parse(res.content);
                                                var tmp_arr = [];
                                                for (var i = 0, r = data.length; i < r; i++) {
                                                    tmp_arr.push(data[i].permissionCode);
                                                }
                                                sessionStorage.setItem('nav', tmp_arr);
                                                sessionStorage.setItem('isLogin', true);
                                                $rootScope.checkLogin(true);
                                            } else {
                                                $rootScope.tipService.setMessage('请求信息为空!', 'warning');
                                            }
                                        }
                                    });
                                return;
                            }
                        } else {
                            $scope.changeState("login");
                        }
                        $scope.errorMsgDisplay(res.message);
                    }, function (res) {
                        if (res.message) {
                            $scope.errorMsgDisplay(res.message);
                        } else {
                            $scope.errorMsgDisplay(res.message);
                        }
                    });
            }
        };
        $scope.errorMsgDisplay = function (text) {
            clearTimeout(timeClear);
            $scope.showErrorMsg = true;
            $scope.topErrorMsg = text;
            timeClear = setTimeout(function () {
                $scope.$apply(function () {
                    $scope.showErrorMsg = false;
                });
            }, 3000);
        };
        $scope.$on('$viewContentLoaded', function () {
            if (localStorageService.get("line") !== null && localStorageService.get("line") !== undefined) {
                $scope.lineData = localStorageService.get("line");
                $scope.line = $scope.lineData[0].value;
                $rootScope.baseUrl = $scope.line;
            }
            if (localStorageService.get('j_password') !== null && localStorageService.get("j_password") !== undefined) {
                $scope.password = Base64.decode(localStorageService.get('j_password'));
                $scope.hasClickSavePassword = true;
            }
            if (localStorageService.get('j_username') !== null && localStorageService.get("j_username") !== undefined) {
                $scope.username = localStorageService.get('j_username');
            }
            if (localStorageService.get('j_orgcode') !== null && localStorageService.get("j_orgcode") !== undefined) {
                $scope.loginOrgCode = localStorageService.get('j_orgcode');
            }
        });
        //页面跳转
        $scope.trunPage = function (url) {
            $state.go(url);
        };
    });