app.controller('riskRegulationCtrl', ['$timeout', '$scope', '$rootScope', 'riskRegulationAll', 'getFormularRiskType', 'getRiskCtrlConditionType', 'getRiskActionType', 'confirmService', 'tipService', 'localStorageService', 'getPageNum', 'getRiskActionTypeOne', function ($timeout, $scope, $rootScope, riskRegulationAll, getFormularRiskType, getRiskCtrlConditionType, getRiskActionType, confirmService, tipService, localStorageService, getPageNum, getRiskActionTypeOne) {
    $scope.toggleTraderSearchState = false;
    $scope.Toggle = function () {
        $scope.toggleTraderSearchState = !$scope.toggleTraderSearchState;
        if ($scope.toggleTraderSearchState) {
            $('.search_column').css('height', 'auto');
        }
        else {
            $('.search_column').css('height', '36px');
        }
    };
    //公式类型
    $scope.FormularRiskType = getFormularRiskType;
    $scope.getFormular = function (parameter) {
        for (i = 0; i < $scope.FormularRiskType.length; i++) {
            if (parameter == $scope.FormularRiskType[i].id) {
                return $scope.FormularRiskType[i].name;
            }
        }
    };
    //公式条件
    $scope.RiskCtrlConditionType = getRiskCtrlConditionType;
    $scope.getCondition = function (Condition, Para1, Para2) {
        switch (Condition) {
            case 0:
                return 'x>' + Para1;
                break;
            case 1:
                return 'x>=' + Para1;
                break;
            case 2:
                return 'x<' + Para1;
                break;
            case 3:
                return 'x<=' + Para1;
                break;
            case 4:
                return Para1 + '<x<' + Para2;
                break;
            default:
                return Para1 + '<=x<=' + Para2;
        }
    };
    //动作
    $scope.RiskActionTypeOne = getRiskActionTypeOne;
    //动作转换
    $scope.getAction = function (Action) {
        switch (Action) {
            case 0:
                return '无';
                break;
            case 1:
                return '禁止开仓';
                break;
            case 2:
                return '禁止平仓';
                break;
            case 3:
                return '禁止开仓|禁止平仓';
                break;
            case 4:
                return '告警';
                break;
            case 5:
                return '禁止开仓|告警';
                break;
            case 6:
                return '禁止平仓|告警';
                break;
            case 7:
                return '禁止开仓|禁止平仓|告警';
                break;
            case 8:
                return '强制平仓';
                break;
            case 9:
                return '禁止开仓|强制平仓';
                break;
            case 10:
                return '禁止平仓|强制平仓';
                break;
            case 11:
                return '禁止开仓|禁止平仓|强制平仓';
                break;
            case 12:
                return '告警|强制平仓';
                break;
            case 13:
                return '禁止开仓|告警|强制平仓';
                break;
            case 14:
                return '禁止平仓|告警|强制平仓';
                break;
            default:
                return '禁止开仓|禁止平仓|告警|强制平仓';
        }
    };
    //公式参数选择
    $scope.showFunc = function () {
        if ($scope.Condition < 4) {
            $scope.Para1Show = false;
        } else {
            $scope.Para1Show = false;
            $scope.Para2Show = false;
        }
    };
    //动作与强平判断
    $scope.forcedFunc = function () {
        console.log($scope.Action3);
        if ($scope.Action3 == true) {
            $('#depositClose input[type=checkbox]').removeAttr('disabled');
        } else {
            $scope.ForceCloseType0 = '';
            $scope.ForceCloseType1 = '';
            $scope.ForceCloseType2 = '';
            $('#depositClose input[type=checkbox]').attr('disabled', true);
        }
    };
    $("input[name='test']").click(function () {
        $scope.ForceCloseType0 = '';
        $scope.ForceCloseType1 = '';
        $scope.ForceCloseType2 = '';
        $("input[name='test']").not(this).attr("disabled", $(this).is(':checked'));
    });
    //动作强平方式
    $scope.moveWay = function () {
        if ($scope.Action == 0) {
            return $scope.Action0 = false, $scope.Action1 = false, $scope.Action2 = false, $scope.Action3 = false;
        }
        if ($scope.Action == 1) {
            return $scope.Action0 = true;
        }
        if ($scope.Action == 2) {
            return $scope.Action1 = true;
        }
        if ($scope.Action == 3) {
            return $scope.Action0 = true, $scope.Action1 = true;
        }
        if ($scope.Action == 4) {
            return $scope.Action2 = true;
        }
        if ($scope.Action == 5) {
            return $scope.Action0 = true, $scope.Action2 = true;
        }
        if ($scope.Action == 6) {
            return $scope.Action1 = true, $scope.Action2 = true;
        }
        if ($scope.Action == 7) {
            return $scope.Action0 = true, $scope.Action1 = true, $scope.Action2 = true;
        }
        if ($scope.Action == 9) {
            return $scope.Action0 = true, $scope.Action3 = true;
        }
        if ($scope.Action == 10) {
            return $scope.Action1 = true, $scope.Action3 = true;
        }
        if ($scope.Action == 11) {
            return $scope.Action0 = true, $scope.Action1 = true, $scope.Action3 = true;
        }
        if ($scope.Action == 12) {
            return $scope.Action2 = true, $scope.Action3 = true;
        }
        if ($scope.Action == 13) {
            return $scope.Action0 = true, $scope.Action2 = true, $scope.Action3 = true;
        }
        if ($scope.Action == 14) {
            return $scope.Action1 = true, $scope.Action2 = true, $scope.Action3 = true;
        }
        if ($scope.Action == 15) {
            return $scope.Action0 = true, $scope.Action1 = true, $scope.Action2 = true, $scope.Action3 = true;
        }
    };

    //查询
    $scope.actionType = '';
    $scope.formularType = '';
    $scope.OperatorType = '';
    $scope.EnableType = '';
    $scope.riskRegulationSearch = function () {
        $scope.toggleTraderSearchState = false;
        $('.search_column').css('height', '36px');
        var json = {
            qryConditionList: [{field: "Action", value: parseFloat($scope.actionType)},
                {field: "Formular", value: parseFloat($scope.formularType)},
                {field: "Operator", value: $scope.OperatorType},
                {field: "Enable", value: $scope.EnableType}
            ]
        };
        riskRegulationAll.riskSearch(json)
            .then(function (res) {
                if (res.retMsg.code === '000000') {
                    $scope.riskList = res.list;
                    console.log($scope.riskList)

                    var source = {
                        localdata: $scope.riskList,
                        datatype: "array",
                        datafields: [
                            {name: 'Key', type: 'string'},
                            {name: 'Name', type: 'string'},
                            {name: 'Enable', type: 'string'},
                            {name: 'Formular', type: 'string'},
                            {name: 'Condition', type: 'string'},

                            {name: 'Para1', type: 'string'},
                            {name: 'Para2', type: 'string'},
                            {name: 'Action', type: 'string'},
                            {name: 'Comment', type: 'string'}
                        ]
                    };
                    var dataAdapter = new $.jqx.dataAdapter(source);
                    $("#entrustDetailGrid").jqxGrid(
                        {
                            width: 100 + '%',
                            height: 80 + '%',
                            theme: 'metrodark',
                            source: dataAdapter,//数据源
                            pageable: true,//是否分页
                            pagesize:10,
                            columnsresize: true,//列间距是否可调整
                            clipboard: false,//屏蔽jqxGrid的复制功能
                            pagesizeoptions: ['10', '30', '100', '200'],
                            columns: [
                                {
                                    text: '名称',
                                    datafield: 'Name',
                                    width: 16 + '%',
                                    minwidth: 16 + '%',
                                    align: 'center',
                                    cellsalign: 'center'
                                },
                                {
                                    text: '启用',
                                    datafield: 'Enable',
                                    columntype: 'checkbox',
                                    width: 16 + '%',
                                    minwidth: 16 + '%',
                                    align: 'center',
                                    cellsalign: 'center'
                                },
                                {
                                    text: '公式类型',
                                    datafield: 'Formular',
                                    width: 16 + '%',
                                    minwidth: 16 + '%',
                                    align: 'center',
                                    cellsalign: 'center',
                                    cellsrenderer: function (row, columnfield, value, defaulthtml, columnproperties) {
                                        if ($scope.FormularRiskType) {
                                            for (var i = 0; i < $scope.FormularRiskType.length; i++) {
                                                if (value == $scope.FormularRiskType[i].id) {
                                                    return $scope.FormularRiskType[i].name;
                                                }
                                            }
                                        }
                                    }
                                },
                                {
                                    text: '公式条件',
                                    datafield: 'Condition',
                                    width: 16 + '%',
                                    minwidth: 16 + '%',
                                    align: 'center',
                                    cellsalign: 'center',
                                    cellsrenderer: function (row, columnfield, value, defaulthtml, columnproperties) {
                                        if ($scope.riskList) {
                                            if (value == 0) {
                                                return 'x>' + $scope.riskList[row].Para1;
                                            }
                                            if (value == 1) {
                                                return 'x>=' + $scope.riskList[row].Para1;
                                            }
                                            if (value == 2) {
                                                return 'x<' + $scope.riskList[row].Para1;
                                            }
                                            if (value == 3) {
                                                return 'x<=' + $scope.riskList[row].Para1;
                                            }
                                            if (value == 4) {
                                                return $scope.riskList[row].Para1 + '<x<' + $scope.riskList[row].Para2;
                                            }
                                            if (value == 5) {
                                                return $scope.riskList[row].Para1 + '<=x<=' + $scope.riskList[row].Para2;
                                            }
                                        }
                                    }
                                },
                                {
                                    text: '动作',
                                    datafield: 'Action',
                                    width: 18 + '%',
                                    minwidth: 18 + '%',
                                    align: 'center',
                                    cellsalign: 'center',
                                    cellsrenderer: function (row, columnfield, value, defaulthtml, columnproperties) {
                                        if (value == 0) {
                                            return '无';
                                        }
                                        if (value == 1) {
                                            return '禁止开仓';
                                        }
                                        if (value == 2) {
                                            return '禁止平仓';
                                        }
                                        if (value == 3) {
                                            return '禁止开仓|禁止平仓';
                                        }
                                        if (value == 4) {
                                            return '告警';
                                        }
                                        if (value == 5) {
                                            return '禁止开仓|告警';
                                        }
                                        if (value == 6) {
                                            return '禁止平仓|告警';
                                        }
                                        if (value == 7) {
                                            return '禁止开仓|禁止平仓|告警';
                                        }
                                        if (value == 8) {
                                            return '强制平仓';
                                        }
                                        if (value == 9) {
                                            return '禁止开仓|强制平仓';
                                        }
                                        if (value == 10) {
                                            return '禁止平仓|强制平仓';
                                        }
                                        if (value == 11) {
                                            return '禁止开仓|禁止平仓|强制平仓';
                                        }
                                        if (value == 12) {
                                            return '告警|强制平仓';
                                        }
                                        if (value == 13) {
                                            return '禁止开仓|告警|强制平仓';
                                        }
                                        if (value == 14) {
                                            return '禁止平仓|告警|强制平仓';
                                        }
                                        if (value == 15) {
                                            return '禁止开仓|禁止平仓|告警|强制平仓';
                                        }
                                    }
                                },
                                {
                                    text: '备注',
                                    datafield: 'Comment',
                                    width: 18 + '%',
                                    minwidth: 18 + '%',
                                    align: 'center',
                                    cellsalign: 'center'
                                }
                            ]
                        });
                    //分页
                    $("#entrustDetailGrid").on("pagechanged", function (event) {
                        console.log(event)
                    });
                } else {
                    $rootScope.tipService.setMessage(res.retMsg.message, 'warning');
                }
            }, function (error) {
                $rootScope.tipService.setMessage(error.message, 'warning');
            });
    };

    //新增
    $scope.Name = '';
    $scope.Para1 = '';
    $scope.Para2 = '';
    $scope.Action = '';
    $scope.Para1 = '';
    $scope.ForceCloseType = '';
    $scope.addEditText = '';
    $scope.addNewUser = function () {
        $scope.newUserShow = true;
        $scope.addEditText = '新增';
        $scope.Para1Show = true;
        $scope.Para2Show = true;
    };
    //修改
    $('#entrustDetailGrid').on('rowselect', function (event) {
        $scope.chooseItemTab1 = event.args.row.Key;
        $scope.Enable=event.args.row.Enable;
        $scope.chooseUserData = {
            Name: event.args.row.Name,
            Formular: event.args.row.Formular,
            Condition: event.args.row.Condition,
            Action: event.args.row.Action,
            Operator: event.args.row.Operator,
            Comment: event.args.row.Comment,
            Para1: event.args.row.Para1,
            Para2: event.args.row.Para2,
            ForceCloseType: event.args.row.ForceCloseType
        };
    });
    $scope.editUser = function () {
        if (!$scope.chooseItemTab1) {
            $rootScope.tipService.setMessage('请先选择规则类型', 'warning');
        }
        else {
            console.log($scope.Enable);
            $scope.addEditText = '修改';
            $scope.editUserLocked = true;
            $scope.newUserShow = true;
            $scope.Name = $scope.chooseUserData.Name;
            $scope.Formular = $scope.chooseUserData.Formular;
            $scope.Condition = $scope.chooseUserData.Condition;
            $scope.Action = $scope.chooseUserData.Action;
            $scope.Operator = $scope.chooseUserData.Operator;
            $scope.Comment = $scope.chooseUserData.Comment;
            $scope.Para1 = $scope.chooseUserData.Para1;
            $scope.Para2 = $scope.chooseUserData.Para2;

            if($scope.Enable=='true'){
                $scope.enableOne=true;
            }else{
                $scope.enableOne=false;
            }

            if ($scope.Action >= 8) {
                $('#depositClose input[type=checkbox]').removeAttr('disabled');
                $scope.moveWay();
                switch ($scope.chooseUserData.ForceCloseType) {
                    case 0:
                        $scope.ForceCloseType0 = true;
                        break;
                    case 1:
                        $scope.ForceCloseType1 = true;
                        break;
                    case 2:
                        $scope.ForceCloseType2 = true;
                        break;
                }
            } else {
                $scope.moveWay();
            }
        }
    };
    $scope.addEditUserSubmit = function () {
        if ($scope.addEditText == '新增') {
            if ($scope.Action0 == true) {
                $scope.Action0 = 1;
            } else {
                $scope.Action0 = 0;
            };
            if ($scope.Action1 == true) {
                $scope.Action1 = 2;
            } else {
                $scope.Action1 = 0;
            };
            if ($scope.Action2 == true) {
                $scope.Action2 = 4;
            } else {
                $scope.Action2 = 0;
            };
            if ($scope.Action3 == true) {
                $scope.Action3 = 8;
            } else {
                $scope.Action3 = 0;
            }
            var actionResult = $scope.Action0 + $scope.Action1 + $scope.Action2 + $scope.Action3;
            if ($scope.ForceCloseType0 == true) {
                $scope.ForceCloseType = 0;
            } else if ($scope.ForceCloseType1 == true) {
                $scope.ForceCloseType = 1;
            } else if ($scope.ForceCloseType2 == true) {
                $scope.ForceCloseType = 2;
            } else {
                $scope.ForceCloseType = 0;
            }
            var riskctrlRule = {
                Key: '',
                Name: $scope.Name,
                Enable: ($scope.enableOne === '') ? false : true,
                Formular: parseFloat($scope.Formular),  //公式类型
                Condition: parseFloat($scope.Condition),
                Para1: parseFloat($scope.Para1),
                Para2: parseFloat($scope.Para2),
                Action: actionResult,
                ForceCloseType: $scope.ForceCloseType,
                Comment: $scope.Comment,
                // Operator: localStorageService.get('selfInfo').userId
            };
            var json = {
                riskctrlRule: riskctrlRule
            };
            riskRegulationAll.riskAdd(json).then(function (res) {
                $rootScope.tipService.setMessage(res.message, 'warning');
                $scope.riskRegulationSearch();
                $scope.remove();
            }, function (error) {
                $rootScope.tipService.setMessage(error.message, 'warning');
            });
        } else if ($scope.addEditText == '修改') {
            if ($scope.addUserName == '') {
                $rootScope.tipService.setMessage('请填写角色名', 'warning');
            } else {
                if ($scope.Action0 == true) {
                    $scope.Action0 = 1;
                } else {
                    $scope.Action0 = 0;
                };
                if ($scope.Action1 == true) {
                    $scope.Action1 = 2;
                } else {
                    $scope.Action1 = 0;
                };
                if ($scope.Action2 == true) {
                    $scope.Action2 = 4;
                } else {
                    $scope.Action2 = 0;
                };
                if ($scope.Action3 == true) {
                    $scope.Action3 = 8;
                    $('#depositClose input[type=checkbox]').removeAttr('disabled');
                } else {
                    $scope.Action3 = 0;
                }
                if ($scope.ForceCloseType0 == true) {
                    $scope.ForceCloseType = 0;
                } else if ($scope.ForceCloseType1 == true) {
                    $scope.ForceCloseType = 1;
                } else if ($scope.ForceCloseType2 == true) {
                    $scope.ForceCloseType = 2;
                } else {
                    $scope.ForceCloseType = '';
                }
                var riskctrlRule = {
                    Key: $scope.chooseItemTab1,
                    Name: $scope.Name,
                    Formular: parseFloat($scope.Formular),  //公式类型
                    Condition: parseFloat($scope.Condition),
                    Para1: parseFloat($scope.Para1),
                    Para2: parseFloat($scope.Para2),
                    Action: $scope.Action0 + $scope.Action1 + $scope.Action2 + $scope.Action3,
                    ForceCloseType: $scope.ForceCloseType,
                    Enable: $scope.enableOne,
                    Comment: $scope.Comment,
                    Operator: localStorageService.get('selfInfo').userId
                };
                var json = {
                    riskctrlRule: riskctrlRule
                };
                riskRegulationAll.riskModify(json)
                    .then(function (res) {
                        $rootScope.tipService.setMessage(res.message, 'warning');
                        $scope.riskRegulationSearch();
                        $scope.remove();
                    }, function (error) {
                        $rootScope.tipService.setMessage(error.message, 'warning');
                    });
            }
        }
    };

    //清空
    $scope.remove = function () {
        $scope.Action0 = '';
        $scope.Action1 = '';
        $scope.Action2 = '';
        $scope.Action3 = '';
        $scope.Name = '';
        $scope.enableOne = '';
        $scope.Para1 = '';
        $scope.Para2 = '';
        $scope.Action = '';
        $scope.Para1 = '';
        $scope.Formular = '';
        $scope.Condition = '';
        $scope.Comment = '';
        $scope.ForceCloseType0 = '';
        $scope.ForceCloseType1 = '';
        $scope.ForceCloseType2 = '';
        $scope.newUserShow = false;
    };
    //注销
    $scope.delete = function () {
        if (!$scope.chooseItemTab1) {
            $rootScope.tipService.setMessage('请先选择用户', 'warning');
        }
        else {
            confirmService.set('确认提示', '确定要删除此用户?', function () {
                var json = {
                    key: $scope.chooseItemTab1
                };
                riskRegulationAll.delete(json)
                    .then(function (res) {
                        $rootScope.tipService.setMessage(res.message, 'warning');
                        $scope.riskRegulationSearch()
                    }, function (error) {
                        $rootScope.tipService.setMessage(error.message, 'warning');
                    });
                confirmService.clear();
            });
        }
    };
}])
 // 风控规则
    .factory('riskRegulationAll', ['$q', '$http', '$rootScope', function ($q, $http, $rootScope) {
        return {
            riskSearch: function (data) {
                var deferred = $q.defer();
                $http({
                    method: "POST",
                    url: $rootScope.baseUrl + "c/riskctrl/rule/query/filter",
                    data: data,
                    headers: {
                        'Content-Type': 'application/json;charset=UTF-8'
                    }
                }).success(function (res) {
                    deferred.resolve(res);
                }).error(function (res) {
                    deferred.reject(res);
                });
                return deferred.promise;
            },
            riskAdd: function (json) {
                var deferred = $q.defer();
                $http({
                    method: "POST",
                    url: $rootScope.baseUrl + "c/riskctrl/rule/insert",
                    data: json,
                    headers: {
                        'Content-Type': 'application/json;charset=UTF-8'
                    }
                }).success(function (res) {
                    deferred.resolve(res);
                }).error(function (res) {
                    deferred.reject(res);
                });
                return deferred.promise;
            },
            riskModify: function (json) {
                var deferred = $q.defer();
                $http({
                    method: "POST",
                    url: $rootScope.baseUrl + "c/riskctrl/rule/modify",
                    data: json,
                    headers: {
                        'Content-Type': 'application/json;charset=UTF-8'
                    }
                }).success(function (res) {
                    deferred.resolve(res);
                }).error(function (res) {
                    deferred.reject(res);
                });
                return deferred.promise;
            },
            delete: function (json) {
                var deferred = $q.defer();
                $http({
                    method: "POST",
                    url: $rootScope.baseUrl + "c/riskctrl/rule/delete",
                    data: json,
                    headers: {
                        'Content-Type': 'application/json;charset=UTF-8'
                    }
                }).success(function (res) {
                    deferred.resolve(res);
                }).error(function (res) {
                    deferred.reject(res);
                });
                return deferred.promise;
            }
        }
    }]);
