app.controller('merchantManageEditCtrl', ['$scope', '$rootScope', 'dataSer', 'merchantManageEditSer', 'getKeyStoreType', 'getFeeType', 'switchBoolean', 'switchThirdPay', 'getCurrencyType', 'getBankState', 'getPageNum', 'localStorageService', function ($scope, $rootScope, dataSer, merchantManageEditSer, getKeyStoreType, getFeeType, switchBoolean, switchThirdPay, getCurrencyType, getBankState, getPageNum, localStorageService) {
    $scope.goBack = function () {
        $scope.changeState('tabs.merchantManage');
    };
// 数据转化
    $scope.bankState = getBankState;
    $scope.KeyStoreType = getKeyStoreType;
    $scope.FeeType = getFeeType;
    $scope.booleanTo = switchBoolean;
    $scope.getBoolean = function (parameter) {
        for (i = 0; i < switchBoolean.length; i++) {
            if (parameter == switchBoolean[i].id) {
                return switchBoolean[i].name;
            }
        }
    };
    $scope.thirdPay = switchThirdPay;
    $scope.getThirdPay = function (parameter) {
        for (i = 0; i < switchThirdPay.length; i++) {
            if (parameter == switchThirdPay[i].id) {
                return switchThirdPay[i].name;
            }
        }
    };
    // 货币转换
    getCurrencyType.then(function (res) {
        console.log(res);
        $scope.currencyList = JSON.parse(res.content);
    });
    $scope.getCurrency = function (parameter) {
        if ($scope.currencyList) {
            for (var i = 0; i < $scope.currencyList.length; i++) {
                if (parameter == $scope.currencyList[i].currency) {
                    return $scope.currencyList[i].currencyName;
                }
            }
        }
    };
    //机构列表
    $scope.addOrgVal = ''; //显示值
    $scope.orgId = ''; //选择值
    $scope.orgCode = '';
    dataSer.organizeQuerySer().then(function(res) {
        $scope.orgList = res;
        console.log(res);
    });
    $scope.addOrgValFTC = function(orgId, orgCode, showval) {
        $scope.orgId = orgId;
        $scope.orgCode = orgCode;
        $scope.addOrgVal = showval;
    };
    $scope.hideOrgList = function() {
        $scope.isShowOrgList = false;
        $(".OrgList").blur();
    };
    //银行通道
    var bankJson = {
        page: 1,
        rows: 9999,
        orders: 'asc'
    };
    merchantManageEditSer.bankChannel(bankJson).then(function (res) {
        if (res.content) {
            $scope.bankChannelList = JSON.parse(res.content).content;
        }
    }, function (error) {
        console.log(error);
    });
//机构码匹配
    var saveOrganizeData=localStorageService.get('organizeData');
    $scope.switchOrganize=function(parameter){
        for(var i=0;i<saveOrganizeData.length;i++){
            if(parameter==saveOrganizeData[i].orgCode){
                return saveOrganizeData[i].orgNum;
            }
        }
    };
    //获取商户信息
    var bankMerchantEditId = localStorageService.get('userIdChecked');
    console.log(bankMerchantEditId);
    var merchantFullV={
        bankMerchantId:bankMerchantEditId
    };
    merchantManageEditSer.merchantEdit(merchantFullV)
        .then(function(res){
           if(res.code=='000000' && res.content){
               console.log(JSON.parse(res.content));
               var merchantData=JSON.parse(res.content);
               $scope.channelBankCode = merchantData.bankCode;
               $scope.ThirdPayFlag = merchantData.thirdpayFlag;
               $scope.channelDefaultFlag = merchantData.defaultFlag.toString();
               $scope.channelCurrency = merchantData.currency.toString();
               $scope.channelStatus = merchantData.status.toString();
               $scope.saveOrgCode = merchantData.orgCode;
               $scope.saveOrgId = merchantData.orgId;
               $scope.addOrgVal=$scope.switchOrganize(merchantData.orgCode);

               $scope.payFeeType = merchantData.payFeeType;
               $scope.payFeeNum = merchantData.payFeeNum;
               $scope.withdrawFeeType = merchantData.withdrawFeeType;
               $scope.withdrawFeeNum = merchantData.withdrawFeeNum;
               $scope.channelSignUpFlag = merchantData.signUpFlag;
               $scope.channelPayFlag = merchantData.payFlag;
               $scope.channelWithdrawFlag = merchantData.withdrawFlag;

               if (merchantData.thirdpayFlag == 1) { //第三方支付
                   $scope.thirdFlag = true;
                   $scope.bankFlagStatus=true;
                   $scope.bankFlag = false;
                   $scope.memberNumber = merchantData.memberNumber;
                   $scope.terminalNumbwe1 = merchantData.terminalNumbwe1;
                   $scope.terminalNumbwe2 = merchantData.terminalNumbwe2;
                   $scope.terminalNumbwe3 = merchantData.terminalNumbwe3;

                   $scope.md5Password = merchantData.md5Password;
                   $scope.prikeyPassowrd = merchantData.prikeyPassowrd;
                   $scope.prikeyName = merchantData.prikeyName;
                   $scope.prikeySavetype = '文件';
                   $scope.pubkeyName = merchantData.pubkeyName;
                   $scope.pubkeySavetype = '文件';
                   $scope.gatepayReturnPage = merchantData.gatepayReturnPage;
                   $scope.gatepayReturnUrl = merchantData.gatepayReturnUrl;

               } else if (merchantData.thirdpayFlag == -1) { //银行
                   $scope.bankFlag = true;
                   $scope.thirdFlagStatus=true;
                   $scope.thirdFlag = false;
                   $scope.bankUserName = merchantData.bankUserName;
                   $scope.bankAccountNo = merchantData.bankAccountNo;
                   $scope.bankMngnodeNum = merchantData.bankMngnodeNum;

                   $scope.bankRequestUrl = merchantData.bankRequestUrl;
               }
           }else{
               $rootScope.tipService.setMessage(res.message, 'warning');
           }
        },function(error){
            $rootScope.tipService.setMessage(error.message, 'warning');
        });
    //数据处理
    $scope.chooseChannel = function () {
        $scope.payFeeNum = '';
        $scope.payFeeType = '';
        $scope.withdrawFeeType = '';
        $scope.channelSignUpFlag = '';
        $scope.channelPayFlag = '';
        $scope.channelWithdrawFlag = '';
        $scope.withdrawFeeNum = '';
        if ($scope.ThirdPayFlag ==-1) {  //-1银行
            $scope.ThirdPayFlag ="-1";
            $scope.bankFlag = true;
            $scope.bankFlagStatus = false;
            $scope.thirdFlag = false;
            $scope.thirdFlagStatus = true;
            $scope.prikeySavetype = '';
            $scope.pubkeySavetype = '';
            $scope.memberNumber = '';
            $scope.terminalNumbwe1 = '';
            $scope.terminalNumbwe2 = '';
            $scope.terminalNumbwe3 = '';
            $scope.channelDefaultFlag = '';
            $scope.channelCurrency = '';
            $scope.channelStatus = '';

            $scope.md5Password = '';
            $scope.prikeyPassowrd = '';
            $scope.prikeyName = '';
            $scope.pubkeyName = '';
        } else if ($scope.ThirdPayFlag == 1) {  //1 第三方支付
            $scope.ThirdPayFlag =1;
            $scope.thirdFlag = true;
            $scope.thirdFlagStatus = false;
            $scope.bankFlag = false;
            $scope.bankFlagStatus = true;
            $scope.prikeySavetype = '文件';
            $scope.pubkeySavetype = '文件';
            $scope.bankUserName = '';
            $scope.bankAccountNo = '';
            $scope.bankMngnodeNum = '';

            $scope.bankRequestUrl = '';
        } else {
            $scope.thirdFlag = false;
        }
    };
    $scope.merchantModify = function () {
        if($scope.prikeySavetype=='文件' && $scope.pubkeySavetype=='文件'){
            $scope.prikeySavetype=1;
            $scope.pubkeySavetype=1;
        }else{
            $scope.prikeySavetype='';
            $scope.pubkeySavetype='';
        }
        console.log($scope.orgId)
        var merchantFullV = {
            basicV: {
                bankMerchantId: bankMerchantEditId,
                bankCode: $scope.channelBankCode,
                bankAccountNo: $scope.bankAccountNo,
                bankUserName: $scope.bankUserName,
                bankMngnodeNum: $scope.bankMngnodeNum,
                memberNumber: $scope.memberNumber,
                orgId: ($scope.orgId=='')?$scope.saveOrgId:$scope.orgId,
                orgCode: ($scope.orgCode=='')?$scope.saveOrgCode:$scope.orgCode,
                terminalNumbwe1: $scope.terminalNumbwe1,
                terminalNumbwe2: $scope.terminalNumbwe2,
                terminalNumbwe3: $scope.terminalNumbwe3,
                defaultFlag: parseInt($scope.channelDefaultFlag),
                thirdpayFlag: $scope.ThirdPayFlag,
                currency: parseInt($scope.channelCurrency),
                status: parseInt($scope.channelStatus)
            },
            sysconfigV: {
                bankMerchantId: bankMerchantEditId,
                bankRequestUrl: $scope.bankRequestUrl,
                md5Password: $scope.md5Password,
                prikeyPassowrd: $scope.prikeyPassowrd,
                prikeyName: $scope.prikeyName,
                prikeySavetype: $scope.prikeySavetype,
                pubkeyName: $scope.pubkeyName,
                pubkeySavetype:$scope.pubkeySavetype
            },
            transconfigV: {
                bankMerchantId:bankMerchantEditId,
                signUpFlag: parseInt($scope.channelSignUpFlag),
                payFlag: parseInt($scope.channelPayFlag),
                withdrawFlag: parseInt($scope.channelWithdrawFlag),
                payFeeNum: $scope.payFeeNum,
                payFeeType: parseInt($scope.payFeeType),
                withdrawFeeNum: $scope.withdrawFeeNum,
                withdrawFeeType: parseInt($scope.withdrawFeeType)
            }
        };
        var json = {
            merchantFullV: merchantFullV
        };
        merchantManageEditSer.unitModify(json)
            .then(function (res) {
                if (res.code == '000000') {
                    $scope.changeState('tabs.merchantManage');
                    $rootScope.tipService.setMessage(res.message, 'warning');
                } else {
                    $rootScope.tipService.setMessage(res.message, 'warning');
                }
            }, function (error) {
                $rootScope.tipService.setMessage(error.message, 'warning');
            })
    }
}])
    .factory('merchantManageEditSer', ['$http', 'localStorageService', 'myHttp', '$q', '$rootScope', function ($http, localStorageService, myHttp, $q, $rootScope) {
        return {
            unitModify: function (json) {
                var deferred = $q.defer();
                $http({
                    method: "POST",
                    url: $rootScope.baseUrl + "exbank/update/bankmerchant/full",
                    data: json,
                    headers: {
                        'Content-Type': 'application/json;charset=UTF-8'
                    }
                }).success(function (res) {
                    deferred.resolve(res);
                }).error(function (res) {
                    deferred.reject(res);
                });
                return deferred.promise;
            },
            //银行通道
            bankChannel: function (json) {
                var deferred = $q.defer();
                myHttp.post("exbank/query/bankchannel/page", json)
                    .then(function (res) {
                        deferred.resolve(res);
                    }, function (res) {
                        deferred.reject(res);
                    });
                return deferred.promise;
            },
            //商户修改
            merchantEdit:function(json){
                var deferred=$q.defer();
                $http({
                    method:"POST",
                    url:$rootScope.baseUrl+"exbank/get/bankmerchant",
                    data:json,
                    headers:{
                        'Content-Type':'application/json;charset=UTF-8'
                    }
                }).success(function(res){
                    deferred.resolve(res);
                }).error(function(res){
                    deferred.reject(res);
                });
                return deferred.promise;
            }
        }
    }]);

