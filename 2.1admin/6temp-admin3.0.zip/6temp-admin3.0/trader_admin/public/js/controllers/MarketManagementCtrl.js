app.controller('MarketManagementCtrl', ['$rootScope', '$scope', 'getPageNum', 'MarketManagementCtrlSer', 'getClassificationState', 'dataSer', 'localStorageService', 'confirmService','$timeout','getmarket','VarietiesCtrlSer','timestamp','getweekType','getadminState', function ($rootScope, $scope, getPageNum, MarketManagementCtrlSer, getClassificationState, dataSer, localStorageService, confirmService,$timeout,getmarket,VarietiesCtrlSer,timestamp,getweekType,getadminState) {
    $scope.toggleTraderSearchState = false;
    $scope.Toggle = function () {
        $scope.toggleTraderSearchState = !$scope.toggleTraderSearchState;
        if ($scope.toggleTraderSearchState) {
            $('.search_column').css('height', 'auto');
        }
        else {
            $('.search_column').css('height', '36px');
        }
    };
    localStorageService.clear('userIdChecked');
    $scope.tableshow = false;
    $scope.marketName='';
    $scope.ToState='';
    $scope.search = function (type) {
        $scope.toggleTraderSearchState = false;
        $('.search_column').css('height', '36px');
        if (type == 'search') {
            pageInitialize()
        };
        $scope.orgCode=localStorageService.get('oldOrgCode');
        var json = {
            page: $scope.currentPage,
            rows: $scope.showNum.showNum,
            orders: 'asc',
            search_EQ_orgCode: ($scope.orgCode) ?  $scope.orgCode : '',
            search_EQ_marketState: $scope.ToState,
            search_EQ_marketName: $scope.marketName,

        };
        MarketManagementCtrlSer.search(json)
            .then(function (res) {
                if (res.code == '000000') {
                    $scope.showPage = true;
                    var data = JSON.parse(res.content);
                    $scope.searchResult = data.content;
                    console.log($scope.searchResult);
                    $scope.dataNum = data.totalElements;
                    $scope.PageNum();

                    var checkedUserId=localStorageService.get('userIdChecked'); //获取上一次存储的id
                    $scope.switchUserId(checkedUserId,$scope.searchResult); //执行选中方法
                } else {
                    $rootScope.tipService.setMessage(res.message, 'warning');
                }
            }, function (error) {
                $rootScope.tipService.setMessage(error.message, 'warning');
            });
    }
    //内部、外部
    $scope.marketlist=getmarket;
    $scope.marketlistType = function (val){
        if ($scope.marketlist) {
            for (var i = 0, r = $scope.marketlist.length; i < r; i++) {
                if ($scope.marketlist[i].val == val) {
                    return $scope.marketlist[i].name;
                }
            }
        }
    }
    dataSer.organizeQuerySer()
        .then(function (res) {
            $scope.orgList = res;
        });

    $scope.addOrgValFTC = function (data) {
        $scope.orgId = data.orgId;
        $scope.orgCode = data.orgCode;
        $scope.addOrgVal = data.text;
    }
    //全部状态下所属机构
    dataSer.organizeQuerylistSer()
        .then(function (res) {
            $scope.orgAllList = res;
        });

    $scope.adjustText = function (orgId) {
        if ($scope.orgAllList) {
            for (var i = 0, r = $scope.orgAllList.length; i < r; i++) {
                if ($scope.orgAllList[i].orgId == orgId) {
                    return $scope.orgAllList[i].text;
                }
            }
        }
    }
    /**
     * 分页功能实现TerryMin
     * **/
    $scope.showDataChoose = getPageNum.pageNum(); //获取分页
    $scope.showNum = $scope.showDataChoose[0]; //初始显示刷具条数
    $scope.showPage = false;
    var pageInitialize = function () {
        $scope.dataNum = 0; //数据总条数
        $scope.dataPage = 0; //分页数
        $scope.currentPage = 1; //当前页数
        $scope.jumpPageNum = '';
    };
    pageInitialize();

    // x/y $scope.dataPage
    $scope.PageNum = function () {
        $scope.showPage = true;
        if ($scope.showNum.showNum < $scope.dataNum) {
            $scope.dataPage =Math.ceil($scope.dataNum / $scope.showNum.showNum);
        } else {
            $scope.dataPage = 0;
        }
    };
    //上页下页 $scope.currentPage
    $scope.pageSlect = function (type) {
        if (type == 'prev') {
            if ($scope.currentPage != 1) {
                $scope.currentPage--;
                $scope.PageNum();
                $scope.search();
            }
        } else {
            if ($scope.currentPage < $scope.dataPage) {
                $scope.currentPage++;
                $scope.PageNum();
                $scope.search();
            }
        }
    };
    // 每页条数单元
    $scope.pageSelect = function (params) {
        $scope.showNum.showNum = params.showNum;
        pageInitialize();
        $scope.search();
    };
    //页数跳转 currentPage
    $scope.jumpPage = function (num) {
        num = parseInt(num);
        if (parseInt(num, 10) === num && num <= ($scope.dataPage + 1) && num > 0) {
            $scope.currentPage = num;
            $scope.PageNum();
            $scope.search();
        }
    };

    $scope.orgId = '';
    $scope.orgCode = '';
    $scope.state = '';
    $scope.JQhideRoleaut=true;
    $scope.JQshowRoleaut=true;
    $scope.SCshowRoleaut=true;
    $scope.SChideRoleaut=true;
    // 选择
    $scope.checkedTab1 = function (index,applyTradeDateId,applyHolidayId,marketId,marketName,marketCode,orgId,marketType,marketSort,marketState){
        $scope.chooseUserData={
            applyTradeDateId:applyTradeDateId,
            applyHolidayId:applyHolidayId,
            marketId:marketId,
            marketName: marketName,
            marketCode: marketCode,
            orgId:orgId,
            marketType: marketType,
            marketSort: marketSort,
            marketState:marketState,
        };
        console.log($scope.chooseUserData)
        var userIdChecked = localStorageService.get('userIdChecked');
        $('#dataReport input[type=checkbox]').prop('checked', false);
        if (marketId == userIdChecked) {
            localStorageService.clear('userIdChecked');
            $scope.chooseItemTab1 = '';
            $scope.applyTradeDateId='';
            $scope.marketId='';
            $scope.applyHolidayId='';
            $scope.marketState='';
        } else {
            $('#dataReport input[type=checkbox]').eq(index).prop('checked', true);
            localStorageService.update('userIdChecked', marketId);
            $scope.chooseItemTab1 = marketId;
            $scope.applyTradeDateId=applyTradeDateId;
            $scope.marketId=marketId;
            $scope.applyHolidayId=applyHolidayId;
            $scope.marketState= marketState;
        }
        if ($scope.chooseUserData.applyHolidayId != null) {
            $scope.JQhideRoleaut=false;
            $scope.JQshowRoleaut=false;
        }else{
            $scope.JQshowRoleaut=true;
            $scope.JQhideRoleaut=true;
        };
        if ($scope.chooseUserData.applyTradeDateId != null) {
            $scope.SChideRoleaut=false;
            $scope.SCshowRoleaut=false;
        }else{
            $scope.SCshowRoleaut=true;
            $scope.SChideRoleaut=true;
        };
    };
    // 存储选中
    $scope.switchUserId = function (parameter, responseData) {
        $timeout(function () {
            for (var i = 0; i < responseData.length; i++) {
                if (parameter == responseData[i].marketId) {
                    $('#dataReport input[type=checkbox]').eq(i).prop('checked', true);
                    return;
                }
            }
        }, 1500)
    };

    $scope.add = function () {
        $scope.tableshow = true;
        $scope.addEditText = '新增';
        $scope.addOrgVal = "";
        $scope.marketName = "";
        $scope.marketCode = "";
        $scope.marketType = "";
        $scope.marketSort = "";

    }

    $scope.edit = function () {
        if (!$scope.chooseItemTab1) {
            $rootScope.tipService.setMessage('请先选择机构配置信息', 'warning');
        } else {
            $scope.addEditText = '修改';
            $scope.tableshow = true;
            $scope.marketId=$scope.chooseUserData.marketId;
            $scope.marketName = $scope.chooseUserData.marketName;
            $scope.marketCode = $scope.chooseUserData.marketCode
            $scope.orgId = $scope.chooseUserData.orgId;
            $scope.marketType = $scope.chooseUserData.marketType;
            $scope.marketSort = $scope.chooseUserData.marketSort;
            //匹配机构代码
            var json = {
                page: 1,
                rows: 9999,
                search_A_EQ_state: 1
            };
            dataSer.getOrganize(json).then(function (res) {
                if (res.code == '000000') {
                    $scope.equalOrgCode = JSON.parse(res.content).content;
                    //console.log($scope.equalOrgCode);
                    for (var i = 0; i < $scope.equalOrgCode.length; i++) {
                        if ($scope.chooseUserData.orgId == $scope.equalOrgCode[i].orgId) {
                            $scope.addOrgVal = $scope.equalOrgCode[i].orgName + '(' + $scope.equalOrgCode[i].orgNum + ')';
                            //console.log($scope.addOrgVal)
                        }
                    }
                } else {
                    console.log(res);
                }
            });
        }
    }
    // 将毫秒转化为系统时间
    $scope.formatTime = function(parameter) {
        return timestamp.daySecondsToDate(parameter);
    };
    $scope.addNewSubmit = function () {
        if ($scope.addEditText == "新增") {
            var marketVIce = {
                orgId: $scope.orgId,
                marketName:$scope.marketName,
                marketCode:$scope.marketCode,
                marketType:parseInt($scope.marketType),
                marketSort:parseInt($scope.marketSort),
            }
            var json = {
                marketVIce: marketVIce
            }
            MarketManagementCtrlSer.Addsub(json)
                .then(function (res) {
                        if (res.data.code == "000000") {
                            $scope.tableshow = false;
                            $rootScope.tipService.setMessage(res.data.message, 'warning');
                            localStorageService.clear('userIdChecked');
                            $scope.search();
                        }else{
                            $rootScope.tipService.setMessage(res.data.message, 'warning');
                        }
                    },function(error){
                        $rootScope.tipService.setMessage(error.data.message, 'warning');
                    }
                )
        } else if ($scope.addEditText == "修改") {
            var marketVIce = {
                marketId:$scope.marketId,
                marketName:$scope.marketName,
                marketCode:$scope.marketCode,
                orgId: $scope.orgId,
                marketType:parseInt($scope.marketType),
                marketSort:parseInt($scope.marketSort),
            }
            var json = {
                marketVIce: marketVIce
            }
            MarketManagementCtrlSer.editsub(json)
                .then(function (res) {
                    if (res.data.code == "000000") {
                        $scope.tableshow = false;
                        $rootScope.tipService.setMessage(res.data.message, 'warning');
                        localStorageService.clear('userIdChecked');
                        $scope.search();
                    }
                    else {
                        $rootScope.tipService.setMessage(res.data.message, 'warning');
                    }
                },function(error){
                    $rootScope.tipService.setMessage(error.data.message, 'warning')
                })
        }
    }
    VarietiesCtrlSer.marketlists()
        .then(function(res){
            console.log(res)
            if(res.code=="000000"){
                $scope.Marketresults=JSON.parse(res.content);
                console.log($scope.Marketresults)
                $scope.marketNamety=function(marketId){
                    for (var i = 0, r = $scope.Marketresults.length; i < r; i++) {
                        if ($scope.Marketresults[i].marketId == marketId) {
                            return $scope.Marketresults[i].marketName;
                        }
                    }
                }
            }
        })
    $scope.apply = function () {
        if (!$scope.marketId) {
            $rootScope.tipService.setMessage('请先选择机构配置信息', 'warning');
        } else {
            $scope.addEditText = "申请市场交易日";
            $scope.applyshow = true;
        }
    }

    $scope.addSubmit = function () {
            var marketTradeTimeV = {
                marketId: $scope.marketId,
                startTime: ($scope.startTime) ? timestamp.DateToSeconds($scope.startTime) * 1000 : '',
                endTime: ($scope.endTime) ? timestamp.DateToSeconds($scope.endTime) * 1000 : '',
            }
            var json = {
                marketTradeTimeV: marketTradeTimeV
            }

            MarketManagementCtrlSer.applysub(json)
            .then(function (res) {
                if (res.data.code == "000000") {
                    $scope.applyshow = false;
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                    localStorageService.clear('userIdChecked');
                    $scope.search();
                } else {
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                }
            }, function (error) {
                $rootScope.tipService.setMessage(error.data.message, 'warning');
            })
        }

    $scope.audit=function () {
        if (!$scope.applyTradeDateId) {
            $rootScope.tipService.setMessage('请先申请交易变更', 'warning');
        } else {
            var json={
                applyId:$scope.applyTradeDateId
            }
            MarketManagementCtrlSer.Getaudit(json)
                .then(function(res){
                    if(res.data.code=="000000"){
                        var getData=JSON.parse(res.data.content);
                        $scope.getaduitDatalist=getData.configMarketTradeTimeV;
                        $scope.addEditText = "审核交易变更";
                        $scope.auditshow = true;
                        $scope.marketId=$scope.getaduitDatalist.marketId;
                        $scope.startTime=$scope.formatTime(($scope.getaduitDatalist.startTime)/1000);
                        $scope.endTime=$scope.formatTime(($scope.getaduitDatalist.endTime)/1000);
                    }
                })

        }
    }

    $scope.RoletrueData = function (tmpOpt) {
        var json = {
            applyId: $scope.applyTradeDateId,
            auditRs: tmpOpt
        };
        MarketManagementCtrlSer.Roletruetion(json)
            .then(function (res) {
                if (res.data.code == '000000') {
                    $scope.auditshow = false;
                    localStorageService.clear('userIdChecked');
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                    $scope.search();
                } else {
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                }
            },function(error) {
                $rootScope.tipService.setMessage(error.data.message, 'warning');
            })
    }
    $scope.RolefalseData = function (tmpOpt) {
        var json = {
            applyId: $scope.applyTradeDateId,
            auditRs: tmpOpt
        };
        MarketManagementCtrlSer.Roletruetion(json)
            .then(function (res) {
                if (res.data.code == '000000') {
                    $scope.auditshow = false;
                    localStorageService.clear('userIdChecked');
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                    $scope.search();
                } else {
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                }
            },function(error) {
                $rootScope.tipService.setMessage(error.data.message, 'warning');
            })
    }
    $scope.getweekType = getweekType;
    //console.log($scope.getweekType)
    $scope.getweekText = function (val) {
        for (var i = 0, r = $scope.getweekType.length; i < r; i++) {
            if (val == $scope.getweekType[i].val) {
                return $scope.getweekType[i].name;
            }
        }
    }
    $scope.ProStateList = getClassificationState;
    $scope.getProStateList = function (params) {
        for (var i = 0, r = $scope.ProStateList.length; i < r; i++) {
            if (params == $scope.ProStateList[i].id) {
                return $scope.ProStateList[i].name;
            }
        }
    }
    $scope.typeData = [{
        name: '指定周',
        val:'0'
    }, {
        name: '指定日期',
        val:'1'
    }];
    $scope.typeText = function (val) {
        for (var i = 0, r = $scope.typeData.length; i < r; i++) {
            if (val == $scope.typeData[i].val) {
                return $scope.typeData[i].name;
            }
        }
    }
    $scope.orgId = '';
    $scope.orgCode = '';
    $scope.manageFlag = '';
    $scope.innerMap = '';
    $scope.outMap = '';
    $scope.state = '';
    $scope.showWeek=true;
    $scope.hideTime=true;
    $scope.weekDay="";
    $scope.assignDay="";
    $scope.typeval=function(){
        if($scope.type==0){
            $scope.showWeek=false;
            $scope.hideTime=true;
            $scope.type=parseInt($scope.type);
            $scope.assignDay="";
        }else if($scope.type==1){
            $scope.hideTime=false;
            $scope.showWeek=true;
            $scope.type=parseInt($scope.type);
            $scope.weekDay="";
        }else{
            $scope.showWeek=true;
            $scope.hideTime=true;
        }

    }
    $scope.Vacationapply=function(){
        if (!$scope.marketId) {
            $rootScope.tipService.setMessage('请先申请假期管理变更', 'warning');
        } else {
            $scope.addEditText = "申请管理假期";
            $scope.Vacationtableshow = true;
            var json = {
                marketId: $scope.marketId
            }
            MarketManagementCtrlSer.get(json)
                .then(function (res) {
                    if (res.data.code = "000000") {
                        $scope.getxq = JSON.parse(res.data.content);
                        console.log($scope.getxq)
                        $scope.channelmaplists = [];
                        for (var i = 0, r = $scope.getxq.length; i < r; i++) {
                            var channelist = {
                                marketId: $scope.getxq[i].marketId,
                                type: parseInt($scope.getxq[i].type),
                                weekDay: parseInt($scope.getxq[i].weekDay),
                                assignDay:($scope.getxq[i].assignDay)? Date.parse(new Date($scope.getxq[i].assignDay)):'',

                            }
                            $scope.channelmaplists.push(channelist);
                        }
                        //$scope.channelmaplists=[];
                        if (!channelist) {
                            console.log(channelist)
                            $scope.channelmaplists = [];
                        }
                    } else {
                        $rootScope.tipService.setMessage(res.message, 'warning');
                    }
                })
        }
        }

    $scope.showtable=function(){
        $scope.Vacationtableshow = false;
        $scope.marketId = "";
        $scope.type= "";
        $scope.weekDay= "";
        $scope.assignDay = "";
        localStorageService.clear('userIdChecked');
        $scope.search();
    }

    //时间戳
    $scope.timestamp = function(stamp) {
        return timestamp.timestampCoverHms(stamp, 'all')
    }
    $scope.VacationaddSubmit = function () {
            var marketHolidayVIce = {
                marketId: $scope.marketId,
                subs: $scope.channelmaplists,
            }

            var json = {
                marketHolidayVIce: marketHolidayVIce
            }
        MarketManagementCtrlSer.VacationAddsub(json)
                .then(function (res) {
                    if (res.data.code == "000000") {
                        $scope.Vacationtableshow = false;
                        $rootScope.tipService.setMessage(res.data.message, 'warning');
                        localStorageService.clear('userIdChecked');
                        $scope.search();
                    }else{
                        $rootScope.tipService.setMessage(res.data.message, 'warning');
                    }
                }, function (error) {
                    $rootScope.tipService.setMessage(error.data.message, 'warning');
                })
    }
    $scope.Vacationaudit=function () {
        console.log($scope.applyHolidayId)
        if (!$scope.applyHolidayId) {
            $rootScope.tipService.setMessage('请先申请假期管理', 'warning');
        } else {
            var json={
                applyId:$scope.applyHolidayId
            }
        MarketManagementCtrlSer.VacationGetaudit(json)
            .then(function(res){
                console.log(res)
                if(res.data.code=="000000"){
                    var getData=JSON.parse(res.data.content);
                    $scope.getaduitDatalist=getData.holidayVs;
                    $scope.addEditText = "审核假期管理变更";
                    $scope.Vacationshow = true;
                    console.log($scope.getaduitDatalist)
                    /*for (var i = 0, r = $scope.getaduitDatalist.length; i < r; i++) {
                        if($scope.type==0){
                            $scope.showWeek=false;
                            $scope.hideTime=true;
                        }else if($scope.type==1){
                            $scope.hideTime=false;
                            $scope.showWeek=true;
                        }else{
                            $scope.showWeek=true;
                            $scope.hideTime=true;
                        }
                        $scope.weekDay = $scope.getaduitDatalist[i].weekDay;
                        $scope.assignDay = $scope.timestamp($scope.getaduitDatalist[i].assignDay);
                        $scope.holidayId=$scope.getaduitDatalist[i].holidayId;
                        $scope.marketId=$scope.getaduitDatalist[i].marketId;
                        $scope.type=parseInt($scope.getaduitDatalist[i].type);
                    }*/
                    $scope.channelmaplists = [];
                    for (var i = 0, r = $scope.getaduitDatalist.length; i < r; i++) {
                        var channelist = {
                            marketId: $scope.getaduitDatalist[i].marketId,
                            type: parseInt($scope.getaduitDatalist[i].type),
                            weekDay: parseInt($scope.getaduitDatalist[i].weekDay),
                            assignDay:($scope.getaduitDatalist[i].assignDay)? Date.parse(new Date($scope.getaduitDatalist[i].assignDay)):'',

                        }
                        $scope.channelmaplists.push(channelist);
                    }
                    //$scope.channelmaplists=[];
                    if (!channelist) {
                        console.log(channelist)
                        $scope.channelmaplists = [];
                    }
                } else {
                    $rootScope.tipService.setMessage(res.message, 'warning');
                }
            })
        }
    }

    $scope.auditRoletrueData = function (tmpOpt) {
        var json = {
            applyId: $scope.applyHolidayId,
            auditRs: tmpOpt
        };
        MarketManagementCtrlSer.VacationRoletruetion(json)
            .then(function (res) {
                if (res.data.code == '000000') {
                    $scope.Vacationshow = false;
                    localStorageService.clear('userIdChecked');
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                    $scope.search();
                } else {
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                }
            },function(error) {
                $rootScope.tipService.setMessage(error.data.message, 'warning');
            })
    }
    $scope.auditRolefalseData = function (tmpOpt) {
        var json = {
            applyId: $scope.applyHolidayId,
            auditRs: tmpOpt
        };
        MarketManagementCtrlSer.VacationRoletruetion(json)
            .then(function (res) {
                if (res.data.code == '000000') {
                    $scope.Vacationshow = false;
                    localStorageService.clear('userIdChecked');
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                    $scope.search();
                } else {
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                }
            },function(error) {
                $rootScope.tipService.setMessage(error.data.message, 'warning');
            })
    }
    $scope.channelmaplists=[];
    $scope.addrule = function() {
        if($scope.type==0){
            var SingleRuleData={
                marketId:$scope.marketId,
                type:$scope.type,
                weekDay:parseInt($scope.weekDay),
                assignDay:($scope.assignDay)? Date.parse(new Date($scope.assignDay)):'',
            }
        }else if($scope.type==1){
            var SingleRuleData={
                marketId:$scope.marketId,
                type:$scope.type,
                weekDay:parseInt($scope.weekDay),
                assignDay:($scope.assignDay)? Date.parse(new Date($scope.assignDay)):'',
            }
        }

        console.log(SingleRuleData)
        $scope.channelmaplists.push(SingleRuleData);
        console.log($scope.channelmaplists)
    };

    $scope.deletesd = function(index) {
        $scope.channelmaplists.splice(index, 1);
    };

    MarketManagementCtrlSer.searchlist()
        .then(function(res){
            if(res.code=="000000"){
                    $scope.markeTypetlist=JSON.parse(res.content);
                $scope.marketType = function (marketId){
                    if ($scope.markeTypetlist) {
                        for (var i = 0, r = $scope.markeTypetlist.length; i < r; i++) {
                            if ($scope.markeTypetlist[i].marketId == marketId) {
                                return $scope.markeTypetlist[i].marketName;
                            }
                        }
                    }
                }
            }
        })

    $scope.pass=function() {
        if (!$scope.chooseItemTab1) {
            $rootScope.tipService.setMessage('请先选择市场管理信息', 'warning');
        } else {
            var json={
                marketId:$scope.chooseItemTab1
            }
            MarketManagementCtrlSer.passCheck(json)
                .then(function (res) {
                    if (res.data.code == '000000') {
                        localStorageService.clear('userIdChecked');
                        $rootScope.tipService.setMessage(res.data.message, 'warning');
                        $scope.search();
                    } else {
                        $rootScope.tipService.setMessage(res.data.message, 'warning');
                    }
                }, function (error) {
                    $rootScope.tipService.setMessage(error.data.message, 'warning');
                });
        }
    }
    $scope.fail=function() {
        if (!$scope.chooseItemTab1) {
            $rootScope.tipService.setMessage('请先选择市场管理信息', 'warning');
        } else {
            var json={
                marketId:$scope.chooseItemTab1
            }
            MarketManagementCtrlSer.failedCheck(json)
                .then(function (res) {
                    if (res.data.code == '000000') {
                        localStorageService.clear('userIdChecked');
                        $rootScope.tipService.setMessage(res.data.message, 'warning');
                        $scope.search();
                    } else {
                        $rootScope.tipService.setMessage(res.data.message, 'warning');
                    }
                }, function (error) {
                    $rootScope.tipService.setMessage(error.data.message, 'warning');
                });
        }
    }
    $scope.open=function() {
        if (!$scope.chooseItemTab1) {
            $rootScope.tipService.setMessage('请先选择市场管理信息', 'warning');
        } else {
            var json={
                marketId:$scope.chooseItemTab1
            }
            MarketManagementCtrlSer.open(json)
                .then(function (res) {
                    if (res.data.code == '000000') {
                        localStorageService.clear('userIdChecked');
                        $rootScope.tipService.setMessage(res.data.message, 'warning');
                        $scope.search();
                    } else {
                        $rootScope.tipService.setMessage(res.data.message, 'warning');
                    }
                }, function (error) {
                    $rootScope.tipService.setMessage(error.data.message, 'warning');
                });
        }
    }

    $scope.close=function() {
        if (!$scope.chooseItemTab1) {
            $rootScope.tipService.setMessage('请先选择市场管理信息', 'warning');
        } else {
            confirmService.set('确认提示', '确定要注销此市场管理信息?', function () {
                var json={
                    marketId:$scope.chooseItemTab1
                }
                MarketManagementCtrlSer.Close(json)
                    .then(function (res) {
                        if (res.data.code == '000000') {
                            localStorageService.clear('userIdChecked');
                            $rootScope.tipService.setMessage(res.data.message, 'warning');
                            $scope.search();
                        } else {
                            $rootScope.tipService.setMessage(res.data.message, 'warning');
                        }
                    }, function (error) {
                        $rootScope.tipService.setMessage(error.data.message, 'warning');
                    });
                confirmService.clear();
            });
        }
    }

    $scope.allotTypeData=getadminState;
    $scope.allotTypeText = function(val) {
        for (var i = 0, r = $scope.allotTypeData.length; i < r; i++) {
            if (val == $scope.allotTypeData[i].id) {
                return $scope.allotTypeData[i].name;
            }
        }
    }
}])
    .factory('MarketManagementCtrlSer', ['$http', 'localStorageService', 'myHttp', '$q', '$rootScope', function ($http, localStorageService, myHttp, $q, $rootScope) {
        return {
            //查询
            search: function (json) {
                var deferred = $q.defer();
                myHttp.post("admin/config/product/market/query/page", json)
                    .then(function (res) { // 调用承诺API获取数据 .resolve
                        deferred.resolve(res);
                    }, function (res) { // 处理错误 .reject
                        deferred.reject(res);
                    });
                return deferred.promise;
            },
            //查询
            searchlist: function () {
                var deferred = $q.defer();
                myHttp.post("admin/config/product/market/query/list")
                    .then(function (res) { // 调用承诺API获取数据 .resolve
                        deferred.resolve(res);
                    }, function (res) { // 处理错误 .reject
                        deferred.reject(res);
                    });
                return deferred.promise;
            },
            Addsub: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'admin/config/product/market/create',
                    data: json
                }).then(function successCallback(response) {
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
            VacationAddsub: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'admin/config/market/time/holiday/apply',
                    data: json
                }).then(function successCallback(response) {
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
            applysub: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'admin/config/market/time/apply',
                    data: json
                }).then(function successCallback(response) {
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
            editsub: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'admin/config/product/market/update',
                    data: json
                }).then(function successCallback(response) {
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
           get: function (json) {
                   var deferred = $q.defer();
                   $http({
                       method: 'POST',
                       url: $rootScope.baseUrl + 'admin/config/market/time/holiday/get',
                       data: json
                   }).then(function successCallback(response) {
                       deferred.resolve(response);
                   }, function errorCallback(response) {
                       deferred.reject(response);
                   });
                   return deferred.promise;
               },
            Getaudit: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'admin/config/market/time/apply/get',
                    data: json
                }).then(function successCallback(response) {
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
            Roletruetion: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'admin/config/market/time/audit',
                    data: json
                }).then(function successCallback(response) {
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
            VacationGetaudit: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'admin/config/market/time/holiday/apply/get',
                    data: json
                }).then(function successCallback(response) {
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
            VacationRoletruetion: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'admin/config/market/time/holiday/audit',
                    data: json
                }).then(function successCallback(response) {
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
            Close: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'admin/config/product/market/close',
                    data: json
                }).then(function successCallback(response) {
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
            //通过
            passCheck: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'admin/config/product/market/pass',
                    data: json
                }).then(function successCallback(response) {
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
            //不通过
            failedCheck: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'admin/config/product/market/fail',
                    data: json
                }).then(function successCallback(response) {
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
            //重新提交
            open: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'admin/config/product/market/open',
                    data: json
                }).then(function successCallback(response) {
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
        }
    }])