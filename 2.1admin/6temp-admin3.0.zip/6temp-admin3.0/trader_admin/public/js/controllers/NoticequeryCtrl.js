app.controller('NoticequeryCtrl', ['$scope', '$state', '$rootScope', 'localStorageService', 'NoticequeryCtrlSer', 'getPageNum', 'confirmService', 'noticeState', 'timestamp', function($scope, $state, $rootScope, localStorageService, NoticequeryCtrlSer, getPageNum, confirmService, noticeState, timestamp) {
		$scope.toggleTraderSearchState = false;
		$scope.Toggle = function() {
			$scope.toggleTraderSearchState = !$scope.toggleTraderSearchState;
			if ($scope.toggleTraderSearchState) {
				$('.search_column').css('height', 'auto');
			} else {
				$('.search_column').css('height', '36px');
			}
		};
		$scope.title = "";
		$scope.searchUserStatesTab1 = "";
		//页面跳转
		$scope.trunPage = function(url) {
				$state.go(url);
			}
			//获取状态显示
		$scope.customerStateList = noticeState;
		console.log($scope.customerStateList)
			//$scope.customerStateList =;

		$scope.ddrangaa = 1;
		$scope.ddrangcc = function(num) {
			$scope.ddrangaa = num;
			console.log($scope.ddrangaa)
		}

		//全部
		$scope.search = function(type, num) {
			$scope.toggleTraderSearchState=false;
			$('.search_column').css('height', '36px');
			if (type == 'search') {
				pageInitialize()
			};
			if ($scope.ddrangaa == 1) {
				NoticequeryCtrlSer.Orgsearch($scope.showNum.showNum, $scope.currentPage, $scope.title, $scope.searchUserStatesTab1)
					.then(function(res) {
						console.log(res)
						if (res.code === '000000') {
							$scope.showPage = true;
							$scope.NoticeResult = JSON.parse(res.content).content;
							$scope.dataNum = JSON.parse(res.content).totalElements;
							$scope.PageNum();
							console.log($scope.dataNum)
						} else {
							$rootScope.tipService.setMessage(res.message, 'warning');
						}
					}, function(error) {
						$rootScope.tipService.setMessage(error.message, 'warning');
					});
			} else if ($scope.ddrangaa == 2) {
				NoticequeryCtrlSer.Departmentsearch($scope.showNum.showNum, $scope.currentPage, $scope.title, $scope.searchUserStatesTab1)
					.then(function(res) {
						console.log(res)
						if (res.code === '000000') {
							console.log(222)
							$scope.showPage = true;
							$scope.NoticeResult = JSON.parse(res.content).content;
							$scope.dataNum = JSON.parse(res.content).totalElements;
							$scope.PageNum();
							//console.log($scope.NoticeResult)
						} else {
							$rootScope.tipService.setMessage(res.message, 'warning');
						}
					}, function(error) {
						$rootScope.tipService.setMessage(error.message, 'warning');
					});
			} else if ($scope.ddrangaa == 3) {
				NoticequeryCtrlSer.search($scope.showNum.showNum, $scope.currentPage, $scope.title, $scope.searchUserStatesTab1)
					.then(function(res) {
						console.log(res)
						if (res.code === '000000') {
							console.log(111)
							$scope.showPage = true;
							$scope.NoticeResult = JSON.parse(res.content).content;
							$scope.dataNum = JSON.parse(res.content).totalElements;
							$scope.PageNum();
							//console.log($scope.NoticeResult)
						} else {
							$rootScope.tipService.setMessage(res.message, 'warning');
						}
					}, function(error) {
						$rootScope.tipService.setMessage(error.message, 'warning');
					});
			}
		}

		//状态互换
		$scope.getState = function(state) {
				for (var i = 0, r = $scope.customerStateList.length; i < r; i++) {
					if ($scope.customerStateList[i].val == state) {
						return $scope.customerStateList[i].name;

					}
				}
			}
			//时间戳
		$scope.timestamp = function(stamp) {
				return timestamp.timestampCoverHms(stamp, 'all')
			}
			//单选
		$scope.chooseNoticeId = null;
		$scope.checkedTab1 = function(index, noticeId) {
			$scope.chooseNoticeId = noticeId;
			$scope.noticeId = $scope.NoticeResult[index].noticeId;
			$('#dataReport input[type=checkbox]').prop('checked', false);
			$('#dataReport input[type=checkbox]').eq(index).prop('checked', true);
			console.log($scope.chooseNoticeId)
		}

		//删除
		$scope.delete = function() {
				if (!$scope.chooseNoticeId) {
					$rootScope.tipService.setMessage('请先选择公告', 'warning');
				} else {
					confirmService.set('确认提示', '确定要删除此公告?', function() {
						NoticequeryCtrlSer.Delete($scope.noticeId)
							.then(function(res) {
								if (res.data.code == "000000") {
									$rootScope.tipService.setMessage(res.data.message, 'warning');
									$scope.search();
								} else {
									$rootScope.tipService.setMessage(res.data.message, 'warning');
								}
							}, function(error) {
								$rootScope.tipService.setMessage(error.data.message, 'warning');
							});
						confirmService.clear();
					});
				}
			}
			//销毁
		$scope.destroy = function() {
				if (!$scope.chooseNoticeId) {
					$rootScope.tipService.setMessage('请先选择公告', 'warning');
				} else {
					confirmService.set('确认提示', '确定要销毁此公告?', function() {
						NoticequeryCtrlSer.Destroy($scope.noticeId)
							.then(function(res) {
								if (res.data.code == "000000") {
									$rootScope.tipService.setMessage(res.data.message, 'warning');
									$scope.search();
								} else {
									$rootScope.tipService.setMessage(res.data.message, 'warning');
								}
							}, function(error) {
								$rootScope.tipService.setMessage(error.data.message, 'warning');
							});
						confirmService.clear();
					});
				}
			}
			//审核通过
		$scope.passCheck = function(noticeId) {
				confirmService.set('确认提示', '确定审核通过此公告?', function() {
					NoticequeryCtrlSer.passCheck(noticeId)
						.then(function(res) {
							if (res.data.code == "000000") {
								$rootScope.tipService.setMessage(res.data.message, 'warning');
								$scope.search();
							} else {
								$rootScope.tipService.setMessage(res.data.message, 'warning');
							}
						}, function(error) {
							$rootScope.tipService.setMessage(error.data.message, 'warning');
						});
					confirmService.clear();
				});
			}
			//审核驳回
		$scope.failedCheck = function(noticeId) {
				confirmService.set('确认提示', '确定审核驳回此公告?', function() {
					NoticequeryCtrlSer.failedCheck(noticeId)
						.then(function(res) {
							if (res.data.code == "000000") {
								$rootScope.tipService.setMessage(res.data.message, 'warning');
								$scope.search();
							} else {
								$rootScope.tipService.setMessage(res.data.message, 'warning');
							}
						}, function(error) {
							$rootScope.tipService.setMessage(error.data.message, 'warning');
						});
					confirmService.clear();
				});
			}
			//冻结
		$scope.freeze = function(noticeId) {
				confirmService.set('确认提示', '确定要冻结此公告?', function() {
					NoticequeryCtrlSer.Freezen(noticeId)
						.then(function(res) {
							if (res.data.code == "000000") {
								$rootScope.tipService.setMessage(res.data.message, 'warning');
								$scope.search();
							} else {
								$rootScope.tipService.setMessage(res.data.message, 'warning');
							}
						}, function(error) {
							$rootScope.tipService.setMessage(error.data.message, 'warning');
						});
					confirmService.clear();
				});
			}
			//解冻
		$scope.unfreeze = function(noticeId) {
				confirmService.set('确认提示', '确定要解冻此公告?', function() {
					NoticequeryCtrlSer.unFreezen(noticeId)
						.then(function(res) {
							if (res.data.code == "000000") {
								$rootScope.tipService.setMessage(res.data.message, 'warning');
								$scope.search();
							} else {
								$rootScope.tipService.setMessage(res.data.message, 'warning');
							}
						}, function(error) {
							$rootScope.tipService.setMessage(error.data.message, 'warning');
						});
					confirmService.clear();
				});
			}
			//重新提交
		$scope.rePassCheck = function(noticeId) {
			NoticequeryCtrlSer.PassCheck(noticeId)
				.then(function(res) {
					if (res.data.code == "000000") {
						$rootScope.tipService.setMessage(res.data.message, 'warning');
						$scope.search();
					} else {
						$rootScope.tipService.setMessage(res.data.message, 'warning');
					}
				}, function(error) {
					$rootScope.tipService.setMessage(error.data.message, 'warning');
				});
		}



		//修改
		$scope.edit = function(url) {
			if ($scope.chooseNoticeId == null) {
				$rootScope.tipService.setMessage('请先选择公告', 'warning');
			} else {
				localStorageService.update('NTchooseNoticeId', $scope.chooseNoticeId);
				$state.go(url);
			}
		}



		/* 分页功能实现 */
		var pageInitialize = function() {
			$scope.dataNum = 0; //数据总条数
			$scope.dataPage = 0; //分页数
			$scope.currentPage = 1; //当前页数
			$scope.jumpPageNum = '';
		}
		$scope.showDataChoose = getPageNum.pageNum(); //获取分页
		$scope.showNum = $scope.showDataChoose[0]; //初始显示刷具条数
		$scope.dataPageNumber = []; //生成页面数
		$scope.showPage = false;
		$scope.pageSelect = function(params) {
			console.log(params);
			$scope.showNum.showNum = params.showNum;
			pageInitialize();
			$scope.search();
		}
		$scope.changePageNumber = function(params) {
			$scope.currentPage = params;
			$scope.search();
			$scope.PageNum();
		}
		$scope.PageNum = function() {
			if ($scope.showNum.showNum < $scope.dataNum) {
				$scope.dataPage = parseInt($scope.dataNum / $scope.showNum.showNum) + 1;
			} else {
				$scope.dataPage = 0;
			}
			$scope.dataPageNumber = [];
			for (var i = 0; i < $scope.dataPage; i++) {
				$scope.dataPageNumber.push(i + 1);
			}
		}
		$scope.jumpPage = function(num) {
			num = parseInt(num);
			if (parseInt(num, 10) === num && num <= ($scope.dataPage + 1) && num > 0) {
				$scope.currentPage = num;
				$scope.PageNum();
				$scope.search();
			}
		}
		$scope.pageSlect = function(type) {
			if (type == 'prev') {
				if ($scope.currentPage != 1) {
					$scope.currentPage--;
					$scope.PageNum();
					$scope.search();
				}
			} else {
				if ($scope.currentPage < $scope.dataPage) {
					$scope.currentPage++;
					$scope.PageNum();
					$scope.search();
				}
			}
		}
		pageInitialize();
		//$scope.search();
	}])
	.factory('NoticequeryCtrlSer', ['$http', 'localStorageService', 'myHttp', '$q', '$rootScope', function($http, localStorageService, myHttp, $q, $rootScope) {
		return {
			search: function(showNum, nowPage, title, searchUserStatesTab1) {
				var json = {
					page: nowPage,
					rows: showNum,
					order: 'desc',
					sort: 'createTime',
					search_A_LIKE_title: (title) ? title : '',
					search_A_EQ_state: (searchUserStatesTab1) ? searchUserStatesTab1 : ''
				}

				var deferred = $q.defer();
				myHttp.post("notice/query/as/list", json)
					.then(function(res) { // 调用承诺API获取数据 .resolve
						deferred.resolve(res);
					}, function(res) { // 处理错误 .reject
						deferred.reject(res);
					});
				return deferred.promise;
			},
			//部门
			Departmentsearch: function(showNum, nowPage, title, searchUserStatesTab1) {
				var json = {
					page: nowPage,
					rows: showNum,
					order: 'desc',
					sort: 'createTime',
					search_A_LIKE_title: (title) ? title : '',
					search_A_EQ_state: (searchUserStatesTab1) ? searchUserStatesTab1 : ''
				}

				var deferred = $q.defer();
				myHttp.post("notice/query/as/list/orgid", json)
					.then(function(res) { // 调用承诺API获取数据 .resolve
						deferred.resolve(res);
					}, function(res) { // 处理错误 .reject
						deferred.reject(res);
					});
				return deferred.promise;
			},
			//全部
			Orgsearch: function(showNum, nowPage, title, searchUserStatesTab1) {
				var json = {
					page: nowPage,
					rows: showNum,
					order: 'desc',
					sort: 'createTime',
					search_A_LIKE_title: (title) ? title : '',
					search_A_EQ_state: (searchUserStatesTab1) ? searchUserStatesTab1 : ''
				}

				var deferred = $q.defer();
				myHttp.post("notice/query/as/list/orgcode", json)
					.then(function(res) { // 调用承诺API获取数据 .resolve
						deferred.resolve(res);
					}, function(res) { // 处理错误 .reject
						deferred.reject(res);
					});
				return deferred.promise;
			},
			Delete: function(noticeId) {
				var deferred = $q.defer();
				$http({
					method: 'POST',
					url: $rootScope.baseUrl + 'notice/delete',
					data: {
						key: noticeId
					}
				}).then(function successCallback(response) {
					deferred.resolve(response);
				}, function errorCallback(response) {
					deferred.reject(response);
				});
				return deferred.promise;
			},
			//
			passCheck: function(noticeId) {
				var json = {
					key: noticeId
				}
				var deferred = $q.defer();
				$http({
					method: 'POST',
					url: $rootScope.baseUrl + 'notice/pass',
					data: json
				}).then(function successCallback(response) {
					deferred.resolve(response);
				}, function errorCallback(response) {
					deferred.reject(response);
				});
				return deferred.promise;
			},
			//
			failedCheck: function(noticeId) {
				var json = {
					key: noticeId
				}
				var deferred = $q.defer();
				$http({
					method: 'POST',
					url: $rootScope.baseUrl + 'notice/fail',
					data: json
				}).then(function successCallback(response) {
					deferred.resolve(response);
				}, function errorCallback(response) {
					deferred.reject(response);
				});
				return deferred.promise;
			},
			//销毁
			Destroy: function(noticeId) {
				var json = {
					key: noticeId
				}
				var deferred = $q.defer();
				$http({
					method: 'POST',
					url: $rootScope.baseUrl + 'notice/close',
					data: json
				}).then(function successCallback(response) {
					deferred.resolve(response);
				}, function errorCallback(response) {
					deferred.reject(response);
				});
				return deferred.promise;
			},
			//
			Freezen: function(noticeId) {
				var json = {
					key: noticeId
				}
				var deferred = $q.defer();
				$http({
					method: 'POST',
					url: $rootScope.baseUrl + 'notice/freezing',
					data: json
				}).then(function successCallback(response) {
					deferred.resolve(response);
				}, function errorCallback(response) {
					deferred.reject(response);
				});
				return deferred.promise;
			},
			//
			unFreezen: function(noticeId) {
				var json = {
					key: noticeId
				}
				var deferred = $q.defer();
				$http({
					method: 'POST',
					url: $rootScope.baseUrl + 'notice/unfreezing',
					data: json
				}).then(function successCallback(response) {
					deferred.resolve(response);
				}, function errorCallback(response) {
					deferred.reject(response);
				});
				return deferred.promise;
			},
			//
			PassCheck: function(noticeId) {
				var json = {
					key: noticeId
				}
				var deferred = $q.defer();
				$http({
					method: 'POST',
					url: $rootScope.baseUrl + 'notice/open',
					data: json
				}).then(function successCallback(response) {
					deferred.resolve(response);
				}, function errorCallback(response) {
					deferred.reject(response);
				});
				return deferred.promise;
			},
			getNTInfo: function(noticeId) {
				var json = {
					key: noticeId
				}
				var deferred = $q.defer();
				$http({
					method: 'POST',
					url: $rootScope.baseUrl + 'notice/read',
					data: json
				}).then(function successCallback(response) {
					console.log(response)
					deferred.resolve(response);
				}, function errorCallback(response) {
					deferred.reject(response);
				});
				return deferred.promise;
			},
		}
	}])