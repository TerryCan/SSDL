app.controller('productClassificationAddCtrl', ['$scope', '$rootScope', '$state', 'productClassificationCtrlSer', 'dataSer', 'getCurrencyType', 'getPageNum', 'tipService', 'confirmService', 'getProductScope', 'productClassificationAddCtrlSer', 'getweekType', 'get24h', 'CurrencysettingsCtrlSer', 'marketMappingCtrlSer','memberMangerCtrlSer', function($scope, $rootScope, $state, productClassificationCtrlSer, dataSer, getCurrencyType, getPageNum, tipService, confirmService, getProductScope, productClassificationAddCtrlSer, getweekType, get24h, CurrencysettingsCtrlSer, marketMappingCtrlSer,memberMangerCtrlSer) {
			$scope.getweekType = getweekType;
			$scope.get24h = get24h;
			$scope.mySel = true;
			$scope.hidetime= true;

			//机构列表
			$scope.addOrgVal = ''; //显示值
			$scope.addOptOrgVal = '';
			$scope.orgCode = '';
			$scope.orgOptCode = '';
			$scope.orgId = ''; //选择值
			$scope.orgOptId = '';
			dataSer.organizeQuerySer()
				.then(function(res) {
					$scope.orgList = res;
				});
			$scope.addOrgValFTC = function(d) {
					$scope.addOrgVal = d.text;
					$scope.orgId = d.orgId;
					$scope.orgCode = d.orgCode;
					$scope.orgNum = d.orgNum;
				}
				//获取币种
			getCurrencyType.then(function(res) {
					$scope.getCurrencybz = JSON.parse(res.content);
					console.log($scope.getCurrencybz)
				});
			$scope.getCurrency = function(parameter) {
				for (var i = 0; i < $scope.getCurrencybz.length; i++) {
					if (parameter == $scope.getCurrencybz[i].id) {
						return $scope.getCurrencybz[i].name;
					}
				}
			}
			memberMangerCtrlSer.search(9999,1,'','','')
			.then(function(res){
				$scope.meborgList = JSON.parse(res.content).content;
				console.log($scope.meborgList)
			})

			$scope.getOrgVal = function(orgCode) {
				if($scope.meborgList){
				for (var i = 0; i < $scope.meborgList.length; i++) {
					if (orgCode == $scope.meborgList[i].orgCode) {
						return $scope.meborgList[i].orgNum;
					}
					}
				}
			}
			$scope.ProductScope = getProductScope; //获取产品作用域

			//绑定参数
			$scope.productCustomizedId = "";
			$scope.productName = ''; //产品名
			$scope.productCode = ''; //产品代码
			$scope.contractNum = ''; //合约大小
			$scope.productCurrency = ''; //产品币种
			$scope.effectType = ''; //作用类型
			$scope.interestMin= '';//仓息最小值
			$scope.interestMax= '';//仓息最大值
			$scope.keepDepositMin= '';//维持保证金最小值
			$scope.keepDepositMax= '';//维持保证金最大值
			$scope.poundageMin= '';//手续费最小值
			$scope.poundageMax= '';//手续费最大值
    		$scope.considerationNum= '';
			$scope.custonchange = function() {
				if ($scope.customizedType == "true") {
					$scope.addwtime = false;
					$scope.hidetime= true;
					$scope.CSTimes = 0;
					document.getElementById('OpeningandclosingtimeData2').style.height="calc(100vh - 550px)";
				} else {
					document.getElementById('OpeningandclosingtimeData2').style.height="calc(100vh - 588px)";
					$scope.addwtime = true;
					$scope.hidetime= false;
					$scope.CSTimes = '1970-01-01';

				}
			}

			$scope.addProduct = function() {
				var product = {
					productId: $scope.productId,
					productName: $scope.productName,
					productCode: $scope.productCode,
					orgId: $scope.orgId,
					orgCode: $scope.orgCode,
					contractNum: $scope.contractNum,
					productCurrency: $scope.productCurrency,
					effectType: $scope.effectType,
					interestMin:$scope.interestMin,//仓息最小值
					interestMax:$scope.interestMax,//仓息最大值
					keepDepositMin:$scope.keepDepositMin,//维持保证金最小值
					keepDepositMax:$scope.keepDepositMax,//维持保证金最大值
					poundageMin:$scope.poundageMin,//手续费最小值
					poundageMax:$scope.poundageMax,//手续费最大值
					considerationNum:parseInt($scope.considerationNum),
				}
				if (toValidate('#formAdd')) {
					productClassificationAddCtrlSer.add(product/*, productCustomized*/)
						.then(function(res) {
							if (res.data.code == '000000') {
								$rootScope.tipService.setMessage(res.data.message, 'warning');
								$state.go('tabs.productClassification');
							} else {
								$rootScope.tipService.setMessage(res.data.message, 'warning');
							}
						});
				}
			}
			$scope.goBack = function() {
				$state.go('tabs.productClassification');
			}
	}])
	.factory('productClassificationAddCtrlSer', ['$http', 'localStorageService', 'myHttp', '$q', '$rootScope', function($http, localStorageService, myHttp, $q, $rootScope) {
		return {
			add: function(product/*, productCustomized*/) {
				var deferred = $q.defer();
				$http({
					method: 'POST',
					url: $rootScope.baseUrl + 'config/product/create',
					data: {
						"product": product
						//"productCustomized": productCustomized
					}
				}).then(function successCallback(response) {
					deferred.resolve(response);
				}, function errorCallback(response) {
					deferred.reject(response);
				});
				return deferred.promise;
			}
		}
	}])