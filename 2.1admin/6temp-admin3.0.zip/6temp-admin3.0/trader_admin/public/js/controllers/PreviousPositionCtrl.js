app.controller('PreviousPositionCtrl', ['$scope', '$rootScope', 'PreviousPositionData', '$timeout', 'getPageNum', 'productManageSer','localStorageService', function ($scope, $rootScope, PreviousPositionData, $timeout, getPageNum, productManageSer,localStorageService) {
    $scope.toggleTraderSearchState=false;
    $scope.Toggle = function(){
        $scope.toggleTraderSearchState = !$scope.toggleTraderSearchState;
        if($scope.toggleTraderSearchState){
           $('.search_column').css('height','auto');
        }
        else{
           $('.search_column').css('height','36px');
        }
    };
    // 商品信息
    productManageSer.productSearch()
        .then(function (response) {
            console.log(response);
            $scope.productList = response.list;
            //console.log($scope.productList)
        });
    $scope.transformProduct = function (productId) {
        for (var i = 0, r = $scope.productList.length; i < r; i++) {
            if (productId == $scope.productList[i].key) {
                return $scope.productList[i].market + '-' + $scope.productList[i].commodity + '-' + $scope.productList[i].contract;
            }
        }
    };
    //过滤字段
    $scope.Account = '';
    $scope.Direct = '';
    $scope.search = function () {
        $scope.toggleTraderSearchState=false;
        $('.search_column').css('height','36px');
        PreviousPositionData.search($scope.Account, $scope.directiveProductId, $scope.Direct)
            .then(function (res) {
                console.log(res);
                if (res.data.retMsg.code == '000000') {
                    $scope.searchResult = res.data.list;
                    pageJump($scope.searchResult);
                } else {
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                }
            }, function (error) {
                $rootScope.tipService.setMessage(error.data.message, 'warning');
            });
    };
    // 分页
    var pageJump = function (tmpArrList) {
        $timeout(function () {
            if (tmpArrList != undefined) {
                console.log(tmpArrList);
                $scope.currentPage = 1; //当前页数
                $scope.dataNum = tmpArrList.length;
                $scope.showDataChoose = getPageNum.pageNum(); //获取分页
                $scope.showNum = $scope.showDataChoose[0]; //初始显示刷具条数
                $scope.showPage = false;
                $timeout(function () {
                    $scope.showPage = true;
                    $scope.copyDataArray = tmpArrList.slice(0, 14); //初始15条数据
                }, 10)
                $scope.dataPage = Math.ceil($scope.dataNum / $scope.showNum.showNum);

                //上下页
                $scope.pageSlect = function (type) {
                    if (type == 'prev') {
                        if ($scope.currentPage != 1) {
                            $scope.currentPage--;
                            $scope.turnPage();
                        } else {
                            $scope.copyDataArray = tmpArrList.slice(0, 14); //初始15条数据
                        }
                    } else {
                        if ($scope.currentPage < $scope.dataPage) {
                            $scope.currentPage++;
                            $scope.turnPage();
                        }
                    }
                }
                //每页数据量
                $scope.baseDataArray = [];
                $scope.copyDataArray = [];
                $scope.pageSelect = function (params) {
                    $scope.showNum.showNum = params.showNum;
                    $scope.copyDataArray = tmpArrList.slice(0, (params.showNum - 1));
                    $scope.dataPage = Math.ceil($scope.dataNum / $scope.showNum.showNum);
                    $scope.currentPage = 1;
                }
                $scope.turnPage = function () {
                    $scope.copyDataArray = tmpArrList.slice((($scope.currentPage - 1) * 15), (($scope.currentPage + 1) * 15 - 1));
                }
                //固定页面跳转
                $scope.jumpPage = function (num) {
                    num = parseInt(num);
                    if (parseInt(num, 10) === num && num <= ($scope.dataPage + 1) && num > 0) {
                        $scope.currentPage = num;
                        $scope.jumpPageNum = '';
                        $scope.turnPage();
                    } else {
                        $scope.copyDataArray = tmpArrList.slice(0, 14); //初始15条数据
                    }
                }
            } else {
                pageJump(tmpArrList);
            }
        }, 200);
    };
}])
    .factory('PreviousPositionData', ['$http', 'localStorageService', 'myHttp', '$q', '$rootScope', function ($http, localStorageService, myHttp, $q, $rootScope) {
        return {
            search: function (Account, directiveProductId, Direct) {
                /*
                 **查询条件
                 *0等于(默认值)
                 *1包含字符串
                 *3大于等于
                 *4小于等于
                 */
                var deferred = $q.defer();
                var filterJson = [{
                    "value": Account,
                    "condition": 0,
                    "name": "Account"
                }, {
                    "value": directiveProductId,
                    "condition": 0,
                    "name": "ProductId"
                }, {
                    "value": Direct,
                    "condition": 0,
                    "name": "Direct"
                }];

                function filterInfo(arr) {
                    var tmpArr = [];
                    for (var i = 0, r = arr.length; i < r; i++) {
                        if (arr[i].value != undefined && arr[i].value != '') {
                            tmpArr.push({
                                "field": arr[i].name,
                                "value": arr[i].value,
                                "condition": arr[i].condition
                            });
                        }
                    }
                    return tmpArr;
                }

                var qryConditions = {
                    "qryConditions": filterInfo(filterJson)
                }
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'admin/trade/query/up/position',
                    data: qryConditions
                }).then(function successCallback(response) {
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            }
        }
    }])