app.controller('CustomerDealCtrl', ['$rootScope', '$scope', 'getPageNum', 'CustomerDealData', 'getCurrencyType', 'getOrderDirect', 'timestamp', 'getOrderReason', 'getRequestType','localStorageService', function ($rootScope, $scope, getPageNum, CustomerDealData, getCurrencyType, getOrderDirect, timestamp, getOrderReason, getRequestType,localStorageService) {
    $scope.toggleTraderSearchState=false;
    $scope.Toggle = function(){
        $scope.toggleTraderSearchState = !$scope.toggleTraderSearchState;
        if($scope.toggleTraderSearchState){
           $('.search_column').css('height','auto');
        }
        else{
           $('.search_column').css('height','36px');
        }
    };
    //买卖方向
    $scope.orderDirect = getOrderDirect;
    //报单
    $scope.OrderReason = getOrderReason;
    //触发类型
    $scope.OrderRequestType = getRequestType;
    //获取币种
    getCurrencyType.then(function (res) {
        $scope.getCurrencyType = JSON.parse(res.content);
        console.log($scope.getCurrencyType);
    });

    var processContent,processTotal;
    var source = {
        type: 'POST',
        datatype: "json",
        datafields: [  //数据字段定义
            {name: 'localOrderId', type: 'string'},

            {name: 'matchNo', type: 'string'},
            {name: 'localOrderNo', type: 'string'},
            {name: 'userName', type: 'string'},
            {name: 'productName', type: 'string'},
            {name: 'productCode', type: 'string'},

            {name: 'matchFeeCurrency', type: 'string'},
            {name: 'reason', type: 'string'},
            {name: 'requestType', type: 'string'},
            {name: 'orderDirect', type: 'string'},
            {name: 'matchVolume', type: 'int'},

            {name: 'matchPrice', type: 'int'},
            {name: 'matchFee', type: 'int'},
            {name: 'createTime', type: 'string'}

        ],
        url: $rootScope.baseUrl + 'admin/trade/match/query/as/page',
        root: "content",
        pagesize:10,
        processData: function (data) {
            data.page = (data.pagenum + 1)?(data.pagenum + 1):1;
            data.rows =(data.pagesize)?(data.pagesize):10;
            data.order =($scope.order)?$scope.order:'desc';
            data.sort =($scope.sort)?$scope.sort:'createTime';
            data.search_A_EQ_userId = ($scope.directiveUserId) ? $scope.directiveUserId : '';
            data.search_A_EQ_orderDirect = ($scope.SearchOrderDirect) ? $scope.SearchOrderDirect : '';
            data.search_A_GTE_createTime = ($scope.createTimeStart) ? $scope.createTimeStart : '';
            data.search_A_LTE_createTime = ($scope.createTimeEnd) ? $scope.createTimeEnd : '';
            data.search_A_EQ_matchFeeCurrency= ($scope.SearchCurrencyType)?$scope.SearchCurrencyType : '';
            data.search_A_EQ_reason = ($scope.orderReason) ? $scope.orderReason : '';

            $scope.orgCode = localStorageService.get('oldOrgCode');
            if ($scope.organizeValue == true && $scope.downOrganizeValue == true) {
                data.search_A_LLIKE_orgCode = ($scope.orgCode) ? $scope.orgCode : '';
            }
            if ($scope.organizeValue == true && $scope.downOrganizeValue == false) {
                data.search_A_EQ_orgCode = ($scope.orgCode) ? $scope.orgCode : '';
            }
            if ($scope.organizeValue == false && $scope.downOrganizeValue == true) {
                data.search_A_LLIKE_orgCode = ($scope.orgCode) ? $scope.orgCode + '-' : '';
            }
        },
        beforeprocessing: function (data) {
            var processData = JSON.parse(data.content);
            console.log(processData);
            processContent = processData.content;
            source.totalrecords = processData.totalElements == 0 ? 5 : processData.totalElements;
            processTotal = processData.totalElements;
        },
        beforeLoadComplete: function (records) { //数据完全加载完执行绘制表格
            var start;
            for (var i in records) {
                start = parseInt(i);
                break;
            }
            for (var k = 0, r = processContent.length; k < r; k++) {
                records[start + k].localOrderId = processContent[k].localOrderId;

                records[start + k].matchNo = processContent[k].matchNo;
                records[start + k].localOrderNo = processContent[k].localOrderNo;
                records[start + k].userName = processContent[k].userName;
                records[start + k].productName = processContent[k].productName;
                records[start + k].productCode = processContent[k].productCode;

                records[start + k].matchFeeCurrency = processContent[k].matchFeeCurrency;
                records[start + k].requestType = processContent[k].requestType;
                records[start + k].reason = processContent[k].reason;
                records[start + k].orderDirect = processContent[k].orderDirect;
                records[start + k].matchVolume = processContent[k].matchVolume;

                records[start + k].matchPrice = processContent[k].matchPrice;
                records[start + k].matchFee = processContent[k].matchFee;
                records[start + k].createTime = processContent[k].createTime;
            }
        },
        loadComplete: function (records) {
            $scope.saveResult=JSON.parse(records.content);
            var data =  $scope.saveResult.totalElements;
            if (data == 0) {
                $('#contenttableentrustDetailGrid > div').remove();
            }
        },
        endUpdate: true
    };

    //创建数据适配器
    var dataAdapter = null;
    $scope.searchAjax = function () {
        $scope.toggleTraderSearchState = false;
        $('.search_column').css('height', '36px');
        if (dataAdapter == null) {
            dataAdapter = new $.jqx.dataAdapter(source);
            //创建表格
            $("#entrustDetailGrid").jqxGrid({
                source: dataAdapter,//数据源
                columns: [  //表格数据域
                    {
                        text: '外部成交单号',
                        datafield: 'matchNo',
                        width: '14%',
                        align: 'center'//设置表头
                    },
                    {
                        text: '委托单号',
                        datafield: 'localOrderNo',
                        align: 'center',
                        width: '13%'
                    },
                    {
                        text: '用户名',
                        datafield: 'userName',
                        width:'6%',
                        align: 'center'
                    },
                    {
                        text: '商品名',
                        datafield: 'productName',
                        align: 'center',
                        width:'9%'
                    },
                    {
                        text: '商品代码',
                        datafield: 'productCode',
                        align: 'center',
                        width:'9%'
                    },
                    {
                        text: '币种',
                        datafield: 'matchFeeCurrency',
                        align: 'center',
                        width:'5%',
                        cellsrenderer: function (row, columnfield, value, defaulthtml, columnproperties) {
                            if ($scope.getCurrencyType) {
                                for (var i = 0; i < $scope.getCurrencyType.length; i++) {
                                    if (value == $scope.getCurrencyType[i].currency) {
                                        return $scope.getCurrencyType[i].currencyName;
                                    }
                                }
                            }
                        }
                    },
                    {
                        text: '买卖方向',
                        datafield: 'orderDirect',
                        align: 'center',
                        width:'5%',
                        cellsrenderer: function (row, columnfield, value, defaulthtml, columnproperties) {
                            if ($scope.orderDirect) {
                                for (var i = 0; i < $scope.orderDirect.length; i++) {
                                    if (value == $scope.orderDirect[i].id) {
                                        return $scope.orderDirect[i].name;
                                    }
                                }
                            }
                        }
                    },
                    {
                        text: '手数',
                        datafield: 'matchVolume',
                        align: 'center',
                        width:'9%'
                    },
                    {
                        text: '价格',
                        datafield: 'matchPrice',
                        align: 'center',
                        width:'9%'
                    },
                    {
                        text: '手续费',
                        datafield: 'matchFee',
                        align: 'center',
                        width:'9%'
                    },
                    {
                        text: '成交时间',
                        datafield: 'createTime',
                        align: 'center',
                        width:'12%',
                        cellsrenderer: function (row, columnfield, value, defaulthtml, columnproperties) {
                            return timestamp.timestampCoverHms(value, 'all');
                        }
                    }
                ],
                width: 100 + '%',
                height: 87 + '%',
                theme:'metrodark',
                virtualmode: true,
                rendergridrows: function (params) {
                    return params.data;
                },
                pageable: true,//是否分页数
                pagesizeoptions: ['10','30','100','200'], //分页选项
                sortable: true,//是否排序
                // altrows: true,
                enablebrowserselection: true,//数据可选
                columnsresize: true,//列间距是否可调整
                selectionmode: 'singlecell',//选择模式
                clipboard: true
            });
        }else {
            $("#entrustDetailGrid").jqxGrid('updatebounddata', 'cells');
        }
    };
    //分页
    $("#entrustDetailGrid").on("pagechanged", function (event) {
        console.log(event)
    });
    //排序
    $("#entrustDetailGrid").on("sort", function (event) {
        var sortinformation = event.args.sortinformation;
        $scope.sort=sortinformation.sortcolumn;
        $scope.order=($scope.sort)?(sortinformation.sortdirection.ascending)?'asc':'desc':'asc';
        data={
            order:$scope.order,
            sort:$scope.sort
        };
        source.processData(data);
        $("#entrustDetailGrid").jqxGrid('updatebounddata', 'sort');
    });

}])
    .factory('CustomerDealData', ['$http', 'localStorageService', 'myHttp', '$q', '$rootScope', function ($http, localStorageService, myHttp, $q, $rootScope) {
        return {
            search: function (json) {
                var deferred = $q.defer();
                myHttp.post("admin/trade/match/query/as/page", json)
                    .then(function (res) { // 调用承诺API获取数据 .resolve
                        deferred.resolve(res);
                    }, function (res) { // 处理错误 .reject
                        deferred.reject(res);
                    });
                return deferred.promise;
            }
        }
    }]);