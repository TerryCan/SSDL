app.controller("prevSourcePositionsManageCtrl", ['$scope','$timeout', 'getPrevSourcePositionData', 'tipService', 'getPrevSource', '$rootScope','productManageSer','getPageNum', function($scope,$timeout, getPrevSourcePositionData, tipService, getPrevSource, $rootScope,productManageSer,getPageNum) {
    // 分页f
    var pageJump = function(tmpArrList){
        $timeout(function(){
            if(tmpArrList != undefined){
                $scope.currentPage = 1;//当前页数
                $scope.dataNum=tmpArrList.length;
                $scope.showDataChoose = getPageNum.pageNum();//获取分页
                $scope.showNum = $scope.showDataChoose[0];//初始显示刷具条数
                $scope.showPage = false;
                $timeout(function(){
                    $scope.showPage = true;
                    $scope.copyDataArray = tmpArrList.slice(0,14); //初始15条数据
                },10)
                $scope.dataPage=Math.ceil($scope.dataNum/$scope.showNum.showNum);

                //上下页
                $scope.pageSlect = function(type){
                    if(type == 'prev'){
                        if($scope.currentPage != 1){
                            $scope.currentPage --;
                            $scope.turnPage();
                        }else{
                            $scope.copyDataArray = tmpArrList.slice(0,14); //初始15条数据
                        }
                    }
                    else{
                        if($scope.currentPage < $scope.dataPage){
                            $scope.currentPage ++;
                            $scope.turnPage();
                        }
                    }
                }
                //每页数据量
                $scope.baseDataArray = [];
                $scope.copyDataArray = [];
                $scope.pageSelect = function(params){
                    $scope.showNum.showNum = params.showNum;
                    $scope.copyDataArray = tmpArrList.slice(0,(params.showNum-1));
                    $scope.dataPage=Math.ceil($scope.dataNum/$scope.showNum.showNum);
                    $scope.currentPage = 1;
                }
                $scope.turnPage=function(){
                    $scope.copyDataArray = tmpArrList.slice((($scope.currentPage-1)*15),(($scope.currentPage+1)*15-1));
                }
                //固定页面跳转
                $scope.jumpPage = function(num){
                    num = parseInt(num);
                    if(parseInt(num,10) === num && num <= ($scope.dataPage+1) && num > 0){
                        $scope.currentPage = num;
                        $scope.jumpPageNum='';
                        $scope.turnPage();
                    }else{
                        $scope.copyDataArray = tmpArrList.slice(0,14); //初始15条数据
                    }
                }
            }else{
                pageJump(tmpArrList);
            }
        },200);
    };
		//查询
		$scope.accountVal="";
		$scope.search = function() {
			var json = {
				key: $scope.accountVal,
			}
			console.log($scope.accountVal)
			if($scope.accountVal!=""){
				console.log($scope.accountVal!="")
			getPrevSourcePositionData.Searchaccount(json)
				.then(function(res) {
					console.log(res)
					if(res.retMsg.code == "000000") {
						var PositionList = res.list;
						$scope.PositionList = PositionList;
                        pageJump($scope.PositionList);
					} else {
						$rootScope.tipService.setMessage(res.retMsg.message, 'warning');
					}
				}, function(error) {
					$rootScope.tipService.setMessage(error.retMsg.message, 'warning');
				})
			}else{
				getPrevSourcePositionData.Search()
				.then(function(res) {
					console.log(res)
					if(res.retMsg.code == "000000") {
						var PositionList = res.list;
						$scope.PositionList = PositionList;
                        pageJump($scope.PositionList);
					} else {
						$rootScope.tipService.setMessage(res.retMsg.message, 'warning');
					}
				}, function(error) {
					$rootScope.tipService.setMessage(error.retMsg.message, 'warning');
				})
			}
		}
		//$scope.search();
		//添加弹窗显示
		$scope.addEditText = ''
		$scope.AddpositionShow = function() {
			$scope.PositionShow = true;
			$scope.addEditText = '添加'
			$scope.positionId="";
			$scope.avgPrice = "";
			$scope.symbolsp="";
			$scope.Positionaccount = ""; //帐号编号(key)
			$scope.Positionmarket = ""; //市场(预留)
			$scope.Positioncommodity = ""; //品种
			$scope.Positioncontract = ""; //合约
			$scope.Positiondirect = ""; //方向("B"-买，"S"-卖)
			$scope.Positionvolume = ""; //手数(头寸)
			$scope.PositionavgPrice = ""; //持仓均价
			$scope.Positionmargin = ""; //占用保证金
			$scope.Positioncommission = ""; //手续费
			$scope.PositionfloatProfit = ""; //浮盈
		}
		$scope.chooseItemTab1 = null;
		$scope.removeShow = function() {
			/*    	if(!$scope.chooseItemTab1){
						$rootScope.tipService.setMessage('请先选择', 'warning');
					}else{*/
			$scope.removePositionShow = true;
			$scope.Positionaccount = $scope.chooseItemTab1;
			/*}*/
		}

		//获取上手账号管理的Key值
		$scope.accountMargin = function() {
			getPrevSourcePositionData.addinsert()
				.then(function(response) {
					var accountList = response.list;
					$scope.accountList = accountList;
					var accountArr = [];
					accountList.forEach(function(arg) {
						accountArr.push(arg.key);
					});
					$scope.accountArrs = accountArr;
				}, function(error) {
				})
		}
		$scope.accountMargin();
	    	//上手商品管理
	    $scope.productManage=function(){
	        productManageSer.productSearch()
	            .then(function(response){
	                console.log(response);
				$scope.productList=response.list;
	            },function(error){
	            })
	    }

	     $scope.accountText = function(symbol) {
	     	if($scope.productList){
            for (var i = 0, r = $scope.productList.length; i < r; i++) {
                if (symbol == $scope.productList[i].key) {
                    return $scope.productList[i].key+'-'+$scope.productList[i].market+'-'+$scope.productList[i].commodity+'-'+$scope.productList[i].contract;
                }
            	}
            }
        }
	    $scope.productManage();
		$scope.directData = [{
			name: '买',
			val: 'B'
		}, {
			name: '卖',
			val: 'S'
		}];
		//市场
		$scope.markets = getPrevSource.market();
		$scope.products = getPrevSource.product();

		$scope.addEditText = ''
		$scope.PositionShow = false;
		//添加
		$scope.positionId="";
		$scope.avgPrice = "";
		$scope.symbolsp="";
		$scope.Positionaccount = ""; //帐号编号(key)
		$scope.Positionmarket = ""; //市场(预留)
		$scope.Positioncommodity = ""; //品种
		$scope.Positioncontract = ""; //合约
		$scope.Positiondirect = ""; //方向("B"-买，"S"-卖)
		$scope.Positionvolume = ""; //手数(头寸)
		$scope.PositionavgPrice = ""; //持仓均价
		$scope.Positionmargin = ""; //占用保证金
		$scope.Positioncommission = ""; //手续费
		$scope.PositionfloatProfit = ""; //浮盈
		$scope.addEditUserSubmit = function() {
			$scope.volumeNum = parseInt($scope.Positionvolume);
			$scope.avgPriceNum = parseFloat($scope.PositionavgPrice);
			$scope.marginNum = parseFloat($scope.Positionmargin);
			$scope.commissionNum = parseFloat($scope.Positioncommission);
			$scope.floatProfitNum = parseFloat($scope.PositionfloatProfit);
			var symbolsps=$scope.symbolsp;
			console.log(symbolsps)
			 symbols=symbolsps.split('-');
			console.log(symbols)
			var upPosition = {
				positionId:$scope.positionId,
				account: $scope.Positionaccount, //帐号编号(key)
		        symbol:symbols[0],
	            market:symbols[1],
	            commodity:symbols[2],
	            contract:symbols[3],
				direct: $scope.Positiondirect, //方向("B"-买，"S"-卖)
				volume: $scope.volumeNum, //手数(头寸)
				avgPrice: $scope.avgPriceNum, //持仓均价
				margin: $scope.marginNum, //占用保证金
				commission: $scope.commissionNum, //手续费
				floatProfit: $scope.floatProfitNum //浮盈

			}
			console.log(upPosition)

			var json = {
				upPosition: upPosition
			}
			 if(toValidate('#PositionAdd')) {
			getPrevSourcePositionData.add(json)
				.then(function(res) {
					console.log(res);
					if(res.data.code == "000000") {
						$scope.PositionShow = false;
						$rootScope.tipService.setMessage(res.data.message, 'warning');
						$scope.search();
					}else{
						$rootScope.tipService.setMessage(res.data.message, 'warning');
						$scope.PositionShow = false;
					}
				}, function(error) {
					  $rootScope.tipService.setMessage(error.data.message, 'warning');
				})
			}
		}
	// }
		//买卖方向
		$scope.directText = function(val) {
			for(var i = 0, r = $scope.directData.length; i < r; i++) {
				if(val == $scope.directData[i].val) {
					return $scope.directData[i].name;
				}
			}
		}

		$scope.editposition = false;
		$scope.editpositionShow = function() {
			if(!$scope.chooseItemTab1){
			$rootScope.tipService.setMessage('请先选择账号编号', 'warning');
			}
			else{
				$scope.editposition = true;
				$scope.account = $scope.chooseItemTab1;
			}
		}

		//单选
		$scope.positionCheck = function(index,account) {
			$scope.chooseItemTab1 = account;
			$scope.positionId = $scope.PositionList[index].positionId;
			$scope.account = $scope.PositionList[index].account; //帐号编号(key)
			$scope.product_key= $scope.PositionList[index].symbol;
	        $scope.product_market= $scope.PositionList[index].market;
	        $scope.product_commodity= $scope.PositionList[index].commodity;
	        $scope.product_contract= $scope.PositionList[index].contract;
			$scope.direct = $scope.PositionList[index].direct; //方向("B"-买，"S"-卖)
			$scope.volume = $scope.PositionList[index].volume; //手数(头寸)
			$scope.symbol = $scope.PositionList[index].symbol;
			$scope.market = $scope.PositionList[index].market;
			$scope.commodity = $scope.PositionList[index].commodity;
			$scope.contract = $scope.PositionList[index].contract;
			$scope.avgPrice = $scope.PositionList[index].avgPrice; //持仓均价
			$scope.margin = $scope.PositionList[index].margin; //占用保证金
			$scope.commission = $scope.PositionList[index].commission; //手续费
			$scope.floatProfit = $scope.PositionList[index].floatProfit; //浮盈
			$('#dataReport input[type=checkbox]').prop('checked', false);
			$('#dataReport input[type=checkbox]').eq(index).prop('checked', true);
			console.log($scope.account);

		}

		$scope.positionEdit = function() {

			$scope.volumeNum = parseInt($scope.volume);
			$scope.avgPriceNum = parseFloat($scope.avgPrice);
			$scope.marginNum = parseFloat($scope.margin);
			$scope.commissionNum = parseFloat($scope.commission);
			$scope.floatProfitNum = parseFloat($scope.floatProfit);
			var symbolsps=$scope.PositionList[0].symbol;
       	 	var symbols= $scope.accountText(symbolsps).split('-');
			var upPosition = {
				positionId:$scope.positionId,
				account: $scope.account, //帐号编号(key)
				symbol:symbols[0],
	            market:symbols[1],
	            commodity:symbols[2],
	            contract:symbols[3],
				direct: $scope.direct, //方向("B"-买，"S"-卖)
				volume: $scope.volumeNum, //手数(头寸)
				avgPrice: $scope.avgPriceNum, //持仓均价
				margin: $scope.marginNum, //占用保证金
				commission: $scope.commissionNum, //手续费
				floatProfit: $scope.floatProfitNum //浮盈
			}
			var json = {
				upPosition: upPosition
			}
			getPrevSourcePositionData.edit(json)
				.then(function(res) {
					if(res.data.code == "000000") {
						$scope.editposition = false;
						$rootScope.tipService.setMessage(res.data.message, 'warning');
						$scope.search();
					}
				},function(error) {
					$rootScope.tipService.setMessage(error.data.message, 'warning');
				})
		}

		//删除
		$scope.cancel = function() {

			var json = {
					positionId:$scope.positionId,
			}
				if(!$scope.chooseItemTab1){
				$rootScope.tipService.setMessage('请先选择账户', 'warning');
		}
		else{
			getPrevSourcePositionData.cancel(json)
				.then(function(res) {
					if(res.data.code == "000000"){
						$scope.removePositionShow = false;
						$rootScope.tipService.setMessage(res.data.message, 'warning');
						$scope.search();
					}
				}, function(error) {
					$rootScope.tipService.setMessage(error.data.message, 'warning');
				})
		}
		}

	}])
	.factory('getPrevSourcePositionData', ['$rootScope', '$http', '$q', function($rootScope, $http, $q) {
		return {
			//上手协议查询
			Search: function() {
				var deferred = $q.defer();
				$http({
					method: "GET",
					url: $rootScope.baseUrl + "c/up/position/query/all"
				}).success(function(res) {
					deferred.resolve(res);
				}).error(function(res) {
					deferred.reject(res);
				});
				return deferred.promise;
			},
			Searchaccount: function(json) {
				var deferred = $q.defer();
				$http({
					method: 'POST',
					url: $rootScope.baseUrl + 'c/up/position/query/key',
					data: json
				})
				.success(function(res) {
				deferred.resolve(res);
				}).error(function(res) {
					deferred.reject(res);
				});
				return deferred.promise;
			},

			// 帐号查询
			addinsert: function() {
				var deferred = $q.defer();
				$http({
					method: "GET",
					url: $rootScope.baseUrl + "c/up/account/query/all"
				}).success(function(res) {
					deferred.resolve(res);
				}).error(function(res) {
					deferred.reject(res);
				});
				return deferred.promise;
			},

			// 添加查询
			add: function(json) {
				var deferred = $q.defer();
				$http({
					method: 'POST',
					url: $rootScope.baseUrl + 'c/up/position/insert',
					data: json,
				}).then(function successCallback(response) {
					deferred.resolve(response);
				}, function errorCallback(response) {
					deferred.reject(response);
				});
				return deferred.promise;
			},

			//修改
			edit: function(json) {
				var deferred = $q.defer();
				$http({
					method: 'POST',
					url: $rootScope.baseUrl + 'c/up/position/modify',
					data: json,
				}).then(function successCallback(response) {
					deferred.resolve(response);
				}, function errorCallback(response) {
					deferred.reject(response);
				});
				return deferred.promise;
			},
			//删除
			cancel: function(json) {
				var deferred = $q.defer();
				$http({
					method: 'POST',
					url: $rootScope.baseUrl + 'c/up/position/delete',
					data: json,
				}).then(function successCallback(response) {
					deferred.resolve(response);
				}, function errorCallback(response) {
					deferred.reject(response);
				});
				return deferred.promise;
			}

		}
	}])