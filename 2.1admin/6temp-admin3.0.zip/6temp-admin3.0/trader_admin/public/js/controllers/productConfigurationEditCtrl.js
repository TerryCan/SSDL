app.controller('productConfigurationEditCtrl', ['$scope', '$rootScope', '$state', 'dataSer', 'getCurrencyType', 'getPageNum', 'tipService', 'confirmService', 'getProductScope', 'productConfigurationEditCtrlSer', 'productConfigurationCtrlSer', 'localStorageService', 'getweekType', 'get24h', 'CurrencysettingsCtrlSer', 'memberMangerCtrlSer','productConfigurationAddCtrlSer','timestamp', function($scope, $rootScope, $state, dataSer, getCurrencyType, getPageNum, tipService, confirmService, getProductScope, productConfigurationEditCtrlSer, productConfigurationCtrlSer, localStorageService, getweekType, get24h, CurrencysettingsCtrlSer, memberMangerCtrlSer,productConfigurationAddCtrlSer,timestamp) {
		$scope.getweekType = getweekType;
		$scope.get24h = get24h;
		$scope.startTime = 0;
		$scope.endTime = 0;
		$scope.CSTimes = 0;
		$scope.custonchange = function() {
			if ($scope.customizedType == "true") {
				$scope.addwtime = false;
				$scope.startNum= '';
				$scope.startTime = "";
				$scope.endNum = "";
				$scope.endTime = "";
				$scope.CSTimes = 0;
			} else if ($scope.customizedType == "false") {
				$scope.addwtime = true;
				$scope.CSTimes = '1970-01-01';
			} else {
				$scope.addwtime = false;
				$scope.CSTimes = 0;
			}
		}

		$scope.UniqueData = [{
			name: '是',
			val: true
		}, {
			name: '否',
			val: false
		}];
		$scope.treVal=function(customizedType){
			for (var i = 0, r = $scope.UniqueData.length; i < r; i++) {
				if (customizedType == $scope.UniqueData[i].val) {
					return $scope.UniqueData[i].name;
				}
			}
		}
		dataSer.organizeQuerySer()
			.then(function(res) {
				//console.log(res)
				$scope.orgList = res;
			});
		$scope.getaddOrgVal = function(orgCode) {
			if ($scope.orgList) {
				for (var i = 0, r = $scope.orgList.length; i < r; i++) {
					if (orgCode == $scope.orgList[i].orgCode) {
						return $scope.orgList[i].text;
						// console.log($scope.orgList[i].text)
					}
				}
			}
		}
		$scope.addOrgValFTC = function(d) {
			$scope.addOrgVal = d.text;
			$scope.orgId = d.orgId;
			$scope.orgCode = d.orgCode;
		}

		//获取币种
		getCurrencyType
			.then(function(res) {
				$scope.getCurrencybz = JSON.parse(res.content);
				//console.log($scope.getCurrencybz)
			});
		$scope.getCurrency = function(parameter) {
			for (var i = 0; i < $scope.getCurrencybz.length; i++) {
				if (parameter == $scope.getCurrencybz[i].id) {
					return $scope.getCurrencybz[i].name;
				}
			}
		}
		CurrencysettingsCtrlSer.search(999999, 1, '', '')
			.then(function(res) {
				$scope.CurrencyTypelist = JSON.parse(res.content);
			})
		$scope.CurrencyTypeText = function(val) {
			//console.log(val)
			if ($scope.CurrencyTypelist) {
				for (var i = 0, r = $scope.CurrencyTypelist.length; i < r; i++) {
					if (val == $scope.CurrencyTypelist[i].currency) {
						return $scope.CurrencyTypelist[i].currencyName;

					}
				}
			}
		}
				//产品ID
			productConfigurationAddCtrlSer.productListdata()
				.then(function(res) {
				if(res.code="000000"){
					var prolistdt = JSON.parse(res.content);
					$scope.prolist = [];
					for (var i = 0, r = prolistdt.length; i < r; i++) {
						if (prolistdt[i].state == 1 || prolistdt[i].state == 8000) {
							$scope.prolist.push(prolistdt[i]);
						}
					}
					}
				});
		$scope.changeWeekText = function(val) {
			//console.log(val)
			for (var i = 0, r = $scope.getweekType.length; i < r; i++) {
				if (val == $scope.getweekType[i].val) {
					return $scope.getweekType[i].name;
				}
			}
		}
		$scope.search = function() {
			var productCustomizedId = localStorageService.get('PMChooseProlist');
			productConfigurationCtrlSer.getlistInfo(productCustomizedId)
				.then(function(res) {
					var data = JSON.parse(res.data.content);
					if (data.customizedSubList.length > 0) {
						$scope.customizedSubList = data.customizedSubList;
					}
				});
		}
		$scope.search();
		memberMangerCtrlSer.search(9999,1,'','','')
			.then(function(res){
				$scope.memberNum=JSON.parse(res.content).content;
			})

		$scope.memberNumText = function(orgCode){
			if($scope.memberNum){
				 	for (var i = 0,r = $scope.memberNum.length; i < r; i++) {
				 		if (orgCode == $scope.memberNum[i].orgCode) {
				 			return $scope.memberNum[i].orgNum;
				 		}
				 	}
				 }
		}
		//获取产品信息
		var productCustomizedId = localStorageService.get('PMChooseProlist');
		productConfigurationCtrlSer.getlistInfo(productCustomizedId)
			.then(function(res) {
				//console.log(res)
				if (res.data.code == '000000') {
					var data = JSON.parse(res.data.content);
					$scope.datacom = JSON.parse(res.data.content);
					//console.log(data)
					$scope.productCustomizedId = data.productCustomizedId;
					$scope.createTime = data.createTime;
					$scope.createUser = data.createUser;
					$scope.updateTime = data.updateTime;
					$scope.updateUser = data.updateUser;
					$scope.orgCode = data.orgCode;
					$scope.orgId = data.orgId;
					$scope.productId = data.productId;
					$scope.productCode = data.productCode;
					$scope.productName = data.productName;
					$scope.productCurrency = data.productCurrency;
					$scope.contractNum = data.contractNum;
					$scope.keepDepositTradeRate = data.keepDepositTradeRate;
					$scope.product = data.product;
					$scope.customizedSub = data.customizedSub;
					 var reportArray = [];
					for(var i = 0, r = data.customizedSubList.length; i < r; i++){
						 var tmpArr = {
                            productCustomizedSubId: '',
                            productCustomizedId: '',
                            interest: '',
                            interestCurrency: '',
                            keepDeposit: '',
                            keepDepositCurrency: '',
                            poundage: '',
                            poundageCurrency: '',
                            openForbidenDang: '',
                            operationTimesDuring: '',
                            operationTimesLimit: '',
                            orderEntrantDang:'',
                            positionLimit:'',
                            tradeFlag:'',
                            customizedType:'',
                            lockFlag:'',
                            startNum:'',
                            startTime:'',
                            endNum:'',
                            endTime:''
                        };
							tmpArr.productCustomizedSubId =data.customizedSubList[i].productCustomizedSubId,					//console.log($scope.productCustomizedSubId)
							tmpArr.productCustomizedId = data.customizedSubList[i].productCustomizedId,
							tmpArr.interest =data.customizedSubList[i].interest,
							tmpArr.interestCurrency = data.customizedSubList[i].interestCurrency,
							tmpArr.keepDeposit = data.customizedSubList[i].keepDeposit,
							tmpArr.keepDepositCurrency = data.customizedSubList[i].keepDepositCurrency,
							tmpArr.poundage = data.customizedSubList[i].poundage,
							tmpArr.poundageCurrency = data.customizedSubList[i].poundageCurrency,
							tmpArr.openForbidenDang = data.customizedSubList[i].openForbidenDang,
							tmpArr.operationTimesDuring = data.customizedSubList[i].operationTimesDuring,
							tmpArr.operationTimesLimit = data.customizedSubList[i].operationTimesLimit,
							tmpArr.orderCreateLimit = data.customizedSubList[i].orderCreateLimit,
							tmpArr.orderEntrantDang = data.customizedSubList[i].orderEntrantDang,
							tmpArr.positionLimit = data.customizedSubList[i].positionLimit,
							tmpArr.tradeFlag = data.customizedSubList[i].tradeFlag,
							tmpArr.customizedType =data.customizedSubList[i].customizedType,
							tmpArr.lockFlag =data.customizedSubList[i].lockFlag,
							tmpArr.startNum = (data.customizedSubList[i].startNum).toString(),
							tmpArr.startTime = (data.customizedSubList[i].startTime).toString(),
							tmpArr.endNum = (data.customizedSubList[i].endNum).toString(),
							tmpArr.endTime =(data.customizedSubList[i].endTime).toString()
							reportArray.push(tmpArr);
						$scope.customizedSubList=reportArray;
						console.log($scope.customizedSubList)
					}
				}
			});
		//匹配机构代码
		var json = {
			page: 1,
			rows: 999,
			search_A_EQ_state: 1
		};
		dataSer.getOrganize(json).then(function(res) {
			if (res.code == '000000') {
				$scope.equalOrgCode = JSON.parse(res.content).content;
				for (var i = 0; i < $scope.equalOrgCode.length; i++) {
					if ($scope.datacom.orgCode == $scope.equalOrgCode[i].orgCode) {
						$scope.addOrgVal = $scope.equalOrgCode[i].orgName + '(' + $scope.equalOrgCode[i].orgNum + ')';
					}
				}
			}
		});
		//动态添加减少数据
		$scope.addrule = function() {
			var customizedType= eval($scope.customizedType.toLowerCase());
			var lockFlag= eval($scope.lockFlag.toLowerCase());
			var startTimes = $scope.CSTimes + ' ' + $scope.startTime;
			var startTimeNum = 0;
			if ($scope.CSTimes != "" || $scope.startTime != '') {
				startTimeNum = Date.parse(new Date(startTimes)).toString();
			}

			var endTimes = $scope.CSTimes + ' ' + $scope.endTime;
			var endTimeNum = 0;
			if ($scope.CSTimes != "" || $scope.endTime != '') {
				endTimeNum = Date.parse(new Date(endTimes)).toString();
			}
			var SingleRule = {
				productCustomizedId: $scope.productCustomizedId,
				interest: parseFloat($scope.interest),
				poundage: parseFloat($scope.poundage),
				keepDeposit: parseFloat($scope.keepDeposit),
				interestCurrency: parseInt($scope.interestCurrency),
				poundageCurrency: parseInt($scope.poundageCurrency),
				keepDepositCurrency: parseInt($scope.keepDepositCurrency),
				tradeFlag: parseInt($scope.tradeFlag),
				customizedType:customizedType, //默认配置标识位
				lockFlag: lockFlag,
				openForbidenDang: parseInt($scope.openForbidenDang),
				operationTimesDuring: parseInt($scope.operationTimesDuring),
				operationTimesLimit: parseInt($scope.positionLimit),
				positionLimit: parseInt($scope.positionLimit),
				orderCreateLimit: parseInt($scope.orderCreateLimit),
				orderEntrantDang: parseInt($scope.orderEntrantDang),
				startNum: $scope.startNum,
				startTime: startTimeNum,
				endNum: $scope.endNum,
				endTime: endTimeNum
			}
			$scope.customizedSubList.push(SingleRule);
			console.log(SingleRule)
		//}
		}
		$scope.delete = function(index) {
			$scope.customizedSubList.splice(index, 1);
			if($scope.customizedSubs!=""){
				$("select[name='productName']").attr('disabled',true);
				$("input[name='addOrgVal']").attr('disabled',true);
				$(".w100p a").hide();
				$(".w100p div").hide();

				}else{
				 $("select[name='productName']").attr('disabled',false);
				 $("iniput[name='addOrgVal']").attr('disabled',false);
				 $(".w100p a").show();
				 $(".w100p div").show();
				};
		}

		 //时间戳
	    $scope.timeSwitch = function (stamp) {
	        return timestamp.timestampCoverHms(stamp, 'hm')
	    };
		$scope.DetailedShow=false;
		$scope.Detailed= function(index) {
			$scope.DetailedShow=true;
			//for (var i = 0, r = $scope.customizedSubList.length; i < r; i++) {
				//console.log(index)
			    console.log($scope.customizedSubList[index])
			   // if(index==$scope.customizedSubList[index]){
					$scope.productCustomizedSubId = $scope.customizedSubList[index].productCustomizedSubId;					//console.log($scope.productCustomizedSubId)
					$scope.productCustomizedId = $scope.customizedSubList[index].productCustomizedId;
					$scope.interest = $scope.customizedSubList[index].interest;
					$scope.interestCurrency = $scope.customizedSubList[index].interestCurrency;
					$scope.keepDeposit = $scope.customizedSubList[index].keepDeposit;
					$scope.keepDepositCurrency = $scope.customizedSubList[index].keepDepositCurrency;
					$scope.poundage = $scope.customizedSubList[index].poundage;
					$scope.poundageCurrency = $scope.customizedSubList[index].poundageCurrency;
					$scope.openForbidenDang = $scope.customizedSubList[index].openForbidenDang;
					$scope.operationTimesDuring = $scope.customizedSubList[index].operationTimesDuring;
					$scope.operationTimesLimit = $scope.customizedSubList[index].operationTimesLimit;
					$scope.orderCreateLimit = $scope.customizedSubList[index].orderCreateLimit;
					$scope.orderEntrantDang = $scope.customizedSubList[index].orderEntrantDang;
					$scope.positionLimit = $scope.customizedSubList[index].positionLimit;
					$scope.tradeFlag = $scope.customizedSubList[index].tradeFlag;
					$scope.customizedType =$scope.customizedSubList[index].customizedType;
					$scope.customizedTypeVal =$scope.treVal($scope.customizedSubList[index].customizedType);
					console.log($scope.customizedTypeVal)
					$scope.lockFlag =$scope.customizedSubList[index].lockFlag;
					$scope.lockFlagVal = $scope.treVal($scope.customizedSubList[index].lockFlag);
					console.log($scope.lockFlagVal)
					if($scope.customizedType==true){
						$scope.addwtime2=false;
					}else{
						$scope.addwtime2=true;
					}
					$scope.startNum = ($scope.customizedSubList[index].startNum).toString();
					$scope.startTime = ($scope.customizedSubList[index].startTime).toString();
					$scope.startTimeNumVal = $scope.timeSwitch(parseInt($scope.customizedSubList[index].startTime));
					$scope.endNum = ($scope.customizedSubList[index].endNum).toString();
					$scope.endTime = ($scope.customizedSubList[index].endTime).toString();
					$scope.endTimeNumVal = $scope.timeSwitch(parseInt($scope.customizedSubList[index].endTime));
				//}
			//}
		}
		$scope.customizedSubList = [];

		$scope.addproductCust = function() {

			var productCustomized = {
				productCustomizedId: $scope.productCustomizedId,
				productId: $scope.productId,
				orgId: $scope.orgId,
				orgCode: $scope.orgCode,
				customizedSubs: $scope.customizedSubList

			}

			productConfigurationEditCtrlSer.Edit(productCustomized)
				.then(function(res) {
					if (res.data.code == '000000') {
						$rootScope.tipService.setMessage(res.data.codeName, 'warning');
						$state.go('tabs.productConfiguration');
					} else {
						$rootScope.tipService.setMessage(res.data.message, 'warning');
					}
				});
		}
		$scope.goBack = function() {
			$state.go('tabs.productConfiguration');
		}
	}])
	.factory('productConfigurationEditCtrlSer', ['$http', 'localStorageService', 'myHttp', '$q', '$rootScope', function($http, localStorageService, myHttp, $q, $rootScope) {
		return {

			Edit: function(productCustomized) {
				var deferred = $q.defer();
				$http({
					method: 'POST',
					url: $rootScope.baseUrl + 'config/product/save/productCustomizeds',
					data: {
						"productCustomized": productCustomized
					}
				}).then(function successCallback(response) {
					deferred.resolve(response);
				}, function errorCallback(response) {
					deferred.reject(response);
				});
				return deferred.promise;
			}
		}
	}])