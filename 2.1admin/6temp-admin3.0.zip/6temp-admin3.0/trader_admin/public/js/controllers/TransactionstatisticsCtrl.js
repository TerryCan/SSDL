app.controller('TransactionstatisticsCtrl', ['$rootScope', '$scope','TransactionstatisticsCtrlSel', 'localStorageService', 'dataSer','timestamp', function ($rootScope, $scope, TransactionstatisticsCtrlSel, localStorageService, dataSer,timestamp) {
    $scope.toggleTraderSearchState=false;
    $scope.Toggle = function(){
        $scope.toggleTraderSearchState = !$scope.toggleTraderSearchState;
        if($scope.toggleTraderSearchState){
           $('.search_column').css('height','auto');
        }
        else{
           $('.search_column').css('height','36px');
        }
    };
    //查询
    $scope.createTimeStart='';
    $scope.createTimeEnd='';
    $scope.search = function () {
         $scope.toggleTraderSearchState=false;
        $('.search_column').css('height','36px');
        var sumParamsIce = {
            orgCode: ($scope.upOrgCode) ? $scope.upOrgCode : '',
            userId: $scope.directiveUserId,
            createTimeS:($scope.createTimeStart)?($scope.createTimeStart.split(' ')[0]+"T"+$scope.createTimeStart.split(' ')[1]):'',
            createTimeE:($scope.createTimeEnd)?($scope.createTimeEnd.split(' ')[0]+"T"+$scope.createTimeEnd.split(' ')[1]):''
        };
        var json = {
            sumParamsIce: sumParamsIce
        };
        TransactionstatisticsCtrlSel.search(json).then(function (res) {
                if (res.data.code == '000000') {
                    $scope.searchResult = JSON.parse(res.data.content);
                    var sumResult={
                        productName:'总计',
                        productCode:'',
                        buy:0,
                        sell:0,
                        total:0,
                        limit:0,
                        cancel:0
                    };
                    for(var i=0;i<$scope.searchResult.length;i++){
                        sumResult.buy+=$scope.searchResult[i].buy;
                        sumResult.sell+=$scope.searchResult[i].sell;
                        sumResult.total+=$scope.searchResult[i].total;
                    }
                    $scope.searchResult.push(sumResult);
                    var source = {
                        localdata: $scope.searchResult,
                        datatype: "array",
                        datafields: [
                            {name: 'productName', type: 'string'},
                            {name: 'productCode', type: 'string'},
                            {name: 'buy', type: 'string'},
                            {name: 'sell', type: 'string'},
                            {name: 'total', type: 'string'},

                            {name: 'cancel', type: 'string'}
                        ]
                    };
                    var dataAdapter = new $.jqx.dataAdapter(source);
                    $("#entrustDetailGrid").jqxGrid(
                        {
                            width: 100 + '%',
                            height: 87 + '%',
                            theme: 'metrodark',
                            source: dataAdapter,//数据源
                            columnsresize: true,
                            selectionmode: 'singlecell',
                            clipboard: true,
                            columns: [  //表格数据域
                                {
                                    text: '商品名',
                                    datafield: 'productName',
                                    minwidth: 20 + '%',
                                    cellsalign: 'center',
                                    align: 'center',
                                    width: '20%'
                                },
                                {
                                    text: '商品代码',
                                    datafield: 'productCode',
                                    minwidth: 20 + '%',
                                    align: 'center',
                                    width: '20%'
                                },
                                {
                                    text: '成交买',
                                    datafield: 'buy',
                                    minwidth: 20 + '%',
                                    cellsalign: 'center',
                                    align: 'center',
                                    width: '20%'
                                },
                                {
                                    text: '成交卖',
                                    datafield: 'sell',
                                    minwidth: 20 + '%',
                                    width: '20%',
                                    align: 'center'
                                },
                                {
                                    text: '成交合计',
                                    datafield: 'total',
                                    minwidth: 20 + '%',
                                    cellsalign: 'center',
                                    align: 'center',
                                    width: '20%'
                                }
                            ]
                        });
                } else {
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                }
            }, function (error) {
                $rootScope.tipService.setMessage(error.data.message, 'warning');
            });
    };
}])
    .factory('TransactionstatisticsCtrlSel', ['$http', 'localStorageService', 'myHttp', '$q', '$rootScope', function ($http, localStorageService, myHttp, $q, $rootScope) {
        return {
            search: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'admin/trade/match/sum',
                    data: json
                })
                    .then(function (res) { // 调用承诺API获取数据 .resolve
                        deferred.resolve(res);
                    }, function (res) { // 处理错误 .reject
                        deferred.reject(res);
                    });
                return deferred.promise;
            }
        }
    }])