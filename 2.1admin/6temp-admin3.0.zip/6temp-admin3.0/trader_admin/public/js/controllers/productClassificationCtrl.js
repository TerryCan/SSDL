app.controller('productClassificationCtrl', ['$scope', '$rootScope', '$state', 'productClassificationCtrlSer', 'localStorageService', 'getCurrencyType', 'getProManageState', 'getPageNum', 'getProductScope', 'dataSer', function($scope, $rootScope, $state, productClassificationCtrlSer, localStorageService, getCurrencyType, getProManageState, getPageNum, getProductScope, dataSer) {
		$scope.toggleTraderSearchState = false;
		$scope.Toggle = function() {
			$scope.toggleTraderSearchState = !$scope.toggleTraderSearchState;
			if ($scope.toggleTraderSearchState) {
				$('.search_column').css('height', 'auto');
			} else {
				$('.search_column').css('height', '36px');
			}
		};
		/*	$scope.CurrencyType = */
		getCurrencyType.then(function(res) {
			console.log(res)
			$scope.CurrencyType = JSON.parse(res.content);
			console.log($scope.CurrencyType)
		});
		$scope.ProductScope = getProductScope;
		$scope.changeCurrencyText = function(productCurrency) {
			if ($scope.CurrencyType) {
				for (var i = 0, r = $scope.CurrencyType.length; i < r; i++) {
					if ($scope.CurrencyType[i].currency == productCurrency) {
						return $scope.CurrencyType[i].currencyName;
					}
				}
			}
		}
		$scope.changeProductScopeText = function(type) {
				for (var i = 0, r = $scope.ProductScope.length; i < r; i++) {
					if ($scope.ProductScope[i].id == type) {
						return $scope.ProductScope[i].name;
					}
				}
			}
			//全部状态下所属机构
		dataSer.organizeQuerylistSer()
			.then(function(res) {
				$scope.orgAllList = res;
				console.log($scope.orgList)
			});

		$scope.getOrgVal = function(orgCode) {
			if ($scope.orgAllList) {
				for (var i = 0; i < $scope.orgAllList.length; i++) {
					if (orgCode == $scope.orgAllList[i].orgCode) {
						return $scope.orgAllList[i].text;
					}
				}
			}
		}

		//搜索过滤字段
		$scope.search_productName = '';
		$scope.search_state = '';
		$scope.search_productCurrency = '';
		$scope.search_productCode = '';
		$scope.search_effectType = '';
		$scope.search = function() {
			$scope.toggleTraderSearchState=false;
			$('.search_column').css('height', '36px');
			if ($scope.search_productName || $scope.search_state || $scope.search_productCurrency || $scope.search_productCode || $scope.search_effectType) {
				$scope.currentPage = 1;
			}
			productClassificationCtrlSer.search($scope.showNum.showNum, $scope.currentPage, $scope.search_productName, $scope.search_state, $scope.search_productCurrency, $scope.search_productCode, $scope.search_effectType)
				.then(function(res) {
					console.log(res)
					if (res.code === '000000') {
						var data = JSON.parse(res.content);
						$scope.chooseProId = null;
						console.log(data)
						$scope.searchResult = data.content;
						$scope.showPage = true;
						$scope.dataNum = data.totalElements;
						$scope.PageNum();
					} else {
						$rootScope.tipService.setMessage(res.message, 'warning');
					}
				}, function(error) {
					$rootScope.tipService.setMessage(error.message, 'warning');
				});
		}
		$scope.turnPage = function(url) {
				$state.go(url);
			}
			//修改
		$scope.edit = function(url) {
				if ($scope.chooseProId == null) {
					$rootScope.tipService.setMessage('请先选择客户', 'warning');
				} else {
					localStorageService.update('productMmanageChooseProId', $scope.chooseProId);
					$state.go(url);
				}
			}
			//单选
		$scope.chooseProId = null;
		$scope.checked = function(index, id) {
			$scope.chooseProId = id;
			console.log($scope.searchResult)
			$('#dataReport input[type=checkbox]').prop('checked', false);
			$('#dataReport input[type=checkbox]').eq(index).prop('checked', true);

		}
		$scope.ProStateList = getProManageState;
		$scope.getProStateList = function(params) {
				for (var i = 0, r = $scope.ProStateList.length; i < r; i++) {
					if (params == $scope.ProStateList[i].id) {
						return $scope.ProStateList[i].name;
					}
				}
			}
			//审核通过
		$scope.pass = function(productId) {
				productClassificationCtrlSer.pass(productId)
					.then(function(res) {
						console.log(res);
						if (res.data.code == '000000') {
							$rootScope.tipService.setMessage(res.data.message, 'warning');
							$scope.search();
						} else {
							$rootScope.tipService.setMessage(res.data.message, 'warning');
						}
					});
			}
			//驳回
		$scope.fail = function(productId) {
				productClassificationCtrlSer.fail(productId)
					.then(function(res) {
						console.log(res);
						if (res.data.code == '000000') {
							$rootScope.tipService.setMessage(res.data.message, 'warning');
							$scope.search();
						} else {
							$rootScope.tipService.setMessage(res.data.message, 'warning');
						}
					});
			}
			//启用
		$scope.open = function(productId) {
				productClassificationCtrlSer.open(productId)
					.then(function(res) {
						console.log(res);
						if (res.data.code == '000000') {
							$rootScope.tipService.setMessage(res.data.message, 'warning');
							$scope.search();
						} else {
							$rootScope.tipService.setMessage(res.data.message, 'warning');
						}
					});
			}
			//禁用
		$scope.close = function(productId) {
				productClassificationCtrlSer.close(productId)
					.then(function(res) {
						console.log(res);
						if (res.data.code == '000000') {
							$rootScope.tipService.setMessage(res.data.message, 'warning');
							$scope.search();
						} else {
							$rootScope.tipService.setMessage(res.data.message, 'warning');
						}
					});
			}
			//退市
		$scope.freeze = function(productId) {
				productClassificationCtrlSer.freeze(productId)
					.then(function(res) {
						console.log(res);
						if (res.data.code == '000000') {
							$rootScope.tipService.setMessage(res.data.message, 'warning');
							$scope.search();
						} else {
							$rootScope.tipService.setMessage(res.data.message, 'warning');
						}
					});
			}
			//上市
		$scope.unfreeze = function(productId) {
			productClassificationCtrlSer.unfreeze(productId)
				.then(function(res) {
					console.log(res);
					if (res.data.code == '000000') {
						$rootScope.tipService.setMessage(res.data.message, 'warning');
						$scope.search();
					} else {
						$rootScope.tipService.setMessage(res.data.message, 'warning');
					}
				});
		}



		/* 分页功能实现 */
		var pageInitialize = function() {
			$scope.dataNum = 0; //数据总条数
			$scope.dataPage = 0; //分页数
			$scope.currentPage = 1; //当前页数
			$scope.jumpPageNum = '';
		}
		$scope.showDataChoose = getPageNum.pageNum(); //获取分页
		$scope.showNum = $scope.showDataChoose[0]; //初始显示刷具条数
		$scope.dataPageNumber = []; //生成页面数
		$scope.showPage = false;
		$scope.pageSelect = function(params) {
			$scope.showNum.showNum = params.showNum;
			pageInitialize();
			$scope.search();
		}
		$scope.changePageNumber = function(params) {
			$scope.currentPage = params;
			$scope.search();
			$scope.PageNum();
		}
		$scope.PageNum = function() {
			if ($scope.showNum.showNum < $scope.dataNum) {
				$scope.dataPage = parseInt($scope.dataNum / $scope.showNum.showNum) + 1;
			} else {
				$scope.dataPage = 0;
			}
			$scope.dataPageNumber = [];
			for (var i = 0; i < $scope.dataPage; i++) {
				$scope.dataPageNumber.push(i + 1);
			}
		}
		$scope.jumpPage = function(num) {
			num = parseInt(num);
			if (parseInt(num, 10) === num && num <= ($scope.dataPage + 1) && num > 0) {
				$scope.currentPage = num;
				$scope.PageNum();
				$scope.search();
			}
		}
		$scope.pageSlect = function(type) {
			if (type == 'prev') {
				if ($scope.currentPage != 1) {
					$scope.currentPage--;
					$scope.PageNum();
					$scope.search();
				}
			} else {
				if ($scope.currentPage < $scope.dataPage) {
					$scope.currentPage++;
					$scope.PageNum();
					$scope.search();
				}
			}
		}
		pageInitialize();
		//$scope.search();
	}])
	.factory('productClassificationCtrlSer', ['$http', 'localStorageService', 'myHttp', '$q', '$rootScope', function($http, localStorageService, myHttp, $q, $rootScope) {
		return {
			search: function(showNum, nowPage, search_productName, search_state, search_productCurrency, search_productCode, search_effectType) {
				var json = {
					orders: 'asc',
					page: nowPage,
					rows: showNum,
					search_A_LIKE_productName: search_productName,
					search_A_EQ_state: search_state,
					search_A_EQ_productCurrency: search_productCurrency,
					search_A_LIKE_productCode: search_productCode,
					search_A_EQ_effectType: search_effectType
				}
				var deferred = $q.defer();
				myHttp.post("config/product/query/as/page", json)
					.then(function(res) { // 调用承诺API获取数据 .resolve
						deferred.resolve(res);
					}, function(res) { // 处理错误 .reject
						deferred.reject(res);
					});
				return deferred.promise;
			},
			getProInfo: function(productId) {
				var deferred = $q.defer();
				$http({
					method: 'POST',
					url: $rootScope.baseUrl + 'config/product/get',
					data: {
						"productId": productId
					}
				}).then(function successCallback(response) {
					console.log(response)
					deferred.resolve(response);
				}, function errorCallback(response) {
					deferred.reject(response);
				});
				return deferred.promise;
			},
			pass: function(productId) {
				var deferred = $q.defer();
				$http({
					method: 'POST',
					url: $rootScope.baseUrl + 'config/product/pass',
					data: {
						"productId": productId
					}
				}).then(function successCallback(response) {
					deferred.resolve(response);
				}, function errorCallback(response) {
					deferred.reject(response);
				});
				return deferred.promise;
			},
			fail: function(productId) {
				var deferred = $q.defer();
				$http({
					method: 'POST',
					url: $rootScope.baseUrl + 'config/product/fail',
					data: {
						"productId": productId
					}
				}).then(function successCallback(response) {
					deferred.resolve(response);
				}, function errorCallback(response) {
					deferred.reject(response);
				});
				return deferred.promise;
			},
			open: function(productId) {
				var deferred = $q.defer();
				$http({
					method: 'POST',
					url: $rootScope.baseUrl + 'config/product/open',
					data: {
						"productId": productId
					}
				}).then(function successCallback(response) {
					deferred.resolve(response);
				}, function errorCallback(response) {
					deferred.reject(response);
				});
				return deferred.promise;
			},
			close: function(productId) {
				var deferred = $q.defer();
				$http({
					method: 'POST',
					url: $rootScope.baseUrl + 'config/product/close',
					data: {
						"productId": productId
					}
				}).then(function successCallback(response) {
					deferred.resolve(response);
				}, function errorCallback(response) {
					deferred.reject(response);
				});
				return deferred.promise;
			},
			freeze: function(productId) {
				var deferred = $q.defer();
				$http({
					method: 'POST',
					url: $rootScope.baseUrl + 'config/product/freeze',
					data: {
						"productId": productId
					}
				}).then(function successCallback(response) {
					deferred.resolve(response);
				}, function errorCallback(response) {
					deferred.reject(response);
				});
				return deferred.promise;
			},
			unfreeze: function(productId) {
				var deferred = $q.defer();
				$http({
					method: 'POST',
					url: $rootScope.baseUrl + 'config/product/unfreeze',
					data: {
						"productId": productId
					}
				}).then(function successCallback(response) {
					deferred.resolve(response);
				}, function errorCallback(response) {
					deferred.reject(response);
				});
				return deferred.promise;
			},

			add: function(product, productCustomized) {
				var deferred = $q.defer();
				$http({
					method: 'POST',
					url: $rootScope.baseUrl + 'config/product/create',
					data: {
						"product": product,
						"productCustomized": productCustomized
					}
				}).then(function successCallback(response) {
					deferred.resolve(response);
				}, function errorCallback(response) {
					deferred.reject(response);
				});
				return deferred.promise;
			}
		}
	}])