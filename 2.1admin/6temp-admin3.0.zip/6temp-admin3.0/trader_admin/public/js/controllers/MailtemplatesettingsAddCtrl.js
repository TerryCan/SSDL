app.controller('MailtemplatesettingsAddCtrl', ['$scope', 'dataSer', 'CommissionallocationAddCtrlSer', 'MailtemplatesettingsAddCtrlSel', '$state', '$rootScope', function($scope, dataSer, CommissionallocationAddCtrlSer, MailtemplatesettingsAddCtrlSel, $state, $rootScope) {
	 var E = window.wangEditor;
        var editor = new E('#editor');
        editor.customConfig.pasteFilterStyle = true;
        console.log(editor.customConfig.pasteFilterStyle)
        editor.customConfig.menus = [
        'head',  // 标题
	    'bold',  // 粗体
	    'italic',  // 斜体
	    'underline',  // 下划线
	    'strikeThrough',  // 删除线
	    'foreColor',  // 文字颜色
	    'backColor',  // 背景颜色
	    'list',  // 列表
	    'justify',  // 对齐方式
	    'table',  // 表格
	    'code',  // 插入代码
	    'undo',  // 撤销
	    'redo'  // 重复
   		 ],
        editor.create();
        $scope.contentText="";
        document.getElementById('editor').onkeyup = function(){

        	 $scope.contentText= editor.txt.html();
        };

		$scope.goBack = function() {
				$state.go('tabs.Mailtemplatesettings');
			}
			//机构列表
		$scope.addOrgVal = ''; //显示值
		$scope.orgId = ''; //选择值
		dataSer.organizeQuerySer()
			.then(function(res) {
				console.log(res)
				$scope.orgList = res;
				//console.log($scope.orgList)
			});
		$scope.allnotlickList = [];
		$scope.copyuesrList = [];
		$scope.addOrgValFTC = function(d) {
				//console.log(data);
				$scope.allotOrgId = d.orgId;
				$scope.superorgCode = d.orgCode;
				$scope.addOrgVal = d.text;
			}
			//清除数据
		$scope.title = "";
		$scope.content = "";
		$scope.createTimeStart = "";
		$scope.createTimeend = "";
		$scope.orgId = "";
		$scope.orgCode = "";
		$scope.readType = "";
		$scope.roleIds = "";
		$scope.userIds = "";

		//切换
		$scope.TypeSelect = function() {
			var json={
				type:$scope.readType
			};
			MailtemplatesettingsAddCtrlSel.zwf(json)
			.then(function(res){
			if(res.data.code=="000000"){
				$scope.zwflist=JSON.parse(res.data.content);
				console.log($scope.zwflist)
			}else{
				$rootScope.tipService.setMessage(res.data.message, 'warning');

			}},function(error){
				$rootScope.tipService.setMessage(error.data.message, 'warning');
			})

			}
		$scope.Zwchange=function(){
			if($scope.Zwselect == undefined || $scope.Zwselect == '') {
				$rootScope.tipService.setMessage('请先选择占位符', 'warning');
			}else{
				 editor.txt.append('<span>'+$scope.Zwselect+'<span>')
					 console.log()
			}
		}
		//创建公告
		$scope.addNoticeInfo = function() {
			if($scope.addOrgVal == undefined || $scope.addOrgVal == '') {
				$rootScope.tipService.setMessage('请先选择机构', 'warning');
			} else if($scope.readType == undefined || $scope.readType == '') {
				$rootScope.tipService.setMessage('请先选择邮件发送类型', 'warning');
			}else if($scope.subject == undefined || $scope.subject == '') {
				$rootScope.tipService.setMessage('请先填写主题', 'warning');
			}else if($scope.Zwselect == undefined || $scope.Zwselect == '') {
				$rootScope.tipService.setMessage('请先选择占位符', 'warning');
			}else if ($scope.contentText == undefined || $scope.contentText == '') {
				$rootScope.tipService.setMessage('请先填写正文', 'warning');
			}else{
			var emailTemplate = {
				orgId:$scope.allotOrgId,
				orgCode:$scope.superorgCode,
				subject:$scope.subject,
				text:$scope.contentText,
				type:$scope.readType
			}
			console.log(emailTemplate)
			var json = {
				emailTemplate: emailTemplate
			}
			MailtemplatesettingsAddCtrlSel.addInfo(json)
				.then(function(res) {
					if (res.data.code =="000000") {
						$rootScope.tipService.setMessage(res.data.message, 'warning');
						$state.go('tabs.Mailtemplatesettings');
					}else{
						$rootScope.tipService.setMessage(res.data.message, 'warning');
					}

				},function(error){
					$rootScope.tipService.setMessage(error.data.message, 'warning');
				})
			}
		}
	}])
	.factory('MailtemplatesettingsAddCtrlSel', ['$http', 'localStorageService', 'myHttp', '$q', '$rootScope', function($http, localStorageService, myHttp, $q, $rootScope) {
		return {
			addInfo: function(json) {
				var deferred = $q.defer();
				$http({
						method: 'POST',
						url: $rootScope.baseUrl + 'email/template/save',
						data: json
					})
					.then(function(res) { // 调用承诺API获取数据 .resolve
						deferred.resolve(res);
					}, function(res) { // 处理错误 .reject
						deferred.reject(res);
					});
				return deferred.promise;
			},
			zwf: function(json) {
				var deferred = $q.defer();
				$http({
						method: 'POST',
						url: $rootScope.baseUrl + 'email/placeholder/query',
						data: json
					})
					.then(function(res) { // 调用承诺API获取数据 .resolve
						deferred.resolve(res);
					}, function(res) { // 处理错误 .reject
						deferred.reject(res);
					});
				return deferred.promise;
			}

		}
	}])