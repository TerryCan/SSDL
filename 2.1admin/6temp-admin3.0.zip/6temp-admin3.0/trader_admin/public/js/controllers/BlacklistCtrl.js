app.controller('BlacklistCtrl', ['$rootScope', '$scope', 'getPageNum', 'BlacklistCtrlSer', 'dataSer', 'localStorageService', 'confirmService','$timeout','VarietiesCtrlSer','getadminState','timestamp', function ($rootScope, $scope, getPageNum, BlacklistCtrlSer , dataSer, localStorageService, confirmService,$timeout,VarietiesCtrlSer,getadminState,timestamp) {
    $scope.toggleTraderSearchState = false;
    $scope.Toggle = function () {
        $scope.toggleTraderSearchState = !$scope.toggleTraderSearchState;
        if ($scope.toggleTraderSearchState) {
            $('.search_column').css('height', 'auto');
        }
        else {
            $('.search_column').css('height', '36px');
        }
    };
    localStorageService.clear('userIdChecked');
    $scope.tableshow = false;

    $scope.allotTypeData=getadminState;
    $scope.allotTypeText = function(val) {
        for (var i = 0, r = $scope.allotTypeData.length; i < r; i++) {
            if (val == $scope.allotTypeData[i].id) {
                return $scope.allotTypeData[i].name;
            }
        }
    }
    $scope.ToState='';
    $scope.search = function (type) {
        $scope.toggleTraderSearchState = false;
        $('.search_column').css('height', '36px');
        if (type == 'search') {
            pageInitialize()
        };
        $scope.orgCode=localStorageService.get('oldOrgCode');
        var json = {
            page: $scope.currentPage,
            rows: $scope.showNum.showNum,
            orders: 'asc',
            search_EQ_orgCode: ($scope.orgCode) ?  $scope.orgCode : '',
            search_EQ_state: $scope.ToState,
           //search_EQ_commodityCustomizedGroupName: $scope.commodityCustomizedGroupName,

        };
        BlacklistCtrlSer.search(json)
            .then(function (res) {
                console.log(res)
                if (res.code == '000000') {
                    $scope.showPage = true;
                    var data = JSON.parse(res.content);
                    $scope.searchResult = data.content;
                    console.log($scope.searchResult);
                    $scope.dataNum = data.totalElements;
                    $scope.PageNum();

                    var checkedUserId=localStorageService.get('userIdChecked'); //获取上一次存储的id
                    $scope.switchUserId(checkedUserId,$scope.searchResult); //执行选中方法
                } else {
                    $rootScope.tipService.setMessage(res.message, 'warning');
                }
            }, function (error) {
                $rootScope.tipService.setMessage(error.message, 'warning');
            });
    }
    //时间戳
    $scope.timestamp = function(stamp) {
        return timestamp.timestampCoverHms(stamp, 'all')
    }

    /**
     * 分页功能实现TerryMin
     * **/
    $scope.showDataChoose = getPageNum.pageNum(); //获取分页
    $scope.showNum = $scope.showDataChoose[0]; //初始显示刷具条数
    $scope.showPage = false;
    var pageInitialize = function () {
        $scope.dataNum = 0; //数据总条数
        $scope.dataPage = 0; //分页数
        $scope.currentPage = 1; //当前页数
        $scope.jumpPageNum = '';
    };
    pageInitialize();

    // x/y $scope.dataPage
    $scope.PageNum = function () {
        $scope.showPage = true;
        if ($scope.showNum.showNum < $scope.dataNum) {
            $scope.dataPage =Math.ceil($scope.dataNum / $scope.showNum.showNum);
        } else {
            $scope.dataPage = 0;
        }
    };
    //上页下页 $scope.currentPage
    $scope.pageSlect = function (type) {
        if (type == 'prev') {
            if ($scope.currentPage != 1) {
                $scope.currentPage--;
                $scope.PageNum();
                $scope.search();
            }
        } else {
            if ($scope.currentPage < $scope.dataPage) {
                $scope.currentPage++;
                $scope.PageNum();
                $scope.search();
            }
        }
    };
    // 每页条数单元
    $scope.pageSelect = function (params) {
        $scope.showNum.showNum = params.showNum;
        pageInitialize();
        $scope.search();
    };
    //页数跳转 currentPage
    $scope.jumpPage = function (num) {
        num = parseInt(num);
        if (parseInt(num, 10) === num && num <= ($scope.dataPage + 1) && num > 0) {
            $scope.currentPage = num;
            $scope.PageNum();
            $scope.search();
        }
    };
    dataSer.organizeQuerySer()
        .then(function (res) {
            $scope.orgList = res;
            console.log($scope.orgList)
        });

    $scope.addOrgValFTC = function (data) {
        console.log(data);
        $scope.orgId = data.orgId;
        $scope.orgCode = data.orgCode;
        $scope.addOrgVal = data.text;
    }
    //全部状态下所属机构
    dataSer.organizeQuerylistSer()
        .then(function (res) {
            $scope.orgAllList = res;
        });

    $scope.adjustText = function (orgId) {
        if ($scope.orgAllList) {
            for (var i = 0, r = $scope.orgAllList.length; i < r; i++) {
                if ($scope.orgAllList[i].orgId == orgId) {
                    return $scope.orgAllList[i].text;
                }
            }
        }
    }
    //品种列表
    VarietiesCtrlSer.searchlist()
        .then(function (res) {
            console.log(res)
            if (res.code == '000000') {
                $scope.showPage = true;
                var data = JSON.parse(res.content);
                $scope.searchdatalist = data;
                console.log($scope.searchdatalist);
                $scope.searchdatalistty=function(commodityId){
                    for (var i = 0, r = $scope.searchdatalist.length; i < r; i++) {
                        if ($scope.searchdatalist[i].commodityId == commodityId) {
                            return $scope.searchdatalist[i].commodityName;
                        }
                    }
                }
            } else {
                $rootScope.tipService.setMessage(res.message, 'warning');
            }
        }, function (error) {
            $rootScope.tipService.setMessage(error.message, 'warning');
        });
    $scope.add = function () {
        $scope.tableshow = true;
        $scope.addEditText = '新增';
        $scope.commodityId='';
        $scope.addOrgVal='';
    }

    $scope.addSubmit = function () {
        var configCommodityBlacklistVIce={
                commodityId:$scope.commodityId,
                orgId:$scope.orgId,
                orgCode:$scope.orgCode
        }
        var json = {
            configCommodityBlacklistVIce: configCommodityBlacklistVIce
        }
        BlacklistCtrlSer.Addsub(json)
            .then(function (res) {
                if (res.data.code == "000000") {
                    $scope.tableshow = false;
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                    localStorageService.clear('userIdChecked');
                    $scope.search();
                } else {
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                }
            }, function (error) {
                $rootScope.tipService.setMessage(error.data.message, 'warning');
            })
    }
    $scope.hideRoleaut=true;
    $scope.showRoleaut=true;
// 选择
    $scope.checkedTab1 = function (index,applyId,commodityBlacklistId,commodityId,createTime,createUser,orgCode,orgId,state){
        $scope.chooseUserData={
            applyId:applyId,
            commodityBlacklistId:commodityBlacklistId,
            commodityId:commodityId,
            createTime:createTime,
            createUser:createUser,
            orgCode:orgCode,
            orgId:orgId,
            state:state,
        };
        console.log($scope.chooseUserData)
        var userIdChecked = localStorageService.get('userIdChecked');
        $('#dataReport input[type=checkbox]').prop('checked', false);
        if (commodityBlacklistId == userIdChecked) {
            localStorageService.clear('userIdChecked');
            $scope.chooseItemTab1 = '';
            $scope.applyId='';
            $scope.state='';
        } else {
            $('#dataReport input[type=checkbox]').eq(index).prop('checked', true);
            localStorageService.update('userIdChecked', commodityBlacklistId);
            $scope.chooseItemTab1 = commodityBlacklistId;
            $scope.applyId = applyId;
            $scope.state=state;
        }
        if ($scope.chooseUserData.applyId != null) {
            console.log($scope.chooseUserData.applyId)
            $scope.hideRoleaut=false;
            $scope.showRoleaut=false;
        }else{
            $scope.showRoleaut=true;
            $scope.hideRoleaut=true;
        };
    };
    // 存储选中
    $scope.switchUserId = function (parameter, responseData) {
        $timeout(function () {
            for (var i = 0; i < responseData.length; i++) {
                if (parameter == responseData[i].commodityBlacklistId) {
                    $('#dataReport input[type=checkbox]').eq(i).prop('checked', true);
                    return;
                }
            }
        }, 1500)
    };

    $scope.apply = function () {
        if (!$scope.chooseItemTab1) {
            $rootScope.tipService.setMessage('请先选择黑名单信息', 'warning');
        } else {
            $scope.auditshow = true;
            $scope.addEditTexts = "申请变更";
            $scope.applyId= $scope.chooseUserData.applyId;
            $scope.commodityBlacklistId= $scope.chooseUserData.commodityBlacklistId;
            $scope.commodityId= $scope.chooseUserData.commodityId;
            $scope.createTime= $scope.chooseUserData.createTime;
            $scope.createUser= $scope.chooseUserData.createUser;
            $scope.orgCode= $scope.chooseUserData.orgCode;
            $scope.orgId= $scope.chooseUserData.orgId;
            //匹配机构代码
            var json = {
                page: 1,
                rows: 9999,
                search_A_EQ_state: 1
            };
            dataSer.getOrganize(json).then(function (res) {
                if (res.code == '000000') {
                    $scope.equalOrgCode = JSON.parse(res.content).content;
                    //console.log($scope.equalOrgCode);
                    for (var i = 0; i < $scope.equalOrgCode.length; i++) {
                        if ($scope.chooseUserData.orgId == $scope.equalOrgCode[i].orgId) {
                            $scope.addOrgVal = $scope.equalOrgCode[i].orgName + '(' + $scope.equalOrgCode[i].orgNum + ')';
                            //console.log($scope.addOrgVal)
                        }
                    }
                } else {
                    console.log(res);
                }
            });
        }
    }

    $scope.applySubmit=function(){
        var configCommodityBlacklistVIce={
            commodityBlacklistId:$scope.commodityBlacklistId,
            commodityId:$scope.commodityId,
            orgId:$scope.orgId,
            orgCode:$scope.orgCode
        }
        var json = {
            configCommodityBlacklistVIce: configCommodityBlacklistVIce
        }
        BlacklistCtrlSer.tradeapply(json)
            .then(function (res) {
                if (res.data.code == "000000") {
                    $scope.auditshow = false;
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                    localStorageService.clear('userIdChecked');
                    $scope.search();
                }else{
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                }
            },function(error){
                $rootScope.tipService.setMessage(error.data.message, 'warning');
            })
    }

    $scope.getaudit=function () {
        if (!$scope.applyId) {
            $rootScope.tipService.setMessage('请先申请变更', 'warning');
        } else {
            var json={
                applyId:$scope.applyId
            }
            BlacklistCtrlSer.Getaudit(json)
                .then(function(res){
                    console.log(res)
                    if(res.data.code=="000000"){
                        var getData=JSON.parse(res.data.content);
                        $scope.getaduitDatalist=getData.configCommodityBlacklistV;
                        console.log($scope.getaduitDatalist)
                        $scope.addEditText = "审核交易变更";
                        $scope.auditGetshow = true;
                        $scope.commodityBlacklistId= $scope.getaduitDatalist.commodityBlacklistId;
                        $scope.commodityId= $scope.getaduitDatalist.commodityId;
                        $scope.orgId= $scope.getaduitDatalist.orgId;
                        $scope.orgCode= $scope.getaduitDatalist.orgCode;;
                        //匹配机构代码
                        var json = {
                            page: 1,
                            rows: 9999,
                            search_A_EQ_state: 1
                        };
                        dataSer.getOrganize(json).then(function (res) {
                            if (res.code == '000000') {
                                $scope.equalOrgCode = JSON.parse(res.content).content;
                                //console.log($scope.equalOrgCode);
                                for (var i = 0; i < $scope.equalOrgCode.length; i++) {
                                    if ($scope.chooseUserData.orgId == $scope.equalOrgCode[i].orgId) {
                                        $scope.addOrgVal = $scope.equalOrgCode[i].orgName + '(' + $scope.equalOrgCode[i].orgNum + ')';
                                        //console.log($scope.addOrgVal)
                                    }
                                }
                            } else {
                                console.log(res);
                            }
                        });
                    }
                })

        }
    }

    $scope.auditRoletrueData = function (tmpOpt) {
        var json = {
            applyId: $scope.applyId,
            auditRs: tmpOpt
        };
        BlacklistCtrlSer.auditRoletruetion(json)
            .then(function (res) {
                if (res.data.code == '000000') {
                    $scope.auditGetshow = false;
                    localStorageService.clear('userIdChecked');
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                    $scope.search();
                } else {
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                }
            },function(error) {
                $rootScope.tipService.setMessage(error.data.message, 'warning');
            })
    }
    $scope.auditRolefalseData = function (tmpOpt) {
        var json = {
            applyId: $scope.applyId,
            auditRs: tmpOpt
        };
        BlacklistCtrlSer.auditRoletruetion(json)
            .then(function (res) {
                if (res.data.code == '000000') {
                    $scope.auditGetshow = false;
                    localStorageService.clear('userIdChecked');
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                    $scope.search();
                } else {
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                }
            },function(error) {
                $rootScope.tipService.setMessage(error.data.message, 'warning');
            })
    }

    $scope.addmember = function () {
        var configCustomizedGroupRelationVIce={
            commodityCustomizedGroupId:$scope.commodityCustomizedGroupId,
            members:[
                {
                    userId:$scope.userId,
                    orgId:$scope.orgId,
                    type:$scope.type
                }
            ]

        }
        var json={
            configCustomizedGroupRelationVIce:configCustomizedGroupRelationVIce
        }
        BlacklistCtrlSer.CustomizedData(json)
            .then(function (res){
                console.log(res)
            })
    }
    $scope.pass=function() {
        if (!$scope.chooseItemTab1) {
            $rootScope.tipService.setMessage('请先选择黑名单信息', 'warning');
        } else {
            var json={
                commodityBlacklistId:$scope.chooseItemTab1
            }
            BlacklistCtrlSer.passCheck(json)
                .then(function (res) {
                    if (res.data.code == '000000') {
                        localStorageService.clear('userIdChecked');
                        $rootScope.tipService.setMessage(res.data.message, 'warning');
                        $scope.search();
                    } else {
                        $rootScope.tipService.setMessage(res.data.message, 'warning');
                    }
                }, function (error) {
                    $rootScope.tipService.setMessage(error.data.message, 'warning');
                });
        }
    }
    $scope.fail=function() {
        if (!$scope.chooseItemTab1) {
            $rootScope.tipService.setMessage('请先选择黑名单信息', 'warning');
        } else {
            var json={
                commodityBlacklistId:$scope.chooseItemTab1
            }
            BlacklistCtrlSer.failedCheck(json)
                .then(function (res) {
                    if (res.data.code == '000000') {
                        localStorageService.clear('userIdChecked');
                        $rootScope.tipService.setMessage(res.data.message, 'warning');
                        $scope.search();
                    } else {
                        $rootScope.tipService.setMessage(res.data.message, 'warning');
                    }
                }, function (error) {
                    $rootScope.tipService.setMessage(error.data.message, 'warning');
                });
        }
    }
    $scope.open=function() {
        if (!$scope.chooseItemTab1) {
            $rootScope.tipService.setMessage('请先选择黑名单信息', 'warning');
        } else {
            var json={
                commodityBlacklistId:$scope.chooseItemTab1
            }
            BlacklistCtrlSer.open(json)
                .then(function (res) {
                    if (res.data.code == '000000') {
                        localStorageService.clear('userIdChecked');
                        $rootScope.tipService.setMessage(res.data.message, 'warning');
                        $scope.search();
                    } else {
                        $rootScope.tipService.setMessage(res.data.message, 'warning');
                    }
                }, function (error) {
                    $rootScope.tipService.setMessage(error.data.message, 'warning');
                });
        }
    }

    $scope.close=function() {
        if (!$scope.chooseItemTab1) {
            $rootScope.tipService.setMessage('请先选择黑名单信息', 'warning');
        } else {
            confirmService.set('确认提示', '确定要注销此黑名单?', function () {
                var json={
                    commodityBlacklistId:$scope.chooseItemTab1
                }
                BlacklistCtrlSer.Close(json)
                    .then(function (res) {
                        if (res.data.code == '000000') {
                            localStorageService.clear('userIdChecked');
                            $rootScope.tipService.setMessage(res.data.message, 'warning');
                            $scope.search();
                        } else {
                            $rootScope.tipService.setMessage(res.data.message, 'warning');
                        }
                    }, function (error) {
                        $rootScope.tipService.setMessage(error.data.message, 'warning');
                    });
                confirmService.clear();
            });
        }
    }

}])
    .factory('BlacklistCtrlSer', ['$http', 'localStorageService', 'myHttp', '$q', '$rootScope', function ($http, localStorageService, myHttp, $q, $rootScope) {
        return {
            //查询
            search: function (json) {
                var deferred = $q.defer();
                myHttp.post("admin/commodity/blacklist/query/page", json)
                    .then(function (res) { // 调用承诺API获取数据 .resolve
                        deferred.resolve(res);
                    }, function (res) { // 处理错误 .reject
                        deferred.reject(res);
                    });
                return deferred.promise;
            },
            searchlist:function(){
                var deferred = $q.defer();
                myHttp.post("admin/config/product/commodity/query/list")
                    .then(function (res) { // 调用承诺API获取数据 .resolve
                        deferred.resolve(res);
                    }, function (res) { // 处理错误 .reject
                        deferred.reject(res);
                    });
                return deferred.promise;
            },
            Addsub: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'admin/commodity/blacklist/create',
                    data: json
                }).then(function successCallback(response) {
                    console.log(response)
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
            tradeapply: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'admin/commodity/blacklist/apply',
                    data: json
                }).then(function successCallback(response) {
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
            Getaudit: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'admin/commodity/blacklist/apply/get',
                    data: json
                }).then(function successCallback(response) {
                    console.log(response)
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
            auditRoletruetion: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'admin/commodity/blacklist/audit',
                    data: json
                }).then(function successCallback(response) {
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
            Close: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'admin/commodity/blacklist/close',
                    data: json
                }).then(function successCallback(response) {
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
            //通过
            passCheck: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'admin/commodity/blacklist/pass',
                    data: json
                }).then(function successCallback(response) {
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
            //不通过
            failedCheck: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'admin/commodity/blacklist/fail',
                    data: json
                }).then(function successCallback(response) {
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
            //重新提交
            open: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'admin/commodity/blacklist/open',
                    data: json
                }).then(function successCallback(response) {
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            }
        }
    }])
