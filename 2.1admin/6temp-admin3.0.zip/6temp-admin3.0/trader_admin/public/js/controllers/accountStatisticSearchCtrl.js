app.controller('accountStatisticSearchCtrl', ['$rootScope', '$scope', 'accountStatisticSearchSer',  '$timeout', '$sce', 'getPageNum','getCurrencyMethod','timestamp', function ($rootScope, $scope, accountStatisticSearchSer, $timeout, $sce, getPageNum,getCurrencyMethod,timestamp) {
    $scope.toggleTraderSearchState=false;
    $scope.Toggle = function(){
        $scope.toggleTraderSearchState = !$scope.toggleTraderSearchState;
        if($scope.toggleTraderSearchState){
           $('.search_column').css('height','auto');
        }
        else{
           $('.search_column').css('height','36px');
        }
    };

    // 货币转换
    getCurrencyMethod.obtainCurrencyType().then(function (res) {
        if(res.code=='000000'){
            $scope.currencyList = JSON.parse(res.content);
        }
    });
    $scope.loginName='';
    $scope.orgCodeNum='';
    $scope.createTimeStart=timestamp.defaultDate('start');
    $scope.createTimeEnd=timestamp.defaultDate();
    $scope.search = function () {
        $scope.toggleTraderSearchState=false;
        $('.search_column').css('height','36px');

        if($scope.createTimeStart && $scope.createTimeEnd){
            var sumBankIoParams = {
                orgCode:($scope.upOrgCode)?$scope.upOrgCode:'',
                loginName: $scope.loginName,
                createTimeS:($scope.createTimeStart)?($scope.createTimeStart.split(' ')[0]+"T"+$scope.createTimeStart.split(' ')[1]):'',
                createTimeE:($scope.createTimeEnd)?($scope.createTimeEnd.split(' ')[0]+"T"+$scope.createTimeEnd.split(' ')[1]):''
            };
            var json={
                sumBankIoParams:sumBankIoParams
            };
            accountStatisticSearchSer.accountStatisticSearch(json)
                .then(function (response) {
                    if (response.code == "000000" && response.content) {
                        $scope.results = JSON.parse(response.content);
                        console.log( $scope.results)

                        var source = {
                            localdata: $scope.results,
                            datatype: "array",
                            datafields: [
                                {name: 'ioInSumNumber', type: 'string'},
                                {name: 'ioOutSumNumber', type: 'string'},
                                {name: 'ioInOutSumNumber', type: 'string'},
                                {name: 'currency', type: 'string'},
                                {name: 'feeSumNumber', type: 'string'},

                                {name: 'rechargeInSumNumber', type: 'string'},
                                {name: 'withdrawOutSumNumber', type: 'string'},
                                {name: 'moneyInSumNumber', type: 'string'},
                                {name: 'moneyOutSumNumber', type: 'string'},
                                {name: 'otherSumNumber', type: 'string'}
                            ]
                        };
                        var dataAdapter = new $.jqx.dataAdapter(source);
                        $("#entrustDetailGrid").jqxGrid(
                            {
                                width: 100 + '%',
                                height: 85 + '%',
                                theme: 'metrodark',
                                source: dataAdapter,//数据源
                                columnsresize: true,
                                selectionmode: 'singlecell',
                                clipboard: true,
                                columns: [  //表格数据域
                                    {
                                        text: '总汇入',
                                        datafield: 'ioInSumNumber',
                                        width: '10%',
                                        minwidth: 10 + '%',
                                        align: 'center'
                                    },
                                    {
                                        text: '总汇出',
                                        datafield: 'ioOutSumNumber',
                                        width: '10%',
                                        minwidth: 10 + '%',
                                        align: 'center'
                                    },
                                    {
                                        text: '净汇入',
                                        datafield: 'ioInOutSumNumber',
                                        width: '10%',
                                        minwidth: 10 + '%',
                                        align: 'center'
                                    },
                                    {
                                        text: '币种',
                                        datafield: 'currency',
                                        width: '10%',
                                        minwidth: 10 + '%',
                                        align: 'center',
                                        cellsrenderer: function (row, columnfield, value, defaulthtml, columnproperties) {
                                            if ($scope.currencyList) {
                                                for (var i = 0; i < $scope.currencyList.length; i++) {
                                                    if (value == $scope.currencyList[i].currency) {
                                                        return $scope.currencyList[i].currencyName;
                                                    }
                                                }
                                            }
                                        }
                                    },
                                    {
                                        text: '手续费',
                                        datafield: 'feeSumNumber',
                                        width: '10%',
                                        minwidth: 10 + '%',
                                        align: 'center'
                                    },
                                    {
                                        text: '调入',
                                        datafield: 'rechargeInSumNumber',
                                        width: '10%',
                                        minwidth: 10 + '%',
                                        align: 'center'
                                    },
                                    {
                                        text: '调出',
                                        datafield: 'withdrawOutSumNumber',
                                        width: '10%',
                                        minwidth: 10 + '%',
                                        align: 'center'
                                    },
                                    {
                                        text: '入金',
                                        datafield: 'moneyInSumNumber',
                                        width: '10%',
                                        minwidth: 10 + '%',
                                        align: 'center'
                                    },
                                    {
                                        text: '出金',
                                        datafield: 'moneyOutSumNumber',
                                        width: '10%',
                                        minwidth: 10 + '%',
                                        align: 'center'
                                    },
                                    {
                                        text: '其他合计',
                                        datafield: 'otherSumNumber',
                                        width: '10%',
                                        minwidth: 10 + '%',
                                        align: 'center'
                                    }

                                ]
                            });
                    } else {
                        $rootScope.tipService.setMessage(response.message, 'warning');
                    }
                }, function (error) {
                    $rootScope.tipService.setMessage(error.message, 'warning');
                });
        }else{
            $rootScope.tipService.setMessage('请先选择起始时间!', 'warning');
        }
    };
}])
// Server
    .factory('accountStatisticSearchSer', ['$http', 'localStorageService', 'myHttp', '$q', '$rootScope', function ($http, localStorageService, myHttp, $q, $rootScope) {
        return {
            accountStatisticSearch: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + "exbank/bank/io/query/sum",
                    data: json,
                    headers: {
                        'Content-Type': 'application/json;charset=UTF-8'
                    }
                }).success(function (res) {
                    deferred.resolve(res);
                }).error(function (res) {
                    deferred.reject(res);
                });
                return deferred.promise;

            }
        }
    }]);