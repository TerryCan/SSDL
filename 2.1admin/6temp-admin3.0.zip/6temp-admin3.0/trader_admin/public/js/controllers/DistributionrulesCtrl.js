app.controller('DistributionrulesCtrl', ['$rootScope', '$scope', 'DistributionrulesCtrlSer', 'getPageNum', 'dataSer', '$state', 'localStorageService', 'CommissionallocationAddCtrlSer','VarietiesCtrlSer','memberMangerCtrlSer', function($rootScope, $scope, DistributionrulesCtrlSer, getPageNum, dataSer, $state, localStorageService, CommissionallocationAddCtrlSer,VarietiesCtrlSer,memberMangerCtrlSer) {
    $scope.toggleTraderSearchState = false;
    $scope.Toggle = function() {
        $scope.toggleTraderSearchState = !$scope.toggleTraderSearchState;
        if ($scope.toggleTraderSearchState) {
            $('.search_column').css('height', 'auto');
        } else {
            $('.search_column').css('height', '36px');
        }
    };
    localStorageService.clear('userIdChecked');
    //品种列表
    VarietiesCtrlSer.searchlist()
        .then(function (res) {
            console.log(res)
            if (res.code == '000000') {
                var data = JSON.parse(res.content);
                $scope.searchdatalist = data;
                console.log($scope.searchdatalist);
            } else {
                $rootScope.tipService.setMessage(res.message, 'warning');
            }
        }, function (error) {
            $rootScope.tipService.setMessage(error.message, 'warning');
        });

    $scope.pzlisttype=function (commodityId) {
        for (var i = 0, r = $scope.searchdatalist.length; i < r; i++) {
            if ($scope.searchdatalist[i].commodityId == commodityId) {
                return $scope.searchdatalist[i].commodityName;

            }
        }
    }


    $scope.commodityIds = "";
    $scope.addOrgVal = "";
    $scope.superorgCode = "";
    $scope.allotToCode = "";
    $scope.choosedistributionState = "";
    dataSer.organizeQuerySer()
        .then(function(res) {
            $scope.orgList = res;
        });
    //全部状态下所属机构
    dataSer.organizeQuerylistSer()
        .then(function(res) {
            $scope.orgAllList = res;
        });
    $scope.addOrgValFTC = function(data) {
        console.log(data);
        $scope.superOrgId = data.orgId;
        $scope.superorgCode = data.orgCode;
        $scope.addOrgVal = data.text;
    };

    $scope.allotToCodesValFTC = function(data) {
        console.log(data);
        $scope.superOrgId = data.orgId;
        $scope.allotToCode = data.orgCode;
        $scope.allotToCodes = data.text;
    };

    $scope.search = function(type) {
        $scope.toggleTraderSearchState=false;
        $('.search_column').css('height', '36px');
        if (type == 'search') {
            pageInitialize()
        };
        $scope.orgCode=localStorageService.get('oldOrgCode');
        var json = {
            page: $scope.currentPage,
            rows: $scope.showNum.showNum,
            orders: 'asc',
            search_EQ_commodityId:$scope.commodityIds,
            search_EQ_allotType: $scope.choosedistributionState,

        };
        if($scope.organizeValue==true && $scope.downOrganizeValue==false){
            json.search_EQ_allotOrgCode=($scope.orgCode)?$scope.orgCode:'';
        }
        if($scope.organizeValue==false && $scope.downOrganizeValue==true){
            json.search_LLIKE_allotToOrgCode=($scope.orgCode)?$scope.orgCode+'-':'';
        }
        DistributionrulesCtrlSer.search(json)
            .then(function(res) {
                if (res.code == '000000') {
                    $scope.showPage = true;
                    $scope.searchResult = JSON.parse(res.content).content;
                    console.log($scope.searchResult)
                    $scope.dataNum = JSON.parse(res.content).totalElements;
                    $scope.PageNum();
                    //var checkedUserId=localStorageService.get('userIdChecked'); //获取上一次存储的id
                    //$scope.switchUserId(checkedUserId,$scope.searchResult); //执行选中方法
                } else {
                    $rootScope.tipService.setMessage(res.message, 'warning');
                }
            }, function(error) {
                $rootScope.tipService.setMessage(error.message, 'warning');
            });
    }

    $scope.allotTypeData = [{
        name: '仓息',
        val: '6'
    }, {
        name: '手续费',
        val: '7'
    }];
    //本级机构名称
    $scope.adjustText = function(allotOrgCode) {
        if ($scope.orgAllList) {
            for (var i = 0, r = $scope.orgAllList.length; i < r; i++) {
                if ($scope.orgAllList[i].orgCode == allotOrgCode) {
                    return $scope.orgAllList[i].orgName;

                }
            }
        }
    }

    $scope.getOrgVal = function(allotToOrgCode) {
        if ($scope.orgAllList) {
            for (var i = 0; i < $scope.orgAllList.length; i++) {
                if (allotToOrgCode == $scope.orgAllList[i].orgCode) {
                    return $scope.orgAllList[i].orgName;
                }
            }
        }
    }

    //分配佣金类型
    $scope.allotTypeText = function(val) {
        for (var i = 0, r = $scope.allotTypeData.length; i < r; i++) {
            if (val == $scope.allotTypeData[i].val) {
                return $scope.allotTypeData[i].name;
            }
        }
    }
    $scope.allotValueTypeData = [{
        name: '百分比',
        val: '1'
    }, {
        name: '固定金额',
        val: '2'
    }];
    $scope.allotValueTypeText = function(val) {
        for (var i = 0, r = $scope.allotValueTypeData.length; i < r; i++) {
            if (val == $scope.allotValueTypeData[i].val) {
                return $scope.allotValueTypeData[i].name;
            }
        }
    }

    $scope.tableshow=false;
    $scope.addEditText="";
    $scope.Add=function(){
        $scope.tableshow=true;
        $scope.addEditText="新增";
        $scope.addOrgVal="";
        $scope.allnotOrgVal="";
        $scope.commodityIdval="";
        $scope.allotType="";
        $scope.allottoOrgIdNum="";
        $scope.allotOrgId="";
        $scope.allotVooType="";
        $scope.selfNum="";
        $scope.nextNum="";
        $scope.taxesNum="";
        $scope.channelNum="";
    }


    $scope.addOrgValFTCs= function(da) {
        $scope.allotOrgId = da.orgId;
        $scope.superorgCode = da.orgCode;
        $scope.addOrgVal = da.text;
        //品种列表
        DistributionrulesCtrlSer.AllNOTLIKEQuerySer($scope.superorgCode)
            .then(function (res) {
                console.log(res)
                    $scope.showPage = true;
                    $scope.allnotlickList = res;
                    console.log($scope.allnotlickList);
            }, function (error) {
                $rootScope.tipService.setMessage(error.message, 'warning');
            });
    }

    $scope.AllNOTLIKE = function(data) {
        console.log(data);
        $scope.allottoOrgIdNum = data.orgId;
        $scope.allnotorgCodeNum = data.orgCode;
        $scope.allnotOrgVal = data.text;
        //品种列表
        VarietiesCtrlSer.searchlist($scope.allottoOrgIdNum)
            .then(function (res) {
                console.log(res)
                if (res.code == '000000') {
                    $scope.showPage = true;
                    var data = JSON.parse(res.content);
                    $scope.prolist = data;
                    console.log($scope.prolist)
                } else {
                    $rootScope.tipService.setMessage(res.message, 'warning');
                }
            }, function (error) {
                $rootScope.tipService.setMessage(error.message, 'warning');
            });

    }



    //保存数据
    $scope.addNewSubmit = function() {
            if ($scope.addOrgVal == undefined || $scope.addOrgVal == '') {
                $rootScope.tipService.setMessage('请选择所属机构编号', 'warning');
            } else if ($scope.commodityIdval == undefined || $scope.commodityIdval == '') {
                $rootScope.tipService.setMessage('请先填写分配产品', 'warning');
            } else if ($scope.allnotOrgVal == undefined || $scope.allnotOrgVal == '') {
                $rootScope.tipService.setMessage('请选择分配机构', 'warning');
            } else if ($scope.allotType == undefined || $scope.allotType == '') {
                $rootScope.tipService.setMessage('请选择分配佣金类型', 'warning');
            } else if ($scope.allotVooType == undefined || $scope.allotVooType == '') {
                $rootScope.tipService.setMessage('请选择分配类型', 'warning');
            } else if ($scope.nextNum == undefined || $scope.nextNum === '') {
                $rootScope.tipService.setMessage('请填写下级百分比', 'warning');
            } else if ($scope.taxesNum == undefined || $scope.taxesNum === '') {
                $rootScope.tipService.setMessage('请填写税费百分比', 'warning');
            } else if ($scope.channelNum == undefined || $scope.channelNum === '') {
                $rootScope.tipService.setMessage('请填写通道百分比', 'warning');
            } else if($scope.allotVooType==1){
                $scope.allotType = parseFloat($scope.allotType);
                $scope.allotVooType= parseInt($scope.allotVooType);
                $scope.nextNum = parseFloat($scope.nextNum);
                $scope.taxesNum = parseFloat($scope.taxesNum);
                $scope.channelNum = parseFloat($scope.channelNum);
                $scope.selfNum = 100 - $scope.nextNum - $scope.taxesNum - $scope.channelNum;
                var allNum = $scope.nextNum + $scope.taxesNum + $scope.channelNum;
                console.log(allNum, typeof(allNum))
                if (allNum > 100) {
                    console.log('y')
                    $rootScope.tipService.setMessage('四项百分比之和不能超过100', 'warning');
                } else {
                    console.log('x')
                    var configAllot= {
                        commodityId: $scope.commodityIdval,
                        allotType: $scope.allotType,
                        allotToOrgId: $scope.allottoOrgIdNum,
                        allotOrgId: $scope.allotOrgId,
                        allotValueType: $scope.allotVooType,
                        selfNum: $scope.selfNum,
                        nextNum: $scope.nextNum,
                        taxesNum: $scope.taxesNum,
                        channelNum: $scope.channelNum
                    }
                }
            } else if($scope.allotVooType==2){
                if ($scope.selfNum == undefined || $scope.selfNum === '') {
                    $rootScope.tipService.setMessage('请填写本级百分比', 'warning');
                }else{
                    $scope.allotType = parseFloat($scope.allotType);
                    $scope.allotVooType= parseInt($scope.allotVooType);
                    $scope.nextNum = parseFloat($scope.nextNum);
                    $scope.taxesNum = parseFloat($scope.taxesNum);
                    $scope.channelNum = parseFloat($scope.channelNum);
                    $scope.selfNum = parseFloat($scope.selfNum);
                    console.log('x')
                    var configAllot = {
                        commodityId: $scope.commodityIdval,
                        allotType: $scope.allotType,
                        allotToOrgId: $scope.allottoOrgIdNum,
                        allotOrgId: $scope.allotOrgId,
                        allotValueType: $scope.allotVooType,
                        selfNum: $scope.selfNum,
                        nextNum: $scope.nextNum,
                        taxesNum: $scope.taxesNum,
                        channelNum: $scope.channelNum
                    }
                }
            }
        var json = {
            configAllotRuleInfoVIce:configAllot
        }
        console.log(json)
        DistributionrulesCtrlSer.Create(json)
            .then(function(res) {
                console.log(res)
                if (res.data.code == '000000') {
                    $scope.tableshow=false;
                    localStorageService.clear('userIdChecked');
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                    $scope.search();
                } else {
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                }
            });

    }

    function changeV(val) {
        val = val.replace(/[^\d.]/g, ""); //清除“数字”和“.”以外的字符
        val = val.replace(/^\./g, ""); //验证第一个字符是数字而不是.
        val = val.replace(/\.{2,}/g, "."); //只保留第一个. 清除多余的
        val = val.replace(".", "$#$").replace(/\./g, "").replace("$#$", ".");
        val = val.replace(/^(\-)*(\d+)\.(\d\d).*$/, '$1$2.$3'); //只能输入两个小数
        console.log(val)
        return val;
    };
    $scope.clearNoNum = function(obj) {
        $scope.nextNum = changeV($scope.nextNum);
        $scope.taxesNum = changeV($scope.taxesNum);
        $scope.channelNum = changeV($scope.channelNum);
        $scope.selfNum = changeV($scope.selfNum);
    };
    memberMangerCtrlSer.search(9999, 1, '', '', '')
        .then(function(res) {
            $scope.meborgList = JSON.parse(res.content).content;
            console.log($scope.meborgList)
        })
    $scope.getOrgnumVal = function(orgCode) {
        if ($scope.meborgList) {
            for (var i = 0; i < $scope.meborgList.length; i++) {
                if (orgCode == $scope.meborgList[i].orgCode) {
                    return $scope.meborgList[i].orgNum;
                }
            }
        }
    }

    $scope.allotText = function(allotOrgId) {
        //console.log(allotOrgId)
        for (var i = 0, r = $scope.allnotlickList.length; i < r; i++) {
            //console.log($scope.allnotlickList[i])
            if (allotOrgId == $scope.allnotlickList[i].orgId) {
                return $scope.allnotlickList[i].orgName;
            }
        }
    }

    $scope.changeVooType=function(){
        if($scope.allotVooType==1){
            $scope.valtype=false;
            $scope.nextNum = "";
            $scope.taxesNum = "";
            $scope.channelNum = "";
            $scope.selfNum ="";
        }else if($scope.allotVooType==2){
            $scope.valtype=true;
            $scope.nextNum = "";
            $scope.taxesNum = "";
            $scope.channelNum = "";
            $scope.selfNum ="";
        }else{
            $scope.valtype=false;
        }
    }

    $scope.hideRoleaut=true;
    $scope.showRoleaut=true;
// 选择
    $scope.checkedTab1 = function (index,applyId,allotRuleId,commodityId,allotType,allotToOrgId,allotOrgId,allotValueType,selfNum,nextNum,taxesNum,channelNum,allotState,allotOrgCode,allotToOrgCode){
        $scope.chooseUserData= {
            applyId: applyId,
            allotRuleId: allotRuleId,
            commodityId: commodityId,
            allotType: allotType,
            allotToOrgId: allotToOrgId,
            allotOrgId: allotOrgId,
            allotValueType: allotValueType,
            selfNum: selfNum,
            nextNum: nextNum,
            taxesNum: taxesNum,
            channelNum: channelNum,
            allotState: allotState,
            allotOrgCode: allotOrgCode,
            allotToOrgCode: allotToOrgCode,

        }

        console.log($scope.chooseUserData)
        var userIdChecked = localStorageService.get('userIdChecked');
        $('#dataReport input[type=checkbox]').prop('checked', false);
        if (allotRuleId == userIdChecked) {
            localStorageService.clear('userIdChecked');
            $scope.chooseItemTab1 = '';
            $scope.applyId = '';
            $scope.allotState='';
        } else {
            $('#dataReport input[type=checkbox]').eq(index).prop('checked', true);
            localStorageService.update('userIdChecked', allotRuleId);
            $scope.chooseItemTab1 = allotRuleId;
            $scope.applyId = applyId;
            $scope.allotState=allotState;
        }
        if ($scope.chooseUserData.applyId != null) {
            console.log($scope.chooseUserData.applyId)
            $scope.hideRoleaut=false;
            $scope.showRoleaut=false;
        }else{
            $scope.showRoleaut=true;
            $scope.hideRoleaut=true;
        };
    };
    // 存储选中
    $scope.switchUserId = function (parameter, responseData) {
        $timeout(function () {
            for (var i = 0; i < responseData.length; i++) {
                if (parameter == responseData[i].allotRuleId) {
                    $('#dataReport input[type=checkbox]').eq(i).prop('checked', true);
                    return;
                }
            }
        }, 1500)
    };




    //申请变更
    $scope.apply = function() {
        if (!$scope.chooseItemTab1) {
            $rootScope.tipService.setMessage('请先选择客户', 'warning');
        } else {
             $scope.edittableshow=true;
             $scope.addEditText ='申请变更';
            $scope.allotToOrgId = $scope.chooseUserData.allotToOrgId;
            $scope.allotOrgId = $scope.chooseUserData.allotOrgId;
            $scope.allotOrgCode= $scope.chooseUserData.allotOrgCode;
            $scope.allotToOrgCode= $scope.chooseUserData.allotToOrgCode;
            console.log($scope.allotOrgCode)
            //品种列表
            DistributionrulesCtrlSer.AllNOTLIKEQuerySer($scope.allotOrgCode)
                .then(function (res) {
                    console.log(res)
                    $scope.allnotlickList = res;
                    console.log($scope.allnotlickList);
                }, function (error) {
                    $rootScope.tipService.setMessage(error.message, 'warning');
                });
            //品种列表
            VarietiesCtrlSer.searchlist($scope.allotToOrgCode)
                .then(function (res) {
                    console.log(res)
                    if (res.code == '000000') {
                        $scope.showPage = true;
                        var data = JSON.parse(res.content);
                        $scope.prolist = data;
                        console.log($scope.prolist)
                    } else {
                        $rootScope.tipService.setMessage(res.message, 'warning');
                    }
                }, function (error) {
                    $rootScope.tipService.setMessage(error.message, 'warning');
                });
             $scope.commodityIdval=$scope.chooseUserData.commodityId;
             $scope.allotType = $scope.chooseUserData.allotType;
             $scope.allotVooType  = $scope.chooseUserData.allotValueType;
            $scope.allotRuleId = $scope.chooseUserData.allotRuleId;
            if($scope.allotVooType==1){
                $scope.valtype=false;
                $scope.selfNum = $scope.chooseUserData.selfNum;
                $scope.nextNum = $scope.chooseUserData.nextNum;
                $scope.taxesNum = $scope.chooseUserData.taxesNum;
                $scope.channelNum = $scope.chooseUserData.channelNum;
            }else if($scope.allotVooType==2){
                $scope.valtype=true;
                $scope.selfNum = $scope.chooseUserData.selfNum;
                $scope.nextNum = $scope.chooseUserData.nextNum;
                $scope.taxesNum = $scope.chooseUserData.taxesNum;
                $scope.channelNum = $scope.chooseUserData.channelNum;
            }else{
                $scope.valtype=false;
            }
            //匹配机构代码
            var json = {
                page: 1,
                rows: 9999,
                search_A_EQ_state: 1
            };
            dataSer.getOrganize(json).then(function (res) {
                if (res.code == '000000') {
                    $scope.equalOrgCode = JSON.parse(res.content).content;
                    for (var i = 0; i < $scope.equalOrgCode.length; i++) {
                        if ($scope.allotOrgId == $scope.equalOrgCode[i].orgId) {
                            $scope.addOrgVal = $scope.equalOrgCode[i].orgName + '(' + $scope.equalOrgCode[i].orgNum + ')';
                            //console.log($scope.addOrgVal)
                        }
                        if ($scope.allotToOrgId == $scope.equalOrgCode[i].orgId) {
                            $scope.allnotOrgVal = $scope.equalOrgCode[i].orgName + '(' + $scope.equalOrgCode[i].orgNum + ')';
                            //console.log($scope.addOrgVal)
                        }

                    }
                } else {
                    console.log(res);
                }
            });
        }
    }

    $scope.auditshow=false;
    $scope.gethide=function () {
        if (!$scope.applyId) {
            $rootScope.tipService.setMessage('请先申请变更', 'warning');
        } else {
            var json={
                applyId:$scope.applyId
            }
            DistributionrulesCtrlSer.Getaudit(json)
                .then(function(res){
                    console.log(res)
                    if(res.data.code=="000000"){
                        var getData=JSON.parse(res.data.content);
                        console.log(getData)
                        $scope.getaduitDatalist=getData.configAllotRuleInfoV;
                        console.log($scope.getaduitDatalist);
                        $scope.auditshow=true;
                        $scope.addEditText = "审核变更";
                        $scope.commodityIdval=$scope.getaduitDatalist.commodityId;
                        console.log($scope.commodityIdval)
                        $scope.allotRuleId= $scope.getaduitDatalist.allotRuleId;
                        $scope.allotType = $scope.getaduitDatalist.allotType;
                        $scope.allotToOrgId = $scope.getaduitDatalist.allotToOrgId;
                        $scope.allotOrgId = $scope.getaduitDatalist.allotOrgId;
                        $scope.allotVooType  = $scope.getaduitDatalist.allotValueType;
                        $scope.allotRuleId = $scope.getaduitDatalist.allotRuleId;
                        if($scope.allotVooType==1){
                            $scope.valtype=false;
                            $scope.selfNum = $scope.getaduitDatalist.selfNum;
                            $scope.nextNum = $scope.getaduitDatalist.nextNum;
                            $scope.taxesNum = $scope.getaduitDatalist.taxesNum;
                            $scope.channelNum = $scope.getaduitDatalist.channelNum;
                        }else if($scope.allotVooType==2){
                            $scope.valtype=true;
                            $scope.selfNum = $scope.getaduitDatalist.selfNum;
                            $scope.nextNum = $scope.getaduitDatalist.nextNum;
                            $scope.taxesNum = $scope.getaduitDatalist.taxesNum;
                            $scope.channelNum = $scope.getaduitDatalist.channelNum;
                        }else{
                            $scope.valtype=false;
                        }
                        //匹配机构代码
                        var json = {
                            page: 1,
                            rows: 9999,
                            search_A_EQ_state: 1
                        };
                        dataSer.getOrganize(json).then(function (res) {
                            if (res.code == '000000') {
                                $scope.equalOrgCode = JSON.parse(res.content).content;
                                for (var i = 0; i < $scope.equalOrgCode.length; i++) {
                                    if ($scope.allotOrgId == $scope.equalOrgCode[i].orgId) {
                                        $scope.addOrgVal = $scope.equalOrgCode[i].orgName + '(' + $scope.equalOrgCode[i].orgNum + ')';
                                        //console.log($scope.addOrgVal)
                                    }
                                    if ($scope.allotToOrgId == $scope.equalOrgCode[i].orgId) {
                                        $scope.allnotOrgVal = $scope.equalOrgCode[i].orgName + '(' + $scope.equalOrgCode[i].orgNum + ')';
                                        //console.log($scope.addOrgVal)
                                    }

                                }
                            } else {
                                console.log(res);
                            }
                        });
                    }
                })
        }
    }

    $scope.auditRoletrueData = function (tmpOpt) {
        var json = {
            applyId: $scope.chooseUserData.applyId,
            auditRs: tmpOpt
        };
        DistributionrulesCtrlSer.auditRoletruetion(json)
            .then(function (res) {
                if (res.data.code == '000000') {
                    $scope.auditshow = false;
                    localStorageService.clear('userIdChecked');
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                    $scope.search();
                } else {
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                }
            },function(error) {
                $rootScope.tipService.setMessage(error.data.message, 'warning');
            })
    }
    $scope.auditRolefalseData = function (tmpOpt) {
        var json = {
            applyId: $scope.chooseUserData.applyId,
            auditRs: tmpOpt
        };
        DistributionrulesCtrlSer.auditRoletruetion(json)
            .then(function (res) {
                if (res.data.code == '000000') {
                    $scope.auditshow = false;
                    localStorageService.clear('userIdChecked');
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                    $scope.search();
                } else {
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                }
            },function(error) {
                $rootScope.tipService.setMessage(error.data.message, 'warning');
            })
    }



    $scope.editNewSubmit=function(){
        console.log($scope.allotVooType)
        if($scope.allotVooType==1){
            $scope.allotType = parseFloat($scope.allotType);
            $scope.allotVooType= parseInt($scope.allotVooType);
            $scope.nextNum = parseFloat($scope.nextNum);
            $scope.taxesNum = parseFloat($scope.taxesNum);
            $scope.channelNum = parseFloat($scope.channelNum);
            $scope.selfNum = 100 - $scope.nextNum - $scope.taxesNum - $scope.channelNum;
            var allNum = $scope.nextNum + $scope.taxesNum + $scope.channelNum;
            console.log(allNum, typeof(allNum))
            if (allNum > 100) {
                console.log('y')
                $rootScope.tipService.setMessage('四项百分比之和不能超过100', 'warning');
            } else {
                console.log('x')
                var configAllotRuleInfoVIce = {
                    allotRuleId:$scope.allotRuleId,
                    commodityId: $scope.commodityIdval,
                    allotType: $scope.allotType,
                    //"allotToOrgCode": $scope.allotToOrgCode,
                    allotOrgId:$scope.allotOrgId,
                    allotToOrgId: $scope.allotToOrgId,
                    allotValueType: $scope.allotVooType,
                    selfNum: $scope.selfNum,
                    nextNum: $scope.nextNum,
                    taxesNum: $scope.taxesNum,
                    channelNum: $scope.channelNum
                }
                var json={
                    configAllotRuleInfoVIce:configAllotRuleInfoVIce
                };
                DistributionrulesCtrlSer.save(json)
                    .then(function(res) {
                        console.log(res)
                        if (res.data.code == '000000') {
                            $scope.edittableshow=false;
                            localStorageService.clear('userIdChecked');
                            $rootScope.tipService.setMessage(res.data.message, 'warning');
                            $scope.search();
                        } else {
                            $rootScope.tipService.setMessage(res.data.message, 'warning');
                        }
                    });
            }
        }else if($scope.allotVooType==2){
            if ($scope.selfNum == undefined || $scope.selfNum === '') {
                $rootScope.tipService.setMessage('请填写本级百分比', 'warning');
            }else{
                $scope.allotType = parseFloat($scope.allotType);
                $scope.allotVooType= parseInt($scope.allotVooType);
                $scope.nextNum = parseFloat($scope.nextNum);
                $scope.taxesNum = parseFloat($scope.taxesNum);
                $scope.channelNum = parseFloat($scope.channelNum);
                $scope.selfNum = parseFloat($scope.selfNum);
                console.log('x')
                var configAllotRuleInfoVIce = {
                    allotRuleId:$scope.allotRuleId,
                    commodityId: $scope.commodityIdval,
                    allotType: $scope.allotType,
                    //"allotToOrgCode": $scope.allotToOrgCode,
                    allotOrgId:$scope.allotOrgId,
                    allotToOrgId: $scope.allotToOrgId,
                    allotValueType: $scope.allotVooType,
                    selfNum: $scope.selfNum,
                    nextNum: $scope.nextNum,
                    taxesNum: $scope.taxesNum,
                    channelNum: $scope.channelNum
                }
                var json={
                    configAllotRuleInfoVIce:configAllotRuleInfoVIce
                };
                DistributionrulesCtrlSer.save(json)
                    .then(function(res) {
                        console.log(res)
                        if (res.data.code == '000000') {
                            $scope.edittableshow=false;
                            localStorageService.clear('userIdChecked');
                            $rootScope.tipService.setMessage(res.data.message, 'warning');
                            $scope.search();
                        } else {
                            $rootScope.tipService.setMessage(res.data.message, 'warning');
                        }
                    });
            }
        }
    }

    $scope.showDataChoose = getPageNum.pageNum(); //获取分页
    $scope.showNum = $scope.showDataChoose[0]; //初始显示刷具条数

    $scope.showPage = false;
    var pageInitialize = function() {
        $scope.dataNum = 0; //数据总条数
        $scope.dataPage = 0; //分页数
        $scope.currentPage = 1; //当前页数
        $scope.jumpPageNum = '';
    };
    pageInitialize();
    // x/y $scope.dataPage
    $scope.PageNum = function() {
        if ($scope.showNum.showNum < $scope.dataNum) {
            $scope.dataPage = Math.ceil($scope.dataNum / $scope.showNum.showNum);
        } else {
            $scope.dataPage = 0;
        }
        if ($scope.dataPage > 1 && $scope.currentPage > 0) {
            if ($scope.dataPage < $scope.currentPage) {
                $scope.currentPage = 1;
                $scope.search();
            }
        }

    };
    //上页下页 $scope.currentPage
    $scope.pageSlect = function(type) {
        if (type == 'prev') {
            if ($scope.currentPage != 1) {
                $scope.currentPage--;
                $scope.PageNum();
                $scope.search();
            }
        } else {
            if ($scope.currentPage < $scope.dataPage) {
                $scope.currentPage++;
                $scope.PageNum();
                $scope.search();
            }
        }
    };
    // 每页条数单元
    $scope.pageSelect = function(params) {
        $scope.showNum.showNum = params.showNum;
        pageInitialize();
        $scope.search();
    };
    //页数跳转 currentPage
    $scope.jumpPage = function(num) {
        num = parseInt(num);
        if (parseInt(num, 10) === num && num <= ($scope.dataPage + 1) && num > 0) {
            $scope.currentPage = num;
            $scope.PageNum();
            $scope.search();
        }
    };
}])
//分配规则
    .factory('DistributionrulesCtrlSer', ['$http', 'localStorageService', 'myHttp', '$q', '$rootScope', function($http, localStorageService, myHttp, $q, $rootScope) {
        return {
            search: function(json) {
                var deferred = $q.defer();
                myHttp.post("admin/config/allot/query/page", json)
                    .then(function(res) { // 调用承诺API获取数据 .resolve
                        deferred.resolve(res);
                    }, function(res) { // 处理错误 .reject
                        deferred.reject(res);
                    });
                return deferred.promise;
            },
            AllNOTLIKEQuerySer: function(superorgCode) { //所属下级机构
                var data = {
                    orders: 'asc',
                    search_LLIKE_orgCode: superorgCode + '-',
                    search_NOTLLIKE_orgCode: superorgCode + '-%-'
                };
                var deferred = $q.defer();
                myHttp.post("organize/query/as/list", data)
                    .then(function(res) { // 调用承诺API获取数据 .resolve
                        //console.log(res)
                        var resArr = [];
                        if (res.code == "000000") {
                            var results = JSON.parse(res.content);
                            //console.log(results)
                            var tmpArr = [];
                            for (var i = 0, r = results.length; i < r; i++) {
                                if (results[i].state == 1) {
                                    var tmp = {};
                                    tmp.orgCode = results[i].orgCode;
                                    tmp.orgId = results[i].orgId;
                                    tmp.orgName = results[i].orgName;
                                    tmp.text = results[i].orgName + ' (' + results[i].orgNum + ')';
                                    tmpArr.push(tmp);
                                }
                            }
                            deferred.resolve(tmpArr);
                        } else {
                            deferred.reject(res);
                        }
                    }, function(res) { // 处理错误 .reject
                        deferred.reject(res);
                    });
                return deferred.promise;
            },
            Create: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'admin/config/allot/create',
                    data: json
                }).then(function successCallback(response) {
                    console.log(response)
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },

            Apply: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'admin/config/allot/apply',
                    data: json
                }).then(function successCallback(response) {
                    console.log(response)
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },

            Audit: function(json) {
                var deferred = $q.defer();
                myHttp.post("admin/config/allot/audit", json)
                    .then(function(res) { // 调用承诺API获取数据 .resolve
                        deferred.resolve(res);
                    }, function(res) { // 处理错误 .reject
                        deferred.reject(res);
                    });
                return deferred.promise;
            },

            getProInfo: function(allotRuleId) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'config/allotrule/get',
                    data: {
                        "allotRuleId": allotRuleId
                    }
                }).then(function successCallback(response) {
                    console.log(response)
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },

            save: function(json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'admin/config/allot/apply',
                    data:json
                }).then(function successCallback(response) {
                    console.log(response)
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
            Getaudit: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'admin/config/allot/apply/get',
                    data: json
                }).then(function successCallback(response) {
                    console.log(response)
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
            auditRoletruetion: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'admin/config/allot/audit',
                    data: json
                }).then(function successCallback(response) {
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
        }

    }])