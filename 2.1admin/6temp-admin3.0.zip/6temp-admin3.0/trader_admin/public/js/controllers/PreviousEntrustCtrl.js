app.controller('PreviousEntrustCtrl', ['$scope', '$rootScope', 'PreviousEntrustData', 'getOrderState', 'getOrderType', 'getOffset', 'timestamp', 'getPageNum',function ($scope, $rootScope, PreviousEntrustData, getOrderState, getOrderType, getOffset, timestamp, getPageNum) {
    $scope.toggleTraderSearchState=false;
    $scope.Toggle = function(){
        $scope.toggleTraderSearchState = !$scope.toggleTraderSearchState;
        if($scope.toggleTraderSearchState){
           $('.search_column').css('height','auto');
        }
        else{
           $('.search_column').css('height','36px');
        }
    };

    //时间转换
    $scope.changeStampText = function (value) {
        return timestamp.timestampCoverHms(value * 1000, 'all');
    };
    //开平文字转换
    $scope.getOffset = getOffset;
    $scope.changeOffsetText = function (value) {
        for (var i = 0, r = $scope.getOffset.length; i < r; i++) {
            if (value == $scope.getOffset[i].id) {
                return $scope.getOffset[i].name;
            }
        }
    };
    //状态文字转换
    $scope.getOrderState = getOrderState;
    $scope.changeStateText = function (value) {
        for (var i = 0, r = $scope.getOrderState.length; i < r; i++) {
            if (value == $scope.getOrderState[i].id) {
                return $scope.getOrderState[i].name;
            }
        }
    };
    //查询
    $scope.OrderId = '';
    $scope.Account = '';
    $scope.Direct = '';
    $scope.State = '';
    $scope.SystemNo = '';
    $scope.createTimeStart=timestamp.defaultDate('start');
    $scope.createTimeEnd='';
    // $scope.createTimeEnd=timestamp.defaultDate();
    $scope.search = function (type) {
        $scope.toggleTraderSearchState=false;
        $('.search_column').css('height','36px');
        if (type == 'search') {
            pageInitialize()
        };
        PreviousEntrustData.search($scope.OrderId, $scope.Account, $scope.directiveProductId, $scope.Direct, $scope.State, $scope.createTimeStart, $scope.createTimeEnd, $scope.SystemNo, $scope.currentPage, $scope.showNum.showNum)
            .then(function (res) {
                console.log(res)
                if (res.data.retMsg.code == '000000') {
                    $scope.searchResult = res.data.list;
                    $scope.showPage = true;
                    $scope.dataNum = res.data.TotalCnt;
                    $scope.PageNum();
                } else {
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                }
            }, function (error) {
                $rootScope.tipService.setMessage(error.data.message, 'warning');
            });
    };

    /**
     * 分页功能实现TerryMin
     * **/
    $scope.showDataChoose = getPageNum.pageNum(); //获取分页
    $scope.showNum = $scope.showDataChoose[0]; //初始显示刷具条数

    $scope.showPage = false;
    var pageInitialize = function () {
        $scope.dataNum = 0; //数据总条数
        $scope.dataPage = 0; //分页数
        $scope.currentPage = 1; //当前页数
        $scope.jumpPageNum = '';
    };
    pageInitialize();
    // x/y $scope.dataPage
    $scope.PageNum = function () {
        if ($scope.showNum.showNum < $scope.dataNum) {
            $scope.dataPage = Math.ceil($scope.dataNum / $scope.showNum.showNum);
        } else {
            $scope.dataPage = 0;
        }
        if ($scope.dataPage > 1 && $scope.currentPage > 0) {
            if ($scope.dataPage < $scope.currentPage) {
                $scope.currentPage = 1;
                $scope.search();
            }
        }
    };
    //上页下页 $scope.currentPage
    $scope.pageSlect = function (type) {
        if (type == 'prev') {
            if ($scope.currentPage != 1) {
                $scope.currentPage--;
                $scope.PageNum();
                $scope.search();
            }
        } else {
            if ($scope.currentPage < $scope.dataPage) {
                $scope.currentPage++;
                $scope.PageNum();
                $scope.search();
            }
        }
    };
    // 每页条数单元
    $scope.pageSelect = function (params) {
        $scope.showNum.showNum = params.showNum;
        pageInitialize();
        $scope.search();
    };
    //页数跳转 currentPage
    $scope.jumpPage = function (num) {
        num = parseInt(num);
        if (parseInt(num, 10) === num && num <= ($scope.dataPage + 1) && num > 0) {
            $scope.currentPage = num;
            $scope.PageNum();
            $scope.search();
        }
    };

}])
    .factory('PreviousEntrustData', ['$http', 'localStorageService', 'myHttp', '$q', '$rootScope', function ($http, localStorageService, myHttp, $q, $rootScope) {
        return {
            search: function (OrderId, Account, directiveProductId, Direct, State, orderTimeStart, orderTimeEnd, SystemNo, nowPage, showNum) {
                var deferred = $q.defer();
                var filterJson = [{
                    "value": OrderId,
                    "condition": 0,
                    "name": "OrderId"
                }, {
                    "value": Account,
                    "condition": 0,
                    "name": "Account"
                }, {
                    "value": directiveProductId,
                    "condition": 0,
                    "name": "ProductId"
                }, {
                    "value": Direct,
                    "condition": 0,
                    "name": "Direct"
                }, {
                    "value": State,
                    "condition": 0,
                    "name": "State"
                }, {
                    "value": Date.parse(new Date(orderTimeStart)) / 1000,
                    "condition": 3,
                    "name": "OrderTime"
                }, {
                    "value": Date.parse(new Date(orderTimeEnd)) / 1000,
                    "condition": 4,
                    "name": "OrderTime"
                }, {
                    "value": SystemNo,
                    "condition": 0,
                    "name": "SystemNo"
                }];

                function filterInfo(arr) {
                    var tmpArr = [];
                    for (var i = 0, r = arr.length; i < r; i++) {
                        if (arr[i].value != undefined && arr[i].value != '') {
                            tmpArr.push({
                                "field": arr[i].name,
                                "value": arr[i].value,
                                "condition": arr[i].condition
                            });
                        }
                    }
                    return tmpArr;
                }

                var qryConditions = {
                    "qryConditions": filterInfo(filterJson),
                    pageNum: nowPage,
                    pageSize: showNum
                };
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'admin/trade/query/up/order',
                    data: qryConditions
                }).then(function successCallback(response) {
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            }
        }
    }]);