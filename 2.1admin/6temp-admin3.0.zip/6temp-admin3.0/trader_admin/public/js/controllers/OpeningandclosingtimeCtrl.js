app.controller("openingandclosingtimeCtrl", ['$scope', '$rootScope', 'getweekType', 'get24h', 'dataSer', 'productClassificationCtrlSer', 'openingandclosingtimeCtrlSer', 'tipService', function($scope, $rootScope, getweekType, get24h, dataSer, productClassificationCtrlSer, openingandclosingtimeCtrlSer, tipService) {
			$scope.getweekType = getweekType;
			$scope.get24h = get24h;
			$("select[name='startTime']").val('');
			$("select[name='endTime']").val('');
			var resetBaseInfo = function() {
				$scope.transactionTimeId = '';
				$scope.transactionTimeName = '';
				scope.transactionTimeSubId = '';
				scope.transactionTimeId = '';
				$scope.startNum = '';
				$scope.startTime = '';
				$scope.endNum = '';
				$scope.endTime = '';
			}
					function add0(m) {
					return m < 10 ? '0' + m : m
				}

				function format(datatime) {
					//shijianchuo是整数，否则要parseInt转换
					var time = new Date(datatime);
					var y = time.getFullYear();
					var m = time.getMonth() + 1;
					var d = time.getDate();
					var h = time.getHours();
					var mm = time.getMinutes();
					var s = time.getSeconds();
					return y + '-' + add0(m) + '-' + add0(d) + ' ' + add0(h) + ':' + add0(mm) + ':' + add0(s);
				}
			$scope.search = function() {
				openingandclosingtimeCtrlSer.search()
					.then(function(res) {
						console.log(res)
						if (res.data.code =="000000"){
							$scope.searchResult = JSON.parse(res.data.content);
							$scope.transactionTimeId = $scope.searchResult.transactionTimeId
						/*if ($scope.searchResult.tradeTimeSubs.length > 0) {
							$scope.tradeTimeSubs = $scope.searchResult.tradeTimeSubs;
						}*/
						for (var i = 0, r = $scope.searchResult.tradeTimeSubs.length; i < r; i++) {
										$scope.endNum=$scope.searchResult.tradeTimeSubs[i].endNum;
										$scope.endTime=format($scope.searchResult.tradeTimeSubs[i].endTime);
										$scope.startNum=$scope.searchResult.tradeTimeSubs[i].startNum;
										$scope.startTime=format($scope.searchResult.tradeTimeSubs[i].startTime);
										var singleData={
										endNum:$scope.endNum,
										endTime:$scope.endTime,
										startNum:$scope.startNum,
										startTime:$scope.startTime,
										}
										console.log(singleData)
										$scope.tradeTimeSubs.push(singleData);
									}
									$scope.endNum="";
									$scope.endTime="";
									$scope.startNum="";
									$scope.startTime="";
						}else{
							$rootScope.tipService.setMessage(res.data.message, 'warning')
						}
					},function(error){
						$rootScope.tipService.setMessage(error.data.message, 'warning')
					});
			}
			$scope.search();
			$scope.changeWeekText = function(val) {
					for (var i = 0, r = $scope.getweekType.length; i < r; i++) {
						if (val == $scope.getweekType[i].val) {
							return $scope.getweekType[i].name;
						}
					}
				}
	/*			//开闭市时间显示转换
			$scope.timeRecover = function(val) {
					// 将系统时间转化为毫秒数
					var time = Date.parse(new Date(val)) + 28800000;
					console.log(time)
					time = time / 1000 / 60 / 60;
					return parseInt(time) + ":00";
				}*/
				//保存数据
			$scope.save = function() {
					openingandclosingtimeCtrlSer.save($scope.transactionTimeId, $scope.tradeTimeSubs)
						.then(function(res) {
							console.log(res)
							if (res.data.code == '000000') {
								$rootScope.tipService.setMessage(res.data.message, 'warning');
							} else {
								$rootScope.tipService.setMessage(res.data.message, 'warning');
							}},function(error){
							$rootScope.tipService.setMessage(error.data.message, 'warning')
						});
				}
				//动态添加减少数据
			$scope.addweekTime = function() {
				if ($scope.startNum == undefined || $scope.startNum == '') {
					$rootScope.tipService.setMessage('请选择开始日', 'warning');
				} else if ($scope.startTime == undefined || $scope.startTime == '') {
					$rootScope.tipService.setMessage('请选择开始时间', 'warning');
				} else if ($scope.endNum == undefined || $scope.endNum == '') {
					$rootScope.tipService.setMessage('请选择结束日', 'warning');
				} else if ($scope.endTime == undefined || $scope.endTime == '') {
					$rootScope.tipService.setMessage('请选择结束时间', 'warning');
				} else {
					var singleData = {
						"transactionTimeSubId": $scope.transactionTimeSubId,
						"transactionTimeId": $scope.transactionTimeId,
						"startNum": $scope.startNum,
						"startTime": '1970-01-01 ' + $scope.startTime,
						"endNum": $scope.endNum,
						"endTime": '1970-01-01 ' + $scope.endTime
					}
					$scope.tradeTimeSubs.push(singleData);
					console.log($scope.tradeTimeSubs)
				}
			}
			$scope.delete = function(index) {
				$scope.tradeTimeSubs.splice(index, 1);
			}
			$scope.tradeTimeSubs = [];
	}])
	.factory('openingandclosingtimeCtrlSer', ['$http', 'localStorageService', 'myHttp', '$q', '$rootScope', function($http, localStorageService, myHttp, $q, $rootScope) {
		return {
			search: function() {
				var deferred = $q.defer();
				$http({
					method: 'POST',
					url: $rootScope.baseUrl + 'config/tradetime/openclosetime/get'
				}).then(function successCallback(response) {
					deferred.resolve(response);
				}, function errorCallback(response) {
					deferred.reject(response);
				});
				return deferred.promise;
			},
			save: function(transactionTimeId, tradeTimeSubs) {
				var json = {
					"tradeTime": {
						"transactionTimeId": transactionTimeId,
						"tradeTimeSubs": tradeTimeSubs
					}
				}
				var deferred = $q.defer();
				$http({
					method: 'POST',
					url: $rootScope.baseUrl + 'config/tradetime/openclosetime/save',
					data: json
				}).then(function successCallback(response) {
					deferred.resolve(response);
				}, function errorCallback(response) {
					deferred.reject(response);
				});
				return deferred.promise;
			}
		}
	}])