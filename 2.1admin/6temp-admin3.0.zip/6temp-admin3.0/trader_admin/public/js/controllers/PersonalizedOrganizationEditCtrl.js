app.controller('PersonalizedOrganizationEditCtrl', ['$scope', '$state', '$rootScope', 'localStorageService','PersonalizedOrganizationEditCtrlSer','dataSer','PersonalizedOrganizationCtrlSer', function($scope, $state, $rootScope, localStorageService,PersonalizedOrganizationEditCtrlSer,dataSer,PersonalizedOrganizationCtrlSer) {
		console.log(123)
			//页面跳转
				$scope.goBack = function() {
				$state.go('tabs.PersonalizedOrganization');
			}
			dataSer.organizeQuerySer()
			.then(function(res) {
				$scope.orgList = res;
				//console.log($scope.orgList)
			});
			$scope.addOrgValFTC = function(d) {
				//console.log(data);
				$scope.allotOrgId = d.orgId;
				$scope.superorgCode = d.orgCode;
				$scope.addOrgVal = d.text;
			}

		var orgCustomizeId = localStorageService.get('choosePersonalized');
		PersonalizedOrganizationCtrlSer.getNTInfo(orgCustomizeId)
			.then(function(res) {
				console.log(res)
				if(res.data.code=="000000"){
				$scope.orgCustomizelist=JSON.parse(res.data.content);
				console.log($scope.orgCustomizelist)
				$scope.orgCustomizeId=$scope.orgCustomizelist.orgCustomizeId;
				$scope.allotOrgId=$scope.orgCustomizelist.orgId;	//机构编号
				$scope.superorgCode=$scope.orgCustomizelist.orgCode;	//机构代码
				$scope.orgLogoFileIdImg1=$scope.orgCustomizelist.orgLogoFileId; //机构LOGO文件Id
				$scope.clientQRFileId=$scope.orgCustomizelist.clientQRFileId;
				$scope.LogoFileIdImgVal=$scope.orgCustomizelist.clientHomeFileId;
				$scope.orgLogoFileIdImg4=$scope.orgCustomizelist.orgAdminLogoFileId; //机构管理端LOGO文件Id
				$scope.orgServiceHotline=$scope.orgCustomizelist.orgServiceHotline, //机构服务热线
				$scope.orgAdminServiceHotline=$scope.orgCustomizelist.orgAdminServiceHotline, //管理端机构服务热线
				$scope.orgOfficialUrl=$scope.orgCustomizelist.orgOfficialUrl, //机构官方url
				$scope.orgAdminOfficialUrl=$scope.orgCustomizelist.orgAdminOfficialUrl,//机构管理官方url
				$scope.clientSysName=$scope.orgCustomizelist.clientSysName,//客户端系统名称
				$scope.clientSysEnglishName=$scope.orgCustomizelist.clientSysEnglishName,//客户端英文系统名称
				$scope.adminSysName=$scope.orgCustomizelist.adminSysName,//后台系统统名称
				$scope.adminSysEnglishName=$scope.orgCustomizelist.adminSysEnglishName,//后台英文系统统名称
				$scope.remark=$scope.orgCustomizelist.remark,	//备注*/
				$('#uploadfile').attr('src',""+$rootScope.baseUrl+"/file/download?fileId="+$scope.orgLogoFileIdImg1+"");
				$('#LogouploadfileVal').attr('src',""+$rootScope.baseUrl+"/file/download?fileId="+$scope.LogoFileIdImgVal+"");
				$('#uploadfile4').attr('src',""+$rootScope.baseUrl+"/file/download?fileId="+$scope.orgLogoFileIdImg4+"");
				$('#clientQRFileId2Val').attr('src',""+$rootScope.baseUrl+"/file/download?fileId="+$scope.clientQRFileId+"");
				}else{
					$rootScope.tipService.setMessage(res.data.message, 'warning');
				}
			})
					//匹配机构代码
		    var json = {
		        page: 1,
		        rows: 9999,
		        search_A_EQ_state: 1
		    };
		    dataSer.getOrganize(json).then(function (res) {
		        if (res.code == '000000') {
		            $scope.equalOrgCode = JSON.parse(res.content).content;
		            console.log($scope.equalOrgCode);
		            for (var i = 0; i < $scope.equalOrgCode.length; i++) {
		                if ($scope.allotOrgId== $scope.equalOrgCode[i].orgId) {
		                    $scope.addOrgVal =$scope.equalOrgCode[i].orgName+'('+$scope.equalOrgCode[i].orgNum+')';
		                    console.log($scope.addOrgVal)
		                }
		            }
		        } else {
		            console.log(res);
		        }
		    });

		 //图片上传
        uploadImg = function(id, num) {
            console.log(id);
            var urlUpload = $rootScope.baseUrl + 'file/upload';
            upload_img(urlUpload, id, function(res, status) {
                if (res.code === '000000') {
                    var data = JSON.parse(res.content);
                    console.log(data);
                    var ImgId = data[0].fileId;
                    switch (num) {
                        case 1:
                            $scope.orgLogoFileIdImg1 = ImgId;
                            $('#uploadfile').attr('src', "" + $rootScope.baseUrl + "/file/download?fileId=" + ImgId + "");
                            break;
                         case 2:
                            $scope.orgLogoFileIdImg4 = ImgId;
                            $('#uploadfile4').attr('src', "" + $rootScope.baseUrl + "/file/download?fileId=" + ImgId + "");
                            break;
                        case 3:
                            $scope.LogoFileIdImgVal = ImgId;
                            $('#LogouploadfileVal').attr('src', "" + $rootScope.baseUrl + "/file/download?fileId=" + ImgId + "");
                            break;
                        case 4:
                            $scope.clientQRFileId = ImgId;
                            $('#clientQRFileId2Val').attr('src', "" + $rootScope.baseUrl + "/file/download?fileId=" + ImgId + "");
                            break;
                    }
                }
            });
        };

        // 上传图片
        // url:后台访问路径 fileId:input file按钮id, btn:点击的按钮id, fileInput:接收上传图片的id
        function upload_img(url, fileId, callback) {
            $.ajaxFileUpload({
                url: url,
                type: 'post',
                secureuri: false,
                fileElementId: fileId, // file标签的id
                dataType: 'json', // 返回数据的类型
                data: {
                    name: fileId
                },
                success: function(data, status) {
                    callback(data, status);
                },
                error: function(data, status, e) {
                    console.log(data, status, e);
                }
            });
        }




		$scope.CustomizeEditInfo = function() {
			var orgCustomize = {
				orgCustomizeId:$scope.orgCustomizeId,
				orgId:$scope.allotOrgId,	//机构编号
				orgCode:$scope.superorgCode,	//机构代码
				orgLogoFileId:$scope.orgLogoFileIdImg1, //机构LOGO文件Id
				clientHomeFileId:$scope.LogoFileIdImgVal,
				clientQRFileId:$scope.clientQRFileId,
				orgAdminLogoFileId:$scope.orgLogoFileIdImg4, //机构管理端LOGO文件Id
				orgServiceHotline:$scope.orgServiceHotline, //机构服务热线
				orgAdminServiceHotline:$scope.orgAdminServiceHotline, //管理端机构服务热线
				orgOfficialUrl:$scope.orgOfficialUrl, //机构官方url
				orgAdminOfficialUrl:$scope.orgAdminOfficialUrl,//机构管理官方url
				clientSysName:$scope.clientSysName,//客户端系统名称
				clientSysEnglishName:$scope.clientSysEnglishName,//客户端英文系统名称
				adminSysName:$scope.adminSysName,//后台系统统名称
				adminSysEnglishName:$scope.adminSysEnglishName,//后台英文系统统名称
				remark:$scope.remark	//备注

			}
			var json = {
				orgCustomize: orgCustomize
			}
			if (toValidate('#PersonalizedEdit')) {
			PersonalizedOrganizationEditCtrlSer.EditInfo(json)
				.then(function(res) {
					if (res.data.code == "000000") {
						$rootScope.tipService.setMessage(res.data.message, 'warning');
						$state.go('tabs.PersonalizedOrganization');
					}else{
						$rootScope.tipService.setMessage(res.data.message, 'warning');
					}

				})
			}
		}
	 //放大图片
    $('.example img').zoomify();
   /* var imgs = document.getElementsByTagName("img");
    var lens = imgs.length;
    var popup = document.getElementById("popup");

    for (var i = 0; i < lens; i++) {
        imgs[i].onclick = function (event) {
            event = event || window.event;
            var target = document.elementFromPoint(event.clientX, event.clientY);
            showBig(target.src);
        }
    }
    popup.onclick = function () {
        popup.style.display = "none";
    };

    function showBig(src) {
        popup.getElementsByTagName("img")[0].src = src;
        popup.style.display = "block";
    }*/

	}])
	.factory('PersonalizedOrganizationEditCtrlSer', ['$http', 'localStorageService', 'myHttp', '$q', '$rootScope', function($http, localStorageService, myHttp, $q, $rootScope) {
		return {

				EditInfo: function(json) {
				var deferred = $q.defer();
				$http({
						method: 'POST',
						url: $rootScope.baseUrl + 'customize/org/customized/save',
						data: json
					})
					.then(function(res) { // 调用承诺API获取数据 .resolve
						deferred.resolve(res);
					}, function(res) { // 处理错误 .reject
						deferred.reject(res);
					});
				return deferred.promise;
			}
		}
	}])