app.controller("prevSourceAccountManageCtrl", ['$rootScope', '$q', '$timeout', '$http', 'myHttp', '$scope', 'tipService', 'accountManagementSer','getPageNum','localStorageService','confirmService', function ($rootScope, $q, $timeout, $http, myHttp, $scope, tipService, accountManagementSer,getPageNum,localStorageService,confirmService) {
    localStorageService.clear('userIdChecked');
    //协议
    accountManagementSer.protocolSearch().then(function (res) {
            $scope.searchResult = res.list;
            console.log($scope.searchResult);
        });
    $scope.switchProtocol=function(paramater){
        for (var k = 0, s = $scope.searchResult.length; k < s; k++) {
            if ($scope.searchResult[k].key == paramater) {
                return $scope.searchResult[k].name;
            }
        }
    };
    // 查询
    $scope.accountMargin = function () {
        accountManagementSer.accountSearch()
            .then(function (response) {
                if(response.retMsg.code==='000000'){
                    $scope.accountList = response.list;
                    console.log($scope.accountList)
                    pageJump($scope.accountList);
                    var checkedUserId=localStorageService.get('userIdChecked');
                    $scope.switchUserId(checkedUserId,$scope.accountList);
                }else{
                    $rootScope.tipService.setMessage(response.retMsg.message, 'warning');
                }
            }, function (error) {
                $rootScope.tipService.setMessage(error.message, 'warning');
            });
    };
    // 存储选中
    $scope.switchUserId=function(parameter,responseData){
        $timeout(function(){
            for(var i=0;i< responseData.length;i++){
                if(parameter==responseData[i].key){
                    $scope.key= parameter;
                    $('#dataReport input[type=checkbox]').not('.start_using').eq(i).prop('checked', true);
                    return;
                }
            }
        },300)
    };
    $scope.accountCheck = function (index,protocol,key) {
        $scope.name = $scope.accountList[index].name;
        $scope.productProtocol=protocol+":"+$scope.switchProtocol(protocol);
        $scope.enable = $scope.accountList[index].enable;
        $scope.account=$scope.accountList[index].account;
        $scope.orderLimit = $scope.accountList[index].orderLimit;
        $scope.volumeLimit = $scope.accountList[index].volumeLimit;
        $scope.login = $scope.accountList[index].login;
        $scope.passwd = $scope.accountList[index].passwd;
        $scope.ip = $scope.accountList[index].ip;
        $scope.appID = $scope.accountList[index].appID;
        $scope.port = $scope.accountList[index].port;
        $scope.AppKey = $scope.accountList[index].certKey;
        $scope.brokerID = $scope.accountList[index].brokerID;
        $scope.loginProtocol = $scope.accountList[index].loginProtocol;
        $scope.organizeId = $scope.accountList[index].organizeId;

        var userIdChecked=localStorageService.get('userIdChecked');
        $('#dataReport input[type=checkbox]').not('.start_using').prop('checked',false);
        if (key == userIdChecked) {
            localStorageService.clear('userIdChecked');
            $scope.key='';
        }else{
            $('#dataReport input[type=checkbox]').not('.start_using').eq(index).prop('checked', true);
            localStorageService.update('userIdChecked',key);
            $scope.key=key;
        }
    };
    //新增
    $scope.remove = function () {
        $scope.account_number = "";
        $scope.account_name = "";
        $scope.account_tradeNum = "";
        $scope.account_landNum = "";
        $scope.account_landPwd = "";
        $scope.account_IP = "";
        $scope.account_port = "";
        $scope.account_AppID = "";
        $scope.account_AppKey = "";
        $scope.account_brokerID = "";
        $scope.account_protocol = "";
        $scope.login_protocol = "";
        $scope.account_start = "";
        $scope.account_organizeId = "";
        $scope.account_volumeLimit = "";
        $scope.account_orderLimit = "";
        $scope.addShowing=false
    };
    $scope.accountAdd = function () {
        var upAccount = {
            key: $scope.account_number,
            name: $scope.account_name,
            protocol: $scope.account_protocol,
            enable: $scope.account_start,
            orderLimit: parseFloat($scope.account_orderLimit),
            volumeLimit: parseFloat($scope.account_volumeLimit),
            account: $scope.account_tradeNum,
            login: $scope.account_landNum,
            passwd: $scope.account_landPwd,
            ip: $scope.account_IP,
            port: parseFloat($scope.account_port),
            appID: $scope.account_AppID,
            certKey: $scope.account_AppKey,
            brokerID: $scope.account_brokerID,
            loginProtocol: $scope.login_protocol,
            organizeId: $scope.account_organizeId
        };
        var json = {
            upAccount: upAccount
        };
        if (toValidate('#formpublic')) {
            accountManagementSer.accountPlus(json)
                .then(function (response) {
                    if (response.code == "000000") {
                        $rootScope.tipService.setMessage(response.message, 'warning');
                        $scope.copyDataArray = '';
                        $scope.accountMargin();
                        $scope.remove();
                    } else {
                        $rootScope.tipService.setMessage(response.message, 'warning');
                    }
                },function(error){
                    $rootScope.tipService.setMessage(error.message, 'warning');
                })
        }
    };
    //修改
    $scope.editShow = function () {
        if (!$scope.key) {
            $rootScope.tipService.setMessage('请先选择账号编号', 'warning');
        } else {
            $scope.editShowing = true;
        }
    };
    $scope.accountCompile = function () {
        var upAccount = {
            key: $scope.key,
            name: $scope.name,
            protocol: $scope.productProtocol.split(':')[0],
            enable: $scope.enable,
            orderLimit: $scope.orderLimit,
            volumeLimit: $scope.volumeLimit,
            account: $scope.account,
            login: $scope.login,
            passwd: $scope.passwd,
            ip: $scope.ip,
            appID: $scope.appID,
            port: $scope.port,
            certKey: $scope.AppKey,
            brokerID: $scope.brokerID,
            loginProtocol: $scope.loginProtocol,
            organizeId: $scope.organizeId
        };
        var json = {
            upAccount: upAccount
        };
        if (toValidate('#formpublic2')) {
            accountManagementSer.accountModify(json)
                .then(function (response) {
                    $scope.editShowing = false;
                    $rootScope.tipService.setMessage(response.message, 'warning');
                    $scope.accountMargin();
                }, function (error) {
                    $rootScope.tipService.setMessage(error.message, 'warning');
                })
        }
    };

    //删除
    $scope.delete = function () {
        if (!$scope.key) {
            $rootScope.tipService.setMessage('请先选择账号!', 'warning');
        }else {
            var json = {
                key: $scope.key
            };
            confirmService.set('确认提示', '确定要注销此账号吗?', function () {
                accountManagementSer.accountDelete(json).then(function (res) {
                    if (res.data.code == "000000") {
                        $rootScope.tipService.setMessage(res.message, 'warning');
                        $scope.accountMargin();
                    } else {
                        $rootScope.tipService.setMessage(res.data.message, 'warning');
                    }
                }, function (error) {
                    $rootScope.tipService.setMessage(error.message, 'warning');
                });
                confirmService.clear();
            })
        }
    };
    //分页
    var pageJump = function (tmpArrList) {
        $timeout(function () {
            if (tmpArrList != undefined) {
                $scope.currentPage = 1; //当前页数
                $scope.dataNum = tmpArrList.length;
                $scope.showDataChoose = getPageNum.pageNum(); //获取分页
                $scope.showNum = $scope.showDataChoose[0]; //初始显示刷具条数
                $scope.showPage = false;
                $timeout(function () {
                    $scope.showPage = true;
                    $scope.copyDataArray = tmpArrList.slice(0, 14); //初始15条数据
                }, 10);
                $scope.dataPage = Math.ceil($scope.dataNum / $scope.showNum.showNum);

                //上下页
                $scope.pageSlect = function (type) {
                    if (type == 'prev') {
                        if ($scope.currentPage != 1) {
                            $scope.currentPage--;
                            $scope.turnPage();
                        } else {
                            $scope.copyDataArray = tmpArrList.slice(0, 14); //初始15条数据
                        }
                    } else {
                        if ($scope.currentPage < $scope.dataPage) {
                            $scope.currentPage++;
                            $scope.turnPage();
                        }
                    }
                };
                //每页数据量
                $scope.baseDataArray = [];
                $scope.copyDataArray = [];
                $scope.pageSelect = function (params) {
                    $scope.showNum.showNum = params.showNum;
                    $scope.copyDataArray = tmpArrList.slice(0, (params.showNum - 1));
                    $scope.dataPage = Math.ceil($scope.dataNum / $scope.showNum.showNum);
                    $scope.currentPage = 1;
                };
                $scope.turnPage = function () {
                    $scope.copyDataArray = tmpArrList.slice((($scope.currentPage - 1) * 15), (($scope.currentPage + 1) * 15 - 1));
                };
                //固定页面跳转
                $scope.jumpPage = function (num) {
                    num = parseInt(num);
                    if (parseInt(num, 10) === num && num <= ($scope.dataPage + 1) && num > 0) {
                        $scope.currentPage = num;
                        $scope.jumpPageNum = '';
                        $scope.turnPage();
                    } else {
                        $scope.copyDataArray = tmpArrList.slice(0, 14); //初始15条数据
                    }
                }
            } else {
                pageJump(tmpArrList);
            }
        }, 200);
    };
}])

    .factory('accountManagementSer', ['$http', 'dataFilter', 'localStorageService', 'myHttp', '$q', '$rootScope', function ($http, dataFilter, localStorageService, myHttp, $q, $rootScope) {
        return {
            accountSearch: function () {
                var data = new Object();
                var deferred = $q.defer();
                $http({
                    method: "GET",
                    url: $rootScope.baseUrl + "c/up/account/query/all",
                    data: data,
                    headers: {
                        'Content-Type': 'application/json;charset=UTF-8'
                    }
                }).success(function (res) {
                    deferred.resolve(res);
                }).error(function (res) {
                    deferred.reject(res);
                });
                return deferred.promise;
            },
            accountPlus: function (upAccount) {
                var deferred = $q.defer();
                $http({
                    method: "POST",
                    url: $rootScope.baseUrl + "c/up/account/insert",
                    data: upAccount,
                    headers: {
                        'Content-Type': 'application/json;charset=UTF-8'
                    }
                }).success(function (res) {
                    deferred.resolve(res);
                }).error(function (res) {
                    deferred.reject(res);
                });
                return deferred.promise;
            },
            accountModify: function (compileData) {
                var deferred = $q.defer();
                $http({
                    method: "POST",
                    url: $rootScope.baseUrl + "c/up/account/modify",
                    data: compileData,
                    headers: {
                        'Content-Type': 'application/json;charset=UTF-8'
                    }
                }).success(function (res) {
                    deferred.resolve(res);
                }).error(function (res) {
                    deferred.reject(res);
                });
                return deferred.promise;
            },
            accountDelete: function (json) {
                var deferred = $q.defer();
                $http({
                    method: "POST",
                    url: $rootScope.baseUrl + "c/up/account/delete",
                    data: json,
                    headers: {
                        'Content-Type': 'application/json;charset=UTF-8'
                    }
                }).success(function (res) {
                    deferred.resolve(res);
                }).error(function (res) {
                    deferred.reject(res);
                });
                return deferred.promise;
            },
            protocolSearch: function () {
                var deferred = $q.defer();
                $http({
                    method: "GET",
                    url: $rootScope.baseUrl + "c/up/protocol/query/all"
                }).success(function (res) {
                    deferred.resolve(res);
                }).error(function (res) {
                    deferred.reject(res);
                });
                return deferred.promise;
            }
        }
    }]);