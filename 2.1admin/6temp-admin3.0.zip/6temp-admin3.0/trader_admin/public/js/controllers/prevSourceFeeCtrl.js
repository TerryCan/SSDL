app.controller("prevSourceFeeCtrl", ['$rootScope', '$timeout', '$q', '$http', 'myHttp', '$scope', 'getPrevSource', 'feeParameterSer','getPageNum', 'tipService','confirmService', function ($rootScope, $timeout, $q, $http, myHttp, $scope, getPrevSource, feeParameterSer,getPageNum, tipService,confirmService) {

    //上手手续费参数查询 terry
    $scope.feeParameter = function () {
        feeParameterSer.feeSearch()
            .then(function (response) {
                if(response.retMsg.code==='000000'){
                    var feeList = response.list;
                    $scope.feeList = feeList;
                    portNum();
                }else{
                    $rootScope.tipService.setMessage(response.retMsg.message, 'warning');
                }
            }, function (error) {
                $rootScope.tipService.setMessage(error.message, 'warning');
            });
        $scope.co_key = null;
    };
// 数据处理
    // 将毫秒转化为系统时间
    $scope.formatTime = function (parameter) {
        var h = Math.floor(parameter / 3600);
        var minute = Math.floor((parameter - h * 3600) / 60);
        var second = parameter - h * 3600 - minute * 60;
        return h + ':' + minute + ':' + second;
    };
    //页面弹窗
    $scope.editShow = function () {
        if (!$scope.co_key) {
            $rootScope.tipService.setMessage('请先选择账号编号', 'warning');
        } else {
            $scope.editShowing = true;
        }
        $scope.accountMargin();
        $scope.productManage();
    };
    $scope.removeShow = function () {
        if (!$scope.co_key) {
            $rootScope.tipService.setMessage('请先选择账号编号', 'warning');
        } else {
            $scope.removeShowing = true;
        }
    };
    //上手账号管理查询 terry
    $scope.accountMargin = function () {
        feeParameterSer.accountSearch()
            .then(function (response) {
                var accountList = response.list;
                $scope.accountList = accountList;
            }, function (error) {
                console.log(error)
            })
    };
    //上手商品管理—查询 terry
    $scope.productManage = function () {
        feeParameterSer.productSearch()
            .then(function (response) {
                var productList = response.list;
                $scope.productList = productList;
                // console.log($scope.productList)
            }, function (error) {
                console.log(error)
            })
    };

    //数据拼接
    var portNum = function () {
        $scope.accountMargin();
        $scope.productManage();
        $timeout(function () {
                if ($scope.feeList && $scope.accountList && $scope.productList) {
                    var reportArray = [];
                    for (var i = 0, r = $scope.feeList.length; i < r; i++) {
                        var tmpArr = {
                            account: '',
                            name: '',
                            commissionFix: '',
                            commissionRatio: '',
                            startTime: '',
                            endTime: '',
                            market: '',
                            commodity: '',
                            contract: '',
                            symbol: ''
                        };
                        tmpArr.account = $scope.feeList[i].account;
                        tmpArr.commissionFix = $scope.feeList[i].commissionFix;
                        tmpArr.commissionRatio = $scope.feeList[i].commissionRatio;
                        tmpArr.symbol = $scope.feeList[i].symbol;
                        tmpArr.startTime = $scope.feeList[i].startTime;
                        tmpArr.endTime = $scope.feeList[i].endTime;
                        for (var k = 0, s = $scope.accountList.length; k < s; k++) {
                            if ($scope.accountList[k].key == $scope.feeList[i].account) {
                                tmpArr.name = $scope.accountList[k].name;
                            }
                        }
                        for (var j = 0; j < $scope.productList.length; j++) {
                            if ($scope.productList[j].key == $scope.feeList[i].symbol) {
                                tmpArr.market = $scope.productList[j].market;
                                tmpArr.commodity = $scope.productList[j].commodity;
                                tmpArr.contract = $scope.productList[j].contract;
                            }
                        }
                        reportArray.push(tmpArr);
                    }
                    $scope.tmpArrList = reportArray;
                    pageJump($scope.tmpArrList);
                    console.log($scope.tmpArrList);
                } else {
                    if ($scope.productList =='' || $scope.feeList == '' || $scope.accountList=='') {
                        $rootScope.tipService.setMessage('请求数据为空!', 'warning');
                    } else {
                        $scope.accountMargin();
                        $scope.productManage();
                        portNum();
                    }
                }
        }, 300);
    };
    $scope.remove = function () {
        $scope.key = "";
        $scope.account = "";
        $scope.symbol = "";
        $scope.createTimeStart = "";
        $scope.createTimeEnd = "";
        $scope.commissionRatio = "";
        $scope.commissionFix = "";
    };
    // 上手手续费参数—添加 terry
    $scope.feeAdd = function () {
        if (toValidate('#formAdd')) {
            console.log($scope.startTime)
            // 将系统时间转化为毫秒数
            $scope.dateTime = function (parameter) {
                var str1 = parameter.split(":");
                var h = parseInt(str1[0], 10) * 3600;
                var m = parseInt(str1[1], 10) * 60;
                var s = parseInt(str1[2], 10);
                return h + m + s;
            };
            $scope.createTimeStartNum = $scope.dateTime($scope.startTime);
            $scope.createTimeEndNum = $scope.dateTime($scope.endTime);
            var symbols = JSON.parse($scope.symbol);
            var upSymbolCommissionPara = {
                key: $scope.key,
                account: $scope.account,
                symbol: symbols.key,
                market: symbols.market,
                commodity: symbols.commodity,
                contract: symbols.contract,
                startTime: $scope.createTimeStartNum,
                endTime: $scope.createTimeEndNum,
                commissionRatio: $scope.commissionRatio,
                commissionFix: $scope.commissionFix
            };
            var json = {
                upSymbolCommissionPara: upSymbolCommissionPara
            };
            feeParameterSer.feePlus(json)
                .then(function (response) {
                    console.log(response)
                    if (response.code == "000000") {
                        $scope.addShowing = false;
                        $rootScope.tipService.setMessage(response.message, 'warning');
                        $scope.copyDataArray = '';
                        $scope.feeParameter();
                        $scope.remove();
                    } else {
                        $rootScope.tipService.setMessage(response.message, 'warning');
                    }
                },function(error){
                    $rootScope.tipService.setMessage(error.message, 'warning');
                })
        }
    };

    // 上手手续费参数—编辑 terry
    $scope.feeCheck = function (index) {
        $scope.account_key = $scope.accountList[index].key;
        $scope.account_name = $scope.accountList[index].name;
        $scope.product_key = $scope.tmpArrList[index].symbol;
        $scope.product_market = $scope.tmpArrList[index].market;
        $scope.product_commodity = $scope.tmpArrList[index].commodity;
        $scope.product_contract = $scope.tmpArrList[index].contract;
        $scope.co_key = $scope.feeList[index].key;

        $scope.endTime = $scope.formatTime($scope.feeList[index].endTime);
        $scope.startTime = $scope.formatTime($scope.feeList[index].startTime);
        $scope.co_commissionRatio = $scope.feeList[index].commissionRatio;
        $scope.co_commissionFix = $scope.feeList[index].commissionFix;
        console.log($scope.co_key);
        $('#dataReport input[type=checkbox]').prop('checked', false);
        $('#dataReport input[type=checkbox]').eq(index).prop('checked', true);
    };
    $scope.feeCompile = function () {
        if (toValidate('#formEdti')) {
            $scope.dateTime = function (parameter) {
                var str1 = parameter.split(":");
                var h = parseInt(str1[0], 10) * 3600;
                var m = parseInt(str1[1], 10) * 60;
                var s = parseInt(str1[2], 10);
                return h + m + s;
            };
            var symbols = new Object();
            if ($scope.co_symbols == undefined) {
                symbols = {
                    key: $scope.product_key,
                    market: $scope.product_market,
                    commodity: $scope.product_commodity,
                    contract: $scope.product_contract
                }
            } else {
                symbols = {
                    key: $scope.co_symbols.split(':')[0],
                    market: $scope.co_symbols.split(':')[1].split('-')[0],
                    commodity: $scope.co_symbols.split(':')[1].split('-')[1],
                    contract: $scope.co_symbols.split(':')[1].split('-')[2]
                }
            }
            // if ($scope.co_account == undefined) {
            //     $scope.co_account = $scope.account_key;
            // } else {
            //     $scope.co_account == $scope.co_account;
            // }
            var upSymbolCommissionPara = {
                key: $scope.co_key,
                account: ($scope.co_account == undefined)?$scope.account_key:$scope.co_account,
                symbol: symbols.key,
                market: symbols.market,
                commodity: symbols.commodity,
                contract: symbols.contract,
                startTime: $scope.dateTime($scope.startTime),
                endTime: $scope.dateTime($scope.endTime),
                commissionRatio: $scope.co_commissionRatio,
                commissionFix: $scope.co_commissionFix
            };
            var json = {
                upSymbolCommissionPara: upSymbolCommissionPara
            };
            feeParameterSer.feeModify(json)
                .then(function (response) {
                    if (response.code == "000000") {
                        $scope.editShowing = false;
                        $rootScope.tipService.setMessage(response.message, 'warning');
                        $scope.copyDataArray = '';
                        $scope.feeParameter();
                    } else {
                        $rootScope.tipService.setMessage('请求参数错误', 'warning');
                    }
                })
        }
    };
    // // 上手手续费参数—删除 terry
    // $scope.delete = function () {
    //     $scope.removeShowing = false;
    //     var json = {
    //         key: $scope.co_key
    //     };
    //     feeParameterSer.feeDelete(json)
    //         .then(function (response) {
    //             if (response.code == "000000") {
    //                 $rootScope.tipService.setMessage(response.message, 'warning');
    //                 $scope.copyDataArray = '';
    //                 $scope.feeParameter();
    //             } else {
    //                 $rootScope.tipService.setMessage('请求参数错误', 'warning');
    //             }
    //         })
    // };
    //删除
    $scope.delete = function () {
        if (!$scope.co_key) {
            $rootScope.tipService.setMessage('请先选择账号!', 'warning');
        }else {
            var json = {
                key: $scope.co_key
            };
            confirmService.set('确认提示', '确定要注销此账号吗?', function () {
                feeParameterSer.feeDelete(json).then(function (res) {
                    if (res.code == "000000") {
                        $rootScope.tipService.setMessage(res.message, 'warning');
                        $scope.feeParameter();
                    } else {
                        $rootScope.tipService.setMessage(res.message, 'warning');
                    }
                }, function (error) {
                    $rootScope.tipService.setMessage(error.message, 'warning');
                });
                confirmService.clear();
            })
        }
    };
    // 分页 TerryMin
    var pageJump = function (tmpArrList) {
        $timeout(function () {
            if (tmpArrList != undefined) {
                $scope.currentPage = 1; //当前页数
                $scope.dataNum = tmpArrList.length;
                $scope.showDataChoose = getPageNum.pageNum(); //获取分页
                $scope.showNum = $scope.showDataChoose[0]; //初始显示刷具条数
                $scope.showPage = false;
                $timeout(function () {
                    $scope.showPage = true;
                    $scope.copyDataArray = tmpArrList.slice(0, 14); //初始15条数据
                }, 10)
                $scope.dataPage = Math.ceil($scope.dataNum / $scope.showNum.showNum);

                //上下页
                $scope.pageSlect = function (type) {
                    if (type == 'prev') {
                        if ($scope.currentPage != 1) {
                            $scope.currentPage--;
                            $scope.turnPage();
                        } else {
                            $scope.copyDataArray = tmpArrList.slice(0, 14); //初始15条数据
                        }
                    } else {
                        if ($scope.currentPage < $scope.dataPage) {
                            $scope.currentPage++;
                            $scope.turnPage();
                        }
                    }
                }
                //每页数据量
                $scope.baseDataArray = [];
                $scope.copyDataArray = [];
                $scope.pageSelect = function (params) {
                    $scope.showNum.showNum = params.showNum;
                    $scope.copyDataArray = tmpArrList.slice(0, (params.showNum - 1));
                    $scope.dataPage = Math.ceil($scope.dataNum / $scope.showNum.showNum);
                    $scope.currentPage = 1;
                }
                $scope.turnPage = function () {
                    $scope.copyDataArray = tmpArrList.slice((($scope.currentPage - 1) * 15), (($scope.currentPage + 1) * 15 - 1));
                }
                //固定页面跳转
                $scope.jumpPage = function (num) {
                    num = parseInt(num);
                    if (parseInt(num, 10) === num && num <= ($scope.dataPage + 1) && num > 0) {
                        $scope.currentPage = num;
                        $scope.jumpPageNum = '';
                        $scope.turnPage();
                    } else {
                        $scope.copyDataArray = tmpArrList.slice(0, 14); //初始15条数据
                    }
                }
            } else {
                pageJump(tmpArrList);
            }
        }, 200);
    }
}])
    .factory('feeParameterSer', ['$http', 'dataFilter', 'localStorageService', 'myHttp', '$q', '$rootScope', function ($http, dataFilter, localStorageService, myHttp, $q, $rootScope) {
        return {
            feeSearch: function () {
                var data = new Object();
                var deferred = $q.defer();
                $http({
                    method: "POST",
                    url: $rootScope.baseUrl + "c/up/symbol/commission/para/query/all",
                    data: data,
                    headers: {
                        'Content-Type': 'application/json;charset=UTF-8'
                    }
                }).success(function (res) {
                    deferred.resolve(res);
                }).error(function (res) {
                    deferred.reject(res);
                });
                return deferred.promise;
            },
            feePlus: function (upAccount) {
                // alert(1111)
                var deferred = $q.defer();
                $http({
                    method: "POST",
                    url: $rootScope.baseUrl + "c/up/symbol/commission/para/insert",
                    data: upAccount,
                    headers: {
                        'Content-Type': 'application/json;charset=UTF-8'
                    }
                }).success(function (res) {
                    deferred.resolve(res);
                }).error(function (res) {
                    deferred.reject(res);
                });
                return deferred.promise;
            },
            feeModify: function (compileData) {
                var deferred = $q.defer();
                // var data=new Object();
                $http({
                    method: "POST",
                    url: $rootScope.baseUrl + "c/up/symbol/commission/para/modify",
                    data: compileData,
                    headers: {
                        'Content-Type': 'application/json;charset=UTF-8'
                    }
                }).success(function (res) {
                    deferred.resolve(res);
                }).error(function (res) {
                    deferred.reject(res);
                });
                return deferred.promise;
            },
            feeDelete: function (removeData) {
                var deferred = $q.defer();
                $http({
                    method: "POST",
                    url: $rootScope.baseUrl + "c/up/symbol/commission/para/delete",
                    data: removeData,
                    headers: {
                        'Content-Type': 'application/json;charset=UTF-8'
                    }
                }).success(function (res) {
                    deferred.resolve(res);
                }).error(function (res) {
                    deferred.reject(res);
                });
                return deferred.promise;
            },
            accountSearch: function () {
                var data = new Object();
                var deferred = $q.defer();
                $http({
                    method: "GET",
                    url: $rootScope.baseUrl + "c/up/account/query/all",
                    data: data,
                    headers: {
                        'Content-Type': 'application/json;charset=UTF-8'
                    }
                }).success(function (res) {
                    deferred.resolve(res);
                }).error(function (res) {
                    deferred.reject(res);
                });
                return deferred.promise;
            },
            productSearch: function () {
                var deferred = $q.defer();
                var data = new Object();
                $http({
                    method: "GET",
                    url: $rootScope.baseUrl + "c/up/symbol/query/all",
                    data: data,
                    headers: {
                        'Content-Type': 'application/json;charset=UTF-8'
                    }
                }).success(function (res) {
                    deferred.resolve(res);
                }).error(function (res) {
                    deferred.reject(res);
                });
                return deferred.promise;
            }
        }
    }]);