app.controller("userManageAllCtrl", ["$scope", "userManageAllCtrlSer", "getUserType", "getbatchstate", "getPageNum", "tipService", "confirmService", "dataSer", "$timeout", "$rootScope","getoperatelist", "localStorageService", "timestamp", function ($scope, userManageAllCtrlSer, getUserType, getbatchstate, getPageNum, tipService, confirmService, dataSer, $timeout, $rootScope,getoperatelist, localStorageService, timestamp) {
    $scope.toggleTraderSearchState = false;
    $scope.Toggle = function () {
        $scope.toggleTraderSearchState = !$scope.toggleTraderSearchState;
        if ($scope.toggleTraderSearchState) {
            $('.search_column').css('height', 'auto');
        } else {
            $('.search_column').css('height', '36px');
        }
    };
    localStorageService.clear('userIdChecked');
    $scope.userManageTab = 1;
    $scope.jurisdiction = false;
    $scope.userType = getUserType;
    $scope.getUserType = function (params) {
        for (var i = 0, r = $scope.userType.length; i < r; i++) {
            if (params == $scope.userType[i].id) {
                return $scope.userType[i].name;
            }
        }
    };
    $scope.operatelist = getoperatelist;
    $scope.getoperatelistType=function(params){
        for (var i = 0, r = $scope.operatelistlength; i < r; i++) {
            if (params == $scope.operatelist[i].id) {
                return $scope.operatelist[i].name;
            }
        }
    }

    $scope.orgNum = '';
    $scope.searchUserNameTab1 = '';
    $scope.searchUserTypeTab1 = '';
    $scope.searchUserStatesTab1 = '';
    $scope.searchOrgName = '';
    $scope.chooseItemTab1 = null;
    $scope.registerTimeStart = timestamp.defaultDate('start');
    $scope.registerTimeEnd = '';
    //机构列表
    $scope.addOrgVal = ''; //显示值
    $scope.addOrgChooseVal = ''; //选择值
    dataSer.organizeQuerySer()
        .then(function (res) {
            $scope.orgList = res;
        });
    $scope.addOrgValFTC = function (val, showval) {
        console.log(val)
        $scope.addOrgChooseVal = val;
        $scope.addOrgVal = showval;
        $scope.roleType="";
        $scope.canJurisdictionData=[];
        $scope.isJurisdictionData=[];
    };

    $scope.Batchclose=function(){
        $scope.jurisdictionShow=false;
        $scope.addOrgVal = "";
        $scope.roleType="";
        $scope.operateType="";
        $scope.isSame=false;
        $scope.isLow=false;
        $scope.canJurisdictionData=[];
        $scope.isJurisdictionData=[];
    }
    $scope.addOrgValCF=function(){
        $scope.addOrgVal="";
        $scope.roleType="";
        $scope.canJurisdictionData=[];
        $scope.isJurisdictionData=[];
    }

    $scope.hideOrgList = function () {
        $scope.isShowOrgList = false;
        $(".OrgList").blur();
    };

    //全部状态下所属机构
    dataSer.organizeQuerylistSer()
        .then(function(res) {
            $scope.orgAllList = res;
        });

    $scope.opText=function(orgId){
        for (var i = 0, r = $scope.orgAllList.length; i < r; i++) {
            if (orgId == $scope.orgAllList[i].orgId) {
                return $scope.orgAllList[i].text;
            }
        }
    }
    $scope.Roleaudit = true;
    $scope.Roleauthority = true;
    $scope.showRoleaut= true;
    $scope.hideRoleaut= true;
    //单选
    $scope.checkedTab1 = function (index,applyId,orgId,roleType,operateType,isSame,isLow,state) {
        console.log(applyId)
        if (applyId != null) {
            $scope.Roleaudit = false;
            $scope.Roleauthority = true;
        } else {
            $scope.Roleauthority = false;
            $scope.Roleaudit = true;
        }
        $scope.chooseUserData = {
            applyId: applyId,
            orgId:orgId,
            roleType:roleType,
            operateType:operateType,
            isSame:isSame,
            isLow:isLow,
            state:state

        };
        var userIdChecked = localStorageService.get('userIdChecked');
        $('#dataReport input[type=checkbox]').prop('checked', false);
        if (applyId == userIdChecked) {
            localStorageService.clear('userIdChecked');
            $scope.chooseItemTab1 = '';
            $scope.state = '';
        } else {
            $('#dataReport input[type=checkbox]').eq(index).prop('checked', true);
            localStorageService.update('userIdChecked', applyId);
            $scope.chooseItemTab1 = applyId;
            $scope.state = state;
        }
        console.log($scope.chooseItemTab1)
        if (!$scope.chooseItemTab1) {
            console.log($scope.chooseItemTab1)
            $scope.hideRoleaut=true;
            $scope.showRoleaut=true;
        }else{
            $scope.showRoleaut=false;
            $scope.hideRoleaut=false;
        };
    };

    // 存储选中
    $scope.switchUserId = function (parameter, responseData) {
        $timeout(function () {
            for (var i = 0; i < responseData.length; i++) {
                if (parameter == responseData[i].applyId) {
                    $('#dataReport input[type=checkbox]').eq(i).prop('checked', true);
                    $scope.chooseItemTab1 = responseData[i].applyId;
                    $scope.state = responseData[i].state;
                    return;
                }
            }
        }, 100)
    };
    // 查询
    $scope.search = function (type) {
        $scope.toggleTraderSearchState = false;
        $('.search_column').css('height', '36px');
        if (type == 'search') {
            pageInitialize();
        }
        ;
        $scope.orgId = localStorageService.get('oldOrgId');
        $scope.orgCode = localStorageService.get('oldOrgCode');
        console.log($scope.orgId,$scope.orgCode )
        var json = {
            page: $scope.currentPage,
            rows: $scope.showNum.showNum,
            orders: 'asc',
            search_A_EQ_type: $scope.searchUserTypeTab1,
            search_A_EQ_state: $scope.searchUserStatesTab1,
            search_A_LIKE_roleName: $scope.searchUserNameTab1,
            search_A_GTE_createTime: $scope.registerTimeStart,
            search_A_LTE_createTime: $scope.registerTimeEnd,
            search_A_EQ_orgId:$scope.orgId,
        };
        userManageAllCtrlSer.search(json)
            .then(function (response) {
                if (response.code == "000000") {
                    var data = JSON.parse(response.content);
                    console.log(data);
                    $scope.showPage = true;
                    $scope.searchResult = data.content;
                    $scope.dataNum = data.totalElements;
                    $scope.PageNum();
                    var checkedUserId = localStorageService.get('userIdChecked');
                    $scope.switchUserId(checkedUserId, $scope.searchResult);
                } else {
                    $rootScope.tipService.setMessage(response.message, 'warning');
                }
            }, function (error) {
                $rootScope.tipService.setMessage(error.message, 'warning');
            });
        $scope.chooseItemTab1 = null;
    };

    $scope.orgauthscope=function(){
        if($scope.addOrgVal==""){
            $rootScope.tipService.setMessage('请先选择机构编号', 'warning');
        }else{

        var json={
            orgId:$scope.addOrgChooseVal,
            roleType:$scope.roleType
        }
        userManageAllCtrlSer.orgauthscope(json)
            .then(function(res){
                console.log(res)
                if(res.data.code=="000000"){
                    $scope.canJurisdictionData = [];
                    var data = JSON.parse(res.data.content);
                    console.log(data);  //可授权数据
                    for (var i = 0, r = data.length; i < r; i++) {
                        data[i].filterId = i;
                        $scope.canJurisdictionData.push(data[i]);
                        //return  $scope.canJurisdictionData;
                    }
                    console.log($scope.canJurisdictionData)
                }else{
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                }},function(error){
                    $rootScope.tipService.setMessage(error.data.message, 'warning');
            })
        }
    }



    //授权
    $scope.authorization = function () {
        $scope.baseAuthorizationList = [];
        for (var i = 0, r = $scope.userManageMultiple.length; i < r; i++) {
            var tmp = parseInt($scope.userManageMultiple[i]);
            $scope.baseAuthorizationList.push($scope.canJurisdictionData[tmp]);
        }
    };


    $scope.toAuthorization = function () {
        console.log($scope.baseAuthorizationList)
        for (var i = 0, r = $scope.baseAuthorizationList.length; i < r; i++) {
            $scope.baseAuthorizationList[i].freezingValid = false; //冻结默认关闭
            $scope.isJurisdictionData.push($scope.baseAuthorizationList[i]);
        }
        console.log($scope.isJurisdictionData)  //已授权数据
        //$scope.postJurisdiction();
        $scope.baseAuthorizationList = [];
    };
    //权限修改
    //$scope.jurisdictionShow = false;
    $scope.editJurisdiction = function () {
            $scope.jurisdictionShow = true;
            $scope.addOrgVal="";
            $scope.roleType="";
            $scope.operateType="";
            $scope.isSame=true;
            $scope.isLow=false;
            $scope.canJurisdictionData=[];
            $scope.isJurisdictionData=[];
            //$scope.ddVal();
            //$scope.getCanJurisdiction($scope.chooseUserData.roleId);
            //$scope.getIsJurisdiction($scope.chooseUserData.roleId);
    };

    //权限审核
    $scope.RoleauditdictionShow = false;
    $scope.RoleJurisdiction = function () {
        console.log($scope.chooseUserData.applyId)
        if (!$scope.chooseItemTab1) {
            $rootScope.tipService.setMessage('请先选择用户', 'warning');
        } else {
            $scope.RoleauditdictionShow = true;
            $scope.applyId= $scope.chooseUserData.applyId;
            $scope.orgId= $scope.chooseUserData.orgId;
            //匹配机构代码
            var json = {
                page: 1,
                rows: 9999,
                search_A_EQ_state: 1
            };
            dataSer.getOrganize(json).then(function (res) {
                if (res.code == '000000') {
                    $scope.equalOrgCode = JSON.parse(res.content).content;
                    for (var i = 0; i < $scope.equalOrgCode.length; i++) {
                        if ($scope.orgId == $scope.equalOrgCode[i].orgId) {
                            console.log($scope.orgId == $scope.equalOrgCode[i].orgId)
                            $scope.addOrgVal = $scope.equalOrgCode[i].orgName + '(' + $scope.equalOrgCode[i].orgNum + ')';
                        }
                    }
                }else{
                    $rootScope.tipService.setMessage(res.message, 'warning');
                }
            });
            $scope.roleType= $scope.chooseUserData.roleType;
            $scope.operateType= $scope.chooseUserData.operateType;
            $scope.isSame= $scope.chooseUserData.isSame;
            $scope.isLow= $scope.chooseUserData.isLow;
            $scope.state= $scope.chooseUserData.state;
            $scope.RoleCanJurisdiction($scope.chooseUserData.applyId);
            console.log($scope.RoleCanJurisdiction($scope.chooseUserData.applyId))
            //.RolegetJurisdiction($scope.chooseUserData.authApplyId);
        }
    };

    //时间戳
    $scope.timestamp = function(stamp) {
        return timestamp.timestampCoverHms(stamp, 'all')
    }

    //读取已授权列表
    $scope.getIsJurisdiction = function (roleId) {
        userManageAllCtrlSer.isJurisdiction(roleId)
            .then(function (res) {
                if (res.data.code === '000000') {
                    $scope.isJurisdictionData = JSON.parse(res.data.content);
                }
            }, function (error) {

            });
    };

    //读取可审核列表
    $scope.RoleCanJurisdiction = function (applyId) {
        //$scope.RolegetJurisdiction();
        userManageAllCtrlSer.RoleJurisdiction(applyId)
            .then(function (res) {
                console.log(res)
                if (res.data.code == '000000') {
                    $scope.RoleJurisdictionData = [];
                    $scope.Rdata = JSON.parse(res.data.content);
                    var data = $scope.Rdata;
                    console.log(data);  //可授权数据
                    for (var i = 0, r = data.changes.length; i < r; i++) {
                        $scope.RoleJurisdictionData.push(data.changes[i]);
                        //console.log($scope.RoleJurisdictionData);
                    }

                } else {
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                }
            });
    };
    //删除所有已授权
    $scope.deleteAauthorization = function () {
        console.log($scope.isJurisdictionData)
        for (var i = 0, r = $scope.isJurisdictionData.length; i < r; i++) {
            $scope.isJurisdictionData[i].delete = true;
        }
        $scope.isJurisdictionData =[];
        //$scope.postJurisdiction();
    };
    //提交授权
    $scope.postJurisdiction = function (tmpOpt) {
        var batchV = {
            orgId: $scope.addOrgChooseVal,
            roleType: $scope.roleType,
            operateType: $scope.operateType,
            isSame: $scope.isSame,
            isLow: $scope.isLow

        };

        var json = {
            batchV: batchV,
            roleAuthorisedVs: $scope.isJurisdictionData
        }
        userManageAllCtrlSer.postJurisdiction(json)
            .then(function (res) {
                console.log(res)
                if (res.data.code === '000000') {
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                    localStorageService.clear('userIdChecked');
                    $scope.search();
                } else {
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                }
            }, function (error) {
                $rootScope.tipService.setMessage(error.data.message, 'warning');
            });
        if (tmpOpt) {
            $scope.jurisdictionShow = false;
            $scope.search();
            }
    };

    $scope.delJurisdictionData = function (index) {

       var userNames=[];
        for (index in $scope.isJurisdictionData) {
            if ($scope.isJurisdictionData[index].allowAuthorised == true) {
                userNames.push($scope.isJurisdictionData[index].permissionName);
            }
        }

        if (userNames.length > 0) {
            for (i in userNames) {
                var name = userNames[i];
                for (j in $scope.isJurisdictionData) {
                    if ($scope.isJurisdictionData[j].permissionName == name) {
                        $scope.isJurisdictionData.splice(j,1);
                    }
                }
            }
        }
    }
    $scope.Batchstatelist=getbatchstate;
    $scope.getState = function (State) {
        for (var i = 0, r = $scope.Batchstatelist.length; i < r; i++) {
            if (State == $scope.Batchstatelist[i].val) {
                return $scope.Batchstatelist[i].name;
            }
        }
    };
    $scope.RoletrueData = function (tmpOpt) {
        var json = {
            applyId: $scope.chooseItemTab1,
            auditRs: tmpOpt
        };
        userManageAllCtrlSer.Roletruetion(json)
            .then(function (res) {
                if (res.data.code === '000000') {
                    $scope.RoleauditdictionShow = false;
                    localStorageService.clear('userIdChecked');
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                    $scope.search();
                } else {
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                }
            },function(error) {
                $rootScope.tipService.setMessage(error.data.message, 'warning');
            })
    }
    $scope.RolefalseData = function (tmpOpt) {
        var json = {
            applyId: $scope.chooseItemTab1,
            auditRs: tmpOpt
        };
        userManageAllCtrlSer.Roletruetion(json)
            .then(function (res) {
                if (res.data.code === '000000') {
                    $scope.RoleauditdictionShow = false;
                    localStorageService.clear('userIdChecked');
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                    $scope.search();
                } else {
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                }
            },function(error) {
                $rootScope.tipService.setMessage(error.data.message, 'warning');
            })
    }
    /**
     * 分页功能实现TerryMin
     * **/
    $scope.showDataChoose = getPageNum.pageNum(); //获取分页
    $scope.showNum = $scope.showDataChoose[0]; //初始显示刷具条数

    $scope.showPage = false;
    var pageInitialize = function () {
        $scope.dataNum = 0; //数据总条数
        $scope.dataPage = 0; //分页数
        $scope.currentPage = 1; //当前页数
        $scope.jumpPageNum = '';
    };
    pageInitialize();
    // x/y $scope.dataPage
    $scope.PageNum = function () {
        if ($scope.showNum.showNum < $scope.dataNum) {
            $scope.dataPage = Math.ceil($scope.dataNum / $scope.showNum.showNum);
        } else {
            $scope.dataPage = 0;
        }
        if ($scope.dataPage > 1 && $scope.currentPage > 0) {
            if ($scope.dataPage < $scope.currentPage) {
                $scope.currentPage = 1;
                $scope.search();
            }
        }
    };
    //上页下页 $scope.currentPage
    $scope.pageSlect = function (type) {
        if (type == 'prev') {
            if ($scope.currentPage != 1) {
                $scope.currentPage--;
                $scope.PageNum();
                $scope.search();
            }
        } else {
            if ($scope.currentPage < $scope.dataPage) {
                $scope.currentPage++;
                $scope.PageNum();
                $scope.search();
            }
        }
    };
    // 每页条数单元
    $scope.pageSelect = function (params) {
        $scope.showNum.showNum = params.showNum;
        pageInitialize();
        $scope.search();
    };
    //页数跳转 currentPage
    $scope.jumpPage = function (num) {
        num = parseInt(num);
        if (parseInt(num, 10) === num && num <= ($scope.dataPage + 1) && num > 0) {
            $scope.currentPage = num;
            $scope.PageNum();
            $scope.search();
        }
    };
}])
//角色管理
    .factory('userManageAllCtrlSer', ['$http', 'localStorageService', 'myHttp', '$q', '$rootScope', function ($http, localStorageService, myHttp, $q, $rootScope) {
        return {
            search: function (json) {
                var deferred = $q.defer();
                myHttp.post("role/query/batch/auth/as/page", json)
                    .then(function (res) { // 调用承诺API获取数据 .resolve
                        deferred.resolve(res);
                    }, function (res) { // 处理错误 .reject
                        deferred.reject(res);
                    });
                return deferred.promise;
            },

            orgauthscope: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'role/query/org/auth/scope',
                    data:json
                }).then(function successCallback(response) {
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
            /*canJurisdiction: function (roleId) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'role/query/may/authorised/as/list',
                    data: {
                        "roleId": roleId
                    }
                }).then(function successCallback(response) {
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
            isJurisdiction: function (roleId) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'role/query/has/authorised/as/list',
                    data: {
                        "roleId": roleId
                    }
                }).then(function successCallback(response) {
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },*/
            postJurisdiction: function (json){
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'role/auth/apply/batch',
                    data: json
                }).then(function successCallback(response) {
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
            RoleJurisdiction: function (applyId) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'role/get/auth/apply',
                    data: {
                        "applyId": applyId
                    }
                }).then(function successCallback(response) {
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
            Roletruetion: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'role/auth/audit/batch',
                    data: json
                }).then(function successCallback(response) {
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
        }
    }])