app.controller("NoticeCtrl",function($scope,$timeout,$rootScope,getNoticeData,tipService,confirmService,timestamp,$sce,$state){
		$scope.goBack = function() {
				$state.go('tabs.home');
			}
	//获取公告列表
	//console.log(12344)
	$scope.timestampCoverHms = timestamp.timestampCoverHms;
	//console.log($scope.timestampCoverHms)
	$scope.showList = true;
	$scope.showDetail = false;
	$scope.title = '';
	$scope.createUserId = '';
	$scope.validTime = '';
	var baseListData = [];
	$rootScope.msgNum = 0;
	function getArticleData(){
		getNoticeData.noticeData()
		.then(function(res){
			if(res.code == '000000' && res.content != ''){
				var data = JSON.parse(res.content);
				baseListData = data.content;
				$scope.changeReadType();
				var tmp_msgNum = 0;
				for(var i=0,r=baseListData.length;i<r;i++){
					if(baseListData[i].readFlag != 1){
						tmp_msgNum++;
					}
				}
				$rootScope.msgNum = tmp_msgNum;
			}
			else{
				$rootScope.tipService.setMessage(res.message, 'warning');
			}
		});
	}
	getArticleData();
	$scope.readNotice = function(title,createUserId,validTime,noticeId){
		$scope.showList = false;
		$scope.showDetail = true;
		$scope.title = title;
		$scope.createUserId = createUserId;
		$scope.validTime = timestamp.timestampCoverHms(validTime,'all');
		getNoticeData.noticeDetailData(noticeId)
		.then(function(res){
			if(res.code == '000000'){
				var data = JSON.parse(res.content);
				$scope.detialText = $sce.trustAsHtml(data.content);
				getArticleData();
			}
		});
	}
	$scope.baseList = function(){
		$scope.showList = true;
		$scope.showDetail = false;
	}
	$scope.readType = '0';
	$scope.changeReadType = function(){
		switch($scope.readType){
			case '0':
				$scope.noticeList = baseListData;
				console.log($scope.noticeList)
				break;
			case '1':
				var tmpArr = [];
				for(var i=0,r=baseListData.length;i<r;i++){
					if(baseListData[i].readFlag == 1){
						tmpArr.push(baseListData[i]);
					}
				}
				$scope.noticeList = tmpArr;
				break;
			case '2':
				var tmpArr = [];
				for(var i=0,r=baseListData.length;i<r;i++){
					if(baseListData[i].readFlag != 1){
						tmpArr.push(baseListData[i]);
					}
				}
				$scope.noticeList = tmpArr;
				break;
		}
	}
	$scope.readAll = function(){
		confirmService.set('提示','确认将所有公告设为已读?',function(){
			getNoticeData.readAll()
			.then(function(res){
				if(res.code == '000000'){
					getArticleData();
				}
			});
			confirmService.clear();
		});
	}
})
//获取公告
.factory('getNoticeData', ['$http','$q','localStorageService','$rootScope',function($http,$q,localStorageService,$rootScope){
	return {
		noticeData:function(){
			var deferred = $q.defer();
			var url = $rootScope.baseUrl+"notice/query/by/user";
			$http({
				method: "POST",
				url: url,
				data: {page:1,rows:999},
				headers: {
					'Content-Type': 'application/x-www-form-urlencoded'
				},
				transformRequest: function (obj) {
					var str = [];
					for (var p in obj) {
						str.push(encodeURIComponent(p) + "=" + encodeURIComponent(obj[p]));
					}
					return str.join("&");
				}
			}).success(function (res) {
				deferred.resolve(res);
			}).error(function (res) {
				deferred.reject(res);
			});
			return deferred.promise;
		},
		noticeDetailData:function(noticeId){
			var deferred = $q.defer();
			var url = $rootScope.baseUrl+"notice/read";
			$http({
				method: "POST",
				url: url,
				data: {key:noticeId}
			}).success(function (res) {
				deferred.resolve(res);
			}).error(function (res) {
				deferred.reject(res);
			});
			return deferred.promise;
		},
		readAll:function(){
			var deferred = $q.defer();
			var url = $rootScope.baseUrl+"notice/read/all";
			$http({
				method: "POST",
				url: url
			}).success(function (res) {
				deferred.resolve(res);
			}).error(function (res) {
				deferred.reject(res);
			});
			return deferred.promise;
		}
	}
}])