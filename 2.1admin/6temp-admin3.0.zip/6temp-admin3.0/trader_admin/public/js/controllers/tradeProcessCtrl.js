app.controller('tradeProcessCtrl', ['$rootScope', '$scope', 'tradeProcessAll','$timeout', '$sce','tipService', 'confirmService', 'getCurrencyType','timestamp','localStorageService','getProcessType',function ($rootScope, $scope, tradeProcessAll,$timeout, $sce,tipService, confirmService, getCurrencyType,timestamp,localStorageService,getProcessType) {
    $scope.toggleTraderSearchState=false;
    $scope.Toggle = function(){
        $scope.toggleTraderSearchState = !$scope.toggleTraderSearchState;
        if($scope.toggleTraderSearchState){
           $('.search_column').css('height','auto');
        }
        else{
           $('.search_column').css('height','36px');
        }
    };
    //机构码匹配
    var saveOrganizeData = localStorageService.get('organizeData');
    //获取币种
    getCurrencyType.then(function (res) {
        $scope.currencyList = JSON.parse(res.content);
    });
    var processContent,processTotal;
    var source = {
        type: 'POST',
        datatype: "json",
        datafields: [  //数据字段定义
            {name: 'processrecordId', type: 'string'},
            {name: 'loginName', type: 'string'},
            {name: 'orgCode', type: 'string'},
            {name: 'proDefId', type: 'string'},
            {name: 'operatorNumber', type: 'string'},

            {name: 'currency', type: 'string'},
            {name: 'createTime', type: 'string'}
        ],
        url: $rootScope.baseUrl + 'account/aiaccount/process/query/page',
        root: "content",
        pagesize:10,
        processData: function (data) {
            data.page = (data.pagenum + 1)?(data.pagenum + 1):1;
            data.rows =(data.pagesize)?(data.pagesize):10;
            // data.order =($scope.order)?$scope.order:'desc';
            // data.sort =($scope.sort)?$scope.sort:'createTime';
            // data.search_A_EQ_userId = ($scope.directiveUserId) ? $scope.directiveUserId : '';
        }, //传递参数处理
        beforeLoadComplete: function (records) { //数据完全加载完执行绘制表格
            var start;
            for (var i in records) {
                start = parseInt(i);
                break;
            }
            for (var k = 0, r = processContent.length; k < r; k++) {
                records[start + k].processrecordId = processContent[k].processrecordId;
                records[start + k].loginName = processContent[k].loginName;
                records[start + k].orgCode = processContent[k].orgCode;
                records[start + k].proDefId = processContent[k].proDefId;
                records[start + k].operatorNumber = processContent[k].operatorNumber;

                records[start + k].currency = processContent[k].currency;
                records[start + k].createTime = processContent[k].createTime;
            }
        },
        beforeprocessing: function (data) { //处理总页数
            var processData = JSON.parse(data.content);
            console.log(processData)
            processContent = processData.content;
            source.totalrecords = processData.totalElements == 0 ? 5 : processData.totalElements;
            processTotal = processData.totalElements;
        },
        loadComplete: function (records){
            $scope.saveResult=JSON.parse(records.content);
            var data =  $scope.saveResult.totalElements;
            if (data == 0) {
                $('#contenttableentrustDetailGrid > div').remove();
            }
        },
        endUpdate: true
    };
    //创建数据适配器
    var dataAdapter = null;
    $scope.searchAjax = function () {
        $scope.toggleTraderSearchState = false;
        $('.search_column').css('height', '36px');
        if (dataAdapter == null) {
            dataAdapter = new $.jqx.dataAdapter(source);
            //创建表格
            $("#entrustDetailGrid").jqxGrid({
                source: dataAdapter,
                columns: [  //表格数据域
                    {
                        text: '用户名',
                        datafield: 'loginName',
                        width: '15%',
                        align: 'center'//设置表头
                    },
                    {
                        text: '所属机构',
                        datafield: 'orgCode',
                        cellsalign: 'center',
                        align: 'center',
                        width: '15%',
                        cellsrenderer: function (row, columnfield, value, defaulthtml, columnproperties) {
                            if (saveOrganizeData) {
                                for (var i = 0; i <saveOrganizeData.length; i++) {
                                    if (value ==saveOrganizeData[i].orgCode) {
                                        return saveOrganizeData[i].orgNum;
                                    }
                                }
                            }
                        }
                    },
                    {
                        text: '流程类型',
                        datafield: 'proDefId',
                        width:'15%',
                        align: 'center',
                        cellsrenderer: function (row, columnfield, value, defaulthtml, columnproperties) {
                            if (getProcessType) {
                                for (var i = 0; i <getProcessType.length; i++) {
                                    if (value ==getProcessType[i].id) {
                                        return getProcessType[i].name;
                                    }
                                }
                            }
                        }
                    },
                    {
                        text: '流程金额',
                        datafield: 'operatorNumber',
                        width:'15%',
                        align: 'center'
                    },
                    {
                        text: '币种',
                        datafield: 'currency',
                        width:'15%',
                        align: 'center',
                        cellsrenderer: function (row, columnfield, value, defaulthtml, columnproperties) {
                            if ($scope.currencyList) {
                                for (var i = 0; i <$scope.currencyList.length; i++) {
                                    if (value ==$scope.currencyList[i].currency) {
                                        return $scope.currencyList[i].currencyName;
                                    }
                                }
                            }
                        }
                    },
                    {
                        text: '创建时间',
                        datafield: 'createTime',
                        width:'25%',
                        align: 'center',
                        cellsrenderer: function (row, columnfield, value, defaulthtml, columnproperties) {
                            return timestamp.timestampCoverHms(value, 'all');
                        }
                    }
                ],
                width: 100 + '%',
                height: 81 + '%',
                theme:'metrodark',
                virtualmode: true,
                rendergridrows: function (params) { //将数据渲染到页面
                    return params.data;
                },
                pageable: true,
                pagesizeoptions: ['10','30','100','200'],
                columnsresize: true,//列间距是否可调整
                clipboard: true
            });
        }else {
            $("#entrustDetailGrid").jqxGrid('updatebounddata', 'cells');
        }
    };

    //分页
    $("#entrustDetailGrid").on("pagechanged", function (event) {
        console.log(event)
    });
    //排序
    $("#entrustDetailGrid").on("sort", function (event) {
        var sortinformation = event.args.sortinformation;
        $scope.sort=sortinformation.sortcolumn;
        $scope.order=($scope.sort)?(sortinformation.sortdirection.ascending)?'asc':'desc':'asc';
        data={
            order:$scope.order,
            sort:$scope.sort
        };
        source.processData(data);
        $("#entrustDetailGrid").jqxGrid('updatebounddata', 'sort');
    });
    //选中
    $('#entrustDetailGrid').on('rowselect', function (event) {
        $scope.processrecordId = event.args.row.processrecordId;
    });

    //审核
    $scope.audit = function () {
        if (!$scope.processrecordId) {
            $rootScope.tipService.setMessage('请先选择用户', 'warning');
        } else {
            var json = {
                result: 9999,
                processrecordId: $scope.processrecordId
            };
            tradeProcessAll.review(json)
                .then(function (res) {
                    $rootScope.tipService.setMessage(res.message, 'warning');
                    $scope.searchAjax();
                }, function (error) {
                    $rootScope.tipService.setMessage(error.message, 'warning');
                })
        }
    };
    //驳回
    $scope.reject = function () {
        if (!$scope.processrecordId) {
            $rootScope.tipService.setMessage('请先选择用户', 'warning');
        } else {
            var json = {
                result: 8888,
                processrecordId: $scope.processrecordId
            };
            tradeProcessAll.review(json)
                .then(function (res) {
                    $rootScope.tipService.setMessage(res.message, 'warning');
                    $scope.searchAjax();
                }, function (error) {
                    $rootScope.tipService.setMessage(error.message, 'warning');
                })
        }
    };
}])
// 交易流程
    .factory('tradeProcessAll', ['$http', 'localStorageService', 'myHttp', '$q', '$rootScope', function ($http, localStorageService, myHttp, $q, $rootScope) {
        return {
            review: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'account/audit/accountprocess',
                    data: json
                }).then(function successCallback(response) {
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            }
        }
    }]);