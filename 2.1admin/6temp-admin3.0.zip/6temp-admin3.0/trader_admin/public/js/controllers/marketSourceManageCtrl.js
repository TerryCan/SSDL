app.controller("marketSourceManageCtrl", ['$scope', '$timeout', 'tipService', '$rootScope', 'confirmService', 'marketSourceManageCtrlSer', 'marketAgreementManageCtrlSer', 'getPageNum', function($scope, $timeout, tipService, $rootScope, confirmService, marketSourceManageCtrlSer, marketAgreementManageCtrlSer, getPageNum) {
			// 分页
			var pageJump = function(tmpArrList) {
				$timeout(function() {
					if (tmpArrList != undefined) {
						console.log(tmpArrList);
						$scope.currentPage = 1; //当前页数
						$scope.dataNum = tmpArrList.length;
						$scope.showDataChoose = getPageNum.pageNum(); //获取分页
						$scope.showNum = $scope.showDataChoose[0]; //初始显示刷具条数
						$scope.showPage = false;
						$timeout(function() {
							$scope.showPage = true;
							$scope.copyDataArray = tmpArrList.slice(0, 14); //初始15条数据
						}, 10)
						$scope.dataPage = Math.ceil($scope.dataNum / $scope.showNum.showNum);

						//上下页
						$scope.pageSlect = function(type) {
								if (type == 'prev') {
									if ($scope.currentPage != 1) {
										$scope.currentPage--;
										$scope.turnPage();
									} else {
										$scope.copyDataArray = tmpArrList.slice(0, 14); //初始15条数据
									}
								} else {
									if ($scope.currentPage < $scope.dataPage) {
										$scope.currentPage++;
										$scope.turnPage();
									}
								}
							}
							//每页数据量
						$scope.baseDataArray = [];
						$scope.copyDataArray = [];
						$scope.pageSelect = function(params) {
							$scope.showNum.showNum = params.showNum;
							$scope.copyDataArray = tmpArrList.slice(0, (params.showNum - 1));
							$scope.dataPage = Math.ceil($scope.dataNum / $scope.showNum.showNum);
							$scope.currentPage = 1;
						}
						$scope.turnPage = function() {
								$scope.copyDataArray = tmpArrList.slice((($scope.currentPage - 1) * 15), (($scope.currentPage + 1) * 15 - 1));
							}
							//固定页面跳转
						$scope.jumpPage = function(num) {
							num = parseInt(num);
							if (parseInt(num, 10) === num && num <= ($scope.dataPage + 1) && num > 0) {
								$scope.currentPage = num;
								$scope.jumpPageNum = '';
								$scope.turnPage();
							} else {
								$scope.copyDataArray = tmpArrList.slice(0, 14); //初始15条数据
							}
						}
					} else {
						pageJump(tmpArrList);
					}
				}, 200);
			};
			$scope.search = function() {
					marketSourceManageCtrlSer.search()
						.then(function(res) {
							if (res.retMsg.code == '000000') {
								$scope.chooseKey = null;
								$scope.searchResult = res.list;
								pageJump($scope.searchResult);
							} else {
								$rootScope.tipService.setMessage(res.message, 'warning');
							}
						}, function(error) {
							$rootScope.tipService.setMessage(error.message, 'warning');
						});
				}
				//$scope.search();

			$scope.addMarketSource = false;
			$scope.resetVal = function() {
				//基础字段
				$scope.key = ''; //账号编号（主键,自动生成）
				$scope.name = ''; //账号名称
				$scope.typeKey = ''; //协议编号
				$scope.extend = ''; //扩展
				$scope.enable = ''; //账号使能/禁止
				$scope.login = ''; //外部账号
				$scope.passwd = ''; //外部密码
				$scope.brokerID = ''; //外部经纪人代码
				$scope.ip1 = ''; //外部IP1
				$scope.port1 = ''; //外部端口1
				$scope.protocol1 = ''; //外部登陆协议1
				$scope.ip2 = ''; //外部IP2
				$scope.port2 = ''; //外部端口2
				$scope.protocol2 = ''; //外部登陆协议2
				$scope.appCert = ''; //外部证书
				$scope.serverId = ''; //服务Id(用于分布式)
			}
			$scope.addMarketSourceSubmit = function() {
				console.log($scope.optType)
				if ($scope.optType == 'edit') {
					var quoteAccount = {
						key: $scope.key,
						name: $scope.name,
						typeKey: $scope.typeKey,
						extend: $scope.extend,
						enable: $scope.enable,
						login: $scope.login,
						passwd: $scope.passwd,
						brokerID: $scope.brokerID,
						ip1: $scope.ip1,
						port1: $scope.port1,
						protocol1: $scope.protocol1,
						ip2: $scope.ip2,
						port2: $scope.port2,
						protocol2: $scope.protocol2,
						appCert: $scope.appCert,
						serverId: $scope.serverId
					}
					if (toValidate('#marketSourceManage')) {
						marketSourceManageCtrlSer.edit($scope.chooseKey, quoteAccount)
							.then(function(res) {
								if (res.data.code == '000000') {
									$rootScope.tipService.setMessage(res.data.message, 'warning');
									$scope.addMarketSource = false;
									$scope.search();
								} else {
									$rootScope.tipService.setMessage(res.data.message, 'warning');
								}
							});
					}
				} else {
					var quoteAccount = {
						key: $scope.key,
						name: $scope.name,
						typeKey: $scope.typeKey,
						extend: $scope.extend,
						enable: $scope.enable,
						login: $scope.login,
						passwd: $scope.passwd,
						brokerID: $scope.brokerID,
						ip1: $scope.ip1,
						port1: $scope.port1,
						protocol1: $scope.protocol1,
						ip2: $scope.ip2,
						port2: $scope.port2,
						protocol2: $scope.protocol2,
						appCert: $scope.appCert,
						serverId: $scope.serverId
					}
					if (toValidate('#marketSourceManage')) {
						marketSourceManageCtrlSer.add(quoteAccount)
							.then(function(res) {
								if (res.data.code == '000000') {
									$rootScope.tipService.setMessage(res.data.message, 'warning');
									$scope.addMarketSource = false;
									$scope.search();
								} else {
									$rootScope.tipService.setMessage(res.data.message, 'warning');
								}
							});
					}
				}
			}
			$scope.optInfo = function(type) {
				$scope.optType = type;
				if (type == 'edit') {
					if ($scope.chooseKey == null) {
						$rootScope.tipService.setMessage("请先选择账号", 'warning');
					} else {
						$scope.infoOptType = '保 存';
						$scope.allsel = true;
						$scope.addMarketSource = true;
						marketSourceManageCtrlSer.singleSearch($scope.chooseKey)
							.then(function(res) {
								if (res.data.retMsg.code == '000000') {
									$scope.key = res.data.account.key; //账号编号（主键,自动生成）
									$scope.name = res.data.account.name; //账号名称
									$scope.typeKey = res.data.account.typeKey; //协议编号
									$scope.extend = res.data.account.extend; //扩展
									$scope.enable = res.data.account.enable; //账号使能/禁止
									$scope.login = res.data.account.login; //外部账号
									$scope.passwd = res.data.account.passwd; //外部密码
									$scope.brokerID = res.data.account.brokerID; //外部经纪人代码
									$scope.ip1 = res.data.account.ip1; //外部IP1
									$scope.port1 = res.data.account.port1; //外部端口1
									$scope.protocol1 = res.data.account.protocol1; //外部登陆协议1
									$scope.ip2 = res.data.account.ip2; //外部IP2
									$scope.port2 = res.data.account.port2; //外部端口2
									$scope.protocol2 = res.data.account.protocol2; //外部登陆协议2
									$scope.appCert = res.data.account.appCert; //外部证书
									$scope.serverId = res.data.account.serverId; //服务Id(用于分布式)
								}
							});
					}
				} else {
					$scope.infoOptType = '新 增';
					$scope.addMarketSource = true;
					$scope.resetVal();
				}
			}
			$scope.delete = function() {
				if ($scope.chooseKey == null) {
					$rootScope.tipService.setMessage("请先选择账号", 'warning');
				} else {
					confirmService.set('确认提示', '确定删除此产品?', function() {
						marketSourceManageCtrlSer.delete($scope.chooseKey)
							.then(function(res) {
								if (res.data.code == '000000') {
									$rootScope.tipService.setMessage(res.data.message, 'warning');
									$scope.search();
								} else {
									$rootScope.tipService.setMessage(res.data.message, 'warning');
								}
							});
						confirmService.clear();
					});

				}
			}
			$scope.start = function(key) {
				marketSourceManageCtrlSer.start(key)
					.then(function(res) {
						if (res.data.code == '000000') {
							$rootScope.tipService.setMessage(res.data.message, 'warning');
							$scope.search();
						} else {
							$rootScope.tipService.setMessage(res.data.message, 'warning');
						}
					});
			}
			$scope.stop = function(key) {
					marketSourceManageCtrlSer.stop(key)
						.then(function(res) {
							if (res.data.code == '000000') {
								$rootScope.tipService.setMessage(res.data.message, 'warning');
								$scope.search();
							} else {
								$rootScope.tipService.setMessage(res.data.message, 'warning');
							}
						});
				}
				//单选
			$scope.chooseKey = null;
			$scope.checked = function(index, key) {
					$scope.chooseKey = key;
					$('#dataReport input[type=checkbox]').prop('checked', false);
					$('#dataReport input[type=checkbox]').eq(index).prop('checked', true);
				}
				//协议查询
			$scope.AgreementData = [];
			marketAgreementManageCtrlSer.search()
				.then(function(res) {
					console.log(res)
					if (res.retMsg.code == '000000') {
						$scope.AgreementData = res.list;
					}
				});

			//协议文字转换
			$scope.changeAgreementDataText = function(val) {
				console.log(val)
				for (var i = 0, r = $scope.AgreementData.length; i < r; i++) {
					if ($scope.AgreementData[i].key == val) {
						return $scope.AgreementData[i].type;
					}
				}
			}
	}])
	.factory('marketSourceManageCtrlSer', ['$http', 'localStorageService', 'myHttp', '$q', '$rootScope', function($http, localStorageService, myHttp, $q, $rootScope) {
		return {
			search: function(showNum, nowPage) {
				var deferred = $q.defer();
				myHttp.post("c/quote/accounts/query/all")
					.then(function(res) { // 调用承诺API获取数据 .resolve
						deferred.resolve(res);
					}, function(res) { // 处理错误 .reject
						deferred.reject(res);
					});
				return deferred.promise;
			},
			add: function(quoteAccount) {
				var deferred = $q.defer();
				$http({
					method: 'POST',
					url: $rootScope.baseUrl + 'c/quote/accounts/insert',
					data: {
						quoteAccount: quoteAccount
					}
				}).then(function successCallback(response) {
					deferred.resolve(response);
				}, function errorCallback(response) {
					deferred.reject(response);
				});
				return deferred.promise;
			},
			edit: function(key, quoteAccount) {
				var deferred = $q.defer();
				$http({
					method: 'POST',
					url: $rootScope.baseUrl + 'c/quote/accounts/modify/full',
					data: {
						key: key,
						quoteAccount: quoteAccount
					}
				}).then(function successCallback(response) {
					deferred.resolve(response);
				}, function errorCallback(response) {
					deferred.reject(response);
				});
				return deferred.promise;
			},
			delete: function(key) {
				var deferred = $q.defer();
				$http({
					method: 'POST',
					url: $rootScope.baseUrl + 'c/quote/accounts/delete',
					data: {
						key: key
					}
				}).then(function successCallback(response) {
					deferred.resolve(response);
				}, function errorCallback(response) {
					deferred.reject(response);
				});
				return deferred.promise;
			},
			start: function(key) {
				var deferred = $q.defer();
				$http({
					method: 'POST',
					url: $rootScope.baseUrl + 'c/quote/accounts/enable',
					data: {
						key: key
					}
				}).then(function successCallback(response) {
					deferred.resolve(response);
				}, function errorCallback(response) {
					deferred.reject(response);
				});
				return deferred.promise;
			},
			stop: function(key) {
				var deferred = $q.defer();
				$http({
					method: 'POST',
					url: $rootScope.baseUrl + 'c/quote/accounts/disenable',
					data: {
						key: key
					}
				}).then(function successCallback(response) {
					deferred.resolve(response);
				}, function errorCallback(response) {
					deferred.reject(response);
				});
				return deferred.promise;
			},
			singleSearch: function(key) {
				var deferred = $q.defer();
				$http({
					method: 'POST',
					url: $rootScope.baseUrl + 'c/quote/accounts/query/key',
					data: {
						key: key
					}
				}).then(function successCallback(response) {
					deferred.resolve(response);
				}, function errorCallback(response) {
					deferred.reject(response);
				});
				return deferred.promise;
			}
		}
	}])