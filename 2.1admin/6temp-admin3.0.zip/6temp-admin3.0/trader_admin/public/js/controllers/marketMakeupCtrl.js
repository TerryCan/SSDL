app.controller('marketMakeupCtrl', ['$rootScope', '$scope','marketMakeupCtrlSel', function ($rootScope, $scope,marketMakeupCtrlSel) {
$scope.NewSubmit=function(){
			var json={
					fileId:$scope.fileFileId,// 附件
				}
				marketMakeupCtrlSel.NewSubmitAdd(json)
				.then(function(res){
					console.log(res)
					if(res.data.code=="000000"){
						$rootScope.tipService.setMessage(res.data.message, 'warning');
					}else{
						$rootScope.tipService.setMessage(res.data.message, 'warning');
					}
					},function(error) {
						$rootScope.tipService.setMessage(error.data.message, 'warning');
					})
			}

	 	//xls文件上传
        uploadImg = function(id, num) {
        	/**function doCheck(){
			var file = $("#AddfileFileId").val();
			if(file == '' || file == null) {
			$("#error").html("请选择所要上传的文件！");
			} else {
			var index = file.lastIndexOf(".");
			if(index < 0) {
			$("#error").html("上传的文件格式不正确，请选择97-2003Excel文件(*.xls)！");
			} else {
			var ext = file.substring(index + 1, file.length);
			if(ext != "xls") {
			$("#error").html("上传的文件格式不正确，请选择97-2003Excel文件(*.xls)！");
			} else {
			$("#error").hide();
			return true;
			}
			}
			}
			return false;
			}
			doCheck();***/
            //console.log(id,num);
            var urlUpload = $rootScope.baseUrl + 'file/upload';
            upload_img(urlUpload, id, function(res, status) {
                if (res.code == '000000') {
                    var data = JSON.parse(res.content);
                    console.log(data);
                    var ImgId = data[0].fileId;
                    switch (num) {
                        case 1:
                            $scope.fileFileId = ImgId;
                            //console.log($scope.orgLogoFileIdImg1)
                            $('#fileFileId').attr('src', "" + $rootScope.baseUrl + "/file/download?fileId=" + ImgId + "");
                            break;
                    }
                }
            });
        };

        // 上传图片
        // url:后台访问路径 fileId:input file按钮id, btn:点击的按钮id, fileInput:接收上传图片的id
        function upload_img(url, fileId, callback) {
            $.ajaxFileUpload({
                url: url,
                type: 'post',
                secureuri: false,
                fileElementId: fileId, // file标签的id
                dataType: 'json', // 返回数据的类型
                data: {
                    name: fileId
                },
                success: function(data, status) {
                    callback(data, status);
                },
                error: function(data, status, e) {
                    console.log(data, status, e);
                }
            });
        }
}])
.factory('marketMakeupCtrlSel', ['$http', 'localStorageService', 'myHttp', '$q', '$rootScope', function($http, localStorageService, myHttp, $q, $rootScope) {
		return {
			NewSubmitAdd:function (json) {
				var deferred = $q.defer();
				$http({
					method: 'POST',
					url: $rootScope.baseUrl + 'trade/price/quote/makeup/insert',
					data: json
				}).then(function successCallback(response) {
					deferred.resolve(response);
				}, function errorCallback(response) {
					deferred.reject(response);
				});
				return deferred.promise;
			},

		}
	}])