app.controller('payUnusualManageCtrl', ['$rootScope', '$scope', 'payUnusualManageSer', 'dataSer', '$timeout', '$sce','timestamp','getCurrencyType','getAccountTradeType', function($rootScope, $scope, payUnusualManageSer, dataSer, $timeout, $sce,timestamp,getCurrencyType,getAccountTradeType) {
    $scope.toggleTraderSearchState=false;
    $scope.Toggle = function(){
        $scope.toggleTraderSearchState = !$scope.toggleTraderSearchState;
        if($scope.toggleTraderSearchState){
           $('.search_column').css('height','auto');
        }
        else{
           $('.search_column').css('height','36px');
        }
    };

    // 货币转换
    getCurrencyType.then(function (res) {
        $scope.currencyList = JSON.parse(res.content);
        console.log($scope.currencyList)
    });
    //交易类型
    $scope.accountTradeType = getAccountTradeType;

    var processContent,processTotal;
    var source = {
        type: 'POST',
        datatype: "json",
        datafields: [  //数据字段定义
            {name: 'externalTransId', type: 'string'},
            {name: 'userName', type: 'string'},
            {name: 'transType', type: 'string'},
            {name: 'currency', type: 'string'},
            {name: 'transMoney', type: 'string'},
            {name: 'startTime', type: 'string'}
        ],
        url: $rootScope.baseUrl + 'exbank/query/transrecords/page',
        root: "content",
        pagesize:10,
        processData: function (data) {
            data.page = (data.pagenum + 1)?(data.pagenum + 1):1;
            data.rows =(data.pagesize)?(data.pagesize):10;
            // data.order =($scope.order)?$scope.order:'desc';
            // data.sort =($scope.sort)?$scope.sort:'createTime';
            data.search_LIKE_userName = ($scope.userName) ? $scope.userName : '';
            data.search_A_EQ_externalResult ='F';

        }, //传递参数处理
        beforeLoadComplete: function (records) { //数据完全加载完执行绘制表格
            var start;
            for (var i in records) {
                start = parseInt(i);
                break;
            }
            for (var k = 0, r = processContent.length; k < r; k++) {
                records[start + k].externalTransId = processContent[k].externalTransId;
                records[start + k].userName = processContent[k].userName;
                records[start + k].transType = processContent[k].transType;
                records[start + k].currency = processContent[k].currency;
                records[start + k].transMoney = processContent[k].transMoney;
                records[start + k].startTime = processContent[k].startTime;
            }
        },
        beforeprocessing: function (data) { //处理总页数
            var processData = JSON.parse(data.content);
            processContent = processData.content;
            source.totalrecords = processData.totalElements == 0 ? 5 : processData.totalElements;
            processTotal = processData.totalElements;
        },
        loadComplete: function (records) {
            $scope.saveResult=JSON.parse(records.content);
            var data =  $scope.saveResult.totalElements;
            if (data == 0) {
                $('#contenttableentrustDetailGrid > div').remove();
            }
        },
        endUpdate: true
    };
    //创建数据适配器
    var dataAdapter = null;
    $scope.searchAjax = function () {
        $scope.toggleTraderSearchState = false;
        $('.search_column').css('height', '36px');
        if (dataAdapter == null) {
            dataAdapter = new $.jqx.dataAdapter(source);
            //创建表格
            $("#entrustDetailGrid").jqxGrid({
                source: dataAdapter,
                columns: [  //表格数据域
                    {
                        text: '商户号',
                        datafield: 'externalTransId',
                        width: '16%',
                        minwidth: 16 + '%',//设置列min宽
                        align: 'center'//设置表头
                    },
                    {
                        text: '用户名',
                        datafield: 'userName',
                        minwidth: 16 + '%',
                        cellsalign: 'center',
                        align: 'center',
                        width: '16%'
                    },
                    {
                        text: '交易类型',
                        datafield: 'transType',
                        width:'16%',
                        minwidth: 16 + '%',
                        align: 'center',
                        cellsrenderer: function (row, columnfield, value, defaulthtml, columnproperties) {
                            if (getAccountTradeType) {
                                for (var i = 0; i < getAccountTradeType.length; i++) {
                                    if (value == getAccountTradeType[i].id) {
                                        return getAccountTradeType[i].name;
                                    }
                                }
                            }
                        }
                    },
                    {
                        text: '币种',
                        datafield: 'currency',
                        minwidth: 16 + '%',
                        cellsalign: 'center',
                        align: 'center',
                        width:'16%',
                        cellsrenderer: function (row, columnfield, value, defaulthtml, columnproperties) {
                            if ($scope.currencyList) {
                                for (var i = 0; i < $scope.currencyList.length; i++) {
                                    if (value == $scope.currencyList[i].currency) {
                                        return $scope.currencyList[i].currencyName;
                                    }
                                }
                            }
                        }
                    },
                    {
                        text: '金额',
                        datafield: 'transMoney',
                        minwidth:16 + '%',
                        align: 'center',
                        width:'16%'
                    },
                    {
                        text: '日期',
                        datafield: 'startTime',
                        minwidth:20 + '%',
                        cellsalign: 'center',
                        align: 'center',
                        width:'20%',
                        cellsrenderer: function (row, columnfield, value, defaulthtml, columnproperties) {
                            return timestamp.timestampCoverHms(value, 'all');
                        }
                    }
                ],
                width: 100 + '%',
                height: 87 + '%',
                theme:'metrodark',
                virtualmode: true,
                rendergridrows: function (params) { //将数据渲染到页面
                    return params.data;
                },
                pageable: true,
                pagesizeoptions: ['10','30','100','200'],
                sortable: true,
                // altrows: true,
                columnsresize: true,//列间距是否可调整
                selectionmode: 'singlecell',//选择模式
                clipboard: true,
            });
        }else {
            $("#entrustDetailGrid").jqxGrid('updatebounddata', 'cells');
        }
    };
    //分页
    $("#entrustDetailGrid").on("pagechanged", function (event) {
        console.log(event)
    });
    //排序
    $("#entrustDetailGrid").on("sort", function (event){
        var sortinformation = event.args.sortinformation;
        $scope.sort=sortinformation.sortcolumn;
        $scope.order=($scope.sort)?(sortinformation.sortdirection.ascending)?'asc':'desc':'asc';
        data={
            order:$scope.order,
            sort:$scope.sort
        };
        source.processData(data);
        $("#entrustDetailGrid").jqxGrid('updatebounddata', 'sort');
    });
}])
// Server
.factory('payUnusualManageSer', ['$http', 'localStorageService', 'myHttp', '$q', '$rootScope', function($http, localStorageService, myHttp, $q, $rootScope) {
    return {
        payUnusualSearch: function(json) {
            var deferred = $q.defer();
            myHttp.post("exbank/query/transrecords/page", json)
                .then(function(res) { // 调用承诺API获取数据 .resolve
                    deferred.resolve(res);
                }, function(res) { // 处理错误 .reject
                    deferred.reject(res);
                });
            return deferred.promise;

        }
    }
}])