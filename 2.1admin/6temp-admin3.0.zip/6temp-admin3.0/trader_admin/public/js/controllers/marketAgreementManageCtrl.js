app.controller("marketAgreementManageCtrl", ['$scope','$timeout','tipService','$rootScope','confirmService','marketAgreementManageCtrlSer','getPageNum', function($scope,$timeout,tipService,$rootScope,confirmService,marketAgreementManageCtrlSer,getPageNum){
    // 分页
    var pageJump = function(tmpArrList){
        $timeout(function(){
            if(tmpArrList != undefined){
                console.log(tmpArrList);
                $scope.currentPage = 1;//当前页数
                $scope.dataNum=tmpArrList.length;
                $scope.showDataChoose = getPageNum.pageNum();//获取分页
                $scope.showNum = $scope.showDataChoose[0];//初始显示刷具条数
                $scope.showPage = false;
                $timeout(function(){
                    $scope.showPage = true;
                    $scope.copyDataArray = tmpArrList.slice(0,14); //初始15条数据
                },10)
                $scope.dataPage=Math.ceil($scope.dataNum/$scope.showNum.showNum);

                //上下页
                $scope.pageSlect = function(type){
                    if(type == 'prev'){
                        if($scope.currentPage != 1){
                            $scope.currentPage --;
                            $scope.turnPage();
                        }else{
                            $scope.copyDataArray = tmpArrList.slice(0,14); //初始15条数据
                        }
                    }
                    else{
                        if($scope.currentPage < $scope.dataPage){
                            $scope.currentPage ++;
                            $scope.turnPage();
                        }
                    }
                }
                //每页数据量
                $scope.baseDataArray = [];
                $scope.copyDataArray = [];
                $scope.pageSelect = function(params){
                    $scope.showNum.showNum = params.showNum;
                    $scope.copyDataArray = tmpArrList.slice(0,(params.showNum-1));
                    $scope.dataPage=Math.ceil($scope.dataNum/$scope.showNum.showNum);
                    $scope.currentPage = 1;
                }
                $scope.turnPage=function(){
                    $scope.copyDataArray = tmpArrList.slice((($scope.currentPage-1)*15),(($scope.currentPage+1)*15-1));
                }
                //固定页面跳转
                $scope.jumpPage = function(num){
                    num = parseInt(num);
                    if(parseInt(num,10) === num && num <= ($scope.dataPage+1) && num > 0){
                        $scope.currentPage = num;
                        $scope.jumpPageNum='';
                        $scope.turnPage();
                    }else{
                        $scope.copyDataArray = tmpArrList.slice(0,14); //初始15条数据
                    }
                }
            }else{
                pageJump(tmpArrList);
            }
        },200);
    };
	$scope.search = function(){
		marketAgreementManageCtrlSer.search()
		.then(function(res){
			//console.log(res)
			if(res.retMsg.code == '000000'){
				$scope.chooseKey = null;
				$scope.searchResult = res.list;
                pageJump($scope.searchResult);
			}else {
							$rootScope.tipService.setMessage(res.message, 'warning');
						}
					}, function(error) {
						$rootScope.tipService.setMessage(error.message, 'warning');
					});
	}
	//$scope.search();
	$scope.resetVal = function(){
		//基础字段
		$scope.key = '';//协议编号（主键,自动生成）
		$scope.type = '';//协议名称
		$scope.enable = '';//协议使能/禁止
	}
	$scope.addMarketSourceSubmit = function(){
		console.log($scope.optType)
		if($scope.optType == 'edit'){
			var quoteProtocol = {
				key:$scope.key,
				type:$scope.type
			}
			if(toValidate('#marketAgree')){
			marketAgreementManageCtrlSer.edit(quoteProtocol)
			.then(function(res){
				if(res.data.code == '000000'){
					$rootScope.tipService.setMessage(res.data.message, 'warning');
					$scope.addMarketAgreement = false;
					$scope.search();
				}
				else{
					$rootScope.tipService.setMessage(res.data.message, 'warning');
				}
			});
		}
		}
		else{
			var quoteProtocol = {
				key:'',
				type:$scope.type,
				enable:$scope.enable
			}
			if(toValidate('#marketAgree')){
			marketAgreementManageCtrlSer.add(quoteProtocol)
			.then(function(res){
				if(res.data.code == '000000'){
					$rootScope.tipService.setMessage(res.data.message, 'warning');
					$scope.addMarketAgreement = false;
					$scope.search();
				}
				else{
					$rootScope.tipService.setMessage(res.data.message, 'warning');
				}
			});
		}
	}
	}
	$scope.optInfo = function(type){
		$scope.optType = type;
		if(type == 'edit'){
			if($scope.chooseKey == null){
				$rootScope.tipService.setMessage("请先选择账号", 'warning');
			}
			else{
				$scope.infoOptType = '保 存';
				$scope.addMarketAgreement = true;
				marketAgreementManageCtrlSer.singleSearch($scope.chooseKey)
				.then(function(res){
					if(res.data.retMsg.code == '000000'){
						console.log(res.data)
						$scope.key = res.data.protocol.key;//协议编号（主键,自动生成）
						$scope.type = res.data.protocol.type;//协议名称
						$scope.enable = res.data.protocol.enable;//协议使能/禁止
					}
				});
			}
		}
		else{
			$scope.infoOptType = '新 增';
			$scope.addMarketAgreement = true;
			$scope.resetVal();
		}
	}
	$scope.delete = function(){
		if($scope.chooseKey == null){
			$rootScope.tipService.setMessage("请先选择协议", 'warning');
		}
		else{
			confirmService.set('确认提示','确定删除此协议?',function(){
				marketAgreementManageCtrlSer.delete($scope.chooseKey)
				.then(function(res){
					if(res.data.code == '000000'){
						$rootScope.tipService.setMessage(res.data.message, 'warning');
						$scope.search();
					}
					else{
						$rootScope.tipService.setMessage(res.data.message, 'warning');
					}
				});
				confirmService.clear();
			});
			
		}
	}
	$scope.start = function(key){
		marketAgreementManageCtrlSer.start(key)
		.then(function(res){
			if(res.data.code == '000000'){
				$rootScope.tipService.setMessage(res.data.message, 'warning');
				$scope.search();
			}
			else{
				$rootScope.tipService.setMessage(res.data.message, 'warning');
			}
		});
	}
	$scope.stop = function(key){
		marketAgreementManageCtrlSer.stop(key)
		.then(function(res){
			if(res.data.code == '000000'){
				$rootScope.tipService.setMessage(res.data.message, 'warning');
				$scope.search();
			}
			else{
				$rootScope.tipService.setMessage(res.data.message, 'warning');
			}
		});
	}
	//单选
	$scope.chooseKey = null;
	$scope.checked = function(index,key){
		$scope.chooseKey = key;
		$('#dataReport input[type=checkbox]').prop('checked',false);
		$('#dataReport input[type=checkbox]').eq(index).prop('checked',true);
	}
}])
.factory('marketAgreementManageCtrlSer',['$http','localStorageService','myHttp','$q','$rootScope',function($http,localStorageService,myHttp,$q,$rootScope){
	return {
		search:function(){
			var deferred = $q.defer();
			myHttp.post("c/quote/protocols/query/all")
				.then(function(res) {  // 调用承诺API获取数据 .resolve
					deferred.resolve(res);
				}, function(res) {  // 处理错误 .reject
					deferred.reject(res);
			});
			return deferred.promise;
		},
		add:function(quoteProtocol){
			var deferred = $q.defer();
			$http({
				method: 'POST',
				url: $rootScope.baseUrl+'c/quote/protocols/insert',
				data:{quoteProtocol:quoteProtocol}
				}).then(function successCallback(response) {
					deferred.resolve(response);
				}, function errorCallback(response) {
					deferred.reject(response);
			});
			return deferred.promise;
		},
		edit:function(quoteProtocol){
			var deferred = $q.defer();
			console.log(quoteProtocol)
			$http({
				method: 'POST',
				url: $rootScope.baseUrl+'c/quote/protocols/modify',
				data:{key:quoteProtocol.key,newType:quoteProtocol.type}
				}).then(function successCallback(response) {
					deferred.resolve(response);
				}, function errorCallback(response) {
					deferred.reject(response);
			});
			return deferred.promise;
		},
		delete:function(key){
			var deferred = $q.defer();
			$http({
				method: 'POST',
				url: $rootScope.baseUrl+'c/quote/protocols/delete',
				data:{key:key}
				}).then(function successCallback(response) {
					deferred.resolve(response);
				}, function errorCallback(response) {
					deferred.reject(response);
			});
			return deferred.promise;
		},
		start:function(key){
			var deferred = $q.defer();
			$http({
				method: 'POST',
				url: $rootScope.baseUrl+'c/quote/protocols/enable',
				data:{key:key}
				}).then(function successCallback(response) {
					deferred.resolve(response);
				}, function errorCallback(response) {
					deferred.reject(response);
			});
			return deferred.promise;
		},
		stop:function(key){
			var deferred = $q.defer();
			$http({
				method: 'POST',
				url: $rootScope.baseUrl+'c/quote/protocols/disenable',
				data:{key:key}
				}).then(function successCallback(response) {
					deferred.resolve(response);
				}, function errorCallback(response) {
					deferred.reject(response);
			});
			return deferred.promise;
		},
		singleSearch:function(key){
			var deferred = $q.defer();
			$http({
				method: 'POST',
				url: $rootScope.baseUrl+'c/quote/protocols/query/key',
				data:{key:key}
				}).then(function successCallback(response) {
					deferred.resolve(response);
				}, function errorCallback(response) {
					deferred.reject(response);
			});
			return deferred.promise;
		}
	}
}])