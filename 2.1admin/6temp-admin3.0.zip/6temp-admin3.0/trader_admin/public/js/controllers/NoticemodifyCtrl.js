app.controller('NoticemodifyCtrl', ['$scope', 'dataSer', 'CommissionallocationAddCtrlSer', 'NoticemodifyCtrlSel', '$state', '$rootScope', 'localStorageService', 'NoticequeryCtrlSer', 'timestamp', 'memberMangerCtrlSer', function($scope, dataSer, CommissionallocationAddCtrlSer, NoticemodifyCtrlSel, $state, $rootScope, localStorageService, NoticequeryCtrlSer, timestamp, memberMangerCtrlSer) {
		var E = window.wangEditor;
		var editor = new E('#editor');
		editor.create();
		var htmls = editor.txt.html();
		$scope.goBack = function() {
				$state.go('tabs.Noticequery');
			}
			//机构列表
			//$scope.addOrgVal = ''; //显示值
		$scope.orgId = ''; //选择值
		dataSer.organizeQuerySer()
			.then(function(res) {
				$scope.orgList = res;
				console.log($scope.orgList)
			});
		$scope.orgListText = function(createOrgCode){
			if($scope.orgList){
				 	for (var i = 0,r = $scope.orgList.length; i < r; i++) {
				 		console.log($scope.orgList)
				 		if (createOrgCode == $scope.orgList[i].orgCode) {
				 			return $scope.orgList[i].text;

				 		}
				 	}
				 }
		}

		$scope.allnotlickList = [];
		$scope.copyuesrList = [];
		$scope.addOrgValFTC = function(d) {
				//console.log(data);
				$scope.allotOrgId = d.orgId;
				$scope.superorgCode = d.orgCode;
				$scope.addOrgVal = d.text;
				CommissionallocationAddCtrlSer.AllNOTLIKEQuerySer($scope.superorgCode)
					.then(function(res) {
						$scope.allnotlickList = res;
						console.log($scope.allnotlickList);
						for (var i = 0, r = $scope.allnotlickList.length; i < r; i++) {
							if ($scope.allnotlickList[i].state == 1) {
								$scope.allnotlickList.push({
									orgCode: $scope.allnotlickList[i].orgCode,
									orgName: $scope.allnotlickList[i].orgName
								})
							}
						}
					})
			}
			//时间戳
		function add0(m) {
			return m < 10 ? '0' + m : m
		}

		function format(datatime) {
			//shijianchuo是整数，否则要parseInt转换
			var time = new Date(datatime);
			var y = time.getFullYear();
			var m = time.getMonth() + 1;
			var d = time.getDate();
			var h = time.getHours();
			var mm = time.getMinutes();
			var s = time.getSeconds();
			return y + '-' + add0(m) + '-' + add0(d) + ' ' + add0(h) + ':' + add0(mm) + ':' + add0(s);
		}
		var chooseNoticeId = localStorageService.get('NTchooseNoticeId');
		NoticequeryCtrlSer.getNTInfo(chooseNoticeId)
			.then(function(res) {
				if (res.data.code == '000000') {
					var dataVal = JSON.parse(res.data.content);
					console.log(dataVal);
					$scope.orgIdVal = dataVal.configs[0].orgId;
					console.log($scope.orgIdVal)
					$scope.noticeId = dataVal.noticeId;
					$scope.title = dataVal.title;
					$scope.content = dataVal.content;
					editor.txt.html($scope.content);
					$scope.createTimeStart = format(dataVal.createTime);
					$scope.validStartTime = format(dataVal.validStartTime);
					if (dataVal.validEndTime != null) {
						$scope.validEndTime = format(dataVal.validEndTime);
					} else {
						$scope.validEndTime = "";
					}
					$scope.createOrgId = dataVal.createOrgId;
					$scope.createOrgCode = dataVal.createOrgCode;
					//$scope.addOrgVal =data.configs[0].orgName;;
					//console.log($scope.addOrgVal)
					$scope.readType = dataVal.configs[0].readType;
				}
			});
		//修改公告
		$scope.addNoticeInfo = function() {
			$scope.content = editor.txt.html();
			var noticeV = {
				noticeId: $scope.noticeId,
				title: $scope.title,
				content: $scope.content,
				validStartTime: $scope.createTimeStart,
				validEndTime: $scope.validEndTime,
				configs: [{
					orgId: $scope.createOrgId,
					orgCode: $scope.createOrgCode,
					readType: $scope.readType,
					userIds: $scope.uesrconfigs,
				}]
			}
			console.log(noticeV)
			var json = {
				noticeV: noticeV
			}
			NoticemodifyCtrlSel.modify(json)
				.then(function(res) {
					console.log(res)
					if (res.data.code =="000000") {
						$rootScope.tipService.setMessage(res.data.message, 'warning');
						$state.go('tabs.Noticequery');
					} else {
						$rootScope.tipService.setMessage(res.data.message, 'warning');
					}
				})
		}
	}])
	.factory('NoticemodifyCtrlSel', ['$http', 'localStorageService', 'myHttp', '$q', '$rootScope', function($http, localStorageService, myHttp, $q, $rootScope) {
		return {
			modify: function(json) {
				var deferred = $q.defer();
				$http({
						method: 'POST',
						url: $rootScope.baseUrl + 'notice/modify',
						data: json
					})
					.then(function(res) { // 调用承诺API获取数据 .resolve
						deferred.resolve(res);
					}, function(res) { // 处理错误 .reject
						deferred.reject(res);
					});
				return deferred.promise;
			}

		}
	}])