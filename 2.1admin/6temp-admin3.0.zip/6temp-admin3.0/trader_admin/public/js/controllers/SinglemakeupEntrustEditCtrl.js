app.controller('SinglemakeupEntrustEditCtrl', ['$scope', 'SinglemakeupEntrustEditSel', 'getPageNum', 'localStorageService', '$state', '$rootScope', 'SinglemakeupdetailsCtrlSel', 'dataSer', function ($scope, SinglemakeupEntrustEditSel, getPageNum, localStorageService, $state, $rootScope, SinglemakeupdetailsCtrlSel, dataSer) {
    dataSer.organizeQuerySer()
        .then(function (res) {
            $scope.orgList = res;
        });
    $scope.addOrgValFTC = function (d) {
        $scope.allotOrgId = d.orgId;
        $scope.superorgCode = d.orgCode;
        $scope.addOrgVal = d.text;
    }
    //匹配机构代码
    var json = {
        page: 1,
        rows: 9999,
        search_A_EQ_state: 1
    };
    dataSer.getOrganize(json).then(function (res) {
        if (res.code == '000000') {
            $scope.equalOrgCode = JSON.parse(res.content).content;
            console.log($scope.equalOrgCode);
            for (var i = 0; i < $scope.equalOrgCode.length; i++) {
                if ($scope.orgIdVal == $scope.equalOrgCode[i].orgId) {
                    $scope.addOrgVal = $scope.equalOrgCode[i].orgName + '(' + $scope.equalOrgCode[i].orgNum + ')';
                    console.log($scope.addOrgVal)
                }
            }
        } else {
            console.log(res);
        }
    });
    //委托修改
    $scope.goBack = function () {
        $state.go('tabs.Singlemakeupdetails');
    }
    function add0(m) {
        return m < 10 ? '0' + m : m
    }

    function format(datatime) {
        //shijianchuo是整数，否则要parseInt转换
        var time = new Date(datatime);
        var y = time.getFullYear();
        var m = time.getMonth() + 1;
        var d = time.getDate();
        var h = time.getHours();
        var mm = time.getMinutes();
        var s = time.getSeconds();
        return y + '-' + add0(m) + '-' + add0(d) + ' ' + add0(h) + ':' + add0(mm) + ':' + add0(s);
    }

    var chooseNoticeId = localStorageService.get('EDNoticeId');
    console.log(chooseNoticeId)
    SinglemakeupdetailsCtrlSel.getNTInfo(chooseNoticeId)
        .then(function (res) {
            console.log(res)
            if (res.data.code == '000000') {
                var dataVal = JSON.parse(res.data.content);
                console.log(dataVal);
                $scope.recoverOrderId = dataVal.recoverOrderId;
                //$scope.recoverId=dataVal.recoverId;// 主表主键
                $scope.orgIdVal = dataVal.orgId;
                $scope.clientNo = dataVal.clientNo;// 客户账号
                $scope.marketNo = dataVal.marketNo;// 市场编号
                $scope.commodityType = dataVal.commodityType;// 品种类型
                $scope.commodityNo = dataVal.commodityNo;// 品种编号
                $scope.contractNo = dataVal.contractNo;// 合约编号
                $scope.orderType = dataVal.orderType;// 委托类型
                $scope.orderSource = dataVal.orderSource;// 委托来源
                $scope.orderPatterns = dataVal.orderPatterns;// 委托模式
                $scope.limitTime = format(dataVal.limitTime);// 有效日期
                //$scope.limitTimeNum=Date.parse(new Date($scope.limitTime));
                $scope.riskType = dataVal.riskType;// 风险报单类型
                $scope.orderDirect = dataVal.orderDirect;// 买卖
                $scope.orderOffset = dataVal.orderOffset;// 开平
                $scope.orderHedge = dataVal.orderHedge;// 投机套保
                $scope.orderPrice = parseFloat(dataVal.orderPrice);// 委托价格
                $scope.triggerPrice = parseFloat(dataVal.triggerPrice);// 触发价格
                $scope.orderVolume = parseInt(dataVal.orderVolume);// 委托数量
                $scope.orderId = parseInt(dataVal.orderId);// 委托号
                $scope.minVolume = parseInt(dataVal.minVolume);// 最小成交数量
                $scope.orderStreamId = parseInt(dataVal.orderStreamId);// 委托流号
                $scope.localNo = dataVal.localNo;// 本地号
                $scope.systemNo = dataVal.systemNo;// 系统号
                $scope.exchangeSystemNo = dataVal.exchangeSystemNo;// 交易所系统号
                $scope.tradeNo = dataVal.tradeNo;// 交易编码
                $scope.serverFlag = dataVal.serverFlag;// 服务器标志
                $scope.upNo = dataVal.upNo;// 上手编号
                $scope.upClientNo = dataVal.upClientNo;// 上手登录号
                $scope.insertNo = dataVal.insertNo;// 下单人
                $scope.insertTime = format(dataVal.insertTime);// 下单时间
                //$scope.insertTimeNum=Date.parse(new Date($scope.insertTime));
                $scope.updateNo = dataVal.updateNo;// 最后一次变更人
                $scope.updateTime = format(dataVal.updateTime);// 最后一次变更时间
                //$scope.updateTimeNum=Date.parse(new Date($scope.updateTime));
                $scope.orderState = dataVal.orderState;// 委托状态
                $scope.matchPrice = dataVal.matchPrice;// 成交价格
                $scope.matchVolume = dataVal.matchVolume;// 成交数量
                $scope.errorMsg = dataVal.errorMsg;// 错误信息
                $scope.upErrorMsg = dataVal.upErrorMsg;// 上手错误信息
                $scope.upStreamId = dataVal.upStreamId;// 上手流号
                $scope.operateLocalNo = dataVal.operateLocalNo;// 操作本地号
                $scope.record = dataVal.record;// 是否录单
                $scope.deleteFlag = dataVal.deleteFlag;// 删除标记
                $scope.t1Flag = dataVal.t1Flag;// T+1成交
                $scope.orderSystemNo = dataVal.orderSystemNo;// 父单系统号
                // 用户信息
                $scope.userName = dataVal.userName; // 用户账户
                // 资产信息
                $scope.productCode = dataVal.productCode; // 资产代码
                $scope.orgNum = dataVal.orgNum;//
            }
        });

    $scope.NewSubmit = function () {
        var recoverOrderVIce = {
            recoverOrderId: $scope.recoverOrderId,
            //recoverId:$scope.recoverId,// 主表主键
            clientNo: $scope.clientNo,// 客户账号
            marketNo: $scope.marketNo,// 市场编号
            commodityType: $scope.commodityType,// 品种类型
            commodityNo: $scope.commodityNo,// 品种编号
            contractNo: $scope.contractNo,// 合约编号
            orderType: $scope.orderType,// 委托类型
            orderSource: $scope.orderSource,// 委托来源
            orderPatterns: $scope.orderPatterns,// 委托模式
            limitTime: Date.parse(new Date($scope.limitTime)),// 有效日期
            riskType: $scope.riskType,// 风险报单类型
            orderDirect: $scope.orderDirect,// 买卖
            orderOffset: $scope.orderOffset,// 开平
            orderHedge: $scope.orderHedge,// 投机套保
            orderPrice: parseFloat($scope.orderPrice),// 委托价格
            triggerPrice: parseFloat($scope.triggerPrice),// 触发价格
            orderVolume: parseInt($scope.orderVolume),// 委托数量
            minVolume: parseInt($scope.minVolume),// 最小成交数量
            orderStreamId: parseInt($scope.orderStreamId),// 委托流号
            orderId: parseInt($scope.orderId),// 委托号
            localNo: $scope.localNo,// 本地号
            systemNo: $scope.systemNo,// 系统号
            exchangeSystemNo: $scope.exchangeSystemNo,// 交易所系统号
            tradeNo: $scope.tradeNo,// 交易编码
            serverFlag: $scope.serverFlag,// 服务器标志
            upNo: $scope.upNo,// 上手编号
            upClientNo: $scope.upClientNo,// 上手登录号
            insertNo: $scope.insertNo,// 下单人
            insertTime: Date.parse(new Date($scope.insertTime)),// 下单时间
            updateNo: $scope.updateNo,// 最后一次变更人
            updateTime: Date.parse(new Date($scope.updateTime)),// 最后一次变更时间
            orderState: $scope.orderState,// 委托状态
            matchPrice: parseFloat($scope.matchPrice),// 成交价格
            matchVolume: parseInt($scope.matchVolume),// 成交数量
            errorMsg: $scope.errorMsg,// 错误信息
            upErrorMsg: $scope.upErrorMsg,// 上手错误信息
            upStreamId: $scope.upStreamId,// 上手流号
            operateLocalNo: $scope.operateLocalNo,// 操作本地号
            record: $scope.record,// 是否录单
            deleteFlag: $scope.deleteFlag,// 删除标记
            t1Flag: $scope.t1Flag,// T+1成交
            orderSystemNo: $scope.orderSystemNo,// 父单系统号
            // 用户信息
            userName: $scope.userName, // 用户账户
            // 资产信息
            productCode: $scope.productCode, // 资产代码
            orgNum: $scope.orgNum,//
        }
        var json = {
            recoverOrderVIce: recoverOrderVIce
        }
        SinglemakeupEntrustEditSel.addSinglemake(json)
            .then(function (res) {
                if (res.data.code == "000000") {
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                    $state.go('tabs.Singlemakeupdetails');
                } else {
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                }
            }, function (error) {
                $rootScope.tipService.setMessage(error.data.message, 'warning');
            })
    }
}])
    .factory('SinglemakeupEntrustEditSel', ['$http', 'localStorageService', 'myHttp', '$q', '$rootScope', function ($http, localStorageService, myHttp, $q, $rootScope) {
        return {
            //委托新增
            addSinglemake: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'admin/trade/recover/save/order',
                    data: json
                })
                    .then(function (res) { // 调用承诺API获取数据 .resolve
                        deferred.resolve(res);
                    }, function (res) { // 处理错误 .reject
                        deferred.reject(res);
                    });
                return deferred.promise;
            }
        }
    }])
