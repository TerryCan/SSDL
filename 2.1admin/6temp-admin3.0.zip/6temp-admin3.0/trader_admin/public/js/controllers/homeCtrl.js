app.controller("homePage", function ($scope, $rootScope, $http, $state, home, getUserStates, localStorageService, $timeout, getUserType, timestamp, tipService, confirmService, getPageNum,signState, dataSer) {
    //获取币种
    home.obtainCurrencyType().then(function (res) {
        if(res.code=='000000' && res.content){
            $scope.currencyList = JSON.parse(res.content);
            console.log($scope.currencyList)
        }
    });
    $scope.getCurrency = function (parameter) {
        if ($scope.currencyList) {
            for (var i = 0; i < $scope.currencyList.length; i++) {
                if (parameter == $scope.currencyList[i].currency) {
                    return $scope.currencyList[i].currencyName;
                }
            }
        }
    };
    //匹配机构代码
    var json = {
        page: 1,
        rows: 999,
        search_A_EQ_state: 1
    };
    dataSer.getOrganize(json).then(function (res) {
        if (res.code == '000000') {
            $scope.equalOrgCode = JSON.parse(res.content).content;
            localStorageService.update('organizeData', $scope.equalOrgCode);
        } else {
            console.log(res);
        }
    });

    //银行商户ID
    home.merchantId().then(function (res) {
        if (res.code == '000000') {
            $scope.merchantIdList = JSON.parse(res.content);
            console.log($scope.merchantIdList);
        }
    });

    //获取银行信息
    $scope.province = '';
    $scope.city = '';
    $scope.custBank = '';
    $scope.bankNameList = '';
    //省
    home.bankProvince().then(function (res) {
        $scope.provinceList = JSON.parse(res.content);
    });
    //市
    $scope.getCity = function () {
        $scope.bankNameList = '';
        $scope.bankDetailList = '';
        var data_map = {
            search_EQ_fatherCityId: $scope.province
        };
        home.bankCity(data_map)
            .then(function (res) {
                $scope.cityDetailList = JSON.parse(res.content);
                console.log($scope.cityDetailList);
            });
    };
    //银行
    $scope.getBank = function () {
        $scope.bankDetailList = '';
        home.mainBank().then(function (res) {
            $scope.bankNameList = JSON.parse(res.content);
            console.log($scope.bankNameList);
        });
    };
    //支行名称
    $scope.getDetailBank = function () {
        var data_map = {
            search_LLIKE_id: $scope.custBank.split('-')[1] + $scope.city
        };
        console.log(data_map);
        home.bankDetailList(data_map)
            .then(function (res) {
                $scope.bankDetailList = JSON.parse(res.content);
                console.log($scope.bankDetailList);
            });
    };
    //支行行号联动
    $scope.searchId = function (parameter) {
        $scope.recvTgfi = parameter.split('-')[0];
        $scope.resign_recvTgfi = parameter.split('-')[0];
    };
    //匹配所属银行
    home.mainBank().then(function (res) {
        $scope.bankNameList = JSON.parse(res.content);
    });
    $scope.switchBankType = function (parameter) {
        for (var i = 0; i < $scope.bankNameList.length; i++) {
            if (parameter == $scope.bankNameList[i].id) {
                return $scope.bankNameList[i].bankName;
            }
        }
    };
    //银行支付通道
    var bankJson = {
        page: 1,
        rows: 9999,
        orders: 'asc'
    };
    home.bankChannel(bankJson).then(function (res) {
        if (res.content) {
            $scope.bankchannelList = JSON.parse(res.content).content;
        }
    }, function (error) {
        console.log(error);
    });
    //数据转换
    getUserStates.userState().then(function (res) {
        $scope.userStates = res;
    });
    var UserType = getUserType;
    $scope.getUserStates = function (params) {
        for (var i in $scope.userStates) {
            if (params == i) {
                return $scope.userStates[i];
            }
        }
    };
    $scope.getUserType = function (params) {
        for (var i = 0, r = UserType.length; i < r; i++) {
            if (params == UserType[i].id) {
                return UserType[i].name;
            }
        }
    };
    $scope.timeRecover = function (val) {
        return timestamp.timestampCoverHms(val, 'all');
    };

    //签约状态
    $scope.SignState = signState;
    $scope.getSignState = function (parameter) {
        for (var i = 0; i < signState.length; i++) {
            if (parameter == signState[i].val) {
                return signState[i].name;
            }
        }
    };
    //修改个人信息时 改密Input密码类型
    $scope.editSelfInfoColumn = false;
    $scope.editSelfInfo = function () {
        $scope.editSelfInfoColumn = true;
    };
    $scope.changeTypeText = 'text';
    $scope.editShow = 'true';
    $scope.passwordShow = false;
    $scope.changeType = function () {
        if ($scope.type == 1) {
            $scope.changeTypeText = 'password';
            $scope.editShow = 'false';
            $scope.passwordShow = true;
        } else {
            $scope.editShow = 'true';
            $scope.passwordShow = false;
            $scope.changeTypeText = 'text';
        }
    };
    $scope.changeTypeShow = function () {
        $scope.changeTypeText = 'text';
    };
    //修改个人信息
    $scope.editSelfInfoColumn = false;
    $scope.editSelfInfo = function () {
        $scope.editSelfInfoColumn = true;
    };
    $scope.newValue = '';
    $scope.ConfirmValue = '';
    $scope.saveEditSelfInfo = function () {
        if ($scope.newValue == $scope.ConfirmValue) {
            $scope.value = $scope.ConfirmValue;
            home.saveSelfInfo($scope.type, $scope.value, $scope.password)
                .then(function (res) {
                    if (res.code == '000000') {
                        $scope.editSelfInfoColumn = false;
                        confirmService.set('提示', '修改成功,请重新登陆', function () {
                            window.localStorage.clear();
                            dataSer.initLine();
                            $scope.changeState('login');
                            confirmService.clear();
                        });
                    } else {
                        $rootScope.tipService.setMessage(res.message, 'warning');
                    }
                },function(error){
                    $rootScope.tipService.setMessage(error.message, 'warning');
                });
        } else {
            $rootScope.tipService.setMessage('新密码与确认密码不一致!', 'warning');
        }
    };

    // 修改与重置资金密码
    $scope.oldGoldPwd = '';
    $scope.newGoldPwd = '';
    $scope.newGoldRepeatPwd = '';
    $scope.removeEdit=function(){
        $scope.EditPwdColumn = false;
        $scope.oldGoldPwd = '';
        $scope.newGoldPwd = '';
        $scope.newGoldRepeatPwd = '';
    };
    $scope.editGoldPwd = function () {
        var error = 0;  //error做前台数据条件校验
        if ($scope.oldGoldPwd == '') {
            $scope.oldGoldPwdShow = true;
            $scope.oldGoldPwdError = '旧密码不能为空';
            error++;
        }
        if ($scope.newGoldPwd == '' || $scope.newGoldPwd.length < 6) {
            $scope.newGoldPwdShow = true;
            $scope.newGoldPwdError = '新密码应大于6位';
            error++;
        }
        if ($scope.newGoldPwd != $scope.newGoldRepeatPwd) {
            $scope.newGoldRepeatPwdShow = true;
            $scope.newGoldRepeatPwdError = '与新密码不一致';
            error++;
        }
        $timeout(function(){
            $scope.oldGoldPwdShow = false;
            $scope.newGoldPwdShow = false;
            $scope.newGoldRepeatPwdShow = false;
        },3000);
        if (error == 0) {
            var userId=localStorageService.get('selfInfo').userId;
            home.goldPwd(userId,$scope.oldGoldPwd, $scope.newGoldPwd)
                .then(function (res) {
                    if (res.code == '000000') {
                        $scope.removeEdit();
                        $rootScope.tipService.setMessage(res.message, 'warning');

                    }
                    else {
                        $scope.removeEdit();
                        $rootScope.tipService.setMessage(res.message, 'warning');
                    }
                });
        }
    };
    //获取验证码1
    var wait=60;
    $scope.restPwdNum= "重置密码";
    $scope.time=function() {
        if (wait == 0) {
            $(".modal-footer button").attr("disabled",false);
            $scope.restPwdNum = "重置密码";
            wait =60;
        } else {
            $(".modal-footer button").attr("disabled", true);
            $scope.restPwdNum= "(" + wait + ")秒后可重发";
            wait--;
            $timeout(function() {
                    $scope.time()
                },
                1000)
        }
    };
    //重置资金密码
    $scope.resetGlodPwd = function () {
        home.resetGoldPwd()
            .then(function (res) {
                console.log(res);
                if (res.code == '000000') {
                    $scope.time();
                    confirmService.set('提示', '资金密码重置成功，请去邮箱修改密码', function () {
                        confirmService.clear();
                    });
                } else {
                    $scope.EditPwdColumn = false;
                    $rootScope.tipService.setMessage(res.message, 'warning');
                }
            });
    };
    $scope.closePwd = function () {
        $scope.EditPwdColumn = false;
        $scope.oldGoldPwd = '';
        $scope.newGoldPwd = '';
        $scope.newGoldRepeatPwd = '';
    };
    //签约
    $scope.signBtnShow = true;
    $scope.resignBtnShow = false;
    $scope.signUserJudge = function () {
        home.unitSignTest().then(function (res) {
            console.log(res);
            if (res.content) {
                if (res.code == '000000') {
                    $scope.signResult = JSON.parse(res.content);
                    localStorageService.update('signInformation', $scope.signResult);
                    $scope.signBtnShow = false;
                    $scope.resignBtnShow = true;
                    $scope.resign_cardNo = $scope.signResult.cardNo;
                    $scope.resign_cardName = $scope.signResult.cardName;
                    $scope.resign_identityCard = $scope.signResult.identityCard;
                    $scope.resign_cusMobile = $scope.signResult.cusMobile;
                    $scope.resign_recvTgfi = $scope.signResult.recvTgfi;
                    $scope.resign_custBank = $scope.signResult.custBank;
                } else {
                    $scope.signBtnShow = true;
                    $scope.resignBtnShow = false;
                    $rootScope.tipService.setMessage(res.message, 'warning');
                }
            } else {
                $scope.signBtnShow = true;
                $scope.resignBtnShow = false;
            }

        });
    };
    $scope.signUserJudge();
    var userMessage = localStorageService.get('userInfo');
    $scope.cardNo = '';
    $scope.cardName = '';
    $scope.identityCard = '';
    $scope.cusMobile = '';
    $scope.custBank = '';
    $scope.recvTgfi = '';
    $scope.recvBankNm = '';
    $scope.accountPassword = '';
    $scope.repeatAccountPassword = '';
    $scope.signUser = function () {
        var signUpV = {
            userId: userMessage.userId,
            custName: userMessage.loginName,
            cardNo: $scope.cardNo,
            cardName: $scope.cardName,
            identityCard: $scope.identityCard,
            mobile: $scope.cusMobile,
            custBank: parseInt($scope.custBank.split('-')[0]),
            recvTgfi: $scope.recvTgfi,
            recvBankNm: $scope.recvBankNm.split('-')[1],
            accountPassword: $scope.accountPassword,
            repeatAccountPassword: $scope.repeatAccountPassword
        };
        var json = {
            signUpV: signUpV
        };
        home.unitSign(json)
            .then(function (res) {
                if (res.code == '000000') {
                    $scope.signColumn = false;
                    $rootScope.tipService.setMessage(res.message, 'warning');
                    $scope.signUserJudge();
                } else {
                    $rootScope.tipService.setMessage(res.message, 'warning');
                    $scope.signBtnShow = true;
                    $scope.resignBtnShow = false;
                }
            }, function (error) {
                $scope.signColumn = false;
                $rootScope.tipService.setMessage(error.message, 'warning');
            });
    };
    //换绑
    $scope.resign_userId = '';
    $scope.resign_cardNo = '';
    $scope.resign_cardName = '';
    $scope.resign_identityCard = '';
    $scope.resign_cusMobile = '';
    $scope.resign_recvTgfi = '';
    $scope.resign_custBank = '';
    $scope.resign_recvBankNm = '';
    $scope.resign_accountPassword = '';
    $scope.resign_repeatAccountPassword = '';
    $scope.resignUser = function () {
        console.log($scope.resign_userId);
        var updateSignV = {
            accountId: $scope.signResult.userId,
            cardNo: $scope.resign_cardNo,
            cardName: $scope.resign_cardName,
            identityCard: $scope.resign_identityCard,
            mobile: $scope.resign_cusMobile,
            accountPassword: $scope.resign_accountPassword,
            repeatAccountPassword: $scope.resign_repeatAccountPassword,
            custBank: parseInt($scope.custBank.split('-')[0]),
            recvTgfi: $scope.resign_recvTgfi,
            recvBankNm: $scope.resign_recvBankNm.split('-')[1]
        };
        var json = {
            updateSignV: updateSignV
        };
        home.unitResign(json)
            .then(function (res) {
                if(res.code=='000000'){
                    $scope.resignColumn = false;
                    $rootScope.tipService.setMessage(res.message, 'warning');
                    $scope.signUserJudge();
                }else{
                    $scope.resignColumn = false;
                    $rootScope.tipService.setMessage(res.message, 'warning');
                }
            }, function (error) {
                $scope.resignColumn = false;
                $rootScope.tipService.setMessage(error.message, 'warning');
            })
    };
    //交易账户
    $scope.currency = '';
    $scope.marketValue = '--';
    $scope.netWorth = '--';
    $scope.balance = '--';
    $scope.freeze = '--';
    $scope.extract = '--';
    $scope.outing = '--';
    $scope.ining = '--';
    $scope.floatProfit = '--';
    $scope.deposit = '--';
    $scope.riskRate = '--';
    $scope.khfFloatProfit='--';
    $scope.tradeAccountCurrency = function () {
        var signUpV = {
            currency: parseFloat($scope.currency)
        };
        home.tradeSearch(signUpV)
            .then(function (res) {
                if (res.code == '000000' && res.content) {
                    var tradeSearchList = JSON.parse(res.content);
                    console.log(tradeSearchList);
                    $scope.marketValue = tradeSearchList.inOut + tradeSearchList.floatProfit;
                    $scope.netWorth = tradeSearchList.netWorth;
                    $scope.balance = tradeSearchList.balance; //结余
                    $scope.freeze = tradeSearchList.freeze;
                    $scope.extract = tradeSearchList.extract;
                    $scope.outing = tradeSearchList.outing;
                    $scope.ining = tradeSearchList.ining;
                    $scope.floatProfit = tradeSearchList.floatProfit;
                    $scope.deposit = tradeSearchList.deposit;
                    $scope.riskRate = tradeSearchList.riskRate;
                    $scope.khfFloatProfit=tradeSearchList.khfFloatProfit;
                } else {
                    $rootScope.tipService.setMessage(res.message, 'warning');
                }
            }, function (error) {
                $rootScope.tipService.setMessage(error.message, 'warning');
            });
    };
    // 出金
    $scope.enableGoldAmount='';
    $scope.goldToBankMerchantId = '';
    $scope.goldPayAmount = '';

    $scope.getGoldAmount=function(){
        console.log($scope.goldToBankMerchantId.split(':'));
        var signUpV = {
            currency: parseFloat($scope.goldToBankMerchantId.split(':')[1]),
            accountPassword:$scope.goldAccountPassword
        };
        home.tradeSearch(signUpV).then(function (res) {
            if (res.code == '000000' && res.content) {
                var tradeSearchList = JSON.parse(res.content);
                console.log(tradeSearchList);
                $scope.enableGoldAmount = tradeSearchList.extract;
            }
        });
    };
    $scope.goldFund = function () {
        $scope.tradeColumn = false;
        $scope.goldColumn = true;
    };
    $scope.removeGold = function () {
        $scope.goldColumn = false;
        $scope.enableGoldAmount='';
        $scope.goldToBankMerchantId = '';
        $scope.goldPayAmount = '';
        $scope.goldAccountPassword = '';
    };
    $scope.Gold = function () {
        var accountV = {
            toBankMerchantId:$scope.goldToBankMerchantId.split(':')[0],
            payAmount: parseFloat($scope.goldPayAmount),
            accountPassword: $scope.goldAccountPassword
        };
        home.unitGold(accountV)
            .then(function (res) {
                if(res.code=='000000'){
                    $scope.removeGold();
                    $rootScope.tipService.setMessage(res.message, 'warning');
                }else{
                    $rootScope.tipService.setMessage(res.message, 'warning');
                }
            }, function (error) {
                $rootScope.tipService.setMessage(error.message, 'warning');
            })
    };
    //入金
    $scope.searchIntoAmount=function(){
        var json = {
            userId:localStorageService.get('selfInfo').userId,
            bankMerchantId:$scope.intoBankSignUpId.split(':')[1],
            accountPassword:($scope.intoGoldPassword)?$scope.intoGoldPassword:''
        };
        home.intoGoldSearch(json).then(function (res) {
            if (res.code == '000000' && res.content) {
                var tradeSearchList = JSON.parse(res.content);
                console.log(tradeSearchList);
                $scope.intoGoldPayAmt = tradeSearchList.balance;
            }
        });
    };
    $scope.intoGoldFund = function () {
        $scope.tradeColumn = false;
        $scope.intoGoldColumn = true;
    };
    $scope.intoBankSignUpId = '';
    $scope.intoGoldPassword = '';
    $scope.payAmt = '';
    $scope.intoGoldPayAmt='';
    $scope.removeIntoGold = function () {
        $scope.intoGoldColumn = false;
        $scope.intoBankSignUpId = '';
        $scope.intoGoldPassword = '';
        $scope.payAmt = '';
        $scope.intoGoldPayAmt='';
    };
    $scope.intoGold = function () {
        var resignUpV = {
            bankSignupId:$scope.intoBankSignUpId.split(':')[0],
            payAmt: $scope.payAmt,
            accountPassword: ($scope.intoGoldPassword)?$scope.intoGoldPassword:''
        };
        home.unitIntoGold(resignUpV)
            .then(function (res) {
                if(res.code=='000000'){
                    $scope.removeIntoGold();
                    $rootScope.tipService.setMessage(res.message, 'warning');
                }else{
                    $rootScope.tipService.setMessage(res.message, 'warning');
                }
            }, function (error) {
                $rootScope.tipService.setMessage(error.message, 'warning');
            })
    };
    //附属账户
    $scope.adjunctAccount = function () {
        $scope.adjunctColumn = true;
        var signUpV = {};
        var json = {
            signUpV: signUpV
        };
        home.unitSign(json)
            .then(function (res) {
                $scope.signColumn = false;
            }, function (error) {
                $scope.signColumn = false;
                $rootScope.tipService.setMessage(error.message, 'warning');
            });
    };
    //附属账户余额
    $scope.balanceList = '';
    $scope.accountPassword = '';
    $scope.BankMerchantId = '';
    $scope.balanceSearch = function () {
        if ($scope.accountPassword && $scope.BankMerchantId) {
            var userIdSave = localStorageService.get('signInformation').userId;
            console.log(userIdSave);
            var ExternalBankV = {
                userId: userIdSave,
                bankMerchantId: $scope.BankMerchantId,
                accountPassword: $scope.accountPassword

            };
            home.unitBalance(ExternalBankV)
                .then(function (res) {
                    if (res.code == '000000') {
                        $scope.balanceList = JSON.parse(res.content).balance;
                        console.log($scope.balanceList);
                    }else{
                        $rootScope.tipService.setMessage(res.message, 'warning');
                    }
                }, function (error) {
                    console.log(error);
                });
        } else {
            $scope.balanceSearch();
        }
    };
    //充值
    //固定银行列表
    $scope.rechargeThirdpayFlag = '';
    $scope.bankListShow = false;
    $scope.chooseBank = true;
    $scope.rechargeShow =function(){
        $scope.adjunctColumn=false;
        $scope.rechargeColumn=true;
    };
    $scope.readBank = function () {
        if (!$scope.rechargeThirdpayFlag) {
            $rootScope.tipService.setMessage('数据不能为空!', 'warning');
        } else {
            if ($scope.rechargeThirdpayFlag.split(':')[0] == 1) {  //1 第三方支付 微信
                $scope.chooseBank = false;
                $scope.bankListShow = true;
                home.bankList().then(function (res) {
                        $scope.bankListData = res.json;
                        console.log($scope.bankListData);
                    }, function (error) {
                        console.log(error);
                    });
            } else {
                $scope.custNo =$scope.merchantIdList[0].custNo;
            }
        }
    };
    $scope.rechargeToBankMerchantId = '';
    $scope.rechargeBankCode = '';
    $scope.rechargePayAmt = '';
    $scope.remove = function () {
        $scope.rechargeColumn=false;
        $scope.rechargeThirdpayFlag = '';
        $scope.rechargeBankId = '';
        $scope.rechargePayAmt = '';
    };
    $scope.recharge = function () {
        var userMessage = localStorageService.get('userInfo');
        var ExternalBankV = {
            userId: userMessage.userId,
            bankMerchantId: $scope.rechargeThirdpayFlag.split(':')[1],
            bankCode: $scope.rechargeBankId,
            payAmt: $scope.rechargePayAmt
        };
        home.unitRecharge(ExternalBankV)
            .then(function (res) {
                if (res.code == '000000') {
                    $scope.remove();
                    $rootScope.tipService.setMessage(res.message, 'warning');
                }else{
                    $rootScope.tipService.setMessage(res.message, 'warning');
                }
            }, function (error) {
                $rootScope.tipService.setMessage(error.message, 'warning');
            });
    };
    //提现
    $scope.withdrawShow = function () {
        $scope.adjunctColumn = false;
        $scope.withdrawColumn = true;
    };
    $scope.withdrawToBankMerchantId = '';
    $scope.getIoNumber = '';
    $scope.withdrawAccountPassword = '';
    $scope.comment = '';
    $scope.searchShow = function () {
        if ($scope.withdrawToBankMerchantId == '') {
            $rootScope.tipService.setMessage('请先选择银行通道!', 'warning');
        } else if ($scope.withdrawAccountPassword == '') {
            $rootScope.tipService.setMessage('密码不能为空!', 'warning');
        } else {
            var userMessage = localStorageService.get('userInfo');
            var json = {
                userId: userMessage.userId,
                accountPassword: $scope.withdrawAccountPassword,
                bankMerchantId: $scope.withdrawToBankMerchantId
            };
            home.searchMoney(json)
                .then(function (res) {
                    if(res.code=='000000'){
                        $rootScope.tipService.setMessage(res.message, 'warning');
                        var balanceNum = JSON.parse(res.content);
                        $scope.withdrawMoney = balanceNum.balance;
                    }else{
                        $rootScope.tipService.setMessage(res.message, 'warning');
                    }
                }, function (error) {
                    $rootScope.tipService.setMessage(error.message, 'warning');
                })
        }
    };
    $scope.removeWithdraw=function(){
        $scope.withdrawColumn = false;
        $scope.withdrawToBankMerchantId='';
        $scope.withdrawAccountPassword='';
        $scope.withdrawMoney='';
        $scope.getIoNumber='';
        $scope.comment='';
    };
    $scope.withdraw = function () {
        var ExternalBankV = {
            bankMerchantId: $scope.withdrawToBankMerchantId,
            accountId: $scope.signResult.accountSignupId,
            ioNumber: $scope.getIoNumber,
            accountPassword: $scope.withdrawAccountPassword,
            comment: $scope.comment
        };
        home.unitWithdrawal(ExternalBankV)
            .then(function (res) {
                if(res.code=='000000'){
                    $scope.removeWithdraw();
                    $rootScope.tipService.setMessage(res.message, 'warning');
                }else{
                    $rootScope.tipService.setMessage(res.message, 'warning');
                }
            }, function (error) {
                $rootScope.tipService.setMessage(error.message, 'warning');
            });
    };
    //明细
    $scope.tradeDetailFund = function () {
        $state.go('tabs.tradeAccountManage');
    };
    $scope.dependencyDetail = function () {
        $state.go('tabs.dependencyAccountManage');
    };
    // 交易附属账户提示
    $scope.tradeAccount = function () {
        home.unitSignTest().then(function (res) {
            if (res.content) {
                if (res.code == '000000') {
                    $scope.tradeColumn = true;
                } else {
                    $rootScope.tipService.setMessage(res.message, 'warning');
                    confirmService.set('确认提示', '该账户未签约请先签约!', function () {
                        confirmService.clear();
                    });
                }
            } else {
                confirmService.set('确认提示', '该账户未签约请先签约!', function () {
                    confirmService.clear();
                });
            }

        });
    };
    $scope.adjunctAccount = function () {
        home.unitSignTest().then(function (res) {
            if (res.content) {
                if (res.code == '000000') {
                    $scope.adjunctColumn = true;
                } else {
                    $rootScope.tipService.setMessage(res.message, 'warning');
                    confirmService.set('确认提示', '该账户未签约请先签约!', function () {
                        confirmService.clear();
                    });
                }
            } else {
                confirmService.set('确认提示', '该账户未签约请先签约!', function () {
                    confirmService.clear();
                });
            }

        });
    };
    $scope.goReadNotice = function () {
        $state.go('tabs.notice');
    };
    $scope.NoticeVal = function () {
        home.Notice(99999, 1)
            .then(function (res) {
                if (res.code == '000000' && res.content != '') {
                    var data = JSON.parse(res.content);
                    $scope.Noticetitle = data.content;
                    // console.log($scope.Noticetitles)
                    $scope.NoticeResult = JSON.parse(res.content).content;
                    console.log($scope.NoticeResult)
                    for (i = 0; i < $scope.NoticeResult.length; i++) {
                        $scope.Noticetitles = $scope.NoticeResult[i].title;
                    }
                }
            })
    }
    $scope.NoticeVal();
    $scope.QRcodeinfoNews=false;
    $scope.QRcodeInfo=function () {
        home.QRcodequery()
            .then(function (res) {
                console.log(res)
                if(res.code=='000000'){
                    $scope.dataVal = JSON.parse(res.content);
                    console.log($scope.dataVal)
                    if($scope.dataVal==''){
                        confirmService.set('确认提示', '当前我的二维码为空,<br>请先设置我的二维码!', function () {
                             confirmService.clear();
                         });
                    }else{
                    $scope.QRcodeinfoNews=true;
                    $scope.qrcodeBase=$scope.dataVal[0];
                    $scope.qrcodeBaseimg=$scope.dataVal[0].qrcodeBase64;
                    }
                }else{
                    $rootScope.tipService.setMessage(res.message, 'warning');
                }
            }, function (error) {
                $rootScope.tipService.setMessage(error.message, 'warning');
            });
    }
    $scope.myFunc=function () {
            $scope.qrcodeBaseimg= $scope.qrcodeBase.qrcodeBase64;
          };
})
    .factory('home', ['$http', 'localStorageService', 'myHttp', '$q', '$rootScope', function ($http, localStorageService, myHttp, $q, $rootScope) {
        return {
            //获取用户详细信息
            get: function () {
                var deferred = $q.defer();
                $http({
                    method: "POST",
                    url: $rootScope.baseUrl + "user/get/oneself",
                    headers: {
                        'Content-Type': 'application/json;charset=UTF-8'
                    }
                }).success(function (res) {
                    deferred.resolve(res);
                }).error(function (res) {
                    deferred.reject(res);
                });
                return deferred.promise;
            },
            //用户修改自己的登入信息
            saveSelfInfo: function (type, value, password) {
                var deferred = $q.defer();
                $http({
                    method: "POST",
                    url: $rootScope.baseUrl + "user/edit/key/info/oneself",
                    data: {
                        type: type,
                        value: value,
                        password: password
                    },
                    headers: {
                        'Content-Type': 'application/json;charset=UTF-8'
                    }
                }).success(function (res) {
                    deferred.resolve(res);
                }).error(function (res) {
                    deferred.reject(res);
                });
                return deferred.promise;
            },
            //交易账户之前选币种查询
            tradeSearch: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'account/query/user/aiaccountm/bypassword',
                    data: json,
                    headers: {
                        'Content-Type': 'application/json;charset=UTF-8'
                    }
                }).success(function (res) {
                    deferred.resolve(res);
                }).error(function (res) {
                    deferred.reject(res);
                });
                return deferred.promise;
            },
            //可入金额查询
            intoGoldSearch: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'exbank/get/user/signup/password',
                    data: json,
                    headers: {
                        'Content-Type': 'application/json;charset=UTF-8'
                    }
                }).success(function (res) {
                    deferred.resolve(res);
                }).error(function (res) {
                    deferred.reject(res);
                });
                return deferred.promise;
            },
            //签约与换绑
            unitSignTest: function () {
                var deferred = $q.defer();
                var data = new Object();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'exbank/get/user/signup',
                    data: data,
                    headers: {
                        'Content-Type': 'application/json;charset=UTF-8'
                    }
                }).success(function (res) {
                    deferred.resolve(res);
                }).error(function (res) {
                    deferred.reject(res);
                });
                return deferred.promise;
            },
            unitSign: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'exbank/backstage/sign/up',
                    data: json,
                    headers: {
                        'Content-Type': 'application/json;charset=UTF-8'
                    }
                }).success(function (res) {
                    deferred.resolve(res);
                }).error(function (res) {
                    deferred.reject(res);
                });
                return deferred.promise;
            },
            unitResign: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'exbank/backstage/update/sign/account',
                    data: json,
                    headers: {
                        'Content-Type': 'application/json;charset=UTF-8'
                    }
                }).success(function (res) {
                    deferred.resolve(res);
                }).error(function (res) {
                    deferred.reject(res);
                });
                return deferred.promise;
            },
            //出金与入金
            unitGold: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'account/backstage/money/out/app',
                    data: json,
                    headers: {
                        'Content-Type': 'application/json;charset=UTF-8'
                    }
                }).success(function (res) {
                    deferred.resolve(res);
                }).error(function (res) {
                    deferred.reject(res);
                });
                return deferred.promise;
            },
            unitIntoGold: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'exbank/backstage/money/in/app',
                    data: json,
                    headers: {
                        'Content-Type': 'application/json;charset=UTF-8'
                    }
                }).success(function (res) {
                    deferred.resolve(res);
                }).error(function (res) {
                    deferred.reject(res);
                });
                return deferred.promise;
            },
            //充值与提现
            unitRecharge: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'exbank/create/online/payid',
                    data: json,
                    headers: {
                        'Content-Type': 'application/json;charset=UTF-8'
                    }
                }).success(function (res) {
                    deferred.resolve(res);
                }).error(function (res) {
                    deferred.reject(res);
                });
                return deferred.promise;
            },
            unitWithdrawal: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'exbank/backstage/confirm/pay',
                    data: json,
                    headers: {
                        'Content-Type': 'application/json;charset=UTF-8'
                    }
                }).success(function (res) {
                    deferred.resolve(res);
                }).error(function (res) {
                    deferred.reject(res);
                });
                return deferred.promise;
            },
            //充值通道
            merchantId: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'exbank/get/user/signup/list',
                    data: json,
                    headers: {
                        'Content-Type': 'application/json;charset=UTF-8'
                    }
                }).success(function (res) {
                    deferred.resolve(res);
                }).error(function (res) {
                    deferred.reject(res);
                });
                return deferred.promise;
            },
            //银行通道
            bankChannel: function (json) {
                var deferred = $q.defer();
                myHttp.post("exbank/query/bankchannel/page", json)
                    .then(function (res) {
                        deferred.resolve(res);
                    }, function (res) {
                        deferred.reject(res);
                    });
                return deferred.promise;
            },
            //省份列表
            bankProvince: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'GET',
                    url: $rootScope.baseUrl + 'mss/query/all/province',
                    data: json,
                    headers: {
                        'Content-Type': 'application/json;charset=UTF-8'
                    }
                }).success(function (res) {
                    deferred.resolve(res);
                }).error(function (res) {
                    deferred.reject(res);
                });
                return deferred.promise;
            },
            bankCity: function (json) {
                var deferred = $q.defer();
                myHttp.post("mss/query/city/by/provinceId", json)
                    .then(function (res) {
                        deferred.resolve(res);
                    }, function (res) {
                        deferred.reject(res);
                    });
                return deferred.promise;
            },
            mainBank: function () {
                var data = new Object();
                var deferred = $q.defer();
                $http({
                    method: 'GET',
                    url: $rootScope.baseUrl + 'bank/area/mainbank',
                    data: data,
                    headers: {
                        'Content-Type': 'application/json;charset=UTF-8'
                    }
                }).success(function (res) {
                    deferred.resolve(res);
                }).error(function (res) {
                    deferred.reject(res);
                });
                return deferred.promise;
            },
            bankDetailList: function (json) {
                var deferred = $q.defer();
                myHttp.post("bank/area/bankname", json)
                    .then(function (res) {
                        deferred.resolve(res);
                    }, function (res) {
                        deferred.reject(res);
                    });
                return deferred.promise;
            },
            //查询提现余额
            unitBalance: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'exbank/get/user/signup/password',
                    data: json,
                    headers: {
                        'Content-Type': 'application/json;charset=UTF-8'
                    }
                }).success(function (res) {
                    deferred.resolve(res);
                }).error(function (res) {
                    deferred.reject(res);
                });
                return deferred.promise;
            },
            //首页公告
            Notice: function (showNum, nowPage) {
                var json = {
                    page: nowPage,
                    rows: showNum,
                    orders: 'asc',
                }

                var deferred = $q.defer();
                myHttp.post("notice/query/by/user", json)
                    .then(function (res) { // 调用承诺API获取数据 .resolve
                        deferred.resolve(res);
                    }, function (res) { // 处理错误 .reject
                        deferred.reject(res);
                    });
                return deferred.promise;
            },
            //查询余额
            searchMoney: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'exbank/get/user/signup/password',
                    data: json,
                    headers: {
                        'Content-Type': 'application/json;charset=UTF-8'
                    }
                }).success(function (res) {
                    deferred.resolve(res);
                }).error(function (res) {
                    deferred.reject(res);
                });
                return deferred.promise;
            },
            goldPwd: function (userId,oldPwd, newPwd) {
                var deferred = $q.defer();
                var url = $rootScope.baseUrl + "/account/update/account/password";
                var accountV = new Object();
                accountV.userId = userId;
                accountV.nowaccountPassword = oldPwd;
                accountV.newAccountPassword = newPwd;
                $http({
                    method: "POST",
                    url: url,
                    data: accountV
                }).success(function (res) {
                    deferred.resolve(res);
                }).error(function (res) {
                    deferred.reject(res);
                });
                return deferred.promise;
            },
            resetGoldPwd: function () {
                var deferred = $q.defer();
                var url = $rootScope.baseUrl + "account/reset/account/password";
                $http({
                    method: "POST",
                    url: url,
                    data: {AccountV: {}}
                }).success(function (res) {
                    deferred.resolve(res);
                }).error(function (res) {
                    deferred.reject(res);
                });
                return deferred.promise;
            },
             //获取币种
            obtainCurrencyType:function(){
                var deferred = $q.defer();
                var json={};
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'admin/config/currency/query/by/user',
                    data:json,
                    headers: {
                        'Content-Type': 'application/json;charset=UTF-8'
                    }
                }).success(function (res) {
                    deferred.resolve(res);
                }).error(function (res) {
                    deferred.reject(res);
                });
                return deferred.promise;
            },
            //固定银行列表
            bankList: function () {
                var data = new Object();
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: '../public/static/json/bankList.json',
                    data: data,
                    headers: {
                        'Content-Type': 'application/json;charset=UTF-8'
                    }
                }).success(function (res) {
                    deferred.resolve(res);
                }).error(function (res) {
                    deferred.reject(res);
                });
                return deferred.promise;
            },
            QRcodequery:function () {
                 var deferred = $q.defer();
                myHttp.post("customize/org/qrcode/query")
                    .then(function (res) { // 调用承诺API获取数据 .resolve
                        deferred.resolve(res);
                    }, function (res) { // 处理错误 .reject
                        deferred.reject(res);
                    });
                return deferred.promise;

            }
        }
    }]);