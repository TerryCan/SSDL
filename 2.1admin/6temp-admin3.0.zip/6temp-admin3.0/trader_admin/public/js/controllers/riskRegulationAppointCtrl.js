app.controller('riskRegulationAppointCtrl', ['$scope', '$rootScope', 'riskRegulationAppointAll', 'memberMangerCtrlSer', 'getFormularRiskType', 'getRiskCtrlConditionType', 'getRiskActionType', 'tipService', 'confirmService', '$timeout', 'localStorageService', 'administratorsManageCtrlSer', 'getPageNum', 'timestamp', 'dataSer', function ($scope, $rootScope, riskRegulationAppointAll, memberMangerCtrlSer, getFormularRiskType, getRiskCtrlConditionType, getRiskActionType, tipService, confirmService, $timeout, localStorageService, administratorsManageCtrlSer, getPageNum, timestamp, dataSer) {
    $scope.toggleTraderSearchState = false;
    $scope.Toggle = function () {
        $scope.toggleTraderSearchState = !$scope.toggleTraderSearchState;
        if ($scope.toggleTraderSearchState) {
            $('.search_column').css('height', 'auto');
        }
        else {
            $('.search_column').css('height', '36px');
        }
    };

    //风控规则查询
    $scope.riskRegulationSearch = function () {
        var json = {};
        riskRegulationAppointAll.riskSearch(json)
            .then(function (res) {
                if (res.retMsg.code == '000000') {
                    $scope.riskRegulationList = res.list;
                    // console.log($scope.riskRegulationList);
                }
            }, function (error) {
                console.log(error);
            })
    };
    $scope.riskRegulationSearch();
    // 机构管理查询
    $scope.ManageSearch = function () {
        $scope.showNum = 9999;
        $scope.currentPage = 1;
        memberMangerCtrlSer.search($scope.showNum, $scope.currentPage)
            .then(function (res) {
                if (res.code == '000000') {
                    $scope.searchManageResult = JSON.parse(res.content).content;
                    // console.log($scope.searchManageResult)
                }
            }, function (error) {
                console.log(error)
            });
    };
    $scope.ManageSearch();

    //机构列表
    $scope.addOrgValOne = ''; //显示值
    $scope.addOrgChooseValOne = ''; //选择值
    dataSer.organizeQuerySer().then(function (res) {
            console.log(res);
            $scope.orgList = res;
        });
    $scope.addOrgValFTCOne = function (orgId, text, orgCode) {
        $scope.addOrgChooseValOne = orgId;
        $scope.addOrgValOne = text;
        $scope.orgCode = orgCode;
    };
    $scope.clearOrg = function () {
        console.log($scope.addOrgValOne);
        $scope.addOrgValOne = '';
    };
    $scope.hideOrgListOne = function () {
        $scope.isShowOrgList = false;
        $(".OrgList").blur();
    };
    //公式类型
    $scope.FormularRiskType = getFormularRiskType;
    $scope.getFormular = function (parameter) {
        for (i = 0; i < $scope.FormularRiskType.length; i++) {
            if (parameter == $scope.FormularRiskType[i].id) {
                return $scope.FormularRiskType[i].name;
            }
        }
    };
    //公式条件
    $scope.RiskCtrlConditionType = getRiskCtrlConditionType;
    $scope.getCondition = function (Condition, Para1, Para2) {
        switch (Condition) {
            case 0:
                return 'x>' + Para1;
                break;
            case 1:
                return 'x>=' + Para1;
                break;
            case 2:
                return 'x<' + Para1;
                break;
            case 3:
                return 'x<=' + Para1;
                break;
            case 4:
                return Para1 + '<x<' + Para2;
                break;
            default:
                return Para1 + '<=x<=' + Para2;
        }
    };
    //动作
    $scope.RiskActionType = getRiskActionType;

    //风控规则指派查询
    $scope.riskRegulationAppointSearch = function () {
        $scope.toggleTraderSearchState = false;
        $('.search_column').css('height', '36px');
        var json = {
            qryConditionList: [{
                field: "OrgCode",
                value: ($scope.upOrgCode)?$scope.upOrgCode:''
            }, {
                field: "Operator",
                value: ($scope.Operator)?$scope.Operator:''
            }, {
                field: "RuleKey",
                value: ($scope.RuleKey)?$scope.RuleKey:''
            }]
        };
        riskRegulationAppointAll.riskFilterSearch(json)
            .then(function (res) {
                if (res.retMsg.code == '000000') {
                    $scope.riskAppointList = res.list;
                    var tempData = portData($scope.riskAppointList);
                    if(tempData){
                        var source = {
                            localdata: tempData,
                            datatype: "array",
                            datafields: [
                                {name: 'Key', type: 'string'},
                                {name: 'orgName', type: 'string'},
                                {name: 'OrgCode', type: 'string'},
                                {name: 'RuleKey', type: 'string'},

                                {name: 'orgNum', type: 'string'},
                                {name: 'risk_name', type: 'string'},
                                {name: 'Formular', type: 'string'},
                                {name: 'Condition', type: 'string'},

                                {name: 'Para1', type: 'string'},
                                {name: 'Para2', type: 'string'},
                                {name: 'Action', type: 'string'},
                                {name: 'StartTime', type: 'string'},
                                {name: 'EndTime', type: 'string'}
                            ]
                        };
                        var dataAdapter = new $.jqx.dataAdapter(source);
                        $("#entrustDetailGrid").jqxGrid(
                            {
                                width: 100 + '%',
                                height: 80 + '%',
                                theme: 'metrodark',
                                source: dataAdapter,//数据源
                                pageable: true,//是否分页
                                pagesize:10,
                                // sortable: true,//是否排序
                                columnsresize: true,//列间距是否可调整
                                clipboard: false,//屏蔽jqxGrid的复制功能
                                pagesizeoptions: ['10', '30', '100', '200'],
                                columns: [
                                    {
                                        text: '机构编号',
                                        datafield: 'orgNum',
                                        width: 14 + '%',
                                        align: 'center',
                                        cellsalign: 'center'
                                    },
                                    {
                                        text: '风控规则',
                                        datafield: 'risk_name',
                                        width: 14 + '%',
                                        align: 'center',
                                        cellsalign: 'center'
                                    },
                                    {
                                        text: '公式类型',
                                        datafield: 'Formular',
                                        width: 14 + '%',
                                        align: 'center',
                                        cellsalign: 'center',
                                        cellsrenderer: function (row, columnfield, value, defaulthtml, columnproperties) {
                                            if ($scope.FormularRiskType) {
                                                for (var i = 0; i < $scope.FormularRiskType.length; i++) {
                                                    if (value == $scope.FormularRiskType[i].id) {
                                                        return $scope.FormularRiskType[i].name;
                                                    }
                                                }
                                            }
                                        }
                                    },
                                    {
                                        text: '公式条件',
                                        datafield: 'Condition',
                                        width: 14 + '%',
                                        align: 'center',
                                        cellsalign: 'center',
                                        cellsrenderer: function (row, columnfield, value, defaulthtml, columnproperties) {
                                            if (tempData) {
                                                if (value == 0) {
                                                    return 'x>' + tempData[row].Para1;
                                                }
                                                if (value == 1) {
                                                    return 'x>=' + tempData[row].Para1;
                                                }
                                                if (value == 2) {
                                                    return 'x<' + tempData[row].Para1;
                                                }
                                                if (value == 3) {
                                                    return 'x<=' + tempData[row].Para1;
                                                }
                                                if (value == 4) {
                                                    return tempData[row].Para1 + '<x<' + tempData[row].Para2;
                                                }
                                                if (value == 5) {
                                                    return tempData[row].Para1 + '<=x<=' + tempData[row].Para2;
                                                }
                                            }
                                        }
                                    },
                                    {
                                        text: '动作',
                                        datafield: 'Action',
                                        width: 14 + '%',
                                        minwidth: 14 + '%',
                                        align: 'center',
                                        cellsalign: 'center',
                                        cellsrenderer: function (row, columnfield, value, defaulthtml, columnproperties) {
                                            if (value == 0) {
                                                return '无';
                                            }
                                            if (value == 1) {
                                                return '禁止开仓';
                                            }
                                            if (value == 2) {
                                                return '禁止平仓';
                                            }
                                            if (value == 3) {
                                                return '禁止开仓|禁止平仓';
                                            }
                                            if (value == 4) {
                                                return '告警';
                                            }
                                            if (value == 5) {
                                                return '禁止开仓|告警';
                                            }
                                            if (value == 6) {
                                                return '禁止平仓|告警';
                                            }
                                            if (value == 7) {
                                                return '禁止开仓|禁止平仓|告警';
                                            }
                                            if (value == 8) {
                                                return '强制平仓';
                                            }
                                            if (value == 9) {
                                                return '禁止开仓|强制平仓';
                                            }
                                            if (value == 10) {
                                                return '禁止平仓|强制平仓';
                                            }
                                            if (value == 11) {
                                                return '禁止开仓|禁止平仓|强制平仓';
                                            }
                                            if (value == 12) {
                                                return '告警|强制平仓';
                                            }
                                            if (value == 13) {
                                                return '禁止开仓|告警|强制平仓';
                                            }
                                            if (value == 14) {
                                                return '禁止平仓|告警|强制平仓';
                                            }
                                            if (value == 15) {
                                                return '禁止开仓|禁止平仓|告警|强制平仓';
                                            }
                                        }
                                    },
                                    {
                                        text: '开始时间',
                                        datafield: 'StartTime',
                                        width: 15 + '%',
                                        minwidth: 15 + '%',
                                        align: 'center',
                                        cellsalign: 'center',
                                        cellsrenderer: function (row, columnfield, value, defaulthtml, columnproperties) {
                                            if (value) {
                                                return timestamp.daySecondsToDate(value);
                                            }
                                        }
                                    },
                                    {
                                        text: '结束时间',
                                        datafield: 'EndTime',
                                        width: 15 + '%',
                                        minwidth: 15 + '%',
                                        align: 'center',
                                        cellsalign: 'center',
                                        cellsrenderer: function (row, columnfield, value, defaulthtml, columnproperties) {
                                            if (value) {
                                                return timestamp.daySecondsToDate(value);
                                            }
                                        }
                                    }
                                ]
                            });
                        //分页
                        $("#entrustDetailGrid").on("pagechanged", function (event) {
                            console.log(event)
                        });
                    }
                } else {
                    $rootScope.tipService.setMessage(res.retMsg.message, 'warning');
                }
            }, function (error) {
                $rootScope.tipService.setMessage(error.message, 'warning');
            })
    };

    var portData = function (parameter) {
        if ($scope.riskRegulationList && $scope.searchManageResult) {
            var reportArray = [];
            for (var i = 0, r = parameter.length; i < r; i++) {
                var tmpArr = {
                    orgNum: '',
                    orgName: '',
                    OrgCode: '',
                    EndTime: '',
                    StartTime: '',
                    RuleKey: '',
                    Formular: '',
                    Condition: '',
                    Action: '',
                    Operator: '',
                    Para1: '',
                    Para2: '',
                    risk_name: '',
                    Key: ''
                };
                tmpArr.EndTime = parameter[i].EndTime;
                tmpArr.StartTime = parameter[i].StartTime;
                tmpArr.RuleKey = parameter[i].RuleKey;
                tmpArr.Operator = parameter[i].Operator;
                tmpArr.Key = parameter[i].Key;
                tmpArr.OrgCode = parameter[i].OrgCode;
                for (var k = 0, s = $scope.searchManageResult.length; k < s; k++) {
                    if ($scope.searchManageResult[k].orgCode == parameter[i].OrgCode) {
                        tmpArr.orgNum = $scope.searchManageResult[k].orgNum;
                        tmpArr.orgName = $scope.searchManageResult[k].orgName;
                    }
                }
                for (var j = 0; j < $scope.riskRegulationList.length; j++) {
                    if ($scope.riskRegulationList[j].Key == parameter[i].RuleKey) {
                        tmpArr.Formular = $scope.riskRegulationList[j].Formular;
                        tmpArr.Condition = $scope.riskRegulationList[j].Condition;
                        tmpArr.Para1 = $scope.riskRegulationList[j].Para1;
                        tmpArr.Para2 = $scope.riskRegulationList[j].Para2;
                        tmpArr.Action = $scope.riskRegulationList[j].Action;
                        tmpArr.risk_name = $scope.riskRegulationList[j].Name;
                    }
                }
                reportArray.push(tmpArr);
            }
            return reportArray;
        } else {
            $rootScope.tipService.setMessage('请求数据为空!', 'warning');
        }
    };

    //风控规则新增
    $scope.Key = '';
    $scope.userId = '';
    $scope.riskRule = '';
    $scope.createTimeStart = '';
    $scope.createTimeEnd = '';
    $scope.addEditText = '';
    $scope.newUserShow = false;
    $scope.addNewUser = function () {
        $scope.newUserShow = true;
        $scope.addEditText = '新增';
    };
    $scope.riskRegulationFunc = function () {
        // 风控规则
        var getRiskFormular = function (parameter) {
            for (i = 0; i < $scope.FormularRiskType.length; i++) {
                if (parameter == $scope.FormularRiskType[i].id) {
                    return $scope.FormularRiskType[i].name;
                }
            }
        }
        for (i = 0, r = $scope.riskRegulationList.length; i < r; i++) {
            if ($scope.riskRule == $scope.riskRegulationList[i].Key) {
                var Para11 = $scope.riskRegulationList[i].Para1;
                var Para22 = $scope.riskRegulationList[i].Para2;
                var Condition11 = $scope.riskRegulationList[i].Condition;
                $scope.getCondition = function (Condition, Para1, Para2) {
                    switch (Condition) {
                        case 0:
                            return 'x>' + Para1;
                            break;
                        case 1:
                            return 'x>=' + Para1;
                            break;
                        case 2:
                            return 'x<' + Para1;
                            break;
                        case 3:
                            return 'x<=' + Para1;
                            break;
                        case 4:
                            return Para1 + '<x<' + Para2;
                            break;
                        default:
                            return Para1 + '<=x<=' + Para2;
                    }
                }
                $scope.riskFormulary = getRiskFormular($scope.riskRegulationList[i].Formular);
                $scope.riskCondition = $scope.getCondition(Condition11, Para11, Para22);
                return;
            }
        }
    };


    //风控规则修改
    $('#entrustDetailGrid').on('rowselect', function (event) {
        $scope.chooseItemTab1 = event.args.row.Key;
        $scope.chooseUserData = {
            Key: event.args.row.Key,
            orgName: event.args.row.orgName,
            orgNum: event.args.row.orgNum,
            OrgCode: event.args.row.OrgCode,
            StartTime: event.args.row.StartTime,
            EndTime: event.args.row.EndTime,
            RuleKey: event.args.row.RuleKey,
            Formular: event.args.row.Formular,
            Condition: event.args.row.Condition,
            Para1: event.args.row.Para1,
            Para2: event.args.row.Para2
        };
    });
    $scope.remove = function () {
        $scope.newUserShow = false;
        $scope.createTimeStart = '';
        $scope.createTimeEnd = '';
        $scope.riskRule = '';
        $scope.riskFormulary = '';
        $scope.riskCondition = '';
        $scope.addOrgValOne = '';
    };
    $scope.editUser = function () {
        if (!$scope.chooseItemTab1) {
            $rootScope.tipService.setMessage('请先选择用户', 'warning');
        } else {
            $scope.addEditText = '修改';
            $scope.newUserShow = true;
            $scope.addOrgValOne = $scope.chooseUserData.orgName + '(' + $scope.chooseUserData.orgNum + ')';
            $scope.riskRule = $scope.chooseUserData.RuleKey;
            $scope.createTimeStart = timestamp.daySecondsToDate($scope.chooseUserData.StartTime);
            $scope.createTimeEnd = timestamp.daySecondsToDate($scope.chooseUserData.EndTime);
            $scope.riskFormulary = $scope.getFormular($scope.chooseUserData.Formular);
            $scope.riskCondition = $scope.getCondition($scope.chooseUserData.Condition, $scope.chooseUserData.Para1, $scope.chooseUserData.Para2);
        }
    };
    $scope.addEditUserSubmit = function () {
        if ($scope.addEditText == '新增') {
            console.log($scope.orgCode);
            var riskctrlRuleAssign = {
                Key: $scope.Key,
                UserId: $scope.userId,
                OrgCode: $scope.orgCode,
                RuleKey: $scope.riskRule,
                StartTime: ($scope.createTimeStart) ? timestamp.DateToSeconds($scope.createTimeStart) : '',
                EndTime: ($scope.createTimeEnd) ? timestamp.DateToSeconds($scope.createTimeEnd) : '',
                Operator: localStorageService.get('selfInfo').userId
            };
            var json = {
                riskctrlRuleAssign: riskctrlRuleAssign
            };
            riskRegulationAppointAll.riskAdd(json)
                .then(function (res) {
                    if (res.code == '000000') {
                        $scope.remove();
                        $rootScope.tipService.setMessage(res.message, 'warning');
                        $scope.copyDataArray = '';
                        $scope.riskRegulationAppointSearch();
                    } else {
                        $scope.remove();
                        $rootScope.tipService.setMessage(res.message, 'warning');
                        $scope.riskRegulationAppointSearch();
                    }
                }, function (error) {
                    $rootScope.tipService.setMessage(error.message, 'warning');
                });
        } else if ($scope.addEditText == '修改') {
            var riskctrlRuleAssign = {
                Key: $scope.chooseItemTab1,
                OrgCode: ($scope.orgCode == undefined) ? $scope.chooseUserData.OrgCode : $scope.orgCode,
                RuleKey: $scope.riskRule,
                StartTime: ($scope.createTimeStart) ? timestamp.DateToSeconds($scope.createTimeStart) : '',
                EndTime: ($scope.createTimeEnd) ? timestamp.DateToSeconds($scope.createTimeEnd) : '',
                Operator: localStorageService.get('selfInfo').userId
            };
            var json = {
                riskctrlRuleAssign: riskctrlRuleAssign
            };
            riskRegulationAppointAll.riskModify(json)
                .then(function (res) {
                    if (res.code == '000000') {
                        $scope.remove();
                        $rootScope.tipService.setMessage(res.message, 'warning');
                        $scope.riskRegulationAppointSearch();
                    } else {
                        $scope.remove();
                        $rootScope.tipService.setMessage(res.message, 'warning');
                        $scope.riskRegulationAppointSearch();
                    }
                }, function (error) {
                    $rootScope.tipService.setMessage(error.message, 'warning');
                });
        }
    };

    //注销
    $scope.cancel = function () {
        if (!$scope.chooseItemTab1) {
            $rootScope.tipService.setMessage('请先选择用户', 'warning');
        } else {
            confirmService.set('确认提示', '确认要删除?', function () {
                var json = {
                    key: $scope.chooseItemTab1
                };
                riskRegulationAppointAll.cancel(json)
                    .then(function (res) {
                        if (res.code == '000000') {
                            $rootScope.tipService.setMessage(res.message, 'warning');
                            $scope.riskRegulationAppointSearch();
                        } else {
                            $rootScope.tipService.setMessage(res.message, 'warning');
                            $scope.riskRegulationAppointSearch();
                        }
                    }, function (error) {
                        $rootScope.tipService.setMessage(error.message, 'warning');
                    });
                confirmService.clear();
            });
        }
    };
}])
// server
    .factory('riskRegulationAppointAll', ['$q', '$http', '$rootScope', function ($q, $http, $rootScope) {
        return {
            riskFilterSearch: function (json) {
                var deferred = $q.defer();
                $http({
                    method: "POST",
                    url: $rootScope.baseUrl + "c/riskctrl/ruleAssign/query/filter",
                    data: json,
                    headers: {
                        'Content-Type': 'application/json;charset=UTF-8'
                    }
                }).success(function (res) {
                    deferred.resolve(res);
                }).error(function (res) {
                    deferred.reject(res);
                });
                return deferred.promise;
            },
            riskAdd: function (json) {
                var deferred = $q.defer();
                $http({
                    method: "POST",
                    url: $rootScope.baseUrl + "c/riskctrl/ruleAssign/insert",
                    data: json,
                    headers: {
                        'Content-Type': 'application/json;charset=UTF-8'
                    }
                }).success(function (res) {
                    deferred.resolve(res);
                }).error(function (res) {
                    deferred.reject(res);
                });
                return deferred.promise;
            },
            riskModify: function (json) {
                var deferred = $q.defer();
                $http({
                    method: "POST",
                    url: $rootScope.baseUrl + "c/riskctrl/ruleAssign/modify",
                    data: json,
                    headers: {
                        'Content-Type': 'application/json;charset=UTF-8'
                    }
                }).success(function (res) {
                    deferred.resolve(res);
                }).error(function (res) {
                    deferred.reject(res);
                });
                return deferred.promise;
            },
            cancel: function (json) {
                var deferred = $q.defer();
                $http({
                    method: "POST",
                    url: $rootScope.baseUrl + "c/riskctrl/ruleAssign/delete",
                    data: json,
                    headers: {
                        'Content-Type': 'application/json;charset=UTF-8'
                    }
                }).success(function (res) {
                    deferred.resolve(res);
                }).error(function (res) {
                    deferred.reject(res);
                });
                return deferred.promise;
            },
            riskSearch: function (data) {
                var deferred = $q.defer();
                $http({
                    method: "POST",
                    url: $rootScope.baseUrl + "c/riskctrl/rule/query/filter",
                    data: data,
                    headers: {
                        'Content-Type': 'application/json;charset=UTF-8'
                    }
                }).success(function (res) {
                    deferred.resolve(res);
                }).error(function (res) {
                    deferred.reject(res);
                });
                return deferred.promise;
            },
        }
    }])