app.controller('CommissionallocationEditCtrl', ['$rootScope', '$scope', 'CommissionallocationEditCtrlSer', 'getPageNum', 'dataSer', '$state', 'localStorageService', 'commissionSplitCtrlSer', 'marketMappingCtrlSer', function($rootScope, $scope, CommissionallocationEditCtrlSer, getPageNum, dataSer, $state, localStorageService, commissionSplitCtrlSer, marketMappingCtrlSer) {
		$scope.goBack = function() {
			$state.go('tabs.commissionSplit');
		}
		dataSer.organizeQuerySer()
			.then(function(res) {
				$scope.orgList = res;
				console.log($scope.orgList);
			});
			$scope.getOrgValNum=function(allotToOrgId){
				if($scope.orgList){
				for (var i = 0, r = $scope.orgList.length; i < r; i++) {
					if (allotToOrgId == $scope.orgList[i].orgId) {
						return $scope.orgList[i].text;
					}
				}
				}
			}

		$scope.addOrgValFTC = function(data) {
			//console.log(data);
			$scope.allotOrgId = data.orgId;
			$scope.superorgCode = data.orgCode;
			$scope.addOrgVal = data.text;
			CommissionallocationEditCtrlSer.AllNOTLIKEQuerySer($scope.superorgCode)
				.then(function(res) {
					$scope.allnotlickList = res;
					//console.log($scope.allnotlickList);
				})

		}
		$scope.addOrgValcler = function() {
			$scope.addOrgVal = "";
			$scope.allnotOrgVal = "";
			$scope.allnotlickList = "";
			$scope.singleRuleVs = [];
		}
		$scope.AllNOTLIKE = function(data) {
			console.log(data);
			$scope.allotToOrgId = data.orgId;
			$scope.allnotorgCode = data.orgCode;
			$scope.allnotOrgVal = data.text;
		}
		$scope.allotTypeData = [{
			name: '仓息',
			val: '6'
		}, {
			name: '手续费',
			val: '7'
		}];
		$scope.allotTypeText = function(val) {
				for (var i = 0, r = $scope.allotTypeData.length; i < r; i++) {
					if (val == $scope.allotTypeData[i].val) {
						return $scope.allotTypeData[i].name;
					}
				}
			}
		$scope.allotText = function(allotOrgId) {
			//console.log(allotOrgId)
			for (var i = 0, r = $scope.allnotlickList.length; i < r; i++) {
				//console.log($scope.allnotlickList[i])
				if (allotOrgId == $scope.allnotlickList[i].orgId) {
					return $scope.allnotlickList[i].orgName;
				}
			}
		}
			//产品ID
		marketMappingCtrlSer.prosearch(1, 99999, '')
			.then(function(res) {
				console.log(res)
				var prolistdt = JSON.parse(res.content);
				$scope.prolist = [];
				for (var i = 0, r = prolistdt.length; i < r; i++) {
					if (prolistdt[i].state == 1 || prolistdt[i].state == 8000) {
						$scope.prolist.push(prolistdt[i]);
					}
				}
				console.log($scope.prolist)
			});
		$scope.PtText = function(productId) {
			if ($scope.prolist) {
				for (var i = 0, r = $scope.prolist.length; i < r; i++) {
					if ($scope.prolist[i].productId == productId) {
						return $scope.prolist[i].productName;
					}
				}
			}
		}

		//获取产品信息
		var allotRuleId = localStorageService.get('CMChooseProId');
		commissionSplitCtrlSer.getProInfo(allotRuleId)
			.then(function(res) {
				console.log(res)
				if (res.data.code == '000000') {
					var data = JSON.parse(res.data.content);
					console.log(data);
					$scope.allotOrgCode = data.allotOrgCode;
					$scope.allotOrgId = data.allotOrgId;
					$scope.allotOrgName = data.allotOrgName;
					$scope.allotRuleId = data.allotRuleId;
					$scope.allotToOrgCode = data.allotToOrgCode;
					$scope.allotToOrgId = data.allotToOrgId;
					$scope.allotToOrgName = data.allotToOrgName;
					$scope.allotType = data.allotType;
					$scope.allotVooType= data.allotValueType;
						if($scope.allotVooType==1){
							$scope.valtype=false;
							$scope.channelNum = data.channelNum;
							$scope.nextNum = data.nextNum;
							$scope.selfNum = data.selfNum;
							$scope.taxesNum = data.taxesNum;
						}else if($scope.allotVooType==2){
							$scope.valtype=true;
							$scope.channelNum = data.channelNum;
							$scope.nextNum = data.nextNum;
							$scope.selfNum = data.selfNum;
							$scope.taxesNum = data.taxesNum;
						}else{
							$scope.valtype=false;
						}
					$scope.productName= data.productName;
					$scope.productId = data.productId;
					$scope.productName = data.productName;
				}
			});
					//匹配机构代码
		var json = {
			page: 1,
			rows: 9999,
			search_A_EQ_state: 1
		};
		dataSer.getOrganize(json).then(function(res) {
			if (res.code == '000000') {
				$scope.equalOrgCode = JSON.parse(res.content).content;
				console.log($scope.equalOrgCode);
				for (var i = 0; i < $scope.equalOrgCode.length; i++) {
				if($scope.allotOrgId == $scope.equalOrgCode[i].orgId){
						$scope.addOrgVal = $scope.equalOrgCode[i].orgName + '(' + $scope.equalOrgCode[i].orgNum + ')';
						console.log($scope.addOrgVal)
					}
				if($scope.allotToOrgId== $scope.equalOrgCode[i].orgId){
						$scope.allnotOrgVal = $scope.equalOrgCode[i].orgName + '(' + $scope.equalOrgCode[i].orgNum + ')';
						console.log($scope.allnotOrgVal)
				}
				}
			} else {
				console.log(res);
			}
		});
		$scope.allotValData = [{
			name: '百分比',
			val: '1'
		}, {
			name: '固定金额',
			val: '2'
		}];

		//$scope.allotVooType=true;
		$scope.changeVooType=function(){
			if($scope.allotVooType==1){
				$scope.valtype=false;
				$scope.nextNum = "";
				$scope.taxesNum = "";
				$scope.channelNum = "";
				$scope.selfNum ="";
			}else if($scope.allotVooType==2){
				$scope.valtype=true;
				$scope.nextNum = "";
				$scope.taxesNum = "";
				$scope.channelNum = "";
				$scope.selfNum ="";
			}else{
				$scope.valtype=false;
			}
		}


		$scope.singleRuleVs = [];
		//保存数据
		$scope.addsaveInfo = function() {
			console.log($scope.allotVooType)
				if($scope.allotVooType==1){
				$scope.allotType = parseFloat($scope.allotType);
				$scope.allotVooType= parseInt($scope.allotVooType);
				$scope.nextNum = parseFloat($scope.nextNum);
				$scope.taxesNum = parseFloat($scope.taxesNum);
				$scope.channelNum = parseFloat($scope.channelNum);
				$scope.selfNum = 100 - $scope.nextNum - $scope.taxesNum - $scope.channelNum;
				var allNum = $scope.nextNum + $scope.taxesNum + $scope.channelNum;
				console.log(allNum, typeof(allNum))
				if (allNum > 100) {
					console.log('y')
					$rootScope.tipService.setMessage('四项百分比之和不能超过100', 'warning');
				} else {
					console.log('x')
					var SingleRuleData = {
						"productId": $scope.productId,
						"allotType": $scope.allotType,
						"allotToOrgCode": $scope.allotToOrgCode,
						"allotToOrgId": $scope.allotToOrgId,
						"allotValueType": $scope.allotVooType,
						"selfNum": $scope.selfNum,
						"nextNum": $scope.nextNum,
						"taxesNum": $scope.taxesNum,
						"channelNum": $scope.channelNum
					}
					$scope.singleRuleVs.push(SingleRuleData);
					console.log(SingleRuleData)
					CommissionallocationEditCtrlSer.save($scope.allotRuleId,$scope.allotOrgId, $scope.allotOrgCode,$scope.singleRuleVs)
						.then(function(res) {
							console.log(res)
							if (res.data.code == '000000') {
								$rootScope.tipService.setMessage(res.data.message, 'warning');
								$state.go('tabs.commissionSplit');
							} else {
								$rootScope.tipService.setMessage(res.data.message, 'warning');
							}
						});
				}
			}else if($scope.allotVooType==2){
				if ($scope.selfNum == undefined || $scope.selfNum === '') {
				$rootScope.tipService.setMessage('请填写本级百分比', 'warning');
				}else{
				$scope.allotType = parseFloat($scope.allotType);
				$scope.allotVooType= parseInt($scope.allotVooType);
				$scope.nextNum = parseFloat($scope.nextNum);
				$scope.taxesNum = parseFloat($scope.taxesNum);
				$scope.channelNum = parseFloat($scope.channelNum);
				$scope.selfNum = parseFloat($scope.selfNum);
					console.log('x')
					var SingleRuleData = {
						"productId": $scope.productId,
						"allotType": $scope.allotType,
						"allotToOrgCode": $scope.allotToOrgCode,
						"allotToOrgId": $scope.allotToOrgId,
						"allotValueType": $scope.allotVooType,
						"selfNum": $scope.selfNum,
						"nextNum": $scope.nextNum,
						"taxesNum": $scope.taxesNum,
						"channelNum": $scope.channelNum
					}
					$scope.singleRuleVs.push(SingleRuleData);
					console.log(SingleRuleData)
					CommissionallocationEditCtrlSer.save($scope.allotRuleId,$scope.allotOrgId, $scope.allotOrgCode,$scope.singleRuleVs)
						.then(function(res) {
							console.log(res)
							if (res.data.code == '000000') {
								$rootScope.tipService.setMessage(res.data.message, 'warning');
								$state.go('tabs.commissionSplit');
							} else {
								$rootScope.tipService.setMessage(res.data.message, 'warning');
							}
						});
				}
			}
			//}
		}
		function changeV(val){
				val = val.replace(/[^\d.]/g,"");  //清除“数字”和“.”以外的字符
				val = val.replace(/^\./g,"");  //验证第一个字符是数字而不是.
				val = val.replace(/\.{2,}/g,"."); //只保留第一个. 清除多余的
				val = val.replace(".","$#$").replace(/\./g,"").replace("$#$",".");
				val = val.replace(/^(\-)*(\d+)\.(\d\d).*$/,'$1$2.$3');//只能输入两个小数
				console.log(val)
				return val;
			};
			$scope.clearNoNum = function(obj){
				$scope.nextNum = changeV($scope.nextNum);
				$scope.taxesNum = changeV($scope.taxesNum);
				$scope.channelNum = changeV($scope.channelNum);
			};
	}])
	.factory('CommissionallocationEditCtrlSer', ['$http', 'localStorageService', 'myHttp', '$q', '$rootScope', function($http, localStorageService, myHttp, $q, $rootScope) {
		return {
			AllNOTLIKEQuerySer: function(superorgCode) { //所属下级机构
				var data = {
					orders: 'asc',
					search_LLIKE_orgCode: superorgCode + '-',
					search_NOTLLIKE_orgCode: superorgCode + '-%-'
				};
				var deferred = $q.defer();
				myHttp.post("organize/query/as/list", data)
					.then(function(res) { // 调用承诺API获取数据 .resolve
						//console.log(res)
						var resArr = [];
						if (res.code === "000000") {
							var results = JSON.parse(res.content);
							console.log(results)
							var tmpArr = [];
							for (var i = 0, r = results.length; i < r; i++) {
								if (results[i].state == 1) {
									var tmp = {};
									tmp.orgCode = results[i].orgCode;
									tmp.orgId = results[i].orgId;
									tmp.orgName = results[i].orgName;
									tmp.text = results[i].orgName + ' (' + results[i].orgNum + ')';
									tmpArr.push(tmp);
								}
							}
							deferred.resolve(tmpArr);
						} else {
							deferred.reject(res);
						}
					}, function(res) { // 处理错误 .reject
						deferred.reject(res);
					});
				return deferred.promise;
			},
			save: function(allotRuleId,allotOrgId, allotOrgCode,singleRuleVs) {
				var json = {
					"allotRule": {
						"allotRuleId": allotRuleId,
						"allotOrgId": allotOrgId,
						"allotOrgCode": allotOrgCode,
						"singleRuleVs": singleRuleVs
					}
				}
				var deferred = $q.defer();
				$http({
					method: 'POST',
					url: $rootScope.baseUrl + 'config/allotrule/save',
					data: json
				}).then(function successCallback(response) {
					deferred.resolve(response);
				}, function errorCallback(response) {
					deferred.reject(response);
				});
				return deferred.promise;
			}
		}

	}])