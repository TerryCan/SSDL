app.controller('PreviousDealCtrl', ['$scope', '$rootScope', 'PreviousDealData', 'getOffset', 'timestamp', '$timeout', 'getPageNum', function ($scope, $rootScope, PreviousDealData, getOffset, timestamp, $timeout, getPageNum) {
    $scope.toggleTraderSearchState=false;
    $scope.Toggle = function(){
        $scope.toggleTraderSearchState = !$scope.toggleTraderSearchState;
        if($scope.toggleTraderSearchState){
           $('.search_column').css('height','auto');
        }
        else{
           $('.search_column').css('height','36px');
        }
    };
    //时间转换
    $scope.changeStampText = function (value) {
        return timestamp.timestampCoverHms(value * 1000, 'all');
    };
    //开平文字转换
    $scope.getOffset = getOffset;
    $scope.changeOffsetText = function (value) {
        for (var i = 0, r = $scope.getOffset.length; i < r; i++) {
            if (value == $scope.getOffset[i].id) {
                return $scope.getOffset[i].name;
            }
        }
    };
    //查询
    $scope.OrderId = '';
    $scope.Account = '';
    $scope.Direct = '';
    $scope.SystemNo = '';
    $scope.createTimeStart=timestamp.defaultDate('start');
    $scope.createTimeEnd='';
    // $scope.createTimeEnd=timestamp.defaultDate();
    $scope.search = function () {
        $scope.toggleTraderSearchState=false;
        $('.search_column').css('height','36px');
        PreviousDealData.search($scope.OrderId, $scope.Account, $scope.createTimeStart, $scope.createTimeEnd, $scope.directiveProductId, $scope.Direct, $scope.SystemNo)
            .then(function (res) {
                console.log(res);
                if (res.data.retMsg.code == '000000') {
                    $scope.searchResult = res.data.list;
                    pageJump($scope.searchResult);
                } else {
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                }
            }, function (error) {
                $rootScope.tipService.setMessage(error.data.message, 'warning');
            });
    };
    // 分页
    var pageJump = function (tmpArrList) {
        $timeout(function () {
            if (tmpArrList != undefined) {
                $scope.currentPage = 1;//当前页数
                $scope.dataNum = tmpArrList.length;
                $scope.showDataChoose = getPageNum.pageNum();//获取分页
                $scope.showNum = $scope.showDataChoose[0];//初始显示刷具条数
                $scope.showPage = false;
                $timeout(function () {
                    $scope.showPage = true;
                    $scope.copyDataArray = tmpArrList.slice(0, 14); //初始15条数据
                }, 10)
                $scope.dataPage = Math.ceil($scope.dataNum / $scope.showNum.showNum);

                //上下页
                $scope.pageSlect = function (type) {
                    if (type == 'prev') {
                        if ($scope.currentPage != 1) {
                            $scope.currentPage--;
                            $scope.turnPage();
                        } else {
                            $scope.copyDataArray = tmpArrList.slice(0, 14); //初始15条数据
                        }
                    }
                    else {
                        if ($scope.currentPage < $scope.dataPage) {
                            $scope.currentPage++;
                            $scope.turnPage();
                        }
                    }
                }
                //每页数据量
                $scope.baseDataArray = [];
                $scope.copyDataArray = [];
                $scope.pageSelect = function (params) {
                    $scope.showNum.showNum = params.showNum;
                    $scope.copyDataArray = tmpArrList.slice(0, (params.showNum - 1));
                    $scope.dataPage = Math.ceil($scope.dataNum / $scope.showNum.showNum);
                    $scope.currentPage = 1;
                }
                $scope.turnPage = function () {
                    $scope.copyDataArray = tmpArrList.slice((($scope.currentPage - 1) * 15), (($scope.currentPage + 1) * 15 - 1));
                }
                //固定页面跳转
                $scope.jumpPage = function (num) {
                    num = parseInt(num);
                    if (parseInt(num, 10) === num && num <= ($scope.dataPage + 1) && num > 0) {
                        $scope.currentPage = num;
                        $scope.jumpPageNum = '';
                        $scope.turnPage();
                    } else {
                        $scope.copyDataArray = tmpArrList.slice(0, 14); //初始15条数据
                    }
                }
            } else {
                pageJump(tmpArrList);
            }
        }, 200);
    };
}])
    .factory('PreviousDealData', ['$http', 'localStorageService', 'myHttp', '$q', '$rootScope', function ($http, localStorageService, myHttp, $q, $rootScope) {
        return {
            search: function (OrderId, Account, matchTimeStart, matchTimeEnd, directiveProductId, Direct, SystemNo) {
                /*
                 **查询条件
                 *0等于(默认值)
                 *1包含字符串
                 *3大于等于
                 *4小于等于
                 */
                var deferred = $q.defer();
                var filterJson = [
                    {"value": OrderId, "condition": 0, "name": "OrderId"},
                    {"value": Account, "condition": 0, "name": "Account"},
                    {"value": directiveProductId, "condition": 0, "name": "ProductId"},
                    {"value": Direct, "condition": 0, "name": "Direct"},
                    {"value": Date.parse(new Date(matchTimeStart)) / 1000, "condition": 3, "name": "MatchTime"},
                    {"value": Date.parse(new Date(matchTimeEnd)) / 1000, "condition": 4, "name": "MatchTime"},
                    {"value": SystemNo, "condition": 0, "name": "SystemNo"}
                ];

                function filterInfo(arr) {
                    var tmpArr = [];
                    for (var i = 0, r = arr.length; i < r; i++) {
                        // console.log(arr[i].value)
                        if (arr[i].value != undefined && arr[i].value != '') {
                            tmpArr.push({"field": arr[i].name, "value": arr[i].value, "condition": arr[i].condition});
                        }
                    }
                    return tmpArr;
                }

                var qryConditions = {
                    "qryConditions": filterInfo(filterJson)
                }
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'admin/trade/query/up/match',
                    data: qryConditions
                }).then(function successCallback(response) {
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            }
        }
    }])