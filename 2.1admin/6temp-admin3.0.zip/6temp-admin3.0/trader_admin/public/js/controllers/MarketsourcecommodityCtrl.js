app.controller('MarketsourcecommodityCtrl', ['$rootScope', '$timeout', '$scope', 'getMarketsourcecommodityData', 'dataSer', 'confirmService', 'tipService', 'marketSourceProductManageCtrlSer', 'productManageSer', 'getPageNum', function($rootScope, $timeout, $scope, getMarketsourcecommodityData, dataSer, confirmService, tipService, marketSourceProductManageCtrlSer, productManageSer, getPageNum) {
            // 分页
            var pageJump = function(tmpArrList) {
                $timeout(function() {
                    if (tmpArrList != undefined) {
                        console.log(tmpArrList);
                        $scope.currentPage = 1; //当前页数
                        $scope.dataNum = tmpArrList.length;
                        $scope.showDataChoose = getPageNum.pageNum(); //获取分页
                        $scope.showNum = $scope.showDataChoose[0]; //初始显示刷具条数
                        $scope.showPage = false;
                        $timeout(function() {
                            $scope.showPage = true;
                            $scope.copyDataArray = tmpArrList.slice(0, 14); //初始15条数据
                        }, 10)
                        $scope.dataPage = Math.ceil($scope.dataNum / $scope.showNum.showNum);

                        //上下页
                        $scope.pageSlect = function(type) {
                                if (type == 'prev') {
                                    if ($scope.currentPage != 1) {
                                        $scope.currentPage--;
                                        $scope.turnPage();
                                    } else {
                                        $scope.copyDataArray = tmpArrList.slice(0, 14); //初始15条数据
                                    }
                                } else {
                                    if ($scope.currentPage < $scope.dataPage) {
                                        $scope.currentPage++;
                                        $scope.turnPage();
                                    }
                                }
                            }
                            //每页数据量
                        $scope.baseDataArray = [];
                        $scope.copyDataArray = [];
                        $scope.pageSelect = function(params) {
                            $scope.showNum.showNum = params.showNum;
                            $scope.copyDataArray = tmpArrList.slice(0, (params.showNum - 1));
                            $scope.dataPage = Math.ceil($scope.dataNum / $scope.showNum.showNum);
                            $scope.currentPage = 1;
                        }
                        $scope.turnPage = function() {
                                $scope.copyDataArray = tmpArrList.slice((($scope.currentPage - 1) * 15), (($scope.currentPage + 1) * 15 - 1));
                            }
                            //固定页面跳转
                        $scope.jumpPage = function(num) {
                            num = parseInt(num);
                            if (parseInt(num, 10) === num && num <= ($scope.dataPage + 1) && num > 0) {
                                $scope.currentPage = num;
                                $scope.jumpPageNum = '';
                                $scope.turnPage();
                            } else {
                                $scope.copyDataArray = tmpArrList.slice(0, 14); //初始15条数据
                            }
                        }
                    } else {
                        pageJump(tmpArrList);
                    }
                }, 200);
            };
            //行情源商品编号
            marketSourceProductManageCtrlSer.search()
                .then(function(res) {
                    if (res.retMsg.code == '000000') {
                        $scope.chooseKey = null;
                        $scope.searchResultsy = res.list;
                        console.log($scope.searchResultsy)
                    }
                });
            //上手交易编号
            productManageSer.productSearch()
                .then(function(response) {
                    var productList = response.list;
                    $scope.productList = productList;
                    console.log(productList)
                }, function(error) {
                    console.log(error)
                })

            //查询所有指定
            $scope.search = function() {
                    getMarketsourcecommodityData.search()
                        .then(function(res) {
                            if (res.retMsg.code == "000000") {
                                $scope.searchResult = res.list;
                                pageJump($scope.searchResult);
                            } else {
                                $rootScope.tipService.setMessage(res.message, 'warning');
                            }
                        }, function(error) {
                            $rootScope.tipService.setMessage(error.message, 'warning');
                        });
                },
                //$scope.search();

                //新增
                $scope.chooseItemTab1 = null;
            $scope.newcreateOrderShow = false;
            addEditText = "";
            $scope.addNewData = function() {
                    $scope.newcreateOrderShow = true;
                    $scope.key = '0'; //编号(主键，自动生成)
                    $scope.addEditText = '新增';
                    addEditText = "";
                }
                //单选
            $scope.checkedTab1 = function(index, key) {
                $scope.chooseItemTab1 = key;
                $scope.key = $scope.searchResult[index].key;
                $scope.symbol = $scope.searchResult[index].ksymboley;
                $scope.quoteSymbol = $scope.searchResult[index].quoteSymbol;
                $('#dataReportTab1 input[type=checkbox]').not('.start_using').prop('checked', false);
                $('#dataReportTab1 input[type=checkbox]').not('.start_using').eq(index).prop('checked', true);
                console.log($scope.key);
            }
            $scope.symbol = "";
            $scope.quoteSymbol = "";
            $scope.addNewSubmit = function() {
                if ($scope.addEditText == '新增') {
                    var map = {
                        key: $scope.key,
                        symbol: $scope.symbol,
                        quoteSymbol: $scope.quoteSymbol,
                    }
                    json = {
                        map: map
                    }
                    if (toValidate('#MarketmodityAdd')) {
                        getMarketsourcecommodityData.addNewinsert(json)
                            .then(function(res) {
                                 if (res.code == "000000") {
                                /* $scope.keyshow=false;*/
                                $scope.newcreateOrderShow = false;
                                $rootScope.tipService.setMessage(res.message, 'warning');
                                $scope.search();
                            }else {
                                $rootScope.tipService.setMessage(res.message, 'warning');
                            }
                            }, function(error) {
                                $$rootScope.tipService.setMessage(error.codeName, 'warning');
                            });
                    }
                }
            }

            //注销
            $scope.cancel = function() {
                if (!$scope.chooseItemTab1) {
                    $rootScope.tipService.setMessage('请先选择账户', 'warning');
                } else {
                    confirmService.set('确认提示', '确定要删除此账户?', function() {
                        getMarketsourcecommodityData.close($scope.chooseItemTab1)
                            .then(function(res) {
                            if (res.retMsg.code == "000000") {
                                $rootScope.tipService.setMessage(res.retMsg.message, 'warning');
                                $scope.search();
                            }else {
                                $rootScope.tipService.setMessage(res.retMsg.message, 'warning');
                            }
                            }, function(error) {
                                $rootScope.tipService.setMessage(error.retMsg.message, 'warning');
                            });
                        confirmService.clear();
                    })
                }
            }
    }])
    .factory('getMarketsourcecommodityData', ['$rootScope', '$http', '$q', function($rootScope, $http, $q) {
        return {
            //上手协议查询
            search: function() {
                var deferred = $q.defer();
                $http({
                    method: "POST",
                    url: $rootScope.baseUrl + "c/up/quote/symbol/query/all"
                }).success(function(res) {
                    deferred.resolve(res);
                }).error(function(res) {
                    deferred.reject(res);
                });
                return deferred.promise;
            },
            //添加
            addNewinsert: function(json) {
                var deferred = $q.defer();
                $http({
                    method: "POST",
                    url: $rootScope.baseUrl + "c/up/quote/symbol/insert",
                    data: json,

                }).success(function(res) {
                    deferred.resolve(res);
                }).error(function(res) {
                    deferred.reject(res);
                });
                return deferred.promise;
            },
            // 注销
            close: function(key) {
                var json = {
                    key: key
                }
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'c/up/quote/symbol/delete',
                    data: json
                }).then(function successCallback(response) {
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;


            }
        }
    }])