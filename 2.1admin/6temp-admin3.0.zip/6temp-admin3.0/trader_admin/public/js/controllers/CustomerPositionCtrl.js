app.controller('CustomerPositionCtrl', ['$rootScope', '$scope', 'getPageNum', 'CustomerPositionData', 'getOrderDirect', 'timestamp','localStorageService', function($rootScope, $scope, getPageNum, CustomerPositionData, getOrderDirect, timestamp,localStorageService) {
    $scope.toggleTraderSearchState=false;
    $scope.Toggle = function(){
        $scope.toggleTraderSearchState = !$scope.toggleTraderSearchState;
        if($scope.toggleTraderSearchState){
           $('.search_column').css('height','auto');
        }
        else{
           $('.search_column').css('height','36px');
        }
    };
    //获取买卖方向
    $scope.OrderDirect = getOrderDirect;

    var processContent,processTotal;
    var source = {
        type: 'POST',
        datatype: "json",
        datafields: [  //数据字段定义
            {name: 'positionId', type: 'string'},
            {name: 'userName', type: 'string'},
            {name: 'productName', type: 'string'},
            {name: 'productCode', type: 'string'},
            {name: 'orderDirect', type: 'string'},

            {name: 'positionPrice', type: 'string'},
            {name: 'positionVolume', type: 'string'},
            {name: 'createTime', type: 'string'}
        ],
        url: $rootScope.baseUrl + 'admin/trade/position/query/sum/as/page',
        root: "content",
        pagesize:10,
        processData: function (data) {
            data.page = (data.pagenum + 1)?(data.pagenum + 1):1;
            data.rows =(data.pagesize)?(data.pagesize):10;
            data.order =($scope.order)?$scope.order:'desc';
            data.sort =($scope.sort)?$scope.sort:'createTime';
            data.search_A_EQ_userId = ($scope.directiveUserId) ? $scope.directiveUserId : '';
            data.search_A_LIKE_productName=($scope.productNames)?$scope.productNames:'',
            data.search_A_EQ_orderDirect = ($scope.Direct) ? $scope.Direct : '';

            $scope.orgCode = localStorageService.get('oldOrgCode');
            if ($scope.organizeValue == true && $scope.downOrganizeValue == true) {
                data.search_A_LLIKE_orgCode = ($scope.orgCode) ? $scope.orgCode : '';
            }
            if ($scope.organizeValue == true && $scope.downOrganizeValue == false) {
                data.search_A_EQ_orgCode = ($scope.orgCode) ? $scope.orgCode : '';
            }
            if ($scope.organizeValue == false && $scope.downOrganizeValue == true) {
                data.search_A_LLIKE_orgCode = ($scope.orgCode) ? $scope.orgCode + '-' : '';
            }
        },
        beforeLoadComplete: function (records) {
            var start;
            for (var i in records) {
                start = parseInt(i);
                break;
            }
            for (var k = 0, r = processContent.length; k < r; k++) {
                records[start + k].positionId = processContent[k].positionId;
                records[start + k].userName = processContent[k].userName;
                records[start + k].productName = processContent[k].productName;
                records[start + k].productCode = processContent[k].productCode;
                records[start + k].orderDirect = processContent[k].orderDirect;

                records[start + k].positionPrice = processContent[k].positionPrice;
                records[start + k].positionVolume = processContent[k].positionVolume;
                records[start + k].createTime = processContent[k].createTime;
            }
        },
        beforeprocessing: function (data) { //处理总页数
            var processData = JSON.parse(data.content);
            console.log(processData)
            processContent = processData.content;
            source.totalrecords = processData.totalElements == 0 ? 5 : processData.totalElements;
            processTotal = processData.totalElements;
        },
        loadComplete: function (records) {
            $scope.saveResult=JSON.parse(records.content);
            var data =  $scope.saveResult.totalElements;
            if (data == 0) {
                $('#contenttableentrustDetailGrid > div').remove();
            }
        },
        endUpdate: true
    };
    //创建数据适配器
    var dataAdapter = null;
    $scope.searchAjax = function () {
        $scope.toggleTraderSearchState = false;
        $('.search_column').css('height', '36px');
        if (dataAdapter == null) {
            dataAdapter = new $.jqx.dataAdapter(source);
            //创建表格
            $("#entrustDetailGrid").jqxGrid({
                source: dataAdapter,//数据源
                columns: [  //表格数据域
                    {
                        text: '用户名',
                        datafield: 'userName',
                        minwidth: 13 + '%',
                        cellsalign: 'center',
                        align: 'center',
                        width: '13%'
                    },
                    {
                        text: '商品名',
                        datafield: 'productName',
                        minwidth: 13 + '%',
                        cellsalign: 'center',
                        align: 'center',
                        width:'13%'
                    },
                    {
                        text: '商品代码',
                        datafield: 'productCode',
                        minwidth:13 + '%',
                        align: 'center',
                        width:'13%'
                    },
                    {
                        text: '买卖方向',
                        datafield: 'orderDirect',
                        minwidth: 13 + '%',
                        cellsalign: 'center',
                        align: 'center',
                        width:'13%',
                        cellsrenderer: function (row, columnfield, value, defaulthtml, columnproperties) {
                            if ($scope.OrderDirect) {
                                for (var i = 0; i < $scope.OrderDirect.length; i++) {
                                    if (value == $scope.OrderDirect[i].id) {
                                        return $scope.OrderDirect[i].name;
                                    }
                                }
                            }
                        }
                    },
                    {
                        text: '持仓价格',
                        datafield: 'positionPrice',
                        minwidth: 13 + '%',
                        width:'13%',
                        align: 'center',
                        cellsrenderer: function (row, columnfield, value, defaulthtml, columnproperties) {
                            if ($scope.orderState) {
                                for (var i = 0; i < $scope.orderState.length; i++) {
                                    if (value == $scope.orderState[i].id) {
                                        return $scope.orderState[i].name;
                                    }
                                }
                            }
                        }
                    },
                    {
                        text: '持仓手数',
                        datafield: 'positionVolume',
                        minwidth: 13 + '%',
                        cellsalign: 'center',
                        align: 'center',
                        width:'13%',
                        cellsrenderer: function (row, columnfield, value, defaulthtml, columnproperties) {
                            if ($scope.OrderReason) {
                                for (var i = 0; i < $scope.OrderReason.length; i++) {
                                    if (value == $scope.OrderReason[i].id) {
                                        return $scope.OrderReason[i].name;
                                    }
                                }
                            }
                        }
                    },
                    {
                        text: '持仓时间',
                        datafield: 'createTime',
                        minwidth: 22 + '%',
                        align: 'center',
                        width:'22%',
                        cellsrenderer: function (row, columnfield, value, defaulthtml, columnproperties) {
                            return timestamp.timestampCoverHms(value, 'all');
                        },
                        cellsalign: 'right',
                    }
                ],
                width: 100 + '%',
                height: 87 + '%',
                theme:'metrodark',
                virtualmode: true,
                rendergridrows: function (params) {
                    return params.data;
                },
                pageable: true,//是否分页数
                pagesizeoptions: ['10','30','100','200'], //分页选项
                sortable: true,//是否排序
                columnsresize: true,//列间距是否可调整
                selectionmode: 'singlecell',//选择模式
                clipboard: true
            });
        }else {
            $("#entrustDetailGrid").jqxGrid('updatebounddata', 'cells');
        }
    };
    //分页
    $("#entrustDetailGrid").on("pagechanged", function (event) {
        console.log(event)
    });
    //排序
    $("#entrustDetailGrid").on("sort", function (event) {
        var sortinformation = event.args.sortinformation;
        $scope.sort=sortinformation.sortcolumn;
        $scope.order=($scope.sort)?(sortinformation.sortdirection.ascending)?'asc':'desc':'asc';
        data={
            order:$scope.order,
            sort:$scope.sort
        };
        source.processData(data);
        $("#entrustDetailGrid").jqxGrid('updatebounddata', 'sort');
    });

	}])
	.factory('CustomerPositionData', ['$http', 'localStorageService', 'myHttp', '$q', '$rootScope', function($http, localStorageService, myHttp, $q, $rootScope) {
		return {
			search: function(json) {
				var deferred = $q.defer();
				myHttp.post("admin/trade/position/query/sum/as/page", json)
					.then(function(res) { // 调用承诺API获取数据 .resolve
						deferred.resolve(res);
					}, function(res) { // 处理错误 .reject
						deferred.reject(res);
					});
				return deferred.promise;
			}
		}
	}])