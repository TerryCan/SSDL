app.controller("marketSourceProductManageCtrl", ['$scope', '$timeout', 'tipService', '$rootScope', 'confirmService', 'marketSourceProductManageCtrlSer', 'marketAgreementManageCtrlSer', 'getPageNum', function ($scope, $timeout, tipService, $rootScope, confirmService, marketSourceProductManageCtrlSer, marketAgreementManageCtrlSer, getPageNum) {
    // 分页
    var pageJump = function (tmpArrList) {
        $timeout(function () {
            if (tmpArrList != undefined) {
                console.log(tmpArrList);
                $scope.currentPage = 1; //当前页数
                $scope.dataNum = tmpArrList.length;
                $scope.showDataChoose = getPageNum.pageNum(); //获取分页
                $scope.showNum = $scope.showDataChoose[0]; //初始显示刷具条数
                $scope.showPage = false;
                $timeout(function () {
                    $scope.showPage = true;
                    $scope.copyDataArray = tmpArrList.slice(0, 14); //初始15条数据
                }, 10)
                $scope.dataPage = Math.ceil($scope.dataNum / $scope.showNum.showNum);

                //上下页
                $scope.pageSlect = function (type) {
                    if (type == 'prev') {
                        if ($scope.currentPage != 1) {
                            $scope.currentPage--;
                            $scope.turnPage();
                        } else {
                            $scope.copyDataArray = tmpArrList.slice(0, 14); //初始15条数据
                        }
                    } else {
                        if ($scope.currentPage < $scope.dataPage) {
                            $scope.currentPage++;
                            $scope.turnPage();
                        }
                    }
                }
                //每页数据量
                $scope.baseDataArray = [];
                $scope.copyDataArray = [];
                $scope.pageSelect = function (params) {
                    $scope.showNum.showNum = params.showNum;
                    $scope.copyDataArray = tmpArrList.slice(0, (params.showNum - 1));
                    $scope.dataPage = Math.ceil($scope.dataNum / $scope.showNum.showNum);
                    $scope.currentPage = 1;
                }
                $scope.turnPage = function () {
                    $scope.copyDataArray = tmpArrList.slice((($scope.currentPage - 1) * 15), (($scope.currentPage + 1) * 15 - 1));
                }
                //固定页面跳转
                $scope.jumpPage = function (num) {
                    num = parseInt(num);
                    if (parseInt(num, 10) === num && num <= ($scope.dataPage + 1) && num > 0) {
                        $scope.currentPage = num;
                        $scope.jumpPageNum = '';
                        $scope.turnPage();
                    } else {
                        $scope.copyDataArray = tmpArrList.slice(0, 14); //初始15条数据
                    }
                }
            } else {
                pageJump(tmpArrList);
            }
        }, 200);
    };
    $scope.search = function () {
        marketSourceProductManageCtrlSer.search()
            .then(function (res) {
                if (res.retMsg.code == '000000') {
                    $scope.chooseKey = null;
                    $scope.searchResult = res.list;
                    console.log($scope.searchResult);
                    pageJump($scope.searchResult);
                } else {
                    $rootScope.tipService.setMessage(res.message, 'warning');
                }
            }, function (error) {
                $rootScope.tipService.setMessage(error.message, 'warning');
            });
    };
    //$scope.search();

    $scope.addMarketSourceProduct = false;
    $scope.resetVal = function () {
        //基础字段
        $scope.key; //商品编号(主键,自动生成)
        $scope.protocol; //协议编号(协议key)
        $scope.exchange; //市场编号
        $scope.commodity; //品种编号
        $scope.contract; //合约编号
        $scope.name; //商品名称
        $scope.type; //品种类型(易盛协议中请填写大写的F,表示期货)
        $scope.maxContractCnt; //最大合约数
        $scope.minPriceDelta //最小价格跳动
    }

    $scope.addMarketSourceSubmit = function () {
        console.log($scope.optType)
        if ($scope.optType == 'edit') {
            var minPriceDelta = parseFloat($scope.minPriceDelta);
            var quoteSymbol = {
                key: $scope.key,
                protocol: $scope.protocol,
                exchange: $scope.exchange,
                commodity: $scope.commodity,
                contract: $scope.contract,
                name: $scope.name,
                type: $scope.type,
                maxContractCnt: $scope.maxContractCnt,
                minPriceDelta: minPriceDelta,
                tradeRatio: $scope.tradeRatio,
                precise: $scope.precise
            };
            if (toValidate('#marketPro')) {
                marketSourceProductManageCtrlSer.edit($scope.chooseKey, quoteSymbol)
                    .then(function (res) {
                        if (res.data.code == '000000') {
                            $rootScope.tipService.setMessage(res.data.message, 'warning');
                            $scope.addMarketSourceProduct = false;
                            $scope.search();
                        } else {
                            $rootScope.tipService.setMessage(res.data.message, 'warning');
                        }
                    });
            }
        } else {
            var minPriceDelta = parseFloat($scope.minPriceDelta);
            var quoteSymbol = {
                key: '',
                protocol: $scope.protocol,
                exchange: $scope.exchange,
                commodity: $scope.commodity,
                contract: $scope.contract,
                name: $scope.name,
                type: $scope.type,
                maxContractCnt: $scope.maxContractCnt,
                minPriceDelta: minPriceDelta,
                tradeRatio: $scope.tradeRatio,
                precise: $scope.precise
            }
            if (toValidate('#marketPro')) {
                marketSourceProductManageCtrlSer.add(quoteSymbol)
                    .then(function (res) {
                        if (res.data.code == '000000') {
                            $rootScope.tipService.setMessage(res.data.message, 'warning');
                            $scope.addMarketSourceProduct = false;
                            $scope.search();
                        } else {
                            $rootScope.tipService.setMessage(res.data.message, 'warning');
                        }
                    });
            }
        }
    };
    $scope.optInfo = function (type) {
        $scope.optType = type;
        if (type == 'edit') {
            if ($scope.chooseKey == null) {
                $rootScope.tipService.setMessage("请先选择账号", 'warning');
            } else {
                $scope.infoOptType = '保 存';
                $scope.addMarketSourceProduct = true;
                marketSourceProductManageCtrlSer.singleSearch($scope.chooseKey)
                    .then(function (res) {
                        if (res.data.retMsg.code == '000000') {
                            console.log(res);
                            $scope.key = res.data.symbol.key;
                            $scope.commodity = res.data.symbol.commodity;
                            $scope.contract = res.data.symbol.contract;
                            $scope.exchange = res.data.symbol.exchange;
                            $scope.maxContractCnt = res.data.symbol.maxContractCnt;
                            $scope.minPriceDelta = res.data.symbol.minPriceDelta;
                            $scope.name = res.data.symbol.name;
                            $scope.protocol = res.data.symbol.protocol;
                            $scope.type = res.data.symbol.type;
                            $scope.tradeRatio=res.data.symbol.tradeRatio;
                            $scope.precise=res.data.symbol.precise;
                        }
                    });
            }
        } else {
            $scope.infoOptType = '新 增';
            $scope.addMarketSourceProduct = true;
            $scope.resetVal();
        }
    }
    $scope.delete = function () {
        if ($scope.chooseKey == null) {
            $rootScope.tipService.setMessage("请先选择账号", 'warning');
        } else {
            confirmService.set('确认提示', '确定删除此产品?', function () {
                marketSourceProductManageCtrlSer.delete($scope.chooseKey)
                    .then(function (res) {
                        if (res.data.code == '000000') {
                            $rootScope.tipService.setMessage(res.data.message, 'warning');
                            $scope.search();
                        } else {
                            $rootScope.tipService.setMessage(res.data.message, 'warning');
                        }
                    });
                confirmService.clear();
            });

        }
    }
    $scope.start = function (key) {
        marketSourceProductManageCtrlSer.start(key)
            .then(function (res) {
                if (res.data.code == '000000') {
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                    $scope.search();
                } else {
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                }
            });
    }
    $scope.stop = function (key) {
        marketSourceProductManageCtrlSer.stop(key)
            .then(function (res) {
                if (res.data.code == '000000') {
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                    $scope.search();
                } else {
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                }
            });
    }
    //单选
    $scope.chooseKey = null;
    $scope.checked = function (index, key) {
        $scope.chooseKey = key;
        $('#dataReport input[type=checkbox]').prop('checked', false);
        $('#dataReport input[type=checkbox]').eq(index).prop('checked', true);
    }
    //协议查询
    marketAgreementManageCtrlSer.search()
        .then(function (res) {
            if (res.retMsg.code == '000000') {
                $scope.AgreementData = res.list;
            }
        });
    //协议文字转换
    $scope.changeAgreementDataText = function (key) {
        for (var i = 0, r = $scope.AgreementData.length; i < r; i++) {
            if (key == $scope.AgreementData[i].key) {
                return $scope.AgreementData[i].type;
            }
        }
    }
}])
    .factory('marketSourceProductManageCtrlSer', ['$http', 'localStorageService', 'myHttp', '$q', '$rootScope', function ($http, localStorageService, myHttp, $q, $rootScope) {
        return {
            search: function () {
                var deferred = $q.defer();
                myHttp.post("c/quote/symbol/query/all")
                    .then(function (res) { // 调用承诺API获取数据 .resolve
                        deferred.resolve(res);
                    }, function (res) { // 处理错误 .reject
                        deferred.reject(res);
                    });
                return deferred.promise;
            },
            add: function (quoteSymbol) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'c/quote/symbol/insert',
                    data: {
                        quoteSymbol: quoteSymbol
                    }
                }).then(function successCallback(response) {
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
            edit: function (key, quoteSymbol) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'c/quote/symbol/modify/full',
                    data: {
                        key: key,
                        quoteSymbol: quoteSymbol
                    }
                }).then(function successCallback(response) {
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
            delete: function (key) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'c/quote/symbol/delete',
                    data: {
                        key: key
                    }
                }).then(function successCallback(response) {
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
            start: function (key) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'c/quote/symbol/enable',
                    data: {
                        key: key
                    }
                }).then(function successCallback(response) {
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
            stop: function (key) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'c/quote/symbol/disenable',
                    data: {
                        key: key
                    }
                }).then(function successCallback(response) {
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
            singleSearch: function (key) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'c/quote/symbol/query/key',
                    data: {
                        key: key
                    }
                }).then(function successCallback(response) {
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            }
        }
    }]);