app.controller("prevSourceRouteManageCtrl", ['routeManagementSer','$scope', '$rootScope', 'getRouteStatus', 'getPageNum', '$timeout','confirmService','localStorageService', function (routeManagementSer,$scope, $rootScope, getRouteStatus, getPageNum, $timeout,confirmService,localStorageService) {
    //路由类型
    $scope.RouteStatus = getRouteStatus;
    $scope.getRoute = function (parameter) {
        for (i = 0; i < $scope.RouteStatus.length; i++) {
            if (parameter == $scope.RouteStatus[i].id) {
                return $scope.RouteStatus[i].name;
            }
        }
    };
    //账号管理
    routeManagementSer.accountSearch().then(function (response) {
            $scope.accountList = response.list;
            // console.log($scope.accountList);
        }, function (error) {
            console.log(error)
        });
    $scope.switchAccount=function(paramater){
        for(var i=0;i<$scope.accountList.length;i++){
            if(paramater==$scope.accountList[i].key){
                return $scope.accountList[i].name;
            }
        }
    };
    $scope.typeEdit = function () {
        $scope.routeTypeNum = parseInt($scope.routeType);
        if ($scope.routeType == 1) {
            $scope.routeTypeShow = true;
        } else {
            $scope.routeTypeShow = false;
            $scope.routeFixAccount = null;
        }
    };
    $scope.typeFunc = function () {
        if ($scope.type == 1) {
            $scope.typeNumber = true;
        } else {
            $scope.typeNumber = false;
            $scope.fixAccount = null;
        }
    };
    //查询
    $scope.routeManagement = function () {
        routeManagementSer.routeSearch()
            .then(function (response) {
                if (response.retMsg.code === '000000') {
                    $scope.routeList = response.list;
                    console.log($scope.routeList);
                    pageJump($scope.routeList);

                    var checkedUserId=localStorageService.get('userIdChecked');
                    $scope.switchUserId(checkedUserId,$scope.routeList);
                } else {
                    $rootScope.tipService.setMessage(response.retMsg.message, 'warning');
                }
            }, function (error) {
                $rootScope.tipService.setMessage(error.message, 'warning');
            });
    };

    //上手路由管理添加
    $scope.remove = function () {
        $scope.key = 0;
        $scope.type = "";
        $scope.name = "";
        $scope.fixAccount = "";
    };

    $scope.routeAdd = function () {
        $scope.keyNum = parseInt($scope.type);
        var upRoute = {
            key: $scope.key,
            type: $scope.keyNum,
            name: $scope.name,
            fixAccount: $scope.fixAccount
        };
        var json = {
            upRoute: upRoute
        };
        if (toValidate('#RouteAdd')) {
            routeManagementSer.routePlus(json)
                .then(function (response) {
                    console.log(response);
                    if (response.code == "000000") {
                        $scope.addShowing = false;
                        $rootScope.tipService.setMessage(response.message, 'warning');
                        $scope.routeManagement();
                        $scope.remove();
                    } else {
                        $rootScope.tipService.setMessage('请求参数错误', 'warning');
                    }
                })
        }
    };
    //选择
    $scope.switchUserId=function(parameter,responseData){
        $timeout(function(){
            for(var i=0;i< responseData.length;i++){
                if(parameter==responseData[i].key){
                    $scope.key= parameter;
                    $('#dataReport input[type=checkbox]').not('.start_using').eq(i).prop('checked', true);
                    return;
                }
            }
        },300)
    };
    $scope.routeCheck = function (index,key) {
        $scope.routeType = $scope.routeList[index].type;
        $scope.routeFixAccount = $scope.routeList[index].fixAccount;
        $scope.routeName = $scope.routeList[index].name;
        // $('#dataReport input[type=checkbox]').prop('checked', false);
        // $('#dataReport input[type=checkbox]').eq(index).prop('checked', true);
        var userIdChecked=localStorageService.get('userIdChecked');
        $('#dataReport input[type=checkbox]').prop('checked',false);
        if (key == userIdChecked) {
            localStorageService.clear('userIdChecked');
            $scope.routeKey ='';
        }else{
            $('#dataReport input[type=checkbox]').eq(index).prop('checked', true);
            localStorageService.update('userIdChecked',key);
            $scope.routeKey =key;
        }
    };
    //修改
    $scope.editShow = function () {
        if (!$scope.routeKey) {
            $rootScope.tipService.setMessage('请先选择账号编号', 'warning');
        } else {
            $scope.editShowing = true;

        }
    };
    $scope.routeType = "";
    $scope.routeCompile = function () {
        var upRoute = {
            key: $scope.routeKey,
            type: $scope.routeTypeNum,
            fixAccount: $scope.routeFixAccount,
            name: $scope.routeName
        };
        var json = {
            upRoute: upRoute
        };
        if (toValidate('#RouteEdit')) {
            routeManagementSer.routeModify(json)
                .then(function (response) {
                    if (response.code == "000000") {
                        $scope.editShowing = false;
                        $rootScope.tipService.setMessage(response.message, 'warning');
                        $scope.routeManagement();
                    } else {
                        $rootScope.tipService.setMessage('请求参数错误', 'warning');
                    }
                })
        }
    };

    //删除
    $scope.delete = function () {
        if (!$scope.routeKey) {
            $rootScope.tipService.setMessage('请先选择路由!', 'warning');
        }else {
            var json = {
                key: $scope.routeKey
            };
            confirmService.set('确认提示', '确定要注销此账户?', function () {
                routeManagementSer.routeDelete(json).then(function (res) {
                    if (res.code == "000000") {
                        $rootScope.tipService.setMessage(res.message, 'warning');
                        $scope.routeManagement();
                    } else {
                        $rootScope.tipService.setMessage(res.message, 'warning');
                    }
                }, function (error) {
                    $rootScope.tipService.setMessage(error.message, 'warning');
                });
                confirmService.clear();
            })
        }
    };
    // 分页 TerryMin
    var pageJump = function (tmpArrList) {
        $timeout(function () {
            if (tmpArrList != undefined) {
                $scope.currentPage = 1; //当前页数
                $scope.dataNum = tmpArrList.length;
                $scope.showDataChoose = getPageNum.pageNum(); //获取分页
                $scope.showNum = $scope.showDataChoose[0]; //初始显示刷具条数
                $scope.showPage = false;
                $timeout(function () {
                    $scope.showPage = true;
                    $scope.copyDataArray = tmpArrList.slice(0, 14); //初始15条数据
                }, 10)
                $scope.dataPage = Math.ceil($scope.dataNum / $scope.showNum.showNum);

                //上下页
                $scope.pageSlect = function (type) {
                    if (type == 'prev') {
                        if ($scope.currentPage != 1) {
                            $scope.currentPage--;
                            $scope.turnPage();
                        } else {
                            $scope.copyDataArray = tmpArrList.slice(0, 14); //初始15条数据
                        }
                    } else {
                        if ($scope.currentPage < $scope.dataPage) {
                            $scope.currentPage++;
                            $scope.turnPage();
                        }
                    }
                };
                //每页数据量
                $scope.baseDataArray = [];
                $scope.copyDataArray = [];
                $scope.pageSelect = function (params) {
                    $scope.showNum.showNum = params.showNum;
                    $scope.copyDataArray = tmpArrList.slice(0, (params.showNum - 1));
                    $scope.dataPage = Math.ceil($scope.dataNum / $scope.showNum.showNum);
                    $scope.currentPage = 1;
                };
                $scope.turnPage = function () {
                    $scope.copyDataArray = tmpArrList.slice((($scope.currentPage - 1) * 15), (($scope.currentPage + 1) * 15 - 1));
                };
                //固定页面跳转
                $scope.jumpPage = function (num) {
                    num = parseInt(num);
                    if (parseInt(num, 10) === num && num <= ($scope.dataPage + 1) && num > 0) {
                        $scope.currentPage = num;
                        $scope.jumpPageNum = '';
                        $scope.turnPage();
                    } else {
                        $scope.copyDataArray = tmpArrList.slice(0, 14); //初始15条数据
                    }
                }
            } else {
                pageJump(tmpArrList);
            }
        }, 200);
    };
}])
    .factory('routeManagementSer', ['$http', 'dataFilter', 'localStorageService', 'myHttp', '$q', '$rootScope', function ($http, dataFilter, localStorageService, myHttp, $q, $rootScope) {
        return {
            routeSearch: function () {
                var data = new Object();
                var deferred = $q.defer();
                $http({
                    method: "POST",
                    url: $rootScope.baseUrl + "c/up/route/query/all",
                    data: data,
                    headers: {
                        'Content-Type': 'application/json;charset=UTF-8'
                    }
                }).success(function (res) {
                    deferred.resolve(res);
                }).error(function (res) {
                    deferred.reject(res);
                });
                return deferred.promise;
            },
            routePlus: function (upAccount) {
                var deferred = $q.defer();
                $http({
                    method: "POST",
                    url: $rootScope.baseUrl + "c/up/route/insert",
                    data: upAccount,
                    headers: {
                        'Content-Type': 'application/json;charset=UTF-8'
                    }
                }).success(function (res) {
                    deferred.resolve(res);
                }).error(function (res) {
                    deferred.reject(res);
                });
                return deferred.promise;
            },
            routeModify: function (compileData) {
                var deferred = $q.defer();
                // var data=new Object();
                $http({
                    method: "POST",
                    url: $rootScope.baseUrl + "c/up/route/modify",
                    data: compileData,
                    headers: {
                        'Content-Type': 'application/json;charset=UTF-8'
                    }
                }).success(function (res) {
                    deferred.resolve(res);
                }).error(function (res) {
                    deferred.reject(res);
                });
                return deferred.promise;
            },
            routeDelete: function (removeData) {
                var deferred = $q.defer();
                $http({
                    method: "POST",
                    url: $rootScope.baseUrl + "c/up/route/delete",
                    data: removeData,
                    headers: {
                        'Content-Type': 'application/json;charset=UTF-8'
                    }
                }).success(function (res) {
                    deferred.resolve(res);
                }).error(function (res) {
                    deferred.reject(res);
                });
                return deferred.promise;
            },
            accountSearch: function () {
                var data = new Object();
                var deferred = $q.defer();
                $http({
                    method: "GET",
                    url: $rootScope.baseUrl + "c/up/account/query/all",
                    data: data,
                    headers: {
                        'Content-Type': 'application/json;charset=UTF-8'
                    }
                }).success(function (res) {
                    deferred.resolve(res);
                }).error(function (res) {
                    deferred.reject(res);
                });
                return deferred.promise;

            }
        }
    }])
    // // 路由管理—添加 terry
    // .factory('routeManagementAdd', ['$http', 'dataFilter', 'localStorageService', 'myHttp', '$q', '$rootScope', function ($http, dataFilter, localStorageService, myHttp, $q, $rootScope) {
    //     return {
    //         routePlus: function (upAccount) {
    //             var deferred = $q.defer();
    //             $http({
    //                 method: "POST",
    //                 url: $rootScope.baseUrl + "c/up/route/insert",
    //                 data: upAccount,
    //                 headers: {
    //                     'Content-Type': 'application/json;charset=UTF-8'
    //                 }
    //             }).success(function (res) {
    //                 deferred.resolve(res);
    //             }).error(function (res) {
    //                 deferred.reject(res);
    //             });
    //             return deferred.promise;
    //         }
    //     }
    // }])
    // // 路由管理—编译 terry
    // .factory('routeManagementModify', ['$http', 'dataFilter', 'localStorageService', 'myHttp', '$q', '$rootScope', function ($http, dataFilter, localStorageService, myHttp, $q, $rootScope) {
    //     return {
    //         routeModify: function (compileData) {
    //             var deferred = $q.defer();
    //             // var data=new Object();
    //             $http({
    //                 method: "POST",
    //                 url: $rootScope.baseUrl + "c/up/route/modify",
    //                 data: compileData,
    //                 headers: {
    //                     'Content-Type': 'application/json;charset=UTF-8'
    //                 }
    //             }).success(function (res) {
    //                 deferred.resolve(res);
    //             }).error(function (res) {
    //                 deferred.reject(res);
    //             });
    //             return deferred.promise;
    //         }
    //     }
    // }])
    // // 路由管理—删除 terry
    // .factory('routeManagementDelete', ['$http', 'dataFilter', 'localStorageService', 'myHttp', '$q', '$rootScope', function ($http, dataFilter, localStorageService, myHttp, $q, $rootScope) {
    //     return {
    //         routeDelete: function (removeData) {
    //             var deferred = $q.defer();
    //             $http({
    //                 method: "POST",
    //                 url: $rootScope.baseUrl + "c/up/route/delete",
    //                 data: removeData,
    //                 headers: {
    //                     'Content-Type': 'application/json;charset=UTF-8'
    //                 }
    //             }).success(function (res) {
    //                 deferred.resolve(res);
    //             }).error(function (res) {
    //                 deferred.reject(res);
    //             });
    //             return deferred.promise;
    //         }
    //     }
    // }])