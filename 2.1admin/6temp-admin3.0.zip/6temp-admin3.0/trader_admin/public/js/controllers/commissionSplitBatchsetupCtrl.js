app.controller('commissionSplitBatchsetupCtrl', ['$scope','CommissionallocationAddCtrlSer','dataSer','commissionSplitBatchsetupCtrlSer','$rootScope','$state', function($scope,CommissionallocationAddCtrlSer,dataSer,commissionSplitBatchsetupCtrlSer,$rootScope,$state) {
			$scope.goBack = function() {
				$state.go('tabs.commissionSplit');
			}

			$scope.allotOrgId="";
			$scope.allotType="";
			$scope.level="";
			$scope.selfNum="";
			$scope.nextNum="";
			$scope.taxesNum="";
			$scope.channelNum="";
			$scope.productIds=[];
			dataSer.organizeQuerySer()
				.then(function(res) {
					$scope.orgList = res;
					//console.log($scope.orgList);
				});

			$scope.addOrgValFTC = function(data) {
				//console.log(data);
				$scope.allotOrgId = data.orgId;
				console.log($scope.allotOrgId)
				$scope.superorgCode = data.orgCode;
				$scope.addOrgVal = data.text;
				$scope.baseProList = [];
				$scope.copyProList = [];
			//产品管理
			CommissionallocationAddCtrlSer.productListdata($scope.allotOrgId)
				.then(function(res) {
					if(res.code=="000000"){
					$scope.proList = JSON.parse(res.content);
					console.log($scope.proList)
					for (var i = 0, r = $scope.proList.length; i < r; i++) {
						if ($scope.proList[i].state == 1 || $scope.proList[i].state == 8000) {
							$scope.baseProList.push({
								productId: $scope.proList[i].productId,
								productName: $scope.proList[i].productName
							});
						}
					}
					}
				})
			}
			$scope.addOrgValClose=function(){
				$scope.addOrgVal ="";
				$scope.baseProList ="";
			}
			$scope.allotTypeData = [{
				name: '仓息',
				val: '6'
			}, {
				name: '手续费',
				val: '7'
			}];
			$scope.allotTypeText = function(val) {
				for (var i = 0, r = $scope.allotTypeData.length; i < r; i++) {
					if (val == $scope.allotTypeData[i].val) {
						return $scope.allotTypeData[i].name;
					}
				}
			}
			$scope.allotValData = [{
			name: '百分比',
			val: '1'
		}, {
			name: '固定金额',
			val: '2'
		}];

		//$scope.allotVooType=true;
		$scope.changeVooType=function(){
			if($scope.allotVooType==1){
				$scope.valtype=false;
				$scope.nextNum = "";
				$scope.taxesNum = "";
				$scope.channelNum = "";
				$scope.selfNum ="";
			}else if($scope.allotVooType==2){
				$scope.valtype=true;
				$scope.nextNum = "";
				$scope.taxesNum = "";
				$scope.channelNum = "";
				$scope.selfNum ="";
			}else{
				$scope.valtype=false;
			}
		}

/*			//产品管理
			CommissionallocationAddCtrlSer.productListdata()
				.then(function(res) {
					if(res.code=="000000"){
					$scope.proList = JSON.parse(res.content);
					console.log($scope.proList)
					for (var i = 0, r = $scope.proList.length; i < r; i++) {
						if ($scope.proList[i].state == 1 || $scope.proList[i].state == 8000) {
							$scope.baseProList.push({
								productId: $scope.proList[i].productId,
								productName: $scope.proList[i].productName
							});
						}
					}
					}
					resetBaseInfo();
				});*/
			$scope.addPro = function(index) {
				$scope.copyProList.unshift($scope.baseProList.splice(index, 1)[0]);
			}
			$scope.backPro = function(index) {
				$scope.baseProList.unshift($scope.copyProList.splice(index, 1)[0]);
			}

						//保存数据
			$scope.saveInfo = function() {
				for (var i = 0, r = $scope.copyProList.length; i < r; i++) {
						$scope.productIds.push($scope.copyProList[i].productId);
					}
				if ($scope.addOrgVal == undefined || $scope.addOrgVal == '') {
					$rootScope.tipService.setMessage('请选择所属机构编号', 'warning');
				} else if ($scope.allotType == undefined || $scope.allotType == '') {
					$rootScope.tipService.setMessage('请选择分配佣金类型', 'warning');
				} else if ($scope.levelVal == undefined || $scope.levelVal == '') {
					$rootScope.tipService.setMessage('请选择分配层级', 'warning');
				} else if ($scope.allotVooType == undefined || $scope.allotVooType == '') {
					$rootScope.tipService.setMessage('请选择分配类型', 'warning');
				} else if ($scope.nextNum == undefined || $scope.nextNum === '') {
					$rootScope.tipService.setMessage('请填写下级百分比', 'warning');
				} else if ($scope.taxesNum == undefined || $scope.taxesNum === '') {
					$rootScope.tipService.setMessage('请填写税费百分比', 'warning');
				} else if ($scope.channelNum == undefined || $scope.channelNum === '') {
					$rootScope.tipService.setMessage('请填写通道百分比', 'warning');
				} else if ($scope.productIds== undefined ||$scope.productIds == "") {
					$rootScope.tipService.setMessage('新增必选产品', 'warning');
				} else if($scope.allotVooType==1) {
					$scope.allotType = parseFloat($scope.allotType);
					$scope.allotVooType= parseInt($scope.allotVooType);
					$scope.nextNum = parseFloat($scope.nextNum);
					$scope.taxesNum = parseFloat($scope.taxesNum);
					$scope.channelNum = parseFloat($scope.channelNum);
					$scope.levelVal= parseFloat($scope.levelVal);
					var levelVal=$scope.levelVal;
					console.log(levelVal)
					$scope.selfNum = 100 - $scope.nextNum - $scope.taxesNum - $scope.channelNum;
					var allNum = $scope.nextNum + $scope.taxesNum + $scope.channelNum;
					console.log(allNum, typeof(allNum))
					if (levelVal>100||levelVal<0) {
						console.log(levelVal)
						$rootScope.tipService.setMessage('分配层级最小值0,最大值为100', 'warning');
					}else if(allNum > 100){
							console.log('y')
						$rootScope.tipService.setMessage('四项百分比之和不能超过100', 'warning');
					} else {
					commissionSplitBatchsetupCtrlSer.save($scope.allotOrgId, $scope.allotType,$scope.allotVooType,levelVal,$scope.selfNum,$scope.nextNum,$scope.taxesNum,$scope.channelNum,$scope.productIds)
						.then(function(res) {
							//console.log(res)
							if (res.data.code == '000000') {
								$rootScope.tipService.setMessage(res.data.message, 'warning');
								$state.go('tabs.commissionSplit');
							} else {
								$rootScope.tipService.setMessage(res.data.message, 'warning');
							}
						});
				}
			} else if($scope.allotVooType==2){
				if ($scope.selfNum == undefined || $scope.selfNum === '') {
				$rootScope.tipService.setMessage('请填写本级百分比', 'warning');
				}else{
				$scope.allotType = parseFloat($scope.allotType);
				$scope.allotVooType= parseInt($scope.allotVooType);
				$scope.nextNum = parseFloat($scope.nextNum);
				$scope.taxesNum = parseFloat($scope.taxesNum);
				$scope.channelNum = parseFloat($scope.channelNum);
				$scope.selfNum = parseFloat($scope.selfNum);
				$scope.levelVal= parseFloat($scope.levelVal);
				var levelVal=$scope.levelVal;
				console.log(levelVal)
				commissionSplitBatchsetupCtrlSer.save($scope.allotOrgId, $scope.allotType,$scope.allotVooType,levelVal,$scope.selfNum,$scope.nextNum,$scope.taxesNum,$scope.channelNum,$scope.productIds)
						.then(function(res) {
							//console.log(res)
							if (res.data.code == '000000') {
								$rootScope.tipService.setMessage(res.data.message, 'warning');
								$state.go('tabs.commissionSplit');
							} else {
								$rootScope.tipService.setMessage(res.data.message, 'warning');
							}
						});
				}
			}

		}

}])
	.factory('commissionSplitBatchsetupCtrlSer', ['$http', 'localStorageService', 'myHttp', '$q', '$rootScope', function($http, localStorageService, myHttp, $q, $rootScope) {
		return {
			save: function(allotOrgId, allotType,allotVooType,levelVal,selfNum,nextNum,taxesNum,channelNum,productIds) {
				var json = {
					"allotRulesV": {
						"allotOrgId":allotOrgId,
						"allotType":allotType,
						"allotValueType":allotVooType,
						"level":levelVal,
						"selfNum":selfNum,
						"nextNum":nextNum,
						"taxesNum":taxesNum,
						"channelNum":channelNum,
						"productIdList":productIds,
					}
				}
				var deferred = $q.defer();
				$http({
					method: 'POST',
					url: $rootScope.baseUrl + 'config/allotrule/save/batch',
					data: json
				}).then(function successCallback(response) {
					deferred.resolve(response);
				}, function errorCallback(response) {
					deferred.reject(response);
				});
				return deferred.promise;
			}
		}

	}])