app.controller("prevSourceDepositCtrl", ['$rootScope', '$timeout', '$q', '$http', 'myHttp', '$scope', 'marginParametersSer', 'getPrevSourceAgreementData', 'getPageNum', 'tipService', 'timestamp', 'localStorageService', 'confirmService', function ($rootScope, $timeout, $q, $http, myHttp, $scope, marginParametersSer, getPrevSourceAgreementData, getPageNum, tipService, timestamp, localStorageService, confirmService) {
    localStorageService.clear('userIdChecked');
    $scope.formatTime = function (parameter) {
        return timestamp.daySecondsToDate(parameter);
    };
    // 上手保证金参数 —查询 terry
    $scope.marginList = [];
    $scope.accountList = [];
    $scope.productList = [];
    $scope.accountSearch = '';
    $scope.deposit = function () {
        marginParametersSer.marginSearch()
            .then(function (response) {
                if (response.retMsg.code === '000000') {
                    $scope.marginList = response.list;
                    console.log($scope.marginList);
                    $scope.protocolSearchOther = $scope.accountSearch;
                    portNum();
                    var checkedUserId = localStorageService.get('userIdChecked');
                    $scope.switchUserId(checkedUserId, $scope.marginList);
                } else {
                    $rootScope.tipService.setMessage(response.retMsg.message, 'warning');
                }
            }, function (error) {
                $rootScope.tipService.setMessage(error.message, 'warning');
            });
        $scope.deposit_key = null;
    };
    $scope.editShow = function () {
        if (!$scope.deposit_key) {
            $rootScope.tipService.setMessage('请先选择账号编号', 'warning');
        }
        else {
            $scope.editShowing = true;
        }
    };
    // 上手账号查询
    $scope.accountMargin = function () {
        marginParametersSer.accountSearch()
            .then(function (response) {
                var accountList = response.list;
                $scope.accountList = accountList;
                console.log(accountList)
            }, function (error) {
                console.log(error)
            })

    };
    //上手商品查询
    $scope.productManage = function () {
        marginParametersSer.productSearch()
            .then(function (response) {
                var productList = response.list;
                $scope.productList = productList;
                console.log(productList);
            }, function (error) {
                console.log(error)
            })
    };

    //数据拼接
    var portNum = function () {
        $scope.accountMargin();
        $scope.productManage();
        $timeout(function () {
            if ($scope.marginList.length > 0 && $scope.accountList.length > 0 && $scope.productList.length > 0) {
                var reportArray = [];
                for (var i = 0, r = $scope.marginList.length; i < r; i++) {
                    var tmpArr = {
                        marginRatio: '',
                        marginFix: '',
                        startTime: '',
                        endTime: '',
                        symbol: '',
                        market: '',
                        commodity: '',
                        contract: '',
                        hand_name: '',
                        product_market: '',
                        product_commodity: '',
                        product_contract: '',
                        product_symbol: '',
                        account_key: '',
                        account_name: ''
                    };
                    tmpArr.marginRatio = $scope.marginList[i].marginRatio;
                    tmpArr.marginFix = $scope.marginList[i].marginFix;
                    tmpArr.startTime = $scope.marginList[i].startTime;
                    tmpArr.endTime = $scope.marginList[i].endTime;
                    tmpArr.symbol = $scope.marginList[i].symbol;
                    tmpArr.market = $scope.marginList[i].market;
                    tmpArr.commodity = $scope.marginList[i].commodity;
                    tmpArr.contract = $scope.marginList[i].contract;
                    for (var k = 0, s = $scope.accountList.length; k < s; k++) {
                        if ($scope.accountList[k].key == $scope.marginList[i].account) {
                            tmpArr.hand_name = $scope.accountList[k].name;
                            tmpArr.account_key = $scope.accountList[k].key;
                            // tmpArr.account_name = $scope.accountList[k].name;
                        }
                    }
                    for (var j = 0; j < $scope.productList.length; j++) {
                        if ($scope.productList[j].key == $scope.marginList[i].symbol) {
                            tmpArr.product_Symbol = $scope.productList[j].key;
                            tmpArr.product_market = $scope.productList[j].market;
                            tmpArr.product_commodity = $scope.productList[j].commodity;
                            tmpArr.product_contract = $scope.productList[j].contract;
                        }
                    }
                    reportArray.push(tmpArr);
                }
                $scope.tmpArrList = reportArray;
                console.log($scope.tmpArrList);
                pageJump($scope.tmpArrList)
                // console.log($scope.tmpArrList);
            } else {
                if ($scope.marginList.length == 0 || $scope.accountList.length == 0 || $scope.productList.length == 0) {
                    $rootScope.tipService.setMessage('请求数据为空!', 'warning');
                } else {
                    $scope.accountMargin();
                    $scope.productManage();
                    portNum();
                }
            }
        }, 300);
    };


    //新增
    $scope.remove = function () {
        $scope.account = "";
        $scope.symbol = "";
        $scope.marginRatio = null;
        $scope.marginFix = null;
        $scope.createTimeStart = "";
        $scope.createTimeEnd = "";
    };
    $scope.marginAdd = function () {
        if (toValidate('#formAdd')) {
            if ($scope.createTimeStart && $scope.createTimeEnd) {
                $scope.createTimeStartNum = timestamp.DateToSeconds($scope.createTimeStart);
                $scope.createTimeEndNum = timestamp.DateToSeconds($scope.createTimeEnd);
            } else if (!$scope.createTimeStart && $scope.createTimeEnd) {
                $scope.createTimeStartNum = 0;
                $scope.createTimeEndNum = timestamp.DateToSeconds($scope.createTimeEnd);
            } else if ($scope.createTimeStart && !$scope.createTimeEnd) {
                $scope.createTimeStartNum = timestamp.DateToSeconds($scope.createTimeStart);
                $scope.createTimeEndNum = 0;
            } else {
                $scope.createTimeStartNum = 0;
                $scope.createTimeEndNum = 0;
            }

            var symbols = {
                key: $scope.symbol.split(':')[0],
                market: $scope.symbol.split(':')[1].split('-')[0],
                commodity: $scope.symbol.split(':')[1].split('-')[1],
                contract: $scope.symbol.split(':')[1].split('-')[2]
            };
            var upSymbolMarginPara = {
                key: $scope.key,
                account: $scope.account,
                symbol: symbols.key,
                market: symbols.market,
                commodity: symbols.commodity,
                contract: symbols.contract,
                startTime: $scope.createTimeStartNum,
                endTime: $scope.createTimeEndNum,
                marginRatio: $scope.marginRatio,
                marginFix: $scope.marginFix
            }
            console.log(upSymbolMarginPara.key);
            var json = {
                upSymbolMarginPara: upSymbolMarginPara
            }

            marginParametersSer.marginPlus(json)
                .then(function (response) {
                    if (response.code == "000000") {
                        $scope.addShowing = false;
                        $rootScope.tipService.setMessage(response.message, 'warning');
                        $scope.copyDataArray = '';
                        $scope.deposit();
                        $scope.remove();
                    } else {
                        $rootScope.tipService.setMessage('请求参数错误', 'warning');
                    }
                })
        }
    };

    // 存储选中
    $scope.switchUserId = function (parameter, responseData) {
        $timeout(function () {
            for (var i = 0; i < responseData.length; i++) {
                if (parameter == responseData[i].key) {
                    $scope.deposit_key = parameter;
                    $('#dataReport input[type=checkbox]').eq(i).prop('checked', true);
                    return;
                }
            }
        }, 300)
    };
    $scope.marginCheck = function (index, key) {
        $scope.account_key = $scope.tmpArrList[index].account_key;
        $scope.account_name = $scope.tmpArrList[index].hand_name;
        $scope.product_key = $scope.tmpArrList[index].symbol;
        $scope.product_market = $scope.tmpArrList[index].market;
        $scope.product_commodity = $scope.tmpArrList[index].commodity;
        $scope.product_contract = $scope.tmpArrList[index].contract;

        $scope.deposit_marginRatio = $scope.marginList[index].marginRatio;
        $scope.deposit_marginFix = $scope.marginList[index].marginFix;
        $scope.endTime = $scope.formatTime($scope.marginList[index].endTime);
        $scope.startTime = $scope.formatTime($scope.marginList[index].startTime);

        var userIdChecked = localStorageService.get('userIdChecked');
        $('#dataReport input[type=checkbox]').prop('checked', false);
        if (key == userIdChecked) {
            localStorageService.clear('userIdChecked');
            $scope.deposit_key = '';
        } else {
            $('#dataReport input[type=checkbox]').eq(index).prop('checked', true);
            localStorageService.update('userIdChecked', key);
            $scope.deposit_key = key;
        }

    };
    //修改
    $scope.marginCompile = function () {
        $scope.dateTime = function (parameter) {
            var str1 = parameter.split(":");
            var h = parseInt(str1[0], 10) * 3600;
            var m = parseInt(str1[1], 10) * 60;
            var s = parseInt(str1[2], 10);
            return h + m + s;
        };
        var symbols = new Object();
        if ($scope.co_symbols == undefined) {
            symbols = {
                key: $scope.product_key,
                market: $scope.product_market,
                commodity: $scope.product_commodity,
                contract: $scope.product_contract
            }
        } else {
            symbols = {
                key: $scope.co_symbols.split(':')[0],
                market: $scope.co_symbols.split(':')[1].split('-')[0],
                commodity: $scope.co_symbols.split(':')[1].split('-')[1],
                contract: $scope.co_symbols.split(':')[1].split('-')[2]
            }
        }
        // if ($scope.co_account == undefined) {
        //     $scope.co_account = $scope.account_key;
        // } else {
        //     $scope.co_account == $scope.co_account;
        // }
        $scope.editShowing = false;
        var upSymbolMarginPara = {
            key: $scope.deposit_key,
            account: ($scope.co_account == undefined) ? $scope.account_key : $scope.co_account,
            symbol: symbols.key,
            market: symbols.market,
            commodity: symbols.commodity,
            contract: symbols.contract,
            startTime: $scope.dateTime($scope.startTime),
            endTime: $scope.dateTime($scope.endTime),
            marginRatio: parseFloat($scope.deposit_marginRatio),
            marginFix: parseFloat($scope.deposit_marginFix)
        };
        var json = {
            upSymbolMarginPara: upSymbolMarginPara
        };
        if (toValidate('#formEdit')) {
            marginParametersSer.marginModify(json)
                .then(function (response) {
                    if (response.code == "000000") {
                        $rootScope.tipService.setMessage(response.message, 'warning');
                        $scope.copyDataArray = '';
                        $scope.deposit();
                    } else {
                        $rootScope.tipService.setMessage('请求参数错误', 'warning');
                    }
                })
        }
    };

    //删除
    $scope.delete = function () {
        if (!$scope.deposit_key) {
            $rootScope.tipService.setMessage('请先选择账号!', 'warning');
        } else {
            var json = {
                key: $scope.deposit_key
            };
            confirmService.set('确认提示', '确定要注销此账号吗?', function () {
                marginParametersSer.marginDelete(json).then(function (res) {
                    if (res.data.code == "000000") {
                        $rootScope.tipService.setMessage(res.message, 'warning');
                        $scope.deposit();
                    } else {
                        $rootScope.tipService.setMessage(res.message, 'warning');
                    }
                }, function (error) {
                    $rootScope.tipService.setMessage(error.message, 'warning');
                });
                confirmService.clear();
            })
        }
    };
    //分页
    var pageJump = function (tmpArrList) {
        $timeout(function () {
            if (tmpArrList != undefined) {
                $scope.currentPage = 1;//当前页数
                $scope.dataNum = tmpArrList.length;
                $scope.showDataChoose = getPageNum.pageNum();//获取分页
                $scope.showNum = $scope.showDataChoose[0];//初始显示刷具条数
                $scope.showPage = false;
                $timeout(function () {
                    $scope.showPage = true;
                    $scope.copyDataArray = tmpArrList.slice(0, 14); //初始15条数据
                }, 10)
                $scope.dataPage = Math.ceil($scope.dataNum / $scope.showNum.showNum);

                //上下页
                $scope.pageSlect = function (type) {
                    if (type == 'prev') {
                        if ($scope.currentPage != 1) {
                            $scope.currentPage--;
                            $scope.turnPage();
                        } else {
                            $scope.copyDataArray = tmpArrList.slice(0, 14); //初始15条数据
                        }
                    }
                    else {
                        if ($scope.currentPage < $scope.dataPage) {
                            $scope.currentPage++;
                            $scope.turnPage();
                        }
                    }
                }
                //每页数据量
                $scope.baseDataArray = [];
                $scope.copyDataArray = [];
                $scope.pageSelect = function (params) {
                    $scope.showNum.showNum = params.showNum;
                    $scope.copyDataArray = tmpArrList.slice(0, (params.showNum - 1));
                    $scope.dataPage = Math.ceil($scope.dataNum / $scope.showNum.showNum);
                    $scope.currentPage = 1;
                }
                $scope.turnPage = function () {
                    $scope.copyDataArray = tmpArrList.slice((($scope.currentPage - 1) * 15), (($scope.currentPage + 1) * 15 - 1));
                }
                //固定页面跳转
                $scope.jumpPage = function (num) {
                    num = parseInt(num);
                    if (parseInt(num, 10) === num && num <= ($scope.dataPage + 1) && num > 0) {
                        $scope.currentPage = num;
                        $scope.jumpPageNum = '';
                        $scope.turnPage();
                    } else {
                        $scope.copyDataArray = tmpArrList.slice(0, 14); //初始15条数据
                    }
                }
            } else {
                pageJump(tmpArrList);
            }
        }, 200);
    };
}])
// Service----上手保证金参数 —查询 terry
    .factory('marginParametersSer', ['$http', 'dataFilter', 'localStorageService', 'myHttp', '$q', '$rootScope', function ($http, dataFilter, localStorageService, myHttp, $q, $rootScope) {
        return {
            marginSearch: function () {
                var data = new Object();
                var deferred = $q.defer();
                $http({
                    method: "GET",
                    url: $rootScope.baseUrl + "c/up/symbol/margin/para/query/all",
                    data: data,
                    headers: {
                        'Content-Type': 'application/json;charset=UTF-8'
                    }
                }).success(function (res) {
                    deferred.resolve(res);
                }).error(function (res) {
                    deferred.reject(res);
                });
                return deferred.promise;
            },
            marginPlus: function (json) {
                var deferred = $q.defer();
                $http({
                    method: "POST",
                    url: $rootScope.baseUrl + "c/up/symbol/margin/para/insert",
                    data: json,
                    headers: {
                        'Content-Type': 'application/json;charset=UTF-8'
                    }
                }).success(function (res) {
                    deferred.resolve(res);
                }).error(function (res) {
                    deferred.reject(res);
                });
                return deferred.promise;
            },
            marginModify: function (compileData) {
                var deferred = $q.defer();
                $http({
                    method: "POST",
                    url: $rootScope.baseUrl + "c/up/symbol/margin/para/modify",
                    data: compileData,
                    headers: {
                        'Content-Type': 'application/json;charset=UTF-8'
                    }
                }).success(function (res) {
                    deferred.resolve(res);
                }).error(function (res) {
                    deferred.reject(res);
                });
                return deferred.promise;
            },
            marginDelete: function (json) {
                var deferred = $q.defer();
                $http({
                    method: "POST",
                    url: $rootScope.baseUrl + "c/up/symbol/margin/para/delete",
                    data: json,
                    headers: {
                        'Content-Type': 'application/json;charset=UTF-8'
                    }
                }).success(function (res) {
                    deferred.resolve(res);
                }).error(function (res) {
                    deferred.reject(res);
                });
                return deferred.promise;
            },
            productSearch: function () {
                var deferred = $q.defer();
                var data = new Object();
                $http({
                    method: "GET",
                    url: $rootScope.baseUrl + "c/up/symbol/query/all",
                    data: data,
                    headers: {
                        'Content-Type': 'application/json;charset=UTF-8'
                    }
                }).success(function (res) {
                    deferred.resolve(res);
                }).error(function (res) {
                    deferred.reject(res);
                });
                return deferred.promise;
            },
            accountSearch: function () {
                var data = new Object();
                var deferred = $q.defer();
                $http({
                    method: "GET",
                    url: $rootScope.baseUrl + "c/up/account/query/all",
                    data: data,
                    headers: {
                        'Content-Type': 'application/json;charset=UTF-8'
                    }
                }).success(function (res) {
                    deferred.resolve(res);
                }).error(function (res) {
                    deferred.reject(res);
                });
                return deferred.promise;
            }
        }
    }])


