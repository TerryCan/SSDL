app.controller("upaccountmapCtrl", ["$scope", "upaccountmapCtrlSer","getPageNum", "tipService", "confirmService", "dataSer", "$timeout", "$rootScope","localStorageService", "timestamp","transactionMappingCtrlSer","accountManagementSer", function ($scope, upaccountmapCtrlSer, getPageNum, tipService, confirmService, dataSer, $timeout, $rootScope, localStorageService, timestamp,transactionMappingCtrlSer,accountManagementSer) {
    $scope.toggleTraderSearchState = false;
    $scope.Toggle = function () {
        $scope.toggleTraderSearchState = !$scope.toggleTraderSearchState;
        if ($scope.toggleTraderSearchState) {
            $('.search_column').css('height', 'auto');
        } else {
            $('.search_column').css('height', '36px');
        }
    };
    localStorageService.clear('userIdChecked');
    //全部状态下所属机构
    dataSer.organizeQuerylistSer()
        .then(function(res) {
            $scope.orgAllList = res;
        });
    $scope.search = function (type) {
        $scope.toggleTraderSearchState=false;
        $('.search_column').css('height', '36px');
        if (type == 'search') {
            pageInitialize();
        }
        $scope.orgCode=localStorageService.get('oldOrgCode');
        var json = {
            page: $scope.currentPage,
            rows: $scope.showNum.showNum,
            order: 'desc',
        };
        if($scope.organizeValue==true && $scope.downOrganizeValue==true){
            json.search_A_LLIKE_orgCode=($scope.orgCode)?$scope.orgCode:'';
        }
        if($scope.organizeValue==true && $scope.downOrganizeValue==false){
            json.search_A_EQ_orgCode=($scope.orgCode)?$scope.orgCode:'';
        }
        if($scope.organizeValue==false && $scope.downOrganizeValue==true){
            json.search_A_LLIKE_orgCode=($scope.orgCode)?$scope.orgCode+'-':'';
        }
        upaccountmapCtrlSer.search(json)
            .then(function (res) {
                if (res.code == '000000') {
                    $scope.Resultlist = JSON.parse(res.content);
                    $scope.Result=$scope.Resultlist.content
                    console.log($scope.Result);
                    $scope.showPage = true;
                    $scope.dataNum = $scope.Resultlist.totalElements;
                    $scope.PageNum();
                    $scope.orgCode = '';
                }
                else {
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                }
            }, function (error) {
                $rootScope.tipService.setMessage(error.message, 'warning');
            });
    };

    //上手机构
    $scope.adjustText = function(opponentOrgCode) {
        if ($scope.orgAllList) {
            for (var i = 0, r = $scope.orgAllList.length; i < r; i++) {
                if ($scope.orgAllList[i].orgCode == opponentOrgCode) {
                    return $scope.orgAllList[i].orgName;

                }
            }
        }
    }

    $scope.getOrgVal = function(orgCode) {
        if ($scope.orgAllList) {
            for (var i = 0; i < $scope.orgAllList.length; i++) {
                if (orgCode == $scope.orgAllList[i].orgCode) {
                    return $scope.orgAllList[i].orgName;
                }
            }
        }
    }
    //上手账号
    accountManagementSer.accountSearch()
        .then(function(response) {
            var accountList = response.list;
            console.log(accountList)
            $scope.accountList = accountList;
            //console.log($scope.accountList);
        })

    $scope.selectAction = function() {
        var upName = $scope.phchannellist.split('-');
        console.log(upName)
        var phchannelId = upName[0];
        var phchannelName = upName[1];
        console.log(phchannelId)
        //可交易商品查询
        transactionMappingCtrlSer.symbolSearch(phchannelId)
            .then(function(res) {
                console.log(res)
                $scope.tradeList = res.data.list;
                console.log($scope.tradeList);
            }, function(error) {
                console.log(error);
            })

        //上手账号机构查询
        transactionMappingCtrlSer.accountSer(phchannelId)
            .then(function(res) {
                console.log(res)
                $scope.organizelist = res;
                //console.log($scope.organizelist)
            }, function(error) {
                console.log(error);
            })

    }
    //所属机构
    dataSer.organizeQuerySer()
        .then(function(res) {
            $scope.orgList = res;
            console.log($scope.orgList);
        });
    $scope.addOrgValFTC=function(v){
        console.log(v)
        $scope.OrgId =v.orgId;
        $scope.OrgCode = v.orgCode;
        $scope.addOrgVal = v.text;

    }

    $scope.addPsOrgValFTC = function(d) {
        console.log(d);
        $scope.opponentOrgId = d.OrgId;
        $scope.opponentOrgCode = d.OrgCode;
        $scope.addPsOrgVal = d.text;
    }
   $scope.add=function(){
    $scope.tableshow=true;
    $scope.addEditText="新增";
    $scope.addOrgVal="";
    $scope.phchannellist="";
    $scope.addPsOrgVal="";
   }
    // 选择
    $scope.checkedTab1 = function(index,orgPhchannelMapId,opponentOrgCode,orgCode,phchannelName) {
        $scope.chooseUserData = {
            orgPhchannelMapId: orgPhchannelMapId,
            opponentOrgCode:opponentOrgCode,
            orgCode:orgCode,
            phchannelName:phchannelName,
        };
        console.log($scope.chooseUserData)
        var userIdChecked = localStorageService.get('userIdChecked');
        $('#dataReport input[type=checkbox]').prop('checked', false);
        if (orgPhchannelMapId == userIdChecked) {
            localStorageService.clear('userIdChecked');
            $scope.chooseItemTab1 = '';
        } else {
            $('#dataReport input[type=checkbox]').eq(index).prop('checked', true);
            localStorageService.update('userIdChecked', orgPhchannelMapId);
            $scope.chooseItemTab1 = orgPhchannelMapId;
        }
    };
    // 存储选中
    $scope.switchUserId = function(parameter, responseData) {
        console.log(responseData)
        $timeout(function() {
            for (var i = 0; i < responseData.length; i++) {
                if (parameter == responseData[i].orgPhchannelMapId) {
                    $('#dataReport input[type=checkbox]').eq(i).prop('checked', true);
                    return;
                }
            }
        }, 1500)
    };
    $scope.edit = function() {
        if (!$scope.chooseItemTab1) {
            $rootScope.tipService.setMessage('请选择上手账号映射信息', 'warning');
        } else {
            $scope.tableshow = true;
            $scope.addEditText = "修改";
            $scope.addOrgVal="";
            $scope.phchannellist="";
            $scope.addPsOrgVal="";

        }
    }
   
   $scope.addSubmit=function () {
        if($scope.addEditText=="新增"){
            var upName = $scope.phchannellist.split('-');
            console.log(upName)
            var phchannelId = upName[0];
            var phchannelName = upName[1];
            console.log($scope.phchannellist)
            var orgPhchannelMapVIce={
                orgId:$scope.OrgId,
                orgCode:$scope.OrgCode,
                phchannelId:phchannelId,
                phchannelName:phchannelName,
                opponentOrgId:$scope.opponentOrgId,
                opponentOrgCode:$scope.opponentOrgCode,

            }
            console.log(orgPhchannelMapVIce)
            var json={
                orgPhchannelMapVIce:orgPhchannelMapVIce
            }
            upaccountmapCtrlSer.add(json)
                .then(function(res){
                    console.log(res)
                    if(res.data.code="000000"){
                        $scope.tableshow=false;
                        $rootScope.tipService.setMessage(res.data.codeName, 'warning');
                        $scope.search();
                    }else{
                        $rootScope.tipService.setMessage(res.data.codeName, 'warning');
                    }
                })
        }else if ($scope.addEditText == '修改') {
            var upName = $scope.phchannellist.split('-');
            console.log(upName)
            var phchannelId = upName[0];
            var phchannelName = upName[1];
            console.log($scope.phchannellist)
            var orgPhchannelMapVIce = {
                orgPhchannelMapId:$scope.chooseItemTab1,
                orgId: $scope.OrgId,
                orgCode: $scope.OrgCode,
                phchannelId: phchannelId,
                phchannelName: phchannelName,
                opponentOrgId: $scope.opponentOrgId,
                opponentOrgCode: $scope.opponentOrgCode,

            }
            console.log(orgPhchannelMapVIce)
            var json = {
                orgPhchannelMapVIce: orgPhchannelMapVIce
            }
            upaccountmapCtrlSer.edit(json)
                .then(function (res) {
                    console.log(res)
                    if (res.data.code = "000000") {
                        $scope.tableshow = false;
                        $rootScope.tipService.setMessage(res.data.codeName, 'warning');
                        $scope.search();
                    } else {
                        $rootScope.tipService.setMessage(res.data.codeName, 'warning');
                    }
                })
             }
         }

    //删除
    $scope.delete = function() {
        if (!$scope.chooseItemTab1) {
            $rootScope.tipService.setMessage('请选择上手账号映射信息', 'warning');
        } else {
            confirmService.set('确认提示', '确定要删除此上手账号映射信息?', function() {
                upaccountmapCtrlSer.Delete($scope.chooseItemTab1)
                    .then(function(res) {
                        if (res.data.code == "000000") {
                            $rootScope.tipService.setMessage(res.data.message, 'warning');
                            $scope.search();
                        } else {
                            $rootScope.tipService.setMessage(res.data.message, 'warning');
                        }
                    }, function(error) {
                        $rootScope.tipService.setMessage(error.data.message, 'warning');
                    });
                confirmService.clear();
            });
        }
    }

    $scope.getCheck=function(){
        if (!$scope.chooseItemTab1) {
            $rootScope.tipService.setMessage('请选择上手账号映射信息', 'warning');
        } else {
            upaccountmapCtrlSer.details($scope.chooseItemTab1)
                .then(function(res) {
                    console.log(res)
                    if(res.data.code=="000000"){
                    $scope.tableshowmx=true;
                    $scope.resultsDetails= JSON.parse(res.data.content);
                    console.log($scope.resultsDetails);
                    $scope.phchannellist=$scope.resultsDetails.phchannelName;
                        //匹配机构代码
                        var json = {
                            page: 1,
                            rows: 9999,
                            search_A_EQ_state: 1
                        };
                        dataSer.getOrganize(json).then(function (res) {
                            if (res.code == '000000') {
                                $scope.equalOrgCode = JSON.parse(res.content).content;
                                //console.log($scope.equalOrgCode);
                                for (var i = 0; i < $scope.equalOrgCode.length; i++) {
                                    if ($scope.resultsDetails.orgCode== $scope.equalOrgCode[i].orgCode) {
                                        $scope.addOrgVal =$scope.equalOrgCode[i].orgName+'('+$scope.equalOrgCode[i].orgNum+')';
                                        //console.log($scope.addOrgVal)
                                    }
                                }
                                for (var i = 0; i < $scope.equalOrgCode.length; i++) {
                                    if ($scope.resultsDetails.opponentOrgCode== $scope.equalOrgCode[i].orgCode) {
                                        $scope.addPsOrgVal =$scope.equalOrgCode[i].orgName+'('+$scope.equalOrgCode[i].orgNum+')';
                                        //console.log($scope.addOrgVal)
                                    }
                                }
                            } else {
                                console.log(res);
                            }
                        });
                    }else{
                        $rootScope.tipService.setMessage(res.data.message, 'warning');
                    }
                    },function(error) {
                        $rootScope.tipService.setMessage(error.data.message, 'warning');
                })
        }
    }

    /**
     * 分页功能实现TerryMin
     * **/
    $scope.showDataChoose = getPageNum.pageNum(); //获取分页
    $scope.showNum = $scope.showDataChoose[0]; //初始显示刷具条数

    $scope.showPage = false;
    var pageInitialize = function () {
        $scope.dataNum = 0; //数据总条数
        $scope.dataPage = 0; //分页数
        $scope.currentPage = 1; //当前页数
        $scope.jumpPageNum = '';
    };
    pageInitialize();
    // x/y $scope.dataPage
    $scope.PageNum = function () {
        if ($scope.showNum.showNum < $scope.dataNum) {
            $scope.dataPage = Math.ceil($scope.dataNum / $scope.showNum.showNum);
        } else {
            $scope.dataPage = 0;
        }
        if ($scope.dataPage > 1 && $scope.currentPage > 0) {
            if ($scope.dataPage < $scope.currentPage) {
                $scope.currentPage = 1;
                $scope.search();
            }
        }
    };
    //上页下页 $scope.currentPage
    $scope.pageSlect = function (type) {
        if (type == 'prev') {
            if ($scope.currentPage != 1) {
                $scope.currentPage--;
                $scope.PageNum();
                $scope.search();
            }
        } else {
            if ($scope.currentPage < $scope.dataPage) {
                $scope.currentPage++;
                $scope.PageNum();
                $scope.search();
            }
        }
    };
    // 每页条数单元
    $scope.pageSelect = function (params) {
        $scope.showNum.showNum = params.showNum;
        pageInitialize();
        $scope.search();
    };
    //页数跳转 currentPage
    $scope.jumpPage = function (num) {
        num = parseInt(num);
        if (parseInt(num, 10) === num && num <= ($scope.dataPage + 1) && num > 0) {
            $scope.currentPage = num;
            $scope.PageNum();
            $scope.search();
        }
    };
}])
//角色管理
    .factory('upaccountmapCtrlSer', ['$http', 'localStorageService', 'myHttp', '$q', '$rootScope', function ($http, localStorageService, myHttp, $q, $rootScope) {
        return {
            search: function(json) {
                var deferred = $q.defer();
                myHttp.post("config/org/phchannelmap/query/as/page", json)
                    .then(function(res) { // 调用承诺API获取数据 .resolve
                        deferred.resolve(res);
                    }, function(res) { // 处理错误 .reject
                        deferred.reject(res);
                    });
                return deferred.promise;
            },

            add: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'config/org/phchannelmap/create',
                    data:json
                }).then(function successCallback(response) {
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
            edit: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'config/org/phchannelmap/update',
                    data:json
                }).then(function successCallback(response) {
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
            Delete: function(chooseItemTab1){
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'config/org/phchannelmap/del',
                    data: {
                        "orgPhchannelMapId": chooseItemTab1
                    }
                }).then(function successCallback(response) {
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
            details: function(chooseItemTab1){
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'config/org/phchannelmap/get',
                    data: {
                        "orgPhchannelMapId": chooseItemTab1
                    }
                }).then(function successCallback(response) {
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            }
        }
    }])