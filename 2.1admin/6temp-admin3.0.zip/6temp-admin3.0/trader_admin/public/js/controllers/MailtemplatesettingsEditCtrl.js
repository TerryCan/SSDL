app.controller('MailtemplatesettingsEditCtrl',['$scope', 'dataSer','MailtemplatesettingsCtrllSer','MailtemplatesettingsEditCtrlSel', '$state', '$rootScope', 'memberMangerCtrlSer', 'localStorageService','MailtemplatesettingsAddCtrlSel', function($scope, dataSer, MailtemplatesettingsCtrllSer,MailtemplatesettingsEditCtrlSel,$state, $rootScope, memberMangerCtrlSer,localStorageService,MailtemplatesettingsAddCtrlSel) {
			//匹配机构代码
		    var json = {
		        page: 1,
		        rows: 9999,
		        search_A_EQ_state: 1
		    };
		    dataSer.getOrganize(json).then(function (res) {
		        if (res.code == '000000') {
		            $scope.equalOrgCode = JSON.parse(res.content).content;
		            console.log($scope.equalOrgCode);
		            for (var i = 0; i < $scope.equalOrgCode.length; i++) {
		                if ($scope.allotOrgId== $scope.equalOrgCode[i].orgId) {
		                    $scope.addOrgVal =$scope.equalOrgCode[i].orgName+'('+$scope.equalOrgCode[i].orgNum+')';
		                    console.log($scope.addOrgVal)
		                }
		            }
		        } else {
		            console.log(res);
		        }
		    });
	var E = window.wangEditor;
		var editor = new E('#editor');
		editor.create();
		var htmls = editor.txt.html();
		$scope.goBack = function() {
				$state.go('tabs.Mailtemplatesettings');
			}
				//匹配机构代码
		    var json = {
		        page: 1,
		        rows: 9999,
		        search_A_EQ_state: 1
		    };
		    dataSer.getOrganize(json).then(function (res) {
		        if (res.code == '000000') {
		            $scope.equalOrgCode = JSON.parse(res.content).content;
		            console.log($scope.equalOrgCode);
		            for (var i = 0; i < $scope.equalOrgCode.length; i++) {
		                if ($scope.orgIdVal== $scope.equalOrgCode[i].orgId) {
		                    $scope.addOrgVal =$scope.equalOrgCode[i].orgName+'('+$scope.equalOrgCode[i].orgNum+')';
		                    console.log($scope.addOrgVal)
		                }
		            }
		        } else {
		            console.log(res);
		        }
		    });


		var choosemailTemplateId = localStorageService.get('MailemailTemp');
		console.log(choosemailTemplateId)
		MailtemplatesettingsCtrllSer.getNTInfo(choosemailTemplateId)
			.then(function(res) {
				console.log(res)
				if (res.data.code == '000000') {
					var dataVal = JSON.parse(res.data.content);
					console.log(dataVal);
					$scope.orgCodeVal=dataVal.orgCode;
					$scope.orgIdVal=dataVal.orgId;
					$scope.emailTemplateId = dataVal.emailTemplateId;
					$scope.readType= dataVal.type;
					$scope.subject = dataVal.subject;
					$scope.contentText = dataVal.text;
					editor.txt.html($scope.contentText);
				}
			});
		dataSer.organizeQuerySer()
			.then(function(res) {
				console.log(res)
				$scope.orgList = res;
				//console.log($scope.orgList)
			});
		$scope.allnotlickList = [];
		$scope.copyuesrList = [];
		$scope.addOrgValFTC = function(d) {
				//console.log(data);
				$scope.allotOrgId = d.orgId;
				$scope.superorgCode = d.orgCode;
				$scope.addOrgVal = d.text;
			}

		//切换
		$scope.TypeSelect = function() {
			var json={
				type:$scope.readType
			};
			MailtemplatesettingsAddCtrlSel.zwf(json)
			.then(function(res){
			if(res.data.code=="000000"){
				$scope.zwflist=JSON.parse(res.data.content);
				console.log($scope.zwflist)
			}else{
				$rootScope.tipService.setMessage(res.data.message, 'warning');

			}},function(error){
				$rootScope.tipService.setMessage(error.data.message, 'warning');
			})

			}
		$scope.Zwchange=function(){
			if($scope.Zwselect == undefined || $scope.Zwselect == '') {
				$rootScope.tipService.setMessage('请先选择占位符', 'warning');
			}else{
				 editor.txt.append('<span>'+$scope.Zwselect+'<span>')
					 console.log()
			}
		}

		//修改
		$scope.addNoticeInfo = function() {
			$scope.contentText = editor.txt.html();
			var emailTemplate = {
				emailTemplateId:$scope.emailTemplateId,
				orgId:$scope.orgIdVal,
				orgCode:$scope.orgCodeVal,
				subject:$scope.subject,
				text:$scope.contentText,
				type:$scope.readType
			}
			console.log(emailTemplate)
			var json = {
				emailTemplate: emailTemplate
			}
			MailtemplatesettingsEditCtrlSel.modify(json)
				.then(function(res) {
					console.log(res)
					if (res.data.code =="000000") {
						$rootScope.tipService.setMessage(res.data.message, 'warning');
						$state.go('tabs.Mailtemplatesettings');
					} else {
						$rootScope.tipService.setMessage(res.data.message, 'warning');
					}
				},function(error){
					$rootScope.tipService.setMessage(error.data.message, 'warning');
				})
		}
	}])
	.factory('MailtemplatesettingsEditCtrlSel', ['$http', '$q', '$rootScope', function($http, $q, $rootScope) {
		return {
			modify: function(json) {
				var deferred = $q.defer();
				$http({
						method: 'POST',
						url: $rootScope.baseUrl + 'email/template/save',
						data: json
					})
					.then(function(res) { // 调用承诺API获取数据 .resolve
						deferred.resolve(res);
					}, function(res) { // 处理错误 .reject
						deferred.reject(res);
					});
				return deferred.promise;
			}

		}
	}])