app.controller('PersonalizedOrganizationAddCtrl', ['$scope', '$state', '$rootScope', 'localStorageService','PersonalizedOrganizationAddCtrllSer','dataSer', function($scope, $state, $rootScope, localStorageService,PersonalizedOrganizationAddCtrllSer,dataSer) {
		console.log(123)
			//页面跳转
				$scope.goBack = function() {
				$state.go('tabs.PersonalizedOrganization');
			}
			dataSer.organizeQuerySer()
			.then(function(res) {
				console.log(res)
				$scope.orgList = res;
				//console.log($scope.orgList)
			});
			$scope.addOrgValFTC = function(d) {
				//console.log(data);
				$scope.allotOrgId = d.orgId;
				$scope.superorgCode = d.orgCode;
				$scope.addOrgVal = d.text;
			}
				$scope.addOrgVal="";	//机构编号
				$scope.orgLogoFileId="";//机构LOGO文件Id
				$scope.LogouploadfileVal="";
				$scope.clientQRFileId="";//退出logo
				$scope.LogoFileIdImgVal="";
				$scope.orgAdminLogoFileId="";//机构管理端LOGO文件Id
				$scope.orgServiceHotline="";//机构服务热线
				$scope.orgAdminServiceHotline="";//管理端机构服务热线
				$scope.orgOfficialUrl="";//机构官方url
				$scope.orgAdminOfficialUrl="";//机构管理官方url
				$scope.clientSysName="";//客户端系统名称
				$scope.clientSysEnglishName="";//客户端英文系统名称
				$scope.adminSysName="";//后台系统统名称
				$scope.adminSysEnglishName="";//后台英文系统统名称
				$scope.remark="";//备注
				$scope.createTime="";//创建时间

		 //图片上传
        uploadImg = function(id, num) {
            console.log(id,num);
            var urlUpload = $rootScope.baseUrl + 'file/upload';
            upload_img(urlUpload, id, function(res, status) {
                if (res.code === '000000') {
                    var data = JSON.parse(res.content);
                    console.log(data);
                    var ImgId = data[0].fileId;
                    switch (num) {
                        case 1:
                            $scope.orgLogoFileIdImg1 = ImgId;
                            //console.log($scope.orgLogoFileIdImg1)
                            $('#uploadfile').attr('src', "" + $rootScope.baseUrl + "/file/download?fileId=" + ImgId + "");
                            break;
                        case 2:
                            $scope.orgLogoFileIdImg3 = ImgId;
                            $('#uploadfile3').attr('src', "" + $rootScope.baseUrl + "/file/download?fileId=" + ImgId + "");
                            break;
                        case 3:
                            $scope.LogoFileIdImgVal = ImgId;
                            $('#LogouploadfileVal').attr('src', "" + $rootScope.baseUrl + "/file/download?fileId=" + ImgId + "");
                            break;
                        case 4:
                            $scope.clientQRFileId = ImgId;
                            $('#clientQRFileIdVal').attr('src', "" + $rootScope.baseUrl + "/file/download?fileId=" + ImgId + "");
                            break;
                    }
                }
            });
        };

        // 上传图片
        // url:后台访问路径 fileId:input file按钮id, btn:点击的按钮id, fileInput:接收上传图片的id
        function upload_img(url, fileId, callback) {
            $.ajaxFileUpload({
                url: url,
                type: 'post',
                secureuri: false,
                fileElementId: fileId, // file标签的id
                dataType: 'json', // 返回数据的类型
                data: {
                    name: fileId
                },
                success: function(data, status) {
                    callback(data, status);
                },
                error: function(data, status, e) {
                    console.log(data, status, e);
                }
            });
        }




		$scope.CustomizeaddInfo = function() {
			var orgCustomize = {
				orgId:$scope.allotOrgId,	//机构编号
				orgCode:$scope.superorgCode,	//机构代码
				orgLogoFileId:$scope.orgLogoFileIdImg1, //机构LOGO文件Id
				clientHomeFileId:$scope.LogoFileIdImgVal,
				orgAdminLogoFileId:$scope.orgLogoFileIdImg3, //机构管理端LOGO文件Id
				clientQRFileId:$scope.clientQRFileId,
				orgServiceHotline:$scope.orgServiceHotline, //机构服务热线
				orgAdminServiceHotline:$scope.orgAdminServiceHotline, //管理端机构服务热线
				orgOfficialUrl:$scope.orgOfficialUrl, //机构官方url
				orgAdminOfficialUrl:$scope.orgAdminOfficialUrl,//机构管理官方url
				clientSysName:$scope.clientSysName,//客户端系统名称
				clientSysEnglishName:$scope.clientSysEnglishName,//客户端英文系统名称
				adminSysName:$scope.adminSysName,//后台系统统名称
				adminSysEnglishName:$scope.adminSysEnglishName,//后台英文系统统名称
				remark:$scope.remark	//备注
			}
			var json = {
				orgCustomize: orgCustomize
			}
			if (toValidate('#PersonalizedAdd')) {
			PersonalizedOrganizationAddCtrllSer.addInfo(json)
				.then(function(res) {
					if (res.data.code =="000000") {
						$rootScope.tipService.setMessage(res.data.message, 'warning');
						$state.go('tabs.PersonalizedOrganization');
					}else{
						$rootScope.tipService.setMessage(res.data.message, 'warning');
					}

				})
			}
			}
			 //放大图片
    $('.example img').zoomify();
   /* var imgs = document.getElementsByTagName("img");
    var lens = imgs.length;
    var popup = document.getElementById("popup");

    for (var i = 0; i < lens; i++) {
        imgs[i].onclick = function (event) {
            event = event || window.event;
            var target = document.elementFromPoint(event.clientX, event.clientY);
            showBig(target.src);
        }
    }
    popup.onclick = function () {
        popup.style.display = "none";
    };

    function showBig(src) {
        popup.getElementsByTagName("img")[0].src = src;
        popup.style.display = "block";
    }*/


	}])
	.factory('PersonalizedOrganizationAddCtrllSer', ['$http', 'localStorageService', 'myHttp', '$q', '$rootScope', function($http, localStorageService, myHttp, $q, $rootScope) {
		return {

				addInfo: function(json) {
				var deferred = $q.defer();
				$http({
						method: 'POST',
						url: $rootScope.baseUrl + 'customize/org/customized/save',
						data: json
					})
					.then(function(res) { // 调用承诺API获取数据 .resolve
						deferred.resolve(res);
					}, function(res) { // 处理错误 .reject
						deferred.reject(res);
					});
				return deferred.promise;
			}
		}
	}])