app.controller('payRunSearchCtrl', ['$rootScope', '$scope', 'payRunSearchSer','$timeout', '$sce', 'getPageNum', 'getCurrencyType', 'getAccountTradeType','timestamp','getExternalResult','localStorageService', function ($rootScope, $scope, payRunSearchSer,$timeout, $sce, getPageNum, getCurrencyType,getAccountTradeType,timestamp,getExternalResult,localStorageService) {
    $scope.toggleTraderSearchState=false;
    $scope.Toggle = function(){
        $scope.toggleTraderSearchState = !$scope.toggleTraderSearchState;
        if($scope.toggleTraderSearchState){
           $('.search_column').css('height','auto');
        }
        else{
           $('.search_column').css('height','36px');
        }
    };

    //时间戳
    $scope.timeSwitch = function (stamp) {
        return timestamp.timestampCoverHms(stamp, 'all')
    };
    // 货币转换
    getCurrencyType.then(function (res) {
        $scope.currencyList = JSON.parse(res.content);
    });
    $scope.getCurrency = function (parameter) {
        if ($scope.currencyList) {
            for (var i = 0; i < $scope.currencyList.length; i++) {
                if (parameter == $scope.currencyList[i].currency) {
                    return $scope.currencyList[i].currencyName;
                }
            }
        }
    };
    // 交易类型
    $scope.accountTradeType = getAccountTradeType;
    $scope.getAccountTradeType = function (params) {
        for (var i = 0, r = $scope.accountTradeType.length; i < r; i++) {
            if (params == $scope.accountTradeType[i].id) {
                return $scope.accountTradeType[i].name;
            }
        }
    };
    //出金状态
    $scope.switchExternalResult = function (params) {
        for (var i = 0, r = getExternalResult.length; i < r; i++) {
            if (params == getExternalResult[i].id) {
                return getExternalResult[i].name;
            }
        }
    };

    $scope.userName = '';
    $scope.createTimeStart='';
    $scope.createTimeEnd='';
    $scope.transType = '';
    $scope.currency = '';
    var processContent, processTotal;
    var source = {
        type: 'POST',
        datatype: "json",
        datafields: [  //数据字段定义
            {name: 'externalTransId', type: 'string'},
            {name: 'userName', type: 'string'},
            {name: 'transType', type: 'string'},
            {name: 'currency', type: 'string'},
            {name: 'externalResult', type: 'string'},
            {name: 'transMoney', type: 'string'},

            {name: 'externalReturnMessage', type: 'string'},
            {name: 'startTime', type: 'string'}
        ],
        url: $rootScope.baseUrl + 'exbank/query/transrecords/page',
        root: "content",
        pagesize: 10,
        processData: function (data) {
            data.page = (data.pagenum + 1) ? (data.pagenum + 1) : 1;
            data.rows = (data.pagesize) ? (data.pagesize) : 10;
            data.order = ($scope.order) ? $scope.order : 'desc';
            data.sort = ($scope.sort) ? $scope.sort : 'startTime';
            data.search_A_EQ_userId = ($scope.directiveUserId) ? $scope.directiveUserId : '';
            data.search_EQ_transType=($scope.transType)?$scope.transType:'';
            data.search_GTE_startTime=($scope.createTimeStartNum) ? Date.parse(new Date(timestamp.formatTimeKind($scope.createTimeStartNum))) : '';
            data.search_LTE_startTime=($scope.createTimeEndNum) ? Date.parse(new Date(timestamp.formatTimeKind($scope.createTimeEndNum))) : '';
            data.search_EQ_currency=($scope.currency)?$scope.currency:'';

            $scope.orgCode = localStorageService.get('oldOrgCode');
            if ($scope.organizeValue == true && $scope.downOrganizeValue == true) {
                data.search_A_LLIKE_orgCode = ($scope.orgCode) ? $scope.orgCode : '';
            }
            if ($scope.organizeValue == true && $scope.downOrganizeValue == false) {
                data.search_A_EQ_orgCode = ($scope.orgCode) ? $scope.orgCode : '';
            }
            if ($scope.organizeValue == false && $scope.downOrganizeValue == true) {
                data.search_A_LLIKE_orgCode = ($scope.orgCode) ? $scope.orgCode + '-' : '';
            }
        }, //传递参数处理
        beforeLoadComplete: function (records) { //数据完全加载完执行绘制表格
            console.log(records)
            var start;
            for (var i in records) {
                start = parseInt(i);
                break;
            }
            for (var k = 0, r = processContent.length; k < r; k++) {
                records[start + k].externalTransId = processContent[k].externalTransId;
                records[start + k].userName = processContent[k].userName;
                records[start + k].cardName = processContent[k].cardName;
                records[start + k].transType = processContent[k].transType;
                records[start + k].currency = processContent[k].currency;
                records[start + k].externalResult = processContent[k].externalResult;

                records[start + k].transMoney = processContent[k].transMoney;
                records[start + k].externalReturnMessage = processContent[k].externalReturnMessage;
                records[start + k].startTime = processContent[k].startTime;
            }
        },
        beforeprocessing: function (data) { //处理总页数
            console.log(data)
            var processData = JSON.parse(data.content);
            processContent = processData.content;
            source.totalrecords = processData.totalElements == 0 ? 5 : processData.totalElements;
            processTotal = processData.totalElements;
        },
        loadComplete: function (records) {
            $scope.saveResult = JSON.parse(records.content);
            var data = $scope.saveResult.totalElements;
            if (data == 0) {
                $('#contenttableentrustDetailGrid > div').remove();
            }
        },
        endUpdate: true
    };
    //创建数据适配器
    var dataAdapter = null;
    $scope.searchAjax = function () {
        $scope.toggleTraderSearchState = false;
        $('.search_column').css('height', '36px');
        if (dataAdapter == null) {
            dataAdapter = new $.jqx.dataAdapter(source);
            //创建表格
            $("#entrustDetailGrid").jqxGrid({
                source: dataAdapter,
                columns: [  //表格数据域
                    {
                        text: '商户流水号',
                        datafield: 'externalTransId',
                        width: '20%',
                        minwidth: 20 + '%',
                        align: 'center'
                    },
                    {
                        text: '用户名',
                        datafield: 'userName',
                        minwidth: 9 + '%',
                        cellsalign: 'center',
                        align: 'center',
                        width: '9%'
                    },
                    {
                        text: '交易类型',
                        datafield: 'transType',
                        width: '10%',
                        minwidth: 10 + '%',
                        align: 'center',
                        cellsrenderer: function (row, columnfield, value, defaulthtml, columnproperties) {
                            if (getAccountTradeType) {
                                for (var i = 0; i < getAccountTradeType.length; i++) {
                                    if (value == getAccountTradeType[i].id) {
                                        return getAccountTradeType[i].name;
                                    }
                                }
                            }
                        }
                    },
                    {
                        text: '币种',
                        datafield: 'currency',
                        minwidth: 9 + '%',
                        cellsalign: 'center',
                        align: 'center',
                        width: '9%',
                        cellsrenderer: function (row, columnfield, value, defaulthtml, columnproperties) {
                            if ($scope.currencyList) {
                                for (var i = 0; i < $scope.currencyList.length; i++) {
                                    if (value == $scope.currencyList[i].currency) {
                                        return $scope.currencyList[i].currencyName;
                                    }
                                }
                            }
                        }
                    },
                    {
                        text: '出金状态',
                        datafield: 'externalResult',
                        minwidth: 10 + '%',
                        align: 'center',
                        width: '10%',
                        cellsrenderer: function (row, columnfield, value, defaulthtml, columnproperties) {
                            if (getExternalResult) {
                                for (var i = 0; i < getExternalResult.length; i++) {
                                    if (value == getExternalResult[i].id) {
                                        return getExternalResult[i].name;
                                    }
                                }
                            }
                        }
                    },
                    {
                        text: '金额',
                        datafield: 'transMoney',
                        minwidth: 10 + '%',
                        cellsalign: 'center',
                        align: 'center',
                        width: '10%'
                    },
                    {
                        text: '备注',
                        datafield: 'externalReturnMessage',
                        minwidth: 20 + '%',
                        width: '20%',
                        align: 'center',
                        cellsrenderer: function (row, columnfield, value, defaulthtml, columnproperties) {
                            if (value==""){
                                return '成功'
                            }else{
                                return value
                            }
                        }
                    },
                    {
                        text: '日期',
                        datafield: 'startTime',
                        minwidth: 12 + '%',
                        cellsalign: 'center',
                        align: 'center',
                        width: '12%',
                        cellsrenderer: function (row, columnfield, value, defaulthtml, columnproperties) {
                            return timestamp.timestampCoverHms(value, 'all');
                        }
                    }
                ],
                width: 100 + '%',
                height: 87 + '%',
                theme: 'metrodark',
                virtualmode: true,
                rendergridrows: function (params) { //将数据渲染到页面
                    return params.data;
                },
                pageable: true,
                pagesizeoptions: ['10', '30', '100', '200'],
                sortable: true,
                // altrows: true,
                columnsresize: true,//列间距是否可调整
                selectionmode: 'singlecell',//选择模式
                clipboard: true,
            });
        } else {
            $("#entrustDetailGrid").jqxGrid('updatebounddata', 'cells');
        }
    };
    //分页
    $("#entrustDetailGrid").on("pagechanged", function (event) {
        console.log(event)
    });
    //排序
    $("#entrustDetailGrid").on("sort", function (event) {
        var sortinformation = event.args.sortinformation;
        $scope.sort = sortinformation.sortcolumn;
        $scope.order = ($scope.sort) ? (sortinformation.sortdirection.ascending) ? 'asc' : 'desc' : 'asc';
        data = {
            order: $scope.order,
            sort: $scope.sort
        };
        source.processData(data);
        $("#entrustDetailGrid").jqxGrid('updatebounddata', 'sort');
    });

    $scope.search = function (type) {
        $scope.toggleTraderSearchState=false;
        $('.search_column').css('height','36px');
        if (type == 'btnSearch') {
            pageInitialize();
        };
        $scope.orgCode=localStorageService.get('oldOrgCode');
        var json = {
            page: $scope.currentPage,
            rows: $scope.showNum.showNum,
            order:'desc',
            sort:'startTime',
            search_EQ_transType: $scope.transType,
            search_GTE_createTime: ($scope.createTimeStartNum) ? Date.parse(new Date(timestamp.formatTimeKind($scope.createTimeStartNum))) : '',
            search_LTE_createTime: ($scope.createTimeEndNum) ? Date.parse(new Date(timestamp.formatTimeKind($scope.createTimeEndNum))) : '',
            search_EQ_currency: $scope.currency,
            search_A_EQ_userId:$scope.directiveUserId
        };
        if($scope.organizeValue==true && $scope.downOrganizeValue==true){
            json.search_A_LLIKE_orgCode=($scope.orgCode)?$scope.orgCode:'';
        }
        if($scope.organizeValue==true && $scope.downOrganizeValue==false){
            json.search_A_EQ_orgCode=($scope.orgCode)?$scope.orgCode:'';
        }
        if($scope.organizeValue==false && $scope.downOrganizeValue==true){
            json.search_A_LLIKE_orgCode=($scope.orgCode)?$scope.orgCode+'-':'';
        }
        payRunSearchSer.paySearch(json)
            .then(function (response) {
                if (response.code == "000000") {
                    var data = JSON.parse(response.content);
                    $scope.searchResult = data.content;
                    console.log($scope.searchResult);
                    // console.log(typeof $scope.searchResult[2].externalTransId);
                    // console.log(typeof $scope.searchResult[2].externalReturnMessage);
                    $scope.dataNum = data.totalElements;
                    $scope.PageNum();
                } else {
                    $rootScope.tipService.setMessage(response.message, 'warning');
                }
            }, function (error) {
                $rootScope.tipService.setMessage(error.message, 'warning');
            });
        $scope.chooseItemTab1 = null;
    };
    /**
     * 分页功能实现TerryMin
     * **/
    $scope.showDataChoose = getPageNum.pageNum(); //获取分页
    $scope.showNum = $scope.showDataChoose[0]; //初始显示刷具条数

    $scope.showPage = false;
    var pageInitialize = function () {
        $scope.dataNum = 0; //数据总条数
        $scope.dataPage = 0; //分页数
        $scope.currentPage = 1; //当前页数
        $scope.jumpPageNum = '';
    };
    pageInitialize();
    // x/y $scope.dataPage
    $scope.PageNum = function () {
        $scope.showPage = true;
        if ($scope.showNum.showNum < $scope.dataNum) {
            $scope.dataPage =Math.ceil($scope.dataNum / $scope.showNum.showNum);
        } else {
            $scope.dataPage = 0;
        }
    };
    //上页下页 $scope.currentPage
    $scope.pageSlect = function (type) {
        if (type == 'prev') {
            if ($scope.currentPage != 1) {
                $scope.currentPage--;
                $scope.PageNum();
                $scope.search();
            }
        } else {
            if ($scope.currentPage < $scope.dataPage) {
                $scope.currentPage++;
                $scope.PageNum();
                $scope.search();
            }
        }
    };
    // 每页条数单元
    $scope.pageSelect = function (params) {
        $scope.showNum.showNum = params.showNum;
        pageInitialize();
        $scope.search();
    };
    //页数跳转 currentPage
    $scope.jumpPage = function (num) {
        num = parseInt(num);
        if (parseInt(num, 10) === num && num <= ($scope.dataPage + 1) && num > 0) {
            $scope.currentPage = num;
            $scope.PageNum();
            $scope.search();
        }
    };
}])
// Server
    .factory('payRunSearchSer', ['$http', 'localStorageService', 'myHttp', '$q', '$rootScope', function ($http, localStorageService, myHttp, $q, $rootScope) {
        return {
            paySearch: function (json) {
                var deferred = $q.defer();
                myHttp.post("exbank/query/transrecords/page", json)
                    .then(function (res) { // 调用承诺API获取数据 .resolve
                        deferred.resolve(res);
                    }, function (res) { // 处理错误 .reject
                        deferred.reject(res);
                    });
                return deferred.promise;

            }
        }
    }])