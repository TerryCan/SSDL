app.controller('currencyManagementCtrl', ['$rootScope', '$scope', 'getPageNum', 'currencyManagementCtrlSer', 'getClassificationState', 'dataSer', 'localStorageService', 'confirmService','$timeout','getadminState', function ($rootScope, $scope, getPageNum, currencyManagementCtrlSer, getClassificationState, dataSer, localStorageService, confirmService,$timeout,getadminState) {
    $scope.toggleTraderSearchState = false;
    $scope.Toggle = function () {
        $scope.toggleTraderSearchState = !$scope.toggleTraderSearchState;
        if ($scope.toggleTraderSearchState) {
            $('.search_column').css('height', 'auto');
        }
        else {
            $('.search_column').css('height', '36px');
        }
    };
    localStorageService.clear('userIdChecked');
    $scope.tableshow = false;
    $scope.CurrencyName='';
    $scope.ToState='';
    $scope.search = function (type) {
        $scope.toggleTraderSearchState = false;
        $('.search_column').css('height', '36px');
        if (type == 'search') {
            pageInitialize()
        };
        $scope.orgCode=localStorageService.get('oldOrgCode');
        var json = {
            page: $scope.currentPage,
            rows: $scope.showNum.showNum,
            orders: 'asc',
            //search_EQ_orgCode: ($scope.orgCode) ?  $scope.orgCode : '',
            search_EQ_state: $scope.ToState,
            search_LIKE_currencyName: $scope.CurrencyName,
            //search_LIKE_currencyGroupName: $scope.curGroupName,

        };
        currencyManagementCtrlSer.search(json)
            .then(function (res) {
                console.log(res)
                if (res.code == '000000') {
                    $scope.showPage = true;
                    var data = JSON.parse(res.content);
                    $scope.searchResult = data.content;
                    console.log($scope.searchResult);
                    $scope.dataNum = data.totalElements;
                    $scope.PageNum();

                    var checkedUserId=localStorageService.get('userIdChecked'); //获取上一次存储的id
                    $scope.switchUserId(checkedUserId,$scope.searchResult); //执行选中方法
                } else {
                    $rootScope.tipService.setMessage(res.message, 'warning');
                }
            }, function (error) {
                $rootScope.tipService.setMessage(error.message, 'warning');
            });
    }
    currencyManagementCtrlSer.searchlist()
        .then(function (res) {
        console.log(res)
        if (res.code == '000000') {
             $scope.listsResult = JSON.parse(res.content);
            console.log($scope.listsResult)
        } else {
            $rootScope.tipService.setMessage(res.message, 'warning');
        }
    }, function (error) {
        $rootScope.tipService.setMessage(error.message, 'warning');
    });

    dataSer.organizeQuerySer()
        .then(function (res) {
            $scope.orgList = res;
            console.log($scope.orgList)
        });

    $scope.addOrgValFTC = function (data) {
        console.log(data);
        $scope.orgId = data.orgId;
        $scope.orgCode = data.orgCode;
        $scope.addOrgVal = data.text;
    }
    //全部状态下所属机构
    dataSer.organizeQuerylistSer()
        .then(function (res) {
            $scope.orgAllList = res;
        });

    $scope.adjustText = function (orgId) {
        if ($scope.orgAllList) {
            for (var i = 0, r = $scope.orgAllList.length; i < r; i++) {
                if ($scope.orgAllList[i].orgId == orgId) {
                    return $scope.orgAllList[i].text;
                }
            }
        }
    }
    /**
     * 分页功能实现TerryMin
     * **/
    $scope.showDataChoose = getPageNum.pageNum(); //获取分页
    $scope.showNum = $scope.showDataChoose[0]; //初始显示刷具条数
    $scope.showPage = false;
    var pageInitialize = function () {
        $scope.dataNum = 0; //数据总条数
        $scope.dataPage = 0; //分页数
        $scope.currentPage = 1; //当前页数
        $scope.jumpPageNum = '';
    };
    pageInitialize();

    // x/y $scope.dataPage
    $scope.PageNum = function () {
        $scope.showPage = true;
        if ($scope.showNum.showNum < $scope.dataNum) {
            $scope.dataPage =Math.ceil($scope.dataNum / $scope.showNum.showNum);
        } else {
            $scope.dataPage = 0;
        }
    };
    //上页下页 $scope.currentPage
    $scope.pageSlect = function (type) {
        if (type == 'prev') {
            if ($scope.currentPage != 1) {
                $scope.currentPage--;
                $scope.PageNum();
                $scope.search();
            }
        } else {
            if ($scope.currentPage < $scope.dataPage) {
                $scope.currentPage++;
                $scope.PageNum();
                $scope.search();
            }
        }
    };
    // 每页条数单元
    $scope.pageSelect = function (params) {
        $scope.showNum.showNum = params.showNum;
        pageInitialize();
        $scope.search();
    };
    //页数跳转 currentPage
    $scope.jumpPage = function (num) {
        num = parseInt(num);
        if (parseInt(num, 10) === num && num <= ($scope.dataPage + 1) && num > 0) {
            $scope.currentPage = num;
            $scope.PageNum();
            $scope.search();
        }
    };
    $scope.basicData = [{
        name: '是',
        val: true
    }, {
        name: '否',
        val: false
    }];
    $scope.basicText = function (val) {
        for (var i = 0, r = $scope.basicData.length; i < r; i++) {
            if (val == $scope.basicData[i].val) {
                return $scope.basicData[i].name;
            }
        }
    }
    $scope.state = '';
    $scope.hideRoleaut=true;
    $scope.showRoleaut=true;
    $scope.HLshowRoleaut=true;
    $scope.HLhideRoleaut=true;
    // 选择
    $scope.checkedTab1 = function (index,applyId,currency,currencyGroupId,currencyCode,currencyName,state,applyRateId,currencyGroupName,tradeRate,buyRate,sellRate,taxRate,basic){
        $scope.chooseUserData={
            applyId:applyId,
            currency:currency,
            currencyGroupId:currencyGroupId,
            currencyCode: currencyCode,
            currencyName: currencyName,
            state:state,
            applyRateId:applyRateId,
            currencyGroupName:currencyGroupName,
            tradeRate:tradeRate,
            buyRate:buyRate,
            sellRate:sellRate,
            taxRate:taxRate,
            basic:basic

        };
        console.log($scope.chooseUserData)
        var userIdChecked = localStorageService.get('userIdChecked');
        $('#dataReport input[type=checkbox]').prop('checked', false);
        if (currency == userIdChecked) {
            localStorageService.clear('userIdChecked');
            $scope.chooseItemTab1 = '';
            $scope.applyId = '';
            $scope.state= '';
            $scope.applyRateId= '';
        } else {
            $('#dataReport input[type=checkbox]').eq(index).prop('checked', true);
            localStorageService.update('userIdChecked', currency);
            $scope.chooseItemTab1 = currency;
            $scope.applyId= applyId;
            $scope.state= state;
            $scope.applyRateId=applyRateId;
        }
        if ($scope.chooseUserData.applyId != null) {
            console.log($scope.chooseUserData.applyId)
            $scope.hideRoleaut=false;
            $scope.showRoleaut=false;
        }else{
            $scope.showRoleaut=true;
            $scope.hideRoleaut=true;
        };
        if ($scope.chooseUserData.applyRateId != null) {
            console.log($scope.chooseUserData.applyRateId)
            $scope.HLhideRoleaut=false;
            $scope.HLshowRoleaut=false;
        }else{
            $scope.HLshowRoleaut=true;
            $scope.HLhideRoleaut=true;
        };

    };
    // 存储选中
    $scope.switchUserId = function (parameter, responseData) {
        $timeout(function () {
            for (var i = 0; i < responseData.length; i++) {
                if (parameter == responseData[i].currency) {
                    $('#dataReport input[type=checkbox]').eq(i).prop('checked', true);
                    return;
                }
            }
        }, 1500)
    };
    $scope.allotTypeData=getadminState;
    $scope.allotTypeText = function(val) {
        for (var i = 0, r = $scope.allotTypeData.length; i < r; i++) {
            if (val == $scope.allotTypeData[i].id) {
                return $scope.allotTypeData[i].name;
            }
        }
    }
    $scope.add = function () {
        $scope.tableshowbz = true;
        $scope.addEditText = '新增';
        $scope.addOrgVal = "";
        $scope.currencyGroupName="";
        $scope.currencyCode="";
        $scope.currencyName="";
    }

    $scope.edit = function () {
        if (!$scope.chooseItemTab1) {
            $rootScope.tipService.setMessage('请先选择币种', 'warning');
        } else {
            $scope.addEditText = '申请变更';
            $scope.tableshowbz = true;
            $scope.currency=$scope.chooseUserData.currency;
            $scope.currencyGroupIdVal=$scope.chooseUserData.currencyGroupId;
            $scope.currencyCode=$scope.chooseUserData.currencyCode;
            $scope.currencyName=$scope.chooseUserData.currencyName;
        }
    }
    $scope.addSubmit = function () {
        if ($scope.addEditText == "新增") {
            var configCurrencyInfoVIce = {
                currencyGroupId:$scope.currencyGroupIdVal,
                currencyCode: $scope.currencyCode,
                currencyName: $scope.currencyName,
            }
            var json = {
                configCurrencyInfoVIce: configCurrencyInfoVIce
            }
            currencyManagementCtrlSer.Addsub(json)
                .then(function (res) {
                        if (res.data.code == "000000") {
                            $scope.tableshowbz = false;
                            $rootScope.tipService.setMessage(res.data.message, 'warning');
                            localStorageService.clear('userIdChecked');
                            $scope.search();
                        }else{
                            $rootScope.tipService.setMessage(res.data.message, 'warning');
                        }
                    },function(error){
                        $rootScope.tipService.setMessage(error.data.message, 'warning');
                    }
                )
        } else if ($scope.addEditText == "申请变更") {
            var configCurrencyInfoVIce = {
                currency:$scope.currency,
                currencyGroupId:$scope.currencyGroupIdVal,
                currencyCode: $scope.currencyCode,
                currencyName: $scope.currencyName,
            }
            var json = {
                configCurrencyInfoVIce: configCurrencyInfoVIce
            }
            currencyManagementCtrlSer.editsub(json)
                .then(function (res) {
                    if (res.data.code == "000000") {
                        $scope.tableshowbz = false;
                        $rootScope.tipService.setMessage(res.data.message, 'warning');
                        localStorageService.clear('userIdChecked');
                        $scope.search();
                    }
                    else {
                        $rootScope.tipService.setMessage(res.data.message, 'warning');
                    }
                },function(error){
                    $rootScope.tipService.setMessage(error.data.message, 'warning')
                })
        }
    }

    $scope.audit=function () {
        if (!$scope.applyId) {
            $rootScope.tipService.setMessage('请先审核变更', 'warning');
        } else {
            var json={
                applyId:$scope.applyId
            }
            currencyManagementCtrlSer.get(json)
                .then(function(res){
                    console.log(res)
                    if(res.data.code=="000000"){
                        var getData=JSON.parse(res.data.content);
                        $scope.getDatalist=getData.configCurrencyInfoV;
                        console.log($scope.getDatalist)
                        $scope.addEditText = "审核变更";
                        $scope.tableshowbzxq = true;
                        $scope.commodityId=$scope.getDatalist.commodityId;
                        $scope.currency=$scope.getDatalist.currency;
                        $scope.currencyCode=$scope.getDatalist.currencyCode;
                        $scope.currencyName=$scope.getDatalist.currencyName;
                        $scope.currencyGroupId=$scope.getDatalist.currencyGroupId;
                    }
                })

        }
    }

    $scope.RoletrueData = function (tmpOpt) {
        var json = {
            applyId: $scope.applyId,
            auditRs: tmpOpt
        };
        currencyManagementCtrlSer.Roletruetion(json)
            .then(function (res) {
                if (res.data.code == '000000') {
                    $scope.tableshowbzxq = false;
                    localStorageService.clear('userIdChecked');
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                    $scope.search();
                } else {
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                }
            },function(error) {
                $rootScope.tipService.setMessage(error.data.message, 'warning');
            })
    }
    $scope.RolefalseData = function (tmpOpt) {
        var json = {
            applyId: $scope.applyId,
            auditRs: tmpOpt
        };
        currencyManagementCtrlSer.Roletruetion(json)
            .then(function (res) {
                if (res.data.code == '000000') {
                    $scope.tableshowbzxq = false;
                    localStorageService.clear('userIdChecked');
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                    $scope.search();
                } else {
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                }
            },function(error) {
                $rootScope.tipService.setMessage(error.data.message, 'warning');
            })
    }

    $scope.pass=function() {
        if (!$scope.chooseItemTab1) {
            $rootScope.tipService.setMessage('请先选择币种信息', 'warning');
        } else {
            var json={
                currency:$scope.chooseItemTab1
            }
            currencyManagementCtrlSer.passCheck(json)
                .then(function (res) {
                    if (res.data.code == '000000') {
                        localStorageService.clear('userIdChecked');
                        $rootScope.tipService.setMessage(res.data.message, 'warning');
                        $scope.search();
                    } else {
                        $rootScope.tipService.setMessage(res.data.message, 'warning');
                    }
                }, function (error) {
                    $rootScope.tipService.setMessage(error.data.message, 'warning');
                });
        }
    }
    $scope.fail=function() {
        if (!$scope.chooseItemTab1) {
            $rootScope.tipService.setMessage('请先选择币种信息', 'warning');
        } else {
            var json={
                currency:$scope.chooseItemTab1
            }
            currencyManagementCtrlSer.failedCheck(json)
                .then(function (res) {
                    if (res.data.code == '000000') {
                        localStorageService.clear('userIdChecked');
                        $rootScope.tipService.setMessage(res.data.message, 'warning');
                        $scope.search();
                    } else {
                        $rootScope.tipService.setMessage(res.data.message, 'warning');
                    }
                }, function (error) {
                    $rootScope.tipService.setMessage(error.data.message, 'warning');
                });
        }
    }
    $scope.open=function() {
        if (!$scope.chooseItemTab1) {
            $rootScope.tipService.setMessage('请先选择币种信息', 'warning');
        } else {
            var json={
                currency:$scope.chooseItemTab1
            }
            currencyManagementCtrlSer.open(json)
                .then(function (res) {
                    if (res.data.code == '000000') {
                        localStorageService.clear('userIdChecked');
                        $rootScope.tipService.setMessage(res.data.message, 'warning');
                        $scope.search();
                    } else {
                        $rootScope.tipService.setMessage(res.data.message, 'warning');
                    }
                }, function (error) {
                    $rootScope.tipService.setMessage(error.data.message, 'warning');
                });
        }
    }

    $scope.close=function() {
        if (!$scope.chooseItemTab1) {
            $rootScope.tipService.setMessage('请先选择币种信息', 'warning');
        } else {
            confirmService.set('确认提示', '确定要注销此币种?', function () {
                var json={
                    currency:$scope.chooseItemTab1
                }
                currencyManagementCtrlSer.Close(json)
                    .then(function (res) {
                        if (res.data.code == '000000') {
                            localStorageService.clear('userIdChecked');
                            $rootScope.tipService.setMessage(res.data.message, 'warning');
                            $scope.search();
                        } else {
                            $rootScope.tipService.setMessage(res.data.message, 'warning');
                        }
                    }, function (error) {
                        $rootScope.tipService.setMessage(error.data.message, 'warning');
                    });
                confirmService.clear();
            });
        }
    }
    $scope.exedit = function () {
        if (!$scope.chooseItemTab1) {
            $rootScope.tipService.setMessage('请先选择币种信息', 'warning');
        } else {
            $scope.addEditText = '申请汇率变更';
            $scope.tableshow = true;
            $scope.currency=$scope.chooseUserData.currency;
            $scope.tradeRate=$scope.chooseUserData.tradeRate;
            $scope.buyRate=$scope.chooseUserData.buyRate;
            $scope.sellRate=$scope.chooseUserData.sellRate;
            //$scope.taxRate=$scope.chooseUserData.taxRate;
        }
    }

    $scope.exaudit=function () {
        if (!$scope.applyRateId) {
            $rootScope.tipService.setMessage('请先审核汇率变更', 'warning');
        } else {
            var json={
                applyId:$scope.applyRateId
            }
            currencyManagementCtrlSer.exget(json)
                .then(function(res){
                    console.log(res)
                    if(res.data.code=="000000"){
                        var getData=JSON.parse(res.data.content);
                        $scope.getDatalist=getData.configCurrencyRateInfoV;
                        console.log($scope.getDatalist)
                        $scope.addEditText = "审核汇率变更";
                        $scope.tableshowxq = true;
                        $scope.currency=$scope.getDatalist.currency;
                        $scope.tradeRate=$scope.getDatalist.tradeRate;
                        $scope.buyRate=$scope.getDatalist.buyRate;
                        $scope.sellRate=$scope.getDatalist.sellRate;
                        //$scope.taxRate=$scope.getDatalist.taxRate;
                    }
                })

        }
    }
    $scope.exaddSubmit = function () {
        if ($scope.tradeRate == undefined || $scope.tradeRate == '') {
            $rootScope.tipService.setMessage('请输入交易汇率', 'warning');
        } else if ($scope.buyRate == undefined || $scope.buyRate == '') {
            $rootScope.tipService.setMessage('请输入入金汇率', 'warning');
        }else if ($scope.sellRate == undefined || $scope.sellRate == '') {
            $rootScope.tipService.setMessage('请输入出金汇率', 'warning');
        }/*else if ($scope.taxRate == undefined || $scope.taxRate == '') {
            $rootScope.tipService.setMessage('请输入税费汇率', 'warning');
        }*/else{
        var configExchangeRateInfoVIce = {
            currency: $scope.currency,
            tradeRate: $scope.tradeRate,
            buyRate: $scope.buyRate,
            sellRate: $scope.sellRate,
            //taxRate: $scope.taxRate,
        }
        var json = {
            configExchangeRateInfoVIce: configExchangeRateInfoVIce
        }
        currencyManagementCtrlSer.exeditsub(json)
            .then(function (res) {
                if (res.data.code == "000000") {
                    $scope.tableshow = false;
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                    localStorageService.clear('userIdChecked');
                    $scope.search();
                }
                else {
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                }
            }, function (error) {
                $rootScope.tipService.setMessage(error.data.message, 'warning')
            })
        }
    }

    $scope.exRoletrueData = function (tmpOpt) {
        var json = {
            applyId: $scope.applyRateId,
            auditRs: tmpOpt
        };
        currencyManagementCtrlSer.exRoletruetion(json)
            .then(function (res) {
                if (res.data.code == '000000') {
                    $scope.tableshowxq = false;
                    localStorageService.clear('userIdChecked');
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                    $scope.search();
                } else {
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                }
            },function(error) {
                $rootScope.tipService.setMessage(error.data.message, 'warning');
            })
    }
    $scope.exRolefalseData = function (tmpOpt) {
        var json = {
            applyId: $scope.applyRateId,
            auditRs: tmpOpt
        };
        currencyManagementCtrlSer.exRoletruetion(json)
            .then(function (res) {
                if (res.data.code == '000000') {
                    $scope.tableshowxq = false;
                    localStorageService.clear('userIdChecked');
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                    $scope.search();
                } else {
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                }
            },function(error) {
                $rootScope.tipService.setMessage(error.data.message, 'warning');
            })
    }

    //设置基币
    $scope.basicCheck = function() {
        if (!$scope.chooseItemTab1) {
            $rootScope.tipService.setMessage('请先选择币种', 'warning');
        } else {
            var json = {
                currency: $scope.chooseItemTab1,
            }
            currencyManagementCtrlSer.basicCheck(json)
                .then(function(res) {
                    console.log()
                    if (res.data.code == '000000') {
                        $rootScope.tipService.setMessage(res.data.message, 'warning');
                        $scope.search();
                    } else {
                        $rootScope.tipService.setMessage(res.data.message, 'warning');
                    }
                }, function(error) {
                    $rootScope.tipService.setMessage(error.data.message, 'warning');
                });
        }
    }

}])
    .factory('currencyManagementCtrlSer', ['$http', 'localStorageService', 'myHttp', '$q', '$rootScope', function ($http, localStorageService, myHttp, $q, $rootScope) {
        return {
            //查询
            search: function (json) {
                var deferred = $q.defer();
                myHttp.post("admin/config/currency/query/page", json)
                    .then(function (res) { // 调用承诺API获取数据 .resolve
                        deferred.resolve(res);
                    }, function (res) { // 处理错误 .reject
                        deferred.reject(res);
                    });
                return deferred.promise;
            },
            currencylist: function () {
                var deferred = $q.defer();
                myHttp.post("admin/config/currency/query/list")
                    .then(function (res) { // 调用承诺API获取数据 .resolve
                        deferred.resolve(res);
                    }, function (res) { // 处理错误 .reject
                        deferred.reject(res);
                    });
                return deferred.promise;
            },
            searchlist: function () {
                var deferred = $q.defer();
                myHttp.post("admin/config/currency/group/query/list")
                    .then(function (res) { // 调用承诺API获取数据 .resolve
                        deferred.resolve(res);
                    }, function (res) { // 处理错误 .reject
                        deferred.reject(res);
                    });
                return deferred.promise;
            },
            Addsub: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'admin/config/currency/create',
                    data: json
                }).then(function successCallback(response) {
                    console.log(response)
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
            editsub: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'admin/config/currency/apply',
                    data: json
                }).then(function successCallback(response) {
                    console.log(response)
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
            //获取
            get: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'admin/config/currency/apply/get',
                    data: json
                }).then(function successCallback(response) {
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
            //变更
            Roletruetion: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'admin/config/currency/audit',
                    data: json
                }).then(function successCallback(response) {
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
            exeditsub: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'admin/config/currency/rate/apply',
                    data: json
                }).then(function successCallback(response) {
                    console.log(response)
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
            //获取
            exget: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'admin/config/currency/rate/apply/get',
                    data: json
                }).then(function successCallback(response) {
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
            //变更
            exRoletruetion: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'admin/config/currency/rate/audit',
                    data: json
                }).then(function successCallback(response) {
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
            Close: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'admin/config/currency/group/close',
                    data: json
                }).then(function successCallback(response) {
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
            //通过
            passCheck: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'admin/config/currency/pass',
                    data: json
                }).then(function successCallback(response) {
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
            //不通过
            failedCheck: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'admin/config/currency/fail',
                    data: json
                }).then(function successCallback(response) {
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
            //重新提交
            open: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'admin/config/currency/open',
                    data: json
                }).then(function successCallback(response) {
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
            //设置基币
            basicCheck: function(json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'admin/config/currency/basic',
                    data: json
                }).then(function successCallback(response) {
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            }
        }
    }])