app.controller("confirmCtrl", function($scope, $http, $location, $state, $sce, $rootScope, $timeout) {
		$scope.hideAlert = function() {
			$rootScope.confirmShow = false;
		}
		$scope.implement = function() {
			$rootScope.confirmImplement();
		}
		$scope.$watch('confirmMessage', function() {
			$scope.trustAsHtml = $sce.trustAsHtml($rootScope.confirmMessage);
		});
});