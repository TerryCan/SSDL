app.controller('EntrustedstatisticsCtrl', ['$rootScope', '$scope', 'EntrustedstatisticsCtrlSel', 'localStorageService', 'timestamp', function ($rootScope, $scope, EntrustedstatisticsCtrlSel, localStorageService, timestamp) {
    $scope.toggleTraderSearchState=false;
    $scope.Toggle = function(){
        $scope.toggleTraderSearchState = !$scope.toggleTraderSearchState;
        if($scope.toggleTraderSearchState){
           $('.search_column').css('height','auto');
        }
        else{
           $('.search_column').css('height','36px');
        }
    };

    var processContent,arr_total;
    var source = {
        type: 'POST',
        datatype: "json",
        datafields: [  //数据字段定义
            {name: 'productName', type: 'string'},
            {name: 'productCode', type: 'string'},
            {name: 'buy', type: 'string'},
            {name: 'sell', type: 'string'},
            {name: 'total', type: 'string'},
            {name: 'limit', type: 'string'},

            {name: 'cancel', type: 'string'}
        ],
        url: $rootScope.baseUrl + 'trade/order/sum',
        root: "content",
        contenttype:"application/json;charset=UTF-8",
        // beforeSend: function (xhr) {
        //     console.log(xhr)
        //     xhr.setRequestHeader("text/html;charset=UTF-8");
        // },
        pagesize:10,
        data:{
            userId:($scope.directiveUserId)? $scope.directiveUserId:'',
            orgCode: ($scope.upOrgCode) ? $scope.upOrgCode : '',
            createTimeS:($scope.createTimeStart)?($scope.createTimeStart.split(' ')[0]+"T"+$scope.createTimeStart.split(' ')[1]):'',
            createTimeE:($scope.createTimeEnd)?($scope.createTimeEnd.split(' ')[0]+"T"+$scope.createTimeEnd.split(' ')[1]):''
        },
        // processData: function (data) {
        //     console.log(data)
        //     var sumParamsIce = {
        //         userId:($scope.directiveUserId)? $scope.directiveUserId:'',
        //         orgCode: ($scope.upOrgCode) ? $scope.upOrgCode : '',
        //         createTimeS:($scope.createTimeStart)?($scope.createTimeStart.split(' ')[0]+"T"+$scope.createTimeStart.split(' ')[1]):'',
        //         createTimeE:($scope.createTimeEnd)?($scope.createTimeEnd.split(' ')[0]+"T"+$scope.createTimeEnd.split(' ')[1]):''
        //     };
        //     data.sumParamsIce={
        //         sumParamsIce:sumParamsIce
        //     };
        //
        // }, //传递参数处理
        beforeLoadComplete: function (records) { //数据完全加载完执行绘制表格
            console.log(records)
            var start;
            for (var i in records) {
                start = parseInt(i);
                break;
            }
            for (var k = 0, r = processContent.length; k < r; k++) {
                records[start + k].productName = processContent[k].productName;
                records[start + k].productCode = processContent[k].productCode;
                records[start + k].buy = processContent[k].buy;
                records[start + k].sell = processContent[k].sell;
                records[start + k].total = processContent[k].total;
                records[start + k].limit = processContent[k].limit;
                records[start + k].cancel = processContent[k].cancel
            }
        },
        beforeprocessing: function (data) { //处理总页数
            var processData = JSON.parse(data.content);
            processContent = processData.content;
            source.totalrecords = processData.totalElements == 0 ? 5 : processData.totalElements;
            arr_total = processData.totalElements;
        },
        loadComplete: function (records) {
            $scope.saveResult=JSON.parse(records.content);
            // console.log($scope.saveResult)
            var data =  $scope.saveResult.totalElements;
            if (data == 0) {
                $('#contenttableentrustDetailGrid > div').remove();
            }
        },
        endUpdate: true
    };

    //创建数据适配器
    var dataAdapter = null;
    $scope.searchAjax = function () {
        $scope.toggleTraderSearchState = false;
        $('.search_column').css('height', '36px');
        if (dataAdapter == null) {
            dataAdapter = new $.jqx.dataAdapter(source);
            //创建表格
            $("#entrustDetailGrid").jqxGrid({
                source: dataAdapter,//数据源
                columns: [  //表格数据域
                    {
                        text: '商品名',
                        datafield: 'productName',
                        minwidth: 13 + '%',
                        cellsalign: 'center',
                        align: 'center',
                        width:'13%'
                    },
                    {
                        text: '商品代码',
                        datafield: 'productCode',
                        minwidth:13 + '%',
                        align: 'center',
                        width:'13%'
                    },
                    {
                        text: '委托买',
                        datafield: 'buy',
                        minwidth: 13 + '%',
                        cellsalign: 'center',
                        align: 'center',
                        width:'13%'
                    },
                    {
                        text: '委托卖',
                        datafield: 'sell',
                        minwidth: 13 + '%',
                        width:'13%',
                        align: 'center'
                    },
                    {
                        text: '委托合计',
                        datafield: 'total',
                        minwidth: 13 + '%',
                        cellsalign: 'center',
                        align: 'center',
                        width:'13%'
                    },
                    {
                        text: '挂单合计',
                        datafield: 'limit',
                        minwidth: 13 + '%',
                        align: 'center',
                        width:'13%',
                        cellsalign: 'center',
                    },
                    {
                        text: '撤单合计',
                        datafield: 'cancel',
                        minwidth: 22 + '%',
                        align: 'center',
                        cellsalign: 'center',
                        width:'22%'
                    }
                ],
                width: 100 + '%',
                height: 87 + '%',
                theme:'metrodark',
                virtualmode: true,
                rendergridrows: function (params) {
                    return params.data;
                },
                sortable: true,//是否排序
                altrows: true,//是否行间颜色区分
                columnsresize: true,//列间距是否可调整
                //selectionmode: 'multiplecellsadvanced',//选择模式
                clipboard: false,//屏蔽jqxGrid的复制功能
                //selectionmode:'getselectedrowindex',
                selectionmode: 'true'//复选框
            });
        }else {
            $("#entrustDetailGrid").jqxGrid('updatebounddata', 'cells');
        }
    };
    //排序
    $("#entrustDetailGrid").on("sort", function (event) {
        var sortinformation = event.args.sortinformation;
        // console.log(sortinformation);
        $scope.sort=sortinformation.sortcolumn;
        $scope.order=($scope.sort)?(sortinformation.sortdirection.ascending)?'asc':'desc':'asc';
        // console.log(sortinformation.sortdirection.ascending,sortinformation.sortdirection.descending,$scope.order);
        data={
            order:$scope.order,
            sort:$scope.sort
        };
        source.processData(data);
        $("#entrustDetailGrid").jqxGrid('updatebounddata', 'sort');
    });


    //总计
    $scope.StatisticsData = false;
    $scope.tjdata = function () {
        $scope.StatisticsData = true;
        $scope.total = 0;
        $scope.buy = 0;
        $scope.sell = 0;
        $scope.limit = 0;
        $scope.cancel = 0;
        if ($scope.searchResult) {
            for (var j = 0; j < $scope.searchResult.length; j++) {
                $scope.total = $scope.total + $scope.searchResult[j].total;
                $scope.buy = $scope.buy + $scope.searchResult[j].buy;
                $scope.sell = $scope.sell + $scope.searchResult[j].sell;
                $scope.limit = $scope.limit + $scope.searchResult[j].limit;
                $scope.cancel = $scope.cancel + $scope.searchResult[j].cancel;
            }
        }
    };
}])
    .factory('EntrustedstatisticsCtrlSel', ['$http', 'localStorageService', 'myHttp', '$q', '$rootScope', function ($http, localStorageService, myHttp, $q, $rootScope) {
        return {
            search: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'trade/order/sum',
                    data: json
                }).then(function (res) { // 调用承诺API获取数据 .resolve
                        deferred.resolve(res);
                    }, function (res) { // 处理错误 .reject
                        deferred.reject(res);
                    });
                return deferred.promise;
            }
        }
    }])