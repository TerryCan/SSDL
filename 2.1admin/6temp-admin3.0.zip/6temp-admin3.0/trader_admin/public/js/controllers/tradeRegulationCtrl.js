app.controller('tradeRegulationCtrl', ['$scope', '$timeout', 'confirmService', '$rootScope', 'tradeRegulationAll', 'getTradeRuleType', 'getTradeRuleConditionType', 'tipService', 'localStorageService', 'getPageNum', 'administratorsManageCtrlSer', function ($scope, $timeout, confirmService, $rootScope, tradeRegulationAll, getTradeRuleType, getTradeRuleConditionType, tipService, localStorageService, getPageNum, administratorsManageCtrlSer) {
    $scope.toggleTraderSearchState=false;
    $scope.Toggle = function(){
        $scope.toggleTraderSearchState = !$scope.toggleTraderSearchState;
        if($scope.toggleTraderSearchState){
           $('.search_column').css('height','auto');
        }
        else{
           $('.search_column').css('height','36px');
        }
    };
    //规则类型
    $scope.TradeRuleType = getTradeRuleType;
    //规则条件
    $scope.TradeRuleConditionType = getTradeRuleConditionType;

    //交易规则查询
    $scope.type = '';
    $scope.OperatorType = '';
    $scope.EnableType = '';
    $scope.tradeRegulationSearch = function () {
         $scope.toggleTraderSearchState=false;
        $('.search_column').css('height','36px');
        var json = {
            qryConditionList: [{
                field: "Type",
                value: $scope.type
            }, {
                field: "Operator",
                value: $scope.OperatorType
            }, {
                field: "Enable",
                value: $scope.EnableType
            }]
        };
        tradeRegulationAll.riskSearch(json)
            .then(function (res) {
                if (res.retMsg.code === '000000') {
                    $scope.featureShow=true;
                    $scope.tradeList = res.list;
                    var source = {
                        localdata: $scope.tradeList,
                        datatype: "array",
                        datafields: [
                            {name: 'Key', type: 'string'},
                            {name: 'Name', type: 'string'},
                            {name: 'Enable', type: 'string'},
                            {name: 'Type', type: 'string'},
                            {name: 'Condition', type: 'string'},
                            {name: 'Para1', type: 'string'},

                            {name: 'Para2', type: 'string'},
                            {name: 'Comment', type: 'string'}
                        ]
                    };
                    var dataAdapter = new $.jqx.dataAdapter(source);
                    $("#entrustDetailGrid").jqxGrid(
                        {
                            width: 100 + '%',
                            height: 80 + '%',
                            theme: 'metrodark',
                            source: dataAdapter,//数据源
                            pageable: true,//是否分页
                            pagesize: 10,
                            // sortable: true,//是否排序
                            columnsresize: true,//列间距是否可调整
                            clipboard: false,//屏蔽jqxGrid的复制功能
                            pagesizeoptions: ['10', '30', '100', '200'],
                            columns: [
                                {
                                    text: '名称',
                                    datafield: 'Name',
                                    width: 20 + '%',
                                    minwidth: 20 + '%',
                                    align: 'center',
                                    cellsalign: 'center'
                                },
                                {
                                    text: '启用',
                                    datafield: 'Enable',
                                    columntype: 'checkbox',
                                    width: 20 + '%',
                                    minwidth: 20 + '%',
                                    align: 'center',
                                    cellsalign: 'center'
                                },
                                {
                                    text: '规则类型',
                                    datafield: 'Type',
                                    width: 20 + '%',
                                    minwidth: 20 + '%',
                                    align: 'center',
                                    cellsalign: 'center',
                                    cellsrenderer: function (row, columnfield, value, defaulthtml, columnproperties) {
                                        if ($scope.TradeRuleType) {
                                            for (var i = 0; i < $scope.TradeRuleType.length; i++) {
                                                if (value == $scope.TradeRuleType[i].id) {
                                                    return $scope.TradeRuleType[i].name;
                                                }
                                            }
                                        }
                                    }
                                },
                                {
                                    text: '规则条件',
                                    datafield: 'Condition',
                                    width: 20 + '%',
                                    minwidth: 20 + '%',
                                    align: 'center',
                                    cellsalign: 'center',
                                    cellsrenderer: function (row, columnfield, value, defaulthtml, columnproperties) {
                                        if ($scope.tradeList) {
                                            if (value == 0) {
                                                return 'x>' + $scope.tradeList[row].Para1;
                                            }
                                            if (value == 1) {
                                                return 'x>=' + $scope.tradeList[row].Para1;
                                            }
                                            if (value == 2) {
                                                return 'x<' + $scope.tradeList[row].Para1;
                                            }
                                            if (value == 3) {
                                                return 'x<=' + $scope.tradeList[row].Para1;
                                            }
                                            if (value == 4) {
                                                return $scope.tradeList[row].Para1 + '<x<' + $scope.tradeList[row].Para2;
                                            }
                                            if (value == 5) {
                                                return $scope.tradeList[row].Para1 + '<=x<=' + $scope.tradeList[row].Para2;
                                            }
                                        }
                                    }
                                },
                                {
                                    text: '备注',
                                    datafield: 'Comment',
                                    width: 20 + '%',
                                    minwidth: 20 + '%',
                                    align: 'center',
                                    cellsalign: 'center'
                                }
                            ]
                        });
                    //分页
                    $("#entrustDetailGrid").on("pagechanged", function (event) {
                        console.log(event)
                    });

                } else {
                    $rootScope.tipService.setMessage(res.retMsg.message, 'warning');
                }
            }, function (error) {
                $rootScope.tipService.setMessage(error.message, 'warning');
            })
    };

    // 存储选中
    $scope.switchUserId = function (parameter, responseData) {
        $timeout(function () {
            for (var i = 0; i < responseData.length; i++) {
                if (parameter == responseData[i].Key) {
                    $('#dataReport input[type=checkbox]').not('.start_using').eq(i).prop('checked', true);
                    return;
                }
            }
        }, 300)
    };
    $scope.checkedTab1 = function (index, Key, Name, Enable, Type, Condition, Para1, Para2, Comment) {
        $scope.chooseUserData = {
            Key: Key,
            Name: Name,
            TradeRule: Type,
            TradeConditionRule: Condition,
            Para1: Para1,
            Para2: Para2,
            Enable: Enable,
            Comment: Comment
        };
        var userIdChecked = localStorageService.get('userIdChecked');
        $('#dataReport input[type=checkbox]').not('.start_using').prop('checked', false);
        if (Key == userIdChecked) {
            localStorageService.clear('userIdChecked');
            $scope.chooseItemTab1 = '';
        } else {
            $('#dataReport input[type=checkbox]').not('.start_using').eq(index).prop('checked', true);
            localStorageService.update('userIdChecked', Key);
            $scope.chooseItemTab1 = Key;
        }
    };
    //新增
    $scope.addEditText = '';
    $scope.newUserShow = false;
    $scope.addNewUser = function () {
        $scope.newUserShow = true;
        $scope.addEditText = '新增';
        $scope.Para1Show = true;
        $scope.Para2Show = true;
        $scope.Name = '';
        $scope.TradeRule = '';
        $scope.TradeConditionRule = '';
        $scope.Para1 = '';
        $scope.Para2 = '';
        $scope.Enable = false;
        $scope.Comment = '';
        $scope.showFunc = function () {
            if ($scope.TradeConditionRule < 4) {
                $scope.Para1Show = false;
            } else {
                $scope.Para1Show = false;
                $scope.Para2Show = false;
            }
        }
    };
    //修改
    $('#entrustDetailGrid').on('rowselect', function (event) {
        console.log(event)
        $scope.chooseItemTab1 = event.args.row.Key;
        $scope.chooseUserData = {
            Key: event.args.row.Key,
            Name: event.args.row.Name,
            TradeRule:  event.args.row.Type,
            TradeConditionRule:  event.args.row.Condition,
            Para1:  event.args.row.Para1,
            Para2:  event.args.row.Para2,
            Enable:  event.args.row.Enable,
            Comment:  event.args.row.Comment
        };
    });
    $scope.editUser = function () {
        if (!$scope.chooseItemTab1) {
            $rootScope.tipService.setMessage('请先选择用户', 'warning');
        } else {
            $scope.addEditText = '修改';
            $scope.newUserShow = true;
            $scope.chooseUserData.key = $scope.chooseItemTab1;
            $scope.Name = $scope.chooseUserData.Name;
            $scope.TradeRule = $scope.chooseUserData.TradeRule;
            $scope.TradeConditionRule = $scope.chooseUserData.TradeConditionRule;
            $scope.Para1 = $scope.chooseUserData.Para1;
            $scope.Para2 = $scope.chooseUserData.Para2;
            $scope.Enable = $scope.chooseUserData.Enable;
            $scope.Comment = $scope.chooseUserData.Comment;
        }
    };
    $scope.addEditUserSubmit = function () {
        if ($scope.addEditText == '新增') {
            if ($scope.Name == null) {
                $rootScope.tipService.setMessage('请填写名称', 'warning');
            } else {
                console.log(localStorageService.get('selfInfo').userId)
                var tradeRule = {
                    Name: $scope.Name,
                    Type: parseFloat($scope.TradeRule), //公式类型
                    Condition: parseFloat($scope.TradeConditionRule),
                    Para1: parseFloat($scope.Para1),
                    Para2: parseFloat($scope.Para2),
                    Enable: $scope.Enable,
                    Comment: $scope.Comment,
                    Operator: localStorageService.get('selfInfo').userId
                };
                var json = {
                    tradeRule: tradeRule

                };
               if ($scope.Name == undefined || $scope.Name == '') {
                    $rootScope.tipService.setMessage('请选择名称', 'warning');
                } else if ($scope.TradeRule == undefined || $scope.TradeRule == '') {
                    $rootScope.tipService.setMessage('请选择公式类型', 'warning');
                } else if ($scope.TradeConditionRule == undefined || $scope.TradeConditionRule == '') {
                    $rootScope.tipService.setMessage('请选择公式条件', 'warning');
                } else if ($scope.Comment == undefined || $scope.Comment == '') {
                    $rootScope.tipService.setMessage('请填写备注', 'warning');
                }else{
                tradeRegulationAll.riskAdd(json)
                    .then(function (res) {
                        console.log(res);
                        $scope.newUserShow = false;
                        $rootScope.tipService.setMessage(res.message, 'warning');
                        $scope.tradeRegulationSearch()
                    }, function (error) {
                        $rootScope.tipService.setMessage(error.message, 'warning');
                    })
                }
            }
        } else if ($scope.addEditText == '修改') {
            var tradeRule = {
                Key: $scope.chooseItemTab1,
                Name: $scope.Name,
                Type: parseFloat($scope.TradeRule), //公式类型
                Condition: parseFloat($scope.TradeConditionRule),
                Para1: parseFloat($scope.Para1),
                Para2: parseFloat($scope.Para2),
                Enable: $scope.Enable,
                Comment: $scope.Comment,
				Operator: localStorageService.get('selfInfo').userId
                
            };
            var json = {
                tradeRule: tradeRule
            };
            if ($scope.Name == undefined || $scope.Name == '') {
                    $rootScope.tipService.setMessage('请选择名称', 'warning');
                } else if ($scope.TradeRule == undefined || $scope.TradeRule == '') {
                    $rootScope.tipService.setMessage('请选择公式类型', 'warning');
                } else if ($scope.TradeConditionRule == undefined || $scope.TradeConditionRule == '') {
                    $rootScope.tipService.setMessage('请选择公式条件', 'warning');
                } else if ($scope.Comment == undefined || $scope.Comment == '') {
                    $rootScope.tipService.setMessage('请填写备注', 'warning');
                }else{
            tradeRegulationAll.riskModify(json)
                .then(function (res) {
                    $scope.newUserShow = false;
                    $rootScope.tipService.setMessage(res.message, 'warning');
                    $scope.tradeRegulationSearch()
                }, function (error) {
                    $rootScope.tipService.setMessage(error.message, 'warning');
                });
            }
        }
        // $scope.chooseItemTab1 = null;
    };
    //注销
    $scope.cancel = function () {
        if (!$scope.chooseItemTab1) {
            $rootScope.tipService.setMessage('请先选择用户', 'warning');
        } else {
            console.log($scope.chooseItemTab1);
            confirmService.set('确认提示', '确定要删除此用户吗?', function () {
                var json = {
                    key: $scope.chooseItemTab1
                };
                tradeRegulationAll.cancel(json)
                    .then(function (res) {
                        $rootScope.tipService.setMessage(res.message, 'warning');
                        $scope.tradeRegulationSearch()
                    }, function (error) {
                        $rootScope.tipService.setMessage(error.message, 'warning');
                    });
                confirmService.clear();
                // $scope.chooseItemTab1 = null;
            });
        }
    };
}])
// server
// 交易规则接口
    .factory('tradeRegulationAll', ['$q', '$http', '$rootScope', function ($q, $http, $rootScope) {
        return {
            riskSearch: function (json) {
                var deferred = $q.defer();
                $http({
                    method: "POST",
                    url: $rootScope.baseUrl + "admin/trade/rule/query/filter",
                    data: json,
                    headers: {
                        'Content-Type': 'application/json;charset=UTF-8'
                    }
                }).success(function (res) {
                    deferred.resolve(res);
                }).error(function (res) {
                    deferred.reject(res);
                });
                return deferred.promise;
            },
            riskFilterSearch: function (json) {
                // alert(json);
                var deferred = $q.defer();
                $http({
                    method: "GET",
                    url: $rootScope.baseUrl + "admin/trade/rule/query/filter",
                    data: json,
                    headers: {
                        'Content-Type': 'application/json;charset=UTF-8'
                    }
                }).success(function (res) {
                    deferred.resolve(res);
                }).error(function (res) {
                    deferred.reject(res);
                });
                return deferred.promise;
            },
            riskAdd: function (json) {
                var deferred = $q.defer();
                $http({
                    method: "POST",
                    url: $rootScope.baseUrl + "admin/trade/rule/insert",
                    data: json,
                    headers: {
                        'Content-Type': 'application/json;charset=UTF-8'
                    }
                }).success(function (res) {
                    deferred.resolve(res);
                }).error(function (res) {
                    deferred.reject(res);
                });
                return deferred.promise;
            },
            riskModify: function (json) {
                var deferred = $q.defer();
                $http({
                    method: "POST",
                    url: $rootScope.baseUrl + "admin/trade/rule/modify",
                    data: json,
                    headers: {
                        'Content-Type': 'application/json;charset=UTF-8'
                    }
                }).success(function (res) {
                    deferred.resolve(res);
                }).error(function (res) {
                    deferred.reject(res);
                });
                return deferred.promise;
            },
            cancel: function (json) {
                var deferred = $q.defer();
                $http({
                    method: "POST",
                    url: $rootScope.baseUrl + "admin/trade/rule/delete",
                    data: json,
                    headers: {
                        'Content-Type': 'application/json;charset=UTF-8'
                    }
                }).success(function (res) {
                    deferred.resolve(res);
                }).error(function (res) {
                    deferred.reject(res);
                });
                return deferred.promise;
            }
        }
    }])