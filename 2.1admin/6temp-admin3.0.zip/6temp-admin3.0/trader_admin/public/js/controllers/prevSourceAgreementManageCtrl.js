app.controller("prevSourceAgreementManageCtrl", ['$scope', '$timeout', '$q', '$http', 'myHttp', 'getPrevSourceAgreementData', 'tipService', '$rootScope', 'confirmService', 'getPageNum','localStorageService', function ($scope, $timeout, $q, $http, myHttp, getPrevSourceAgreementData, tipService, $rootScope, confirmService, getPageNum,localStorageService) {
    localStorageService.clear('userIdChecked');
    $scope.search = function () {
        getPrevSourceAgreementData.search().then(function (res) {
            if (res.retMsg.code == "000000") {
                $scope.searchResult = res.list;
                console.log($scope.searchResult)
                pageJump($scope.searchResult);
                var checkedUserId=localStorageService.get('userIdChecked'); //获取上一次存储的id
                $scope.switchUserId(checkedUserId,$scope.searchResult); //执行选中方法
            } else {
                $rootScope.tipService.setMessage(res.retMsg.message, 'warning');
            }
        }, function (error) {
            $rootScope.tipService.setMessage(error.retMsg.message, 'warning');
        });
    };
    // 存储选中
    $scope.switchUserId=function(parameter,responseData){
        $timeout(function(){
            for(var i=0;i< responseData.length;i++){
                if(parameter==responseData[i].key){
                    $scope.key = parameter;
                    $('#dataReport input[type=checkbox]').not('.start_using').eq(i).prop('checked', true);
                    return;
                }
            }
        },300)
    };
    //单选
    $scope.checkedTab1 = function (index, key, name, enable) {
        $scope.name = name;
        $scope.enable = enable;
        var userIdChecked=localStorageService.get('userIdChecked');
        $('#dataReport input[type=checkbox]').not('.start_using').prop('checked',false);
        if (key == userIdChecked) {
            localStorageService.clear('userIdChecked');
            $scope.key = '';
        }else{
            $('#dataReport input[type=checkbox]').not('.start_using').eq(index).prop('checked', true);
            localStorageService.update('userIdChecked',key);
            $scope.key = key;
        }
    };
    //新增
    $scope.addNewAgreement = function () {
        $scope.name='';
        $scope.addEditText = '新增';
        $scope.enable = true;
        $scope.newAgreementShow = true;
    };
    //修改
    $scope.edit = function () {
        if (!$scope.key) {
            $rootScope.tipService.setMessage('请先选择协议!', 'warning');
        }
        else {
            $scope.addEditText = '修改';
            $scope.newAgreementShow = true;
            $scope.keyShow = true;
        }
    };
    //取消
    $scope.abolish=function(){
        $scope.key='';
        $scope.name='';
        $scope.newAgreementShow = false;
    };
    //提交
    $scope.addNewAgreementSubmit = function () {
        if ($scope.addEditText == '新增') {
            if ($scope.name == '') {
                $rootScope.tipService.setMessage('请输入协议名称!', 'warning');
            } else {
                var json = {
                    upProtocol: {
                        key: $scope.key,
                        name: $scope.name,
                        enable: $scope.enable
                    }
                };
                if (toValidate('#Agreementform')) {
                    getPrevSourceAgreementData.addNewInsert(json).then(function (res) {
                        if (res.code == "000000") {
                            $scope.abolish();
                            $scope.search();
                            $rootScope.tipService.setMessage(res.message, 'warning');
                        } else {
                            $rootScope.tipService.setMessage(res.message, 'warning');
                        }
                    }, function (error) {
                        $rootScope.tipService.setMessage(error.retMsg.message, 'warning');
                    });
                }
            }
        } else if ($scope.addEditText == '修改') {
            if ($scope.name == '') {
                $rootScope.tipService.setMessage('请填写修改名称!', 'warning');
            }
            else {
                var json = {
                    upProtocol: {
                        key: $scope.key,
                        name: $scope.name,
                        enable: $scope.enable
                    }
                };
                if (toValidate('#Agreementform')) {
                    getPrevSourceAgreementData.edit(json).then(function (res) {
                        if (res.code == "000000") {
                            $scope.abolish();
                            $scope.search();
                            $rootScope.tipService.setMessage(res.message, 'warning');
                        } else {
                            $rootScope.tipService.setMessage(res.message, 'warning');
                        }
                    }, function (error) {
                        $rootScope.tipService.setMessage(error.message, 'warning');
                    });
                }
            }

        }
    };
    //删除
    $scope.cancel = function () {
        if (!$scope.key) {
            $rootScope.tipService.setMessage('请先选择账户', 'warning');
        }
        else {
            confirmService.set('确认提示', '确定要注销此账户?', function () {
                getPrevSourceAgreementData.close($scope.chooseItemTab1).then(function (res) {
                    if (res.data.code == "000000") {
                        $rootScope.tipService.setMessage(res.data.message, 'warning');
                        $scope.search();
                    } else {
                        $rootScope.tipService.setMessage(res.data.message, 'warning');
                    }
                }, function (error) {
                    $rootScope.tipService.setMessage(error.data.message, 'warning');
                });
                confirmService.clear();
            })
        }
    };
    // 分页
    var pageJump = function (tmpArrList) {
        $timeout(function () {
            if (tmpArrList != undefined) {
                console.log(tmpArrList);
                $scope.currentPage = 1;//当前页数
                $scope.dataNum = tmpArrList.length;
                $scope.showDataChoose = getPageNum.pageNum();//获取分页
                $scope.showNum = $scope.showDataChoose[0];//初始显示刷具条数
                $scope.showPage = false;
                $timeout(function () {
                    $scope.showPage = true;
                    $scope.copyDataArray = tmpArrList.slice(0, 14); //初始15条数据
                }, 10)
                $scope.dataPage = Math.ceil($scope.dataNum / $scope.showNum.showNum);

                //上下页
                $scope.pageSlect = function (type) {
                    if (type == 'prev') {
                        if ($scope.currentPage != 1) {
                            $scope.currentPage--;
                            $scope.turnPage();
                        } else {
                            $scope.copyDataArray = tmpArrList.slice(0, 14); //初始15条数据
                        }
                    }
                    else {
                        if ($scope.currentPage < $scope.dataPage) {
                            $scope.currentPage++;
                            $scope.turnPage();
                        }
                    }
                };
                //每页数据量
                $scope.baseDataArray = [];
                $scope.copyDataArray = [];
                $scope.pageSelect = function (params) {
                    $scope.showNum.showNum = params.showNum;
                    $scope.copyDataArray = tmpArrList.slice(0, (params.showNum - 1));
                    $scope.dataPage = Math.ceil($scope.dataNum / $scope.showNum.showNum);
                    $scope.currentPage = 1;
                };
                $scope.turnPage = function () {
                    $scope.copyDataArray = tmpArrList.slice((($scope.currentPage - 1) * 15), (($scope.currentPage + 1) * 15 - 1));
                };
                //固定页面跳转
                $scope.jumpPage = function (num) {
                    num = parseInt(num);
                    if (parseInt(num, 10) === num && num <= ($scope.dataPage + 1) && num > 0) {
                        $scope.currentPage = num;
                        $scope.jumpPageNum = '';
                        $scope.turnPage();
                    } else {
                        $scope.copyDataArray = tmpArrList.slice(0, 14); //初始15条数据
                    }
                }
            } else {
                pageJump(tmpArrList);
            }
        }, 200);
    };
}])
    .factory('getPrevSourceAgreementData', ['$rootScope', '$http', '$q', function ($rootScope, $http, $q) {
        return {
            //上手协议查询
            search: function () {
                var deferred = $q.defer();
                $http({
                    method: "GET",
                    url: $rootScope.baseUrl + "c/up/protocol/query/all"
                }).success(function (res) {
                    deferred.resolve(res);
                }).error(function (res) {
                    deferred.reject(res);
                });
                return deferred.promise;
            },
            //新增
            addNewInsert: function (json) {
                var deferred = $q.defer();
                $http({
                    method: "POST",
                    url: $rootScope.baseUrl + "c/up/protocol/insert",
                    data: json
                }).success(function (res) {
                    deferred.resolve(res);
                }).error(function (res) {
                    deferred.reject(res);
                });
                return deferred.promise;
            },
            //修改
            edit: function (json) {
                var deferred = $q.defer();
                $http({
                    method: "POST",
                    url: $rootScope.baseUrl + "c/up/protocol/modify",
                    data: json
                }).success(function (res) {
                    deferred.resolve(res);
                }).error(function (res) {
                    deferred.reject(res);
                });
                return deferred.promise;
            },
            // 注销
            close: function (key) {
                var json = {
                    key: key
                };
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'c/up/protocol/delete',
                    data: json
                }).then(function successCallback(response) {
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            }
        }
    }]);
