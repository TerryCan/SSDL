app.controller('riskRegulationCtrl',['$timeout','$scope','$rootScope','riskRegulationAll','getFormularRiskType','getRiskCtrlConditionType','getRiskActionType','confirmService','tipService','localStorageService','getPageNum','getRiskActionTypeOne',function($timeout,$scope,$rootScope,riskRegulationAll,getFormularRiskType,getRiskCtrlConditionType,getRiskActionType,confirmService,tipService,localStorageService,getPageNum,getRiskActionTypeOne){
    $scope.toggleTraderSearchState=false;
    $scope.Toggle = function(){
        $scope.toggleTraderSearchState = !$scope.toggleTraderSearchState;
        if($scope.toggleTraderSearchState){
           $('.search_column').css('height','auto');
        }
        else{
           $('.search_column').css('height','36px');
        }
    };

    localStorageService.clear('userIdChecked');
    //风控规则查询(过滤)
    $scope.actionType='';
    $scope.formularType='';
    $scope.OperatorType='';
    $scope.EnableType='';
    $scope.riskRegulationSearch=function(){
        var json={qryConditionList:
            [{field:"Action", value:parseFloat($scope.actionType)},
                {field:"Formular", value:parseFloat($scope.formularType)},
                {field:"Operator", value:$scope.OperatorType},
                {field:"Enable", value:$scope.EnableType}
            ]};
        riskRegulationAll.riskSearch(json)
            .then(function(res){
                if(res.retMsg.code==='000000'){
                    $scope.riskList=res.list;
                    pageJump( $scope.riskList);
                    var checkedUserId=localStorageService.get('userIdChecked');
                    $scope.switchUserId(checkedUserId,$scope.riskList);
                    console.log($scope.riskList);
                }else{
                    $rootScope.tipService.setMessage(res.retMsg.message, 'warning');
                }
            },function(error){
                $rootScope.tipService.setMessage(error.message, 'warning');
            });
    };
 //数据转换
    $scope.switchOperator=function(parameter){
        for(var i=0;i<$scope.customerManageResult.length;i++){
            if(parameter=$scope.customerManageResult[i].userId){
                return $scope.customerManageResult[i].loginName
            }
        }
    };
    //公式类型
    $scope.FormularRiskType=getFormularRiskType;
    $scope.getFormular=function(parameter){
        for(i=0;i<$scope.FormularRiskType.length;i++){
            if(parameter==$scope.FormularRiskType[i].id){
                return $scope.FormularRiskType[i].name;
            }
        }
    };
    //公式条件
    $scope.RiskCtrlConditionType=getRiskCtrlConditionType;
    $scope.getCondition=function(Condition,Para1,Para2){
        switch(Condition){
            case 0: return 'x>'+Para1;
                break;
            case 1: return 'x>='+Para1;
                break;
            case 2: return 'x<'+Para1;
                break;
            case 3: return 'x<='+Para1;
                break;
            case 4: return Para1+'<x<'+Para2;
                break;
            default: return Para1+'<=x<='+Para2;
        }
    };
    //动作类型
    // $scope.RiskActionType=getRiskActionType;
    $scope.RiskActionTypeOne=getRiskActionTypeOne;
    //动作转换
    $scope.getAction=function(Action){
        switch(Action){
            case 0: return '无';
                break;
            case 1: return '禁止开仓';
                break;
            case 2: return '禁止平仓';
                break;
            case 3: return '禁止开仓|禁止平仓';
                break;
            case 4: return '告警';
                break;
            case 5: return '禁止开仓|告警';
                break;
            case 6: return '禁止平仓|告警';
                break;
            case 7: return '禁止开仓|禁止平仓|告警';
                break;
            case 8: return '强制平仓';
                break;
            case 9: return '禁止开仓|强制平仓';
                break;
            case 10: return '禁止平仓|强制平仓';
                break;
            case 11: return '禁止开仓|禁止平仓|强制平仓';
                break;
            case 12: return '告警|强制平仓';
                break;
            case 13: return '禁止开仓|告警|强制平仓';
                break;
            case 14: return '禁止平仓|告警|强制平仓';
                break;
            default: return '禁止开仓|禁止平仓|告警|强制平仓';
        }
    };
    //公式参数选择
    $scope.showFunc=function(){
        if($scope.Condition<4){
            $scope.Para1Show=false;
        }else{
            $scope.Para1Show=false;
            $scope.Para2Show=false;
        }
    };
    //动作与强平判断
    $scope.forcedFunc=function(){
        console.log($scope.Action3);
        if($scope.Action3==true){
            $('#depositClose input[type=checkbox]').removeAttr('disabled');
        }else{
            $scope.ForceCloseType0='';
            $scope.ForceCloseType1='';
            $scope.ForceCloseType2='';
            $('#depositClose input[type=checkbox]').attr('disabled',true);
        }
    };
    $("input[name='test']").click(function() {
        $scope.ForceCloseType0='';
        $scope.ForceCloseType1='';
        $scope.ForceCloseType2='';
        $("input[name='test']").not(this).attr("disabled", $(this).is(':checked'));
    });

    //选择
    $scope.checkedTab1 = function(index,Key,Name,Enable,Formular,Condition,Action,Operator,Comment,Para1,Para2,ForceCloseType){
        $scope.chooseUserData = {
            Name:Name,
            Enable:Enable,
            Formular:Formular,
            Condition:Condition,
            Action:Action,
            Operator:Operator,
            Comment:Comment,
            Para1:Para1,
            Para2:Para2,
            ForceCloseType:ForceCloseType
        };

        var userIdChecked=localStorageService.get('userIdChecked');
        $('#dataReport input[type=checkbox]').not('.start_using').prop('checked',false);
        if (Key == userIdChecked) {
            localStorageService.clear('userIdChecked');
            $scope.chooseItemTab1 = '';
        }else{
            $('#dataReport input[type=checkbox]').not('.start_using').eq(index).prop('checked', true);
            localStorageService.update('userIdChecked',Key);
            $scope.chooseItemTab1 = Key;
        }
    };
    // 存储选中
    $scope.switchUserId=function(parameter,responseData){
        $timeout(function(){
            for(var i=0;i< responseData.length;i++){
                if(parameter==responseData[i].Key){
                    // $scope.chooseItemTab1 = parameter;
                    $('#dataReport input[type=checkbox]').not('.start_using').eq(i).prop('checked', true);
                    return;
                }
            }
        },300)
    };

    //风控规则新增
    $scope.Name = '';
    $scope.Para1 = '';
    $scope.Para2 = '';
    $scope.Action = '';
    $scope.Para1 = '';
    $scope.ForceCloseType='';
    $scope.addEditText = '';
    $scope.newUserShow = false;
    //数据清空
    $scope.remove=function(){
        $scope.Action0='';
        $scope.Action1='';
        $scope.Action2='';
        $scope.Action3='';
        $scope.Name = '';
        $scope.Enable = '';
        $scope.Para1 = '';
        $scope.Para2 = '';
        $scope.Action = '';
        $scope.Para1 = '';
        $scope.Formular = '';
        $scope.Condition = '';
        $scope.Comment ='';
        $scope.ForceCloseType0='';
        $scope.ForceCloseType1='';
        $scope.ForceCloseType2='';
        $scope.newUserShow = false;
    };
    $scope.addNewUser = function(){
        $scope.newUserShow = true;
        $scope.addEditText = '新增';
        $scope.Para1Show=true;
        $scope.Para2Show=true;
        $scope.Enable='';
    };
    //动作强平方式
    $scope.moveWay=function(){
        switch($scope.Action){
            case 0: $scope.Action0=false,$scope.Action1=false,$scope.Action2=false,$scope.Action3=false;break;
            case 1: $scope.Action0=true;break;
            case 2: $scope.Action1=true;break;
            case 3: $scope.Action0=true,$scope.Action1=true;break;
            case 4: $scope.Action2=true;break;
            case 5:  $scope.Action0=true,$scope.Action2=true;break;
            case 6:  $scope.Action1=true,$scope.Action2=true;break;
            case 7:  $scope.Action0=true,$scope.Action1=true,$scope.Action2=true;break;
            // case 8: $scope.Action3=true;break;
            case 9: $scope.Action0=true,$scope.Action3=true;break;
            case 10: $scope.Action1=true,$scope.Action3=true;break;
            case 11: $scope.Action0=true,$scope.Action1=true,$scope.Action3=true;break;
            case 12: $scope.Action2=true,$scope.Action3=true;break;
            case 13: $scope.Action0=true,$scope.Action2=true,$scope.Action3=true;break;
            case 14: $scope.Action1=true,$scope.Action2=true,$scope.Action3=true;break;
            default: $scope.Action0=true,$scope.Action1=true,$scope.Action2=true,$scope.Action3=true;
        };
    };
    //风控规则提交
    $scope.editUser = function(){
        if(!$scope.chooseItemTab1){
            $rootScope.tipService.setMessage('请先选择规则类型', 'warning');
        }
        else{
            $scope.addEditText = '修改';
            $scope.editUserLocked = true;
            $scope.newUserShow = true;
            $scope.Name = $scope.chooseUserData.Name;
            $scope.Enable = $scope.chooseUserData.Enable;
            $scope.Formular = $scope.chooseUserData.Formular;
            $scope.Condition = $scope.chooseUserData.Condition;
            $scope.Action = $scope.chooseUserData.Action;
            $scope.Operator = $scope.chooseUserData.Operator;
            $scope.Comment = $scope.chooseUserData.Comment;
            $scope.Para1 = $scope.chooseUserData.Para1;
            $scope.Para2 = $scope.chooseUserData.Para2;
            if($scope.Action>=8){
                $('#depositClose input[type=checkbox]').removeAttr('disabled');
                $scope.moveWay();
                switch($scope.chooseUserData.ForceCloseType){
                    case 0:  $scope.ForceCloseType0=true;break;
                    case 1:  $scope.ForceCloseType1=true;break;
                    case 2:  $scope.ForceCloseType2=true;break;
                }
            }else{
                $scope.moveWay();
            }
        }
    };
    // var Operator=localStorageService.get('selfInfo');
    $scope.addEditUserSubmit = function(){
        if($scope.addEditText == '新增'){
                if($scope.Action0==true){
                    $scope.Action0=1;
                }else{
                    $scope.Action0=0;
                };
                if($scope.Action1==true){
                    $scope.Action1=2;
                }else{
                    $scope.Action1=0;
                };
                if($scope.Action2==true){
                    $scope.Action2=4;
                }else{
                    $scope.Action2=0;
                };
                if($scope.Action3==true){
                    $scope.Action3=8;
                }else{
                    $scope.Action3=0;
                }
                var actionResult=$scope.Action0+$scope.Action1+$scope.Action2+$scope.Action3;
                if($scope.ForceCloseType0==true){
                    $scope.ForceCloseType=0;
                }else if($scope.ForceCloseType1==true){
                    $scope.ForceCloseType=1;
                }else if($scope.ForceCloseType2==true){
                    $scope.ForceCloseType=2;
                }else{
                    $scope.ForceCloseType=0;
                }
                var riskctrlRule={
                    Key:'',
                    Name:$scope.Name,
                    Enable:($scope.Enable==='')?false:true,
                    Formular:parseFloat($scope.Formular),  //公式类型
                    Condition:parseFloat($scope.Condition),
                    Para1:parseFloat($scope.Para1),
                    Para2:parseFloat($scope.Para2),
                    Action:actionResult,
                    ForceCloseType:$scope.ForceCloseType,
                    Comment:$scope.Comment,
                    Operator:localStorageService.get('selfInfo').userId
                };
                var json={
                    riskctrlRule:riskctrlRule
                };
                riskRegulationAll.riskAdd(json)
                    .then(function(res){
                        $rootScope.tipService.setMessage(res.message, 'warning');
                        $scope.riskRegulationSearch();
                        $scope.remove();
                    },function(error){
                        $rootScope.tipService.setMessage(error.message, 'warning');
                    });
        }else if($scope.addEditText == '修改'){
            if($scope.addUserName == ''){
                $rootScope.tipService.setMessage('请填写角色名', 'warning');
            }else{
                if($scope.Action0==true){
                    $scope.Action0=1;
                }else{
                    $scope.Action0=0;
                };
                if($scope.Action1==true){
                    $scope.Action1=2;
                }else{
                    $scope.Action1=0;
                };
                if($scope.Action2==true){
                    $scope.Action2=4;
                }else{
                    $scope.Action2=0;
                };
                if($scope.Action3==true){
                    $scope.Action3=8;
                    $('#depositClose input[type=checkbox]').removeAttr('disabled');
                }else{
                    $scope.Action3=0;
                }
                if($scope.ForceCloseType0==true){
                    $scope.ForceCloseType=0;
                }else if($scope.ForceCloseType1==true){
                    $scope.ForceCloseType=1;
                }else if($scope.ForceCloseType2==true){
                    $scope.ForceCloseType=2;
                }else{
                    $scope.ForceCloseType='';
                }
                var actionResult=$scope.Action0+$scope.Action1+$scope.Action2+$scope.Action3;
                var riskctrlRule={
                    Key:$scope.chooseItemTab1,
                    Name:$scope.Name,
                    Formular:parseFloat($scope.Formular),  //公式类型
                    Condition:parseFloat($scope.Condition),
                    Para1:parseFloat($scope.Para1),
                    Para2:parseFloat($scope.Para2),
                    Action:actionResult,
                    ForceCloseType:$scope.ForceCloseType,
                    Enable:$scope.Enable,
                    Comment:$scope.Comment,
                    Operator:localStorageService.get('selfInfo').userId
                };
                var json={
                    riskctrlRule:riskctrlRule
                };
                riskRegulationAll.riskModify(json)
                    .then(function(res){
                        $rootScope.tipService.setMessage(res.message, 'warning');
                        $scope.riskRegulationSearch();
                        $scope.remove();
                    },function(error){
                        $rootScope.tipService.setMessage(error.message, 'warning');
                    });
            }
        }
    };
    //注销
    $scope.delete = function(){
        if(!$scope.chooseItemTab1){
            $rootScope.tipService.setMessage('请先选择用户', 'warning');
        }
        else{
            confirmService.set('确认提示','确定要删除此用户?',function(){
                var json={
                    key:$scope.chooseItemTab1
                };
                riskRegulationAll.delete(json)
                    .then(function(res){
                        $rootScope.tipService.setMessage(res.message, 'warning');
                        $scope.riskRegulationSearch()
                    },function(error){
                        $rootScope.tipService.setMessage(error.message, 'warning');
                    });
                confirmService.clear();
            });
        }
    };
    // 分页 TerryMin
    var pageJump = function(tmpArrList){
        $timeout(function(){
            if(tmpArrList != undefined){
                $scope.currentPage = 1;//当前页数
                $scope.dataNum=tmpArrList.length;
                $scope.showDataChoose = getPageNum.pageNum();//获取分页
                $scope.showNum = $scope.showDataChoose[0];//初始显示刷具条数
                $scope.showPage = false;
                $timeout(function(){
                    $scope.showPage = true;
                    $scope.copyDataArray = tmpArrList.slice(0,14); //初始15条数据
                },10);
                $scope.dataPage=Math.ceil($scope.dataNum/$scope.showNum.showNum);
                //上下页
                $scope.pageSlect = function(type){
                    if(type == 'prev'){
                        if($scope.currentPage != 1){
                            $scope.currentPage --;
                            $scope.turnPage();
                        }else{
                            $scope.copyDataArray = tmpArrList.slice(0,14); //初始15条数据
                        }
                    }
                    else{
                        if($scope.currentPage < $scope.dataPage){
                            $scope.currentPage ++;
                            $scope.turnPage();
                        }
                    }
                };
                //每页数据量
                $scope.baseDataArray = [];
                $scope.copyDataArray = [];
                $scope.pageSelect = function(params){
                    $scope.showNum.showNum = params.showNum;
                    $scope.copyDataArray = tmpArrList.slice(0,(params.showNum-1));
                    $scope.dataPage=Math.ceil($scope.dataNum/$scope.showNum.showNum);
                    $scope.currentPage = 1;
                };
                $scope.turnPage=function(){
                    $scope.copyDataArray = tmpArrList.slice((($scope.currentPage-1)*15),(($scope.currentPage+1)*15-1));
                };
                //固定页面跳转
                $scope.jumpPage = function(num){
                    num = parseInt(num);
                    if(parseInt(num,10) === num && num <= ($scope.dataPage+1) && num > 0){
                        $scope.currentPage = num;
                        $scope.jumpPageNum='';
                        $scope.turnPage();
                    }else{
                        $scope.copyDataArray = tmpArrList.slice(0,14); //初始15条数据
                    }
                }
            }else{
                pageJump(tmpArrList);
            }
        },200);
    };
}])
// server 风控接口
    .factory('riskRegulationAll',['$q','$http','$rootScope',function($q,$http,$rootScope){
        return{
            riskSearch:function(data){
                var deferred=$q.defer();
                $http({
                   method:"POST",
                   url: $rootScope.baseUrl + "c/riskctrl/rule/query/filter",
                   data:data,
                   headers: {
                        'Content-Type': 'application/json;charset=UTF-8'
                    }
                }).success(function(res){
                    deferred.resolve(res);
                }).error(function(res){
                    deferred.reject(res);
                });
                return deferred.promise;
            },
            riskAdd:function(json){
                var deferred=$q.defer();
                $http({
                    method:"POST",
                    url: $rootScope.baseUrl + "c/riskctrl/rule/insert",
                    data:json,
                    headers: {
                        'Content-Type': 'application/json;charset=UTF-8'
                    }
                }).success(function(res){
                    deferred.resolve(res);
                }).error(function(res){
                    deferred.reject(res);
                });
                return deferred.promise;
            },
            riskModify:function(json){
                var deferred=$q.defer();
                $http({
                    method:"POST",
                    url: $rootScope.baseUrl + "c/riskctrl/rule/modify",
                    data:json,
                    headers: {
                        'Content-Type': 'application/json;charset=UTF-8'
                    }
                }).success(function(res){
                    deferred.resolve(res);
                }).error(function(res){
                    deferred.reject(res);
                });
                return deferred.promise;
            },
            delete:function(json){
                var deferred=$q.defer();
                $http({
                    method:"POST",
                    url: $rootScope.baseUrl + "c/riskctrl/rule/delete",
                    data:json,
                    headers: {
                        'Content-Type': 'application/json;charset=UTF-8'
                    }
                }).success(function(res){
                    deferred.resolve(res);
                }).error(function(res){
                    deferred.reject(res);
                });
                return deferred.promise;
            }
        }
    }]);
