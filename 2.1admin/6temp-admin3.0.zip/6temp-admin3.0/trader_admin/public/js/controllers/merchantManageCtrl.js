app.controller('merchantManageCtrl', ['$rootScope', '$state', '$scope', 'merchantManageSer', '$timeout', '$sce', 'getPageNum', 'getBankState', 'getCurrencyType', 'switchBoolean', 'switchThirdPay', 'getFeeType', 'localStorageService', function ($rootScope, $state, $scope, merchantManageSer, $timeout, $sce, getPageNum, getBankState, getCurrencyType, switchBoolean, switchThirdPay, getFeeType, localStorageService) {
    $scope.toggleTraderSearchState = false;
    $scope.Toggle = function () {
        $scope.toggleTraderSearchState = !$scope.toggleTraderSearchState;
        if ($scope.toggleTraderSearchState) {
            $('.search_column').css('height', 'auto');
        }
        else {
            $('.search_column').css('height', '36px');
        }
    };
    localStorageService.clear('userIdChecked');

    //商户状态
    $scope.bankState = getBankState;
    //布尔值
    $scope.booleanTo = switchBoolean;
    //支付方式 1第三方支付 -1银行
    $scope.thirdPay = switchThirdPay;
    //机构码匹配
    var saveOrganizeData = localStorageService.get('organizeData');
    // 货币转换
    getCurrencyType.then(function (res) {
        $scope.currencyList = JSON.parse(res.content);
    });
    //银行通道名
    var bankJson = {
        page: 1,
        rows: 9999
    };
    merchantManageSer.bankChannel(bankJson).then(function (res) {
        if (res.content) {
            $scope.bankChannelList = JSON.parse(res.content).content;
        }
    });

    var processContent, processTotal;
    var source = {
        type: 'POST',
        datatype: "json",
        datafields: [  //数据字段定义
            {name: 'bankMerchantId', type: 'string'},
            {name: 'orgCode', type: 'string'},
            {name: 'thirdpayFlag', type: 'string'},
            {name: 'memberNumber', type: 'string'},
            {name: 'bankAccountNo', type: 'string'},

            {name: 'status', type: 'string'},
            {name: 'bankName', type: 'string'},
            {name: 'currency', type: 'string'},
            {name: 'payFeeNum', type: 'string'},
            {name: 'withdrawFeeNum', type: 'string'},

            {name: 'signUpFlag', type: 'string'},
            {name: 'payFlag', type: 'string'},
            {name: 'withdrawFlag', type: 'string'}
        ],
        url: $rootScope.baseUrl + 'exbank/query/bankmerchant/page',
        root: "content",
        pagesize: 10,
        processData: function (data) {
            data.page = (data.pagenum + 1) ? (data.pagenum + 1) : 1;
            data.rows = (data.pagesize) ? (data.pagesize) : 10;
            // data.order =($scope.order)?$scope.order:'desc';
            // data.sort =($scope.sort)?$scope.sort:'createTime';
            data.search_EQ_thirdpayFlag = ($scope.thirdpayFlag) ? $scope.thirdpayFlag : '';
            data.search_EQ_bankCode = ($scope.bankCode) ? $scope.bankCode : '';
            data.search_EQ_status = ($scope.status) ? $scope.status : '';
            data.search_EQ_currency = ($scope.currency) ? $scope.currency : '';

            $scope.orgCode = localStorageService.get('oldOrgCode');
            if ($scope.organizeValue == true && $scope.downOrganizeValue == true) {
                data.search_A_LLIKE_orgCode = ($scope.orgCode) ? $scope.orgCode : '';
            }
            if ($scope.organizeValue == true && $scope.downOrganizeValue == false) {
                data.search_A_EQ_orgCode = ($scope.orgCode) ? $scope.orgCode : '';
            }
            if ($scope.organizeValue == false && $scope.downOrganizeValue == true) {
                data.search_A_LLIKE_orgCode = ($scope.orgCode) ? $scope.orgCode + '-' : '';
            }
        }, //传递参数处理
        beforeLoadComplete: function (records) { //数据完全加载完执行绘制表格
            var start;
            for (var i in records) {
                start = parseInt(i);
                break;
            }
            for (var k = 0, r = processContent.length; k < r; k++) {
                records[start + k].bankMerchantId = processContent[k].bankMerchantId;
                records[start + k].orgCode = processContent[k].orgCode;
                records[start + k].thirdpayFlag = processContent[k].thirdpayFlag;
                records[start + k].memberNumber = processContent[k].memberNumber;
                records[start + k].bankAccountNo = processContent[k].bankAccountNo;

                records[start + k].status = processContent[k].status;
                records[start + k].bankName = processContent[k].bankName;
                records[start + k].currency = processContent[k].currency;
                records[start + k].payFeeNum = processContent[k].payFeeNum;
                records[start + k].withdrawFeeNum = processContent[k].withdrawFeeNum;

                records[start + k].signUpFlag = processContent[k].signUpFlag;
                records[start + k].payFlag = processContent[k].payFlag;
                records[start + k].withdrawFlag = processContent[k].withdrawFlag;
            }
        },
        beforeprocessing: function (data) { //处理总页数
            var processData = JSON.parse(data.content);
            console.log(processData);
            processContent = processData.content;
            source.totalrecords = processData.totalElements == 0 ? 5 : processData.totalElements;
            processTotal = processData.totalElements;
        },
        loadComplete: function (records) {
            $scope.saveResult = JSON.parse(records.content);
            var data = $scope.saveResult.totalElements;
            if (data == 0) {
                $('#contenttableentrustDetailGrid > div').remove();
            }
        },
        endUpdate: true
    };
    //创建数据适配器
    var dataAdapter = null;
    $scope.searchAjax = function () {
        $scope.featureShow = true;
        $scope.toggleTraderSearchState = false;
        $('.search_column').css('height', '36px');
        if (dataAdapter == null) {
            dataAdapter = new $.jqx.dataAdapter(source);
            $("#entrustDetailGrid").jqxGrid({
                source: dataAdapter,
                columns: [  //表格数据域
                    {
                        text: '上级机构',
                        datafield: 'orgCode',
                        width: '9%',
                        minwidth: 9 + '%',//设置列min宽
                        align: 'center',//设置表头
                        cellsrenderer: function (row, columnfield, value, defaulthtml, columnproperties) {
                            if (saveOrganizeData) {
                                for (var i = 0; i < saveOrganizeData.length; i++) {
                                    if (value == saveOrganizeData[i].orgCode) {
                                        return saveOrganizeData[i].orgNum;
                                    }
                                }
                            }
                        }
                    },
                    {
                        text: '商户号',
                        datafield: 'memberNumber',
                        minwidth: 10 + '%',
                        cellsalign: 'center',
                        align: 'center',
                        width: '10%',
                        // cellsrenderer: function (row, columnfield, value, defaulthtml, columnproperties) {
                        //     // if (value==1) {
                        //     //     return
                        //     // }else{
                        //     //     return
                        //     // }
                        // }
                    },
                    {
                        text: '商户状态',
                        datafield: 'status',
                        width: '9%',
                        minwidth: 9 + '%',
                        align: 'center',
                        cellsrenderer: function (row, columnfield, value, defaulthtml, columnproperties) {
                            if (getBankState) {
                                for (var i = 0; i < getBankState.length; i++) {
                                    if (value == getBankState[i].id) {
                                        return getBankState[i].name;
                                    }
                                }
                            }
                        }
                    },
                    {
                        text: '通道名',
                        datafield: 'bankName',
                        width: '9%',
                        minwidth: 9 + '%',
                        align: 'center'
                    },
                    {
                        text: '支付方式',
                        datafield: 'thirdpayFlag',
                        width: '9%',
                        minwidth: 9 + '%',
                        align: 'center',
                        cellsrenderer: function (row, columnfield, value, defaulthtml, columnproperties) {
                            if (switchThirdPay) {
                                for (var i = 0; i < switchThirdPay.length; i++) {
                                    if (value == switchThirdPay[i].id) {
                                        return switchThirdPay[i].name;
                                    }
                                }
                            }
                        }
                    },
                    {
                        text: '币种',
                        datafield: 'currency',
                        width: '9%',
                        minwidth: 9 + '%',
                        align: 'center',
                        cellsrenderer: function (row, columnfield, value, defaulthtml, columnproperties) {
                            if ($scope.currencyList) {
                                for (var i = 0; i < $scope.currencyList.length; i++) {
                                    if (value == $scope.currencyList[i].currency) {
                                        return $scope.currencyList[i].currencyName;
                                    }
                                }
                            }
                        }
                    },
                    {
                        text: '充值手续费',
                        datafield: 'payFeeNum',
                        width: '9%',
                        minwidth: 9 + '%',
                        align: 'center'
                    },
                    {
                        text: '提现手续费',
                        datafield: 'withdrawFeeNum',
                        width: '9%',
                        minwidth: 9 + '%',
                        align: 'center'
                    },
                    {
                        text: '能否签约',
                        datafield: 'signUpFlag',
                        width: '9%',
                        minwidth: 9 + '%',
                        align: 'center',
                        cellsrenderer: function (row, columnfield, value, defaulthtml, columnproperties) {
                            if (switchBoolean) {
                                for (var i = 0; i < switchBoolean.length; i++) {
                                    if (value == switchBoolean[i].id) {
                                        return switchBoolean[i].name;
                                    }
                                }
                            }
                        }
                    },
                    {
                        text: '能否充值',
                        datafield: 'payFlag',
                        width: '9%',
                        minwidth: 9 + '%',
                        align: 'center',
                        cellsrenderer: function (row, columnfield, value, defaulthtml, columnproperties) {
                            if (switchBoolean) {
                                for (var i = 0; i < switchBoolean.length; i++) {
                                    if (value == switchBoolean[i].id) {
                                        return switchBoolean[i].name;
                                    }
                                }
                            }
                        }
                    },
                    {
                        text: '能否提现',
                        datafield: 'withdrawFlag',
                        width: '9%',
                        minwidth: 9 + '%',
                        align: 'center',
                        cellsrenderer: function (row, columnfield, value, defaulthtml, columnproperties) {
                            if (switchBoolean) {
                                for (var i = 0; i < switchBoolean.length; i++) {
                                    if (value == switchBoolean[i].id) {
                                        return switchBoolean[i].name;
                                    }
                                }
                            }
                        }
                    }
                ],
                width: 100 + '%',
                height: 81 + '%',
                theme: 'metrodark',
                virtualmode: true,
                rendergridrows: function (params) { //将数据渲染到页面
                    return params.data;
                },
                pageable: true,
                pagesizeoptions: ['10', '30', '100', '200'],
                // sortable: true,
                columnsresize: true,//列间距是否可调整
                clipboard: true
            });
        } else {
            $("#entrustDetailGrid").jqxGrid('updatebounddata', 'cells');
        }
    };

    //分页
    $("#entrustDetailGrid").on("pagechanged", function (event) {
        console.log(event)
    });
    //排序
    $("#entrustDetailGrid").on("sort", function (event) {
        var sortinformation = event.args.sortinformation;
        $scope.sort = sortinformation.sortcolumn;
        $scope.order = ($scope.sort) ? (sortinformation.sortdirection.ascending) ? 'asc' : 'desc' : 'asc';
        data = {
            order: $scope.order,
            sort: $scope.sort
        };
        source.processData(data);
        $("#entrustDetailGrid").jqxGrid('updatebounddata', 'sort');
    });
    //选中
    $('#entrustDetailGrid').on('rowselect', function (event) {
        $scope.bankMerchantId = event.args.row.bankMerchantId;
        localStorageService.update('userIdChecked',$scope.bankMerchantId);
    });
    //修改
    $scope.modify = function () {
        if (!$scope.bankMerchantId) {
            $rootScope.tipService.setMessage('请先选择用户', 'warning');
        } else {
            $state.go('tabs.merchantManageEdit')
        }
    };

    //配置运营参数
    $scope.payFeeNum = '';
    $scope.payFeeType = '';
    $scope.withdrawFeeType = '';
    $scope.channelThirdpayFlag = '';
    $scope.channelSignUpFlag = '';
    $scope.channelPayFlag = '';
    $scope.channelWithdrawFlag = '';
    $scope.withdrawFeeNum = '';
    $scope.deployConfig = function () {
        if (!$scope.bankMerchantId) {
            $rootScope.tipService.setMessage('请先选择用户', 'warning');
        } else {
            $scope.channelColumn = true;
        }
    };
    $scope.deploy = function () {
        var merchantTransconfigV = {
            bankMerchantId: $scope.bankMerchantId,
            signUpFlag: parseInt($scope.channelSignUpFlag),
            payFlag: parseInt($scope.channelPayFlag),
            withdrawFlag: parseInt($scope.channelWithdrawFlag),
            payFeeNum: $scope.payFeeNum,
            payFeeType: parseInt($scope.payFeeType),
            withdrawFeeNum: $scope.withdrawFeeNum,
            withdrawFeeType: parseInt($scope.withdrawFeeType)
        };
        var json = {
            merchantTransconfigV: merchantTransconfigV
        };
        merchantManageSer.unitDeploy(json)
            .then(function (res) {
                $scope.channelColumn = false;
                $rootScope.tipService.setMessage(res.message, 'warning');
                $scope.searchAjax();
            }, function (error) {
                $rootScope.tipService.setMessage(error.message, 'warning');
            })
    };

}])

// Server
    .factory('merchantManageSer', ['$http', 'localStorageService', 'myHttp', '$q', '$rootScope', function ($http, localStorageService, myHttp, $q, $rootScope) {
        return {
            merchantSearch: function (json) {
                var deferred = $q.defer();
                myHttp.post("exbank/query/bankmerchant/page", json)
                    .then(function (res) {  // 调用承诺API获取数据 .resolve
                        deferred.resolve(res);
                    }, function (res) {  // 处理错误 .reject
                        deferred.reject(res);
                    });
                return deferred.promise;

            },
            unitDeploy: function (json) {
                var deferred = $q.defer();
                $http({
                    method: "POST",
                    url: $rootScope.baseUrl + "exbank/update/bankmerchant/transconfig",
                    data: json,
                    headers: {
                        'Content-Type': 'application/json;charset=UTF-8'
                    }
                }).success(function (res) {
                    deferred.resolve(res);
                }).error(function (res) {
                    deferred.reject(res);
                });
                return deferred.promise;
            },
            //银行通道
            bankChannel: function (json) {
                var deferred = $q.defer();
                myHttp.post("exbank/query/bankchannel/page", json)
                    .then(function (res) {
                        deferred.resolve(res);
                    }, function (res) {
                        deferred.reject(res);
                    });
                return deferred.promise;
            }
        }
    }]);