app.controller('productManageCtrl',['$rootScope','$scope',function($rootScope,$scope){

}])
