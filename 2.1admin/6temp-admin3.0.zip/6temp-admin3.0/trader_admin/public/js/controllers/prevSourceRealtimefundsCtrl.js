app.controller("prevSourceRealtimefundsCtrl", ['$scope', '$timeout', 'prevSourceRealtimefundsCtrlSel', 'getPageNum', 'plateType', 'accountManagementSer', '$rootScope', 'dataSer', function($scope, $timeout, prevSourceRealtimefundsCtrlSel, getPageNum, plateType, accountManagementSer, $rootScope, dataSer) {
            //分页
            var pageJump = function(tmpArrList) {
                $timeout(function() {
                    if (tmpArrList != undefined) {
                        $scope.currentPage = 1; //当前页数
                        $scope.dataNum = tmpArrList.length;
                        $scope.showDataChoose = getPageNum.pageNum(); //获取分页
                        $scope.showNum = $scope.showDataChoose[0]; //初始显示刷具条数
                        $scope.showPage = false;
                        $timeout(function() {
                            $scope.showPage = true;
                            $scope.copyDataArray = tmpArrList.slice(0, 14); //初始15条数据
                        }, 10)
                        $scope.dataPage = Math.ceil($scope.dataNum / $scope.showNum.showNum);

                        //上下页
                        $scope.pageSlect = function(type) {
                                if (type == 'prev') {
                                    if ($scope.currentPage != 1) {
                                        $scope.currentPage--;
                                        $scope.turnPage();
                                    } else {
                                        $scope.copyDataArray = tmpArrList.slice(0, 14); //初始15条数据
                                    }
                                } else {
                                    if ($scope.currentPage < $scope.dataPage) {
                                        $scope.currentPage++;
                                        $scope.turnPage();
                                    }
                                }
                            }
                            //每页数据量
                        $scope.baseDataArray = [];
                        $scope.copyDataArray = [];
                        $scope.pageSelect = function(params) {
                            $scope.showNum.showNum = params.showNum;
                            $scope.copyDataArray = tmpArrList.slice(0, (params.showNum - 1));
                            $scope.dataPage = Math.ceil($scope.dataNum / $scope.showNum.showNum);
                            $scope.currentPage = 1;
                        }
                        $scope.turnPage = function() {
                                $scope.copyDataArray = tmpArrList.slice((($scope.currentPage - 1) * 15), (($scope.currentPage + 1) * 15 - 1));
                            }
                            //固定页面跳转
                        $scope.jumpPage = function(num) {
                            num = parseInt(num);
                            if (parseInt(num, 10) === num && num <= ($scope.dataPage + 1) && num > 0) {
                                $scope.currentPage = num;
                                $scope.jumpPageNum = '';
                                $scope.turnPage();
                            } else {
                                $scope.copyDataArray = tmpArrList.slice(0, 14); //初始15条数据
                            }
                        }
                    } else {
                        pageJump(tmpArrList);
                    }
                }, 200);
            };

            $scope.account = "";
            $scope.DirectNum = "";
            $scope.calcType = "";
            accountManagementSer.accountSearch()
                .then(function(response) {
                    var accountList = response.list;
                    $scope.accountList = accountList;
                    console.log($scope.accountList);
                })
            $scope.accountType = function(key) {
                    for (var i = 0, r = $scope.accountList.length; i < r; i++) {
                        if (key == $scope.accountList[i].key) {
                            return $scope.accountList[i].name
                        }

                    }
                }
                //统计查询
            $scope.search = function() {
                prevSourceRealtimefundsCtrlSel.search($scope.account)
                    .then(function(res) {
                        //console.log(res)
                        if (res.data.code = "000000") {
                            $scope.currentlsit = res.data.list;
                            pageJump($scope.currentlsit);
                            console.log($scope.currentlsit)
                        } else {
                            $rootScope.tipService.setMessage(res.data.message, 'warning');
                        }
                    }, function(error) {
                        $rootScope.tipService.setMessage(error.data.message, 'warning');
                    });
            }
    }])
    .factory('prevSourceRealtimefundsCtrlSel', ['$http', 'localStorageService', 'myHttp', '$q', '$rootScope', function($http, localStorageService, myHttp, $q, $rootScope) {
        return {
            search: function(account) {
                var deferred = $q.defer();
                $http({
                        method: 'POST',
                        url: $rootScope.baseUrl + 'c/up/capital/query',
                        data: {
                            "account": account,
                        }
                    })
                    .then(function(res) { // 调用承诺API获取数据 .resolve
                        deferred.resolve(res);
                    }, function(res) { // 处理错误 .reject
                        deferred.reject(res);
                    });
                return deferred.promise;
            }

        }
    }])