app.controller('prevSourceOptionalopponentmechanismCtrl', ['$rootScope', '$timeout', '$scope', 'getOptionalopponentmechanismData', 'getPrevSourcePositionData', 'dataSer', 'confirmService', 'tipService', 'getPageNum','memberMangerCtrlSer', function($rootScope, $timeout, $scope, getOptionalopponentmechanismData, getPrevSourcePositionData, dataSer, confirmService, tipService, getPageNum,memberMangerCtrlSer) {
            // 分页
            var pageJump = function(tmpArrList) {
                $timeout(function() {
                    if (tmpArrList != undefined) {
                        console.log(tmpArrList);
                        $scope.currentPage = 1; //当前页数
                        $scope.dataNum = tmpArrList.length;
                        $scope.showDataChoose = getPageNum.pageNum(); //获取分页
                        $scope.showNum = $scope.showDataChoose[0]; //初始显示刷具条数
                        $scope.showPage = false;
                        $timeout(function() {
                            $scope.showPage = true;
                            $scope.copyDataArray = tmpArrList.slice(0, 14); //初始15条数据
                        }, 10)
                        $scope.dataPage = Math.ceil($scope.dataNum / $scope.showNum.showNum);

                        //上下页
                        $scope.pageSlect = function(type) {
                                if (type == 'prev') {
                                    if ($scope.currentPage != 1) {
                                        $scope.currentPage--;
                                        $scope.turnPage();
                                    } else {
                                        $scope.copyDataArray = tmpArrList.slice(0, 14); //初始15条数据
                                    }
                                } else {
                                    if ($scope.currentPage < $scope.dataPage) {
                                        $scope.currentPage++;
                                        $scope.turnPage();
                                    }
                                }
                            }
                            //每页数据量
                        $scope.baseDataArray = [];
                        $scope.copyDataArray = [];
                        $scope.pageSelect = function(params) {
                            $scope.showNum.showNum = params.showNum;
                            $scope.copyDataArray = tmpArrList.slice(0, (params.showNum - 1));
                            $scope.dataPage = Math.ceil($scope.dataNum / $scope.showNum.showNum);
                            $scope.currentPage = 1;
                        }
                        $scope.turnPage = function() {
                                $scope.copyDataArray = tmpArrList.slice((($scope.currentPage - 1) * 15), (($scope.currentPage + 1) * 15 - 1));
                            }
                            //固定页面跳转
                        $scope.jumpPage = function(num) {
                            num = parseInt(num);
                            if (parseInt(num, 10) === num && num <= ($scope.dataPage + 1) && num > 0) {
                                $scope.currentPage = num;
                                $scope.jumpPageNum = '';
                                $scope.turnPage();
                            } else {
                                $scope.copyDataArray = tmpArrList.slice(0, 14); //初始15条数据
                            }
                        }
                    } else {
                        pageJump(tmpArrList);
                    }
                }, 200);
            };
            $scope.account = "";
            //获取上手账号管理的Key值
            getPrevSourcePositionData.addinsert()
                .then(function(response) {
                    console.log(response);
                    var accountList = response.list;
                    $scope.accountList = accountList;
                })
            dataSer.organizeQuerySer()
                .then(function(res) {
                    $scope.orgList = res;
                    console.log($scope.orgList)
                });
           memberMangerCtrlSer.search(9999,1,'','','')
            .then(function(res){
                $scope.meborgList = JSON.parse(res.content).content;
                console.log($scope.meborgList)
            })

            $scope.getOrgVal = function(OrgCode) {
                if($scope.meborgList){
                    console.log($scope.meborgList)
                for (var i = 0; i < $scope.meborgList.length; i++) {
                    if (OrgCode == $scope.meborgList[i].orgCode) {
                        return $scope.meborgList[i].orgNum;
                    }
                    }
                }
            }

            $scope.addOrgValFTC = function(data) {
                    console.log(data);
                    $scope.superOrgId = data.orgId;
                    $scope.superorgCode = data.orgCode;
                    $scope.addOrgVal = data.text;
                }
                //查询所有指定
            $scope.search = function() {
                    getOptionalopponentmechanismData.search($scope.account)
                        .then(function(res) {
                            if (res.retMsg.code == "000000") {
                                $scope.searchResult = res.list;
                                pageJump($scope.searchResult);
                            } else {
                                $rootScope.tipService.setMessage(res.retMsg.message, 'warning');
                            }
                        }, function(error) {
                            $rootScope.tipService.setMessage(error.retMsg.message, 'warning');
                        });
                },
                //$scope.search();

                $scope.accountText = function(account) {
                    for (var i = 0, r = $scope.accountList.length; i < r; i++) {
                        if (account == $scope.accountList[i].key) {
                            return $scope.accountList[i].name;
                        }
                    }
                }

            $scope.key = "";
            //新增
            $scope.chooseItemTab1 = null;
            $scope.newcreateOrderShow = false;
            addEditText = "";
            $scope.addNewData = function() {
                    $scope.newcreateOrderShow = true;
                    $scope.key = '0'; //编号(主键，自动生成)
                    $scope.addEditText = '新增';
                    $scope.account = ""; //名称
                    $scope.orgId = ""; //内部用户(或机构)编号,*表示全部
                }
                //单选
            $scope.checkedTab1 = function(index, key) {
                $scope.chooseItemTab1 = key;
                $scope.key = $scope.searchResult[index].key;
                $scope.account = $scope.searchResult[index].account;
                $scope.orgId = $scope.searchResult[index].orgId;
                $('#dataReportTab1 input[type=checkbox]').not('.start_using').prop('checked', false);
                $('#dataReportTab1 input[type=checkbox]').not('.start_using').eq(index).prop('checked', true);
                console.log($scope.key);
            }

            $scope.addNewSubmit = function() {
                if ($scope.addEditText == '新增') {
                    if ($scope.account == '') {
                        $rootScope.tipService.setMessage('请先选择账户', 'warning');
                    } else {
                        var organize = {
                            key: $scope.key,
                            account: $scope.account,
                            OrgId: $scope.superOrgId,
                            OrgCode: $scope.superorgCode,
                        }
                        var json = {
                            organize: organize
                        }
                        if (toValidate('#OptionalopAdd')) {
                            getOptionalopponentmechanismData.addNewinsert(json)
                                .then(function(res) {
                                    /* $scope.keyshow=false;*/
                                    $scope.newcreateOrderShow = false;
                                    $rootScope.tipService.setMessage(res.retMsg.message, 'warning');
                                    $scope.search();
                                }, function(error) {
                                    $$rootScope.tipService.setMessage(error.retMsg.message, 'warning');
                                });
                        }
                    }
                }
            }

            //注销
            $scope.cancel = function() {
                if (!$scope.chooseItemTab1) {
                    $rootScope.tipService.setMessage('请先选择账户', 'warning');
                } else {

                    confirmService.set('确认提示', '确定要删除此账户?', function() {
                        getOptionalopponentmechanismData.close($scope.chooseItemTab1)
                            .then(function(res) {
                                $rootScope.tipService.setMessage(res.message, 'warning');
                                $scope.search();
                            }, function(error) {
                                $rootScope.tipService.setMessage(error.message, 'warning');
                            });
                        confirmService.clear();
                    })
                }
            }
    }])
    .factory('getOptionalopponentmechanismData', ['$rootScope', '$http', '$q', function($rootScope, $http, $q) {
        return {
            //上手协议查询
            search: function(account) {
                var deferred = $q.defer();
                $http({
                    method: "POST",
                    url: $rootScope.baseUrl + "c/up/account/organize/query/all",
                    data: {
                        'account': account
                    }
                }).success(function(res) {
                    deferred.resolve(res);
                }).error(function(res) {
                    deferred.reject(res);
                });
                return deferred.promise;
            },
            //添加
            addNewinsert: function(json) {
                var deferred = $q.defer();
                $http({
                    method: "POST",
                    url: $rootScope.baseUrl + "c/up/account/organize/insert",
                    data: json,
                }).success(function(res) {
                    deferred.resolve(res);
                }).error(function(res) {
                    deferred.reject(res);
                });
                return deferred.promise;
            },
            // 注销
            close: function(key) {
                var json = {
                    key: key
                }
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'c/up/account/organize/delete',
                    data: json
                }).then(function successCallback(response) {
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;

            }
        }
    }])