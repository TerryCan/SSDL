app.controller('commissionSplitCtrl', ['$rootScope', '$scope', 'commissionSplitCtrlSer', 'getPageNum', 'dataSer', '$state', 'localStorageService', 'CommissionallocationAddCtrlSer', 'memberMangerCtrlSer', function($rootScope, $scope, commissionSplitCtrlSer, getPageNum, dataSer, $state, localStorageService, CommissionallocationAddCtrlSer, memberMangerCtrlSer) {
		$scope.toggleTraderSearchState = false;
		$scope.Toggle = function() {
			$scope.toggleTraderSearchState = !$scope.toggleTraderSearchState;
			if ($scope.toggleTraderSearchState) {
				$('.search_column').css('height', 'auto');
			} else {
				$('.search_column').css('height', '36px');
			}
		};
		//localStorageService.clear('userIdChecked');
		$scope.productName = "";
		//$scope.orgCodeValCode = "";
		$scope.addOrgVal = "";
		$scope.superorgCode = "";
		$scope.allotToCode = "";

		$scope.choosedistributionState = "";
		dataSer.organizeQuerySer()
			.then(function(res) {
				$scope.orgList = res;
			});
		//全部状态下所属机构
		dataSer.organizeQuerylistSer()
			.then(function(res) {
				$scope.orgAllList = res;
			});
		$scope.addOrgValFTC = function(data) {
			console.log(data);
			$scope.superOrgId = data.orgId;
			$scope.superorgCode = data.orgCode;
			$scope.addOrgVal = data.text;
		};
		$scope.addOrgVal1 = function() {
			$scope.addOrgVal = '';
			$scope.superorgCode = '';
		}
		$scope.allotToCodesValFTC = function(data) {
			console.log(data);
			$scope.superOrgId = data.orgId;
			$scope.allotToCode = data.orgCode;
			$scope.allotToCodes = data.text;
		};
		$scope.allotToCodes1 = function() {
			$scope.allotToCodes = '';
			$scope.allotToCode = '';
		}

		//产品ID
		$scope.userInfo = localStorageService.get('selfInfo');
		console.log($scope.userInfo)
		var json = {
			orgId: $scope.userInfo.orgId,
		};
		console.log(json)
			//产品ID
		CommissionallocationAddCtrlSer.productListadmin(json)
			.then(function(res) {
				console.log(res)
				if (res.code == "000000") {
					var proadminlistdt = JSON.parse(res.content);
					$scope.proadminlist = [];
					for (var i = 0, r = proadminlistdt.length; i < r; i++) {
						$scope.proadminlist.push(proadminlistdt[i]);
					}
					console.log($scope.proadminlist)
				} else {
					$rootScope.tipService.setMessage(res.message, 'warning')
				}
			}),
			function(error) {
				$rootScope.tipService.setMessage(error.message, 'warning')
			}
		$scope.search = function(type) {
			$scope.toggleTraderSearchState=false;
			$('.search_column').css('height', '36px');
			if (type == 'search') {
				pageInitialize()
			};
			$scope.orgCode=localStorageService.get('oldOrgCode');
			var json = {
				page: $scope.currentPage,
            	rows: $scope.showNum.showNum,
				orders: 'asc',
				search_EQ_productId:$scope.productName,
				/*search_EQ_allotOrgCode: (superorgCode) ? superorgCode : '',
				search_EQ_allotToOrgCode: (allotToCode) ? allotToCode : '',*/
				search_EQ_allotType: $scope.choosedistributionState,

				};
        if($scope.organizeValue==true && $scope.downOrganizeValue==false){
                json.search_EQ_allotOrgCode=($scope.orgCode)?$scope.orgCode:'';
         }
        if($scope.organizeValue==false && $scope.downOrganizeValue==true){
            json.search_LLIKE_allotToOrgCode=($scope.orgCode)?$scope.orgCode+'-':'';
        }
			commissionSplitCtrlSer.search(json)
				.then(function(res) {
					console.log(res)
					if (res.code == '000000') {
						$scope.showPage = true;
						$scope.searchResult = JSON.parse(res.content).content;
						$scope.dataNum = JSON.parse(res.content).totalElements;
						$scope.PageNum();
						//var checkedUserId=localStorageService.get('userIdChecked'); //获取上一次存储的id
                    	//$scope.switchUserId(checkedUserId,$scope.searchResult); //执行选中方法
					} else {
						$rootScope.tipService.setMessage(res.message, 'warning');
					}
				}, function(error) {
					$rootScope.tipService.setMessage(error.message, 'warning');
				});
		}

		$scope.allotTypeData = [{
			name: '仓息',
			val: '6'
		}, {
			name: '手续费',
			val: '7'
		}];
		//本级机构名称
		$scope.adjustText = function(allotOrgCode) {
			if ($scope.orgAllList) {
				for (var i = 0, r = $scope.orgAllList.length; i < r; i++) {
					if ($scope.orgAllList[i].orgCode == allotOrgCode) {
						return $scope.orgAllList[i].orgName;

					}
				}
			}
		}

		$scope.getOrgVal = function(allotToOrgCode) {
			if ($scope.orgAllList) {
				for (var i = 0; i < $scope.orgAllList.length; i++) {
					if (allotToOrgCode == $scope.orgAllList[i].orgCode) {
						return $scope.orgAllList[i].orgName;
					}
				}
			}
		}

		//分配佣金类型
		$scope.allotTypeText = function(val) {
			for (var i = 0, r = $scope.allotTypeData.length; i < r; i++) {
				if (val == $scope.allotTypeData[i].val) {
					return $scope.allotTypeData[i].name;
				}
			}
		}
		$scope.allotValueTypeData = [{
			name: '百分比',
			val: '1'
		}, {
			name: '固定金额',
			val: '2'
		}];
		$scope.allotValueTypeText = function(val) {
			for (var i = 0, r = $scope.allotValueTypeData.length; i < r; i++) {
				if (val == $scope.allotValueTypeData[i].val) {
					return $scope.allotValueTypeData[i].name;
				}
			}
		}

		$scope.chooseItemTab1 = null;
		//单选
		$scope.positionCheck = function(index, allotRuleId) {
			$scope.chooseItemTab1 = allotRuleId;
			console.log($scope.chooseItemTab1)
			$scope.positionId = $scope.searchResult[index].positionId;
			$('#dataReport input[type=checkbox]').prop('checked', false);
			$('#dataReport input[type=checkbox]').eq(index).prop('checked', true);
			console.log($scope.chooseItemTab1);

		}
		// 存储选中
   /* $scope.switchUserId=function(parameter,responseData){
        $timeout(function(){
            for(var i=0;i< responseData.length;i++){
                if(parameter==responseData[i].accountIoId){
                    $scope.ioId = parameter;
                    $('#dataReport input[type=checkbox]').eq(i).prop('checked', true);
                    return;
                }
            }
        },100)
    };
    //选择选中或取消
    $scope.positionCheck = function (index, allotRuleId) {
        var userIdChecked=localStorageService.get('userIdChecked');
        $('#dataReport input[type=checkbox]').prop('checked',false);
        if (allotRuleId == userIdChecked) {
            localStorageService.clear('userIdChecked');
            $scope.ioId = '';
        }else{
            $('#dataReport input[type=checkbox]').eq(index).prop('checked', true);
            localStorageService.update('userIdChecked',allotRuleId); //存储本次选中的id
            $scope.ioId = allotRuleId;
        }
    };*/
		//修改
		$scope.edit = function(url) {
			if ($scope.chooseItemTab1 == null) {
				$rootScope.tipService.setMessage('请先选择客户', 'warning');
			} else {
				localStorageService.update('CMChooseProId', $scope.chooseItemTab1);
				$state.go(url);
			}
		}
		$scope.showDataChoose = getPageNum.pageNum(); //获取分页
		$scope.showNum = $scope.showDataChoose[0]; //初始显示刷具条数

		$scope.showPage = false;
		var pageInitialize = function() {
			$scope.dataNum = 0; //数据总条数
			$scope.dataPage = 0; //分页数
			$scope.currentPage = 1; //当前页数
			$scope.jumpPageNum = '';
		};
		pageInitialize();
		// x/y $scope.dataPage
		$scope.PageNum = function() {
			if ($scope.showNum.showNum < $scope.dataNum) {
				$scope.dataPage = Math.ceil($scope.dataNum / $scope.showNum.showNum);
			} else {
				$scope.dataPage = 0;
			}
			if ($scope.dataPage > 1 && $scope.currentPage > 0) {
				if ($scope.dataPage < $scope.currentPage) {
					$scope.currentPage = 1;
					$scope.search();
				}
			}

		};
		//上页下页 $scope.currentPage
		$scope.pageSlect = function(type) {
			if (type == 'prev') {
				if ($scope.currentPage != 1) {
					$scope.currentPage--;
					$scope.PageNum();
					$scope.search();
				}
			} else {
				if ($scope.currentPage < $scope.dataPage) {
					$scope.currentPage++;
					$scope.PageNum();
					$scope.search();
				}
			}
		};
		// 每页条数单元
		$scope.pageSelect = function(params) {
			$scope.showNum.showNum = params.showNum;
			pageInitialize();
			$scope.search();
		};
		//页数跳转 currentPage
		$scope.jumpPage = function(num) {
			num = parseInt(num);
			if (parseInt(num, 10) === num && num <= ($scope.dataPage + 1) && num > 0) {
				$scope.currentPage = num;
				$scope.PageNum();
				$scope.search();
			}
		};

		//页面跳转
		$scope.trunPage = function(url) {
			$state.go(url);
		}
	}])
	//分配规则
	.factory('commissionSplitCtrlSer', ['$http', 'localStorageService', 'myHttp', '$q', '$rootScope', function($http, localStorageService, myHttp, $q, $rootScope) {
		return {
			search: function(json) {
				var deferred = $q.defer();
				myHttp.post("config/allotrule/query/as/page", json)
					.then(function(res) { // 调用承诺API获取数据 .resolve
						deferred.resolve(res);
					}, function(res) { // 处理错误 .reject
						deferred.reject(res);
					});
				return deferred.promise;
			},
			getProInfo: function(allotRuleId) {
				var deferred = $q.defer();
				$http({
					method: 'POST',
					url: $rootScope.baseUrl + 'config/allotrule/get',
					data: {
						"allotRuleId": allotRuleId
					}
				}).then(function successCallback(response) {
					console.log(response)
					deferred.resolve(response);
				}, function errorCallback(response) {
					deferred.reject(response);
				});
				return deferred.promise;
			},
		}

	}])