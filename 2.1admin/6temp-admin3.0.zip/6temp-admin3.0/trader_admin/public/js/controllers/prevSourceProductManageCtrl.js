app.controller("prevSourceProductManageCtrl", ['$rootScope', '$timeout', '$q', '$http', 'myHttp', 'productManageSer','getPrevSource', '$scope','tipService', 'getPageNum','confirmService','localStorageService', function ($rootScope, $timeout, $q, $http, myHttp, productManageSer,getPrevSource, $scope,tipService, getPageNum,confirmService,localStorageService) {
    localStorageService.clear('userIdChecked');
    // 数据处理
    $scope.markets = getPrevSource.market();
    $scope.products = getPrevSource.product();
    //协议
    productManageSer.protocolSearch().then(function (res) {
        $scope.searchResult = res.list;
        console.log($scope.searchResult);
    });
    $scope.switchProtocol=function(paramater){
        for (var k = 0, s = $scope.searchResult.length; k < s; k++) {
            if ($scope.searchResult[k].key == paramater) {
                return $scope.searchResult[k].name;
            }
        }
    };
    //查询
    $scope.productManage = function () {
        productManageSer.productSearch()
            .then(function (response) {
                if(response.retMsg.code==='000000') {
                    $scope.productList = response.list;
                    console.log($scope.productList)
                    $scope.protocolSearchOther = $scope.protocolSearch;
                    pageJump($scope.productList);
                    var checkedUserId=localStorageService.get('userIdChecked');
                    $scope.switchUserId(checkedUserId,$scope.productList);
                }else{
                    $rootScope.tipService.setMessage(response.retMsg.message, 'warning');
                }
            }, function (error) {
                $rootScope.tipService.setMessage(error.message, 'warning');
            });
    };
    // 存储选中
    $scope.switchUserId=function(parameter,responseData){
        $timeout(function(){
            for(var i=0;i< responseData.length;i++){
                if(parameter==responseData[i].key){
                    $scope.product_key = parameter;
                    $('#dataReport input[type=checkbox]').eq(i).prop('checked', true);
                    return;
                }
            }
        },100)
    };
    //选择
    $scope.productCheck = function (index,protocol,key) {
        $scope.product_protocol=protocol+":"+$scope.switchProtocol(protocol);
        $scope.protocolName = $scope.productList[index].protocol;
        $scope.product_extraMarket = $scope.productList[index].extraMarket;
        $scope.product_extraCommodity = $scope.productList[index].extraCommodity;
        $scope.product_extraContract = $scope.productList[index].extraContract;
        $scope.product_market = $scope.productList[index].market;
        $scope.product_commodity = $scope.productList[index].commodity;
        $scope.product_contract = $scope.productList[index].contract;
        $scope.product_size = $scope.productList[index].size;
        $scope.product_minPriceDelta = $scope.productList[index].minPriceDelta;
        $scope.product_marginRatio = $scope.productList[index].marginRatio;
        $scope.product_marginFix = $scope.productList[index].marginFix;
        $scope.product_commissionRatio = $scope.productList[index].commissionRatio;
        $scope.product_commissionFix = $scope.productList[index].commissionFix;
        $scope.product_tradeRatio = $scope.productList[index].tradeRatio;
        var userIdChecked=localStorageService.get('userIdChecked');
        $('#dataReport input[type=checkbox]').prop('checked',false);
        if (key == userIdChecked) {
            localStorageService.clear('userIdChecked');
            $scope.product_key = '';
        }else{
            $('#dataReport input[type=checkbox]').eq(index).prop('checked', true);
            localStorageService.update('userIdChecked',key); //存储本次选中的id
            $scope.product_key = key;
        }
    };
    //新增
    $scope.remove = function () {
        $scope.addShowing = false;
        $scope.key = "";
        $scope.protocol_name = "";
        $scope.extraMarket = "";
        $scope.extraCommodity = "";
        $scope.extraContract = "";
        $scope.market = "";
        $scope.commodity = "";
        $scope.contract = "";
        $scope.size = "";
        $scope.minPriceDelta = "";
        $scope.marginRatio = "";
        $scope.marginFix = "";
        $scope.commissionRatio = "";
        $scope.commissionFix = "";
        $scope.tradeRatio="";
    };
    $scope.productAdd = function () {
        var upSymbol = {
            key: $scope.key,
            protocol: $scope.protocol_name,
            extraMarket: $scope.extraMarket,
            extraCommodity: $scope.extraCommodity,
            extraContract: $scope.extraContract,
            market: $scope.market,
            commodity: $scope.commodity,
            contract: $scope.contract,
            size: parseFloat($scope.size),
            minPriceDelta: parseFloat($scope.minPriceDelta),
            marginRatio: parseFloat($scope.marginRatio),
            marginFix: parseFloat($scope.marginFix),
            commissionRatio: parseFloat($scope.commissionRatio),
            commissionFix: parseFloat($scope.commissionFix),
            tradeRatio:$scope.tradeRatio
        };
        var json = {
            upSymbol: upSymbol
        };
        if (toValidate('#formAdd')) {
            productManageSer.productPlus(json)
                .then(function (response) {
                    if (response.code == "000000") {
                        $rootScope.tipService.setMessage(response.message, 'warning');
                        $scope.productManage();
                        $scope.remove();
                    } else {
                        $scope.addShowing = false;
                        $rootScope.tipService.setMessage(response.message, 'warning');
                    }
                },function(error){
                    $scope.editShowing = false;
                    $rootScope.tipService.setMessage(error.message, 'warning');
                })
        }
    };

    //修改
    $scope.editShow = function () {
        if (!$scope.product_key) {
            $rootScope.tipService.setMessage('请先选择账号编号', 'warning');
        } else {
            $scope.editShowing = true;
        }
    };
    $scope.productCompile = function () {
        var upSymbol = {
            key: $scope.product_key,
            protocol: $scope.product_protocol.split(":")[0],
            extraMarket: $scope.product_extraMarket,
            extraCommodity: $scope.product_extraCommodity,
            extraContract: $scope.product_extraContract,
            market: $scope.product_market,
            commodity: $scope.product_commodity,
            contract: $scope.product_contract,
            size:parseInt($scope.product_size),
            minPriceDelta:parseFloat($scope.product_minPriceDelta),
            marginRatio:parseFloat($scope.product_marginRatio),
            marginFix:parseFloat($scope.product_marginFix),
            commissionRatio:parseFloat($scope.product_commissionRatio),
            commissionFix: parseFloat($scope.product_commissionFix)
        };
        var json = {
            upSymbol: upSymbol
        };
        if (toValidate('#formEdit')) {
            productManageSer.productModify(json)
                .then(function (response) {
                    if (response.code == "000000") {
                        $scope.editShowing = false;
                        $rootScope.tipService.setMessage(response.message, 'warning');
                        $scope.productManage();
                    } else {
                        $scope.editShowing = false;
                        $rootScope.tipService.setMessage(response.message, 'warning');
                    }
                },function(error){
                    $scope.editShowing = false;
                    $rootScope.tipService.setMessage(error.message, 'warning');
                })
        }
    };
    //删除
    $scope.delete = function () {
        if (!$scope.key) {
            $rootScope.tipService.setMessage('请先选择账号!', 'warning');
        }else {
            var json = {
                        key: $scope.product_key
                    };
            confirmService.set('确认提示', '确定要注销此账号吗?', function () {
                productManageSer.accountDelete(json).then(function (res) {
                    if (res.data.code == "000000") {
                        $rootScope.tipService.setMessage(res.message, 'warning');
                        $scope.productManage();
                    } else {
                        $rootScope.tipService.setMessage(res.message, 'warning');
                    }
                }, function (error) {
                    $rootScope.tipService.setMessage(error.message, 'warning');
                });
                confirmService.clear();
            })
        }
    };
    //分页
    var pageJump = function (tmpArrList) {
        $timeout(function () {
            if (tmpArrList != undefined) {
                $scope.currentPage = 1; //当前页数
                $scope.dataNum = tmpArrList.length;
                $scope.showDataChoose = getPageNum.pageNum(); //获取分页
                $scope.showNum = $scope.showDataChoose[0]; //初始显示刷具条数
                $scope.showPage = false;
                $timeout(function () {
                    $scope.showPage = true;
                    $scope.copyDataArray = tmpArrList.slice(0, 14); //初始15条数据
                }, 10)
                $scope.dataPage = Math.ceil($scope.dataNum / $scope.showNum.showNum);

                //上下页
                $scope.pageSlect = function (type) {
                    if (type == 'prev') {
                        if ($scope.currentPage != 1) {
                            $scope.currentPage--;
                            $scope.turnPage();
                        } else {
                            $scope.copyDataArray = tmpArrList.slice(0, 14); //初始15条数据
                        }
                    } else {
                        if ($scope.currentPage < $scope.dataPage) {
                            $scope.currentPage++;
                            $scope.turnPage();
                        }
                    }
                }
                //每页数据量
                $scope.baseDataArray = [];
                $scope.copyDataArray = [];
                $scope.pageSelect = function (params) {
                    $scope.showNum.showNum = params.showNum;
                    $scope.copyDataArray = tmpArrList.slice(0, (params.showNum - 1));
                    $scope.dataPage = Math.ceil($scope.dataNum / $scope.showNum.showNum);
                    $scope.currentPage = 1;
                }
                $scope.turnPage = function () {
                    $scope.copyDataArray = tmpArrList.slice((($scope.currentPage - 1) * 15), (($scope.currentPage + 1) * 15 - 1));
                }
                //固定页面跳转
                $scope.jumpPage = function (num) {
                    num = parseInt(num);
                    if (parseInt(num, 10) === num && num <= ($scope.dataPage + 1) && num > 0) {
                        $scope.currentPage = num;
                        $scope.jumpPageNum = '';
                        $scope.turnPage();
                    } else {
                        $scope.copyDataArray = tmpArrList.slice(0, 14); //初始15条数据
                    }
                }
            } else {
                pageJump(tmpArrList);
            }
        }, 200);
    }
}])

  //Service
    .factory('productManageSer', ['$http', 'dataFilter', 'localStorageService', 'myHttp', '$q', '$rootScope', function ($http, dataFilter, localStorageService, myHttp, $q, $rootScope) {
        return {
            productSearch: function () {
                var deferred = $q.defer();
                var data = new Object();
                $http({
                    method: "GET",
                    url: $rootScope.baseUrl + "c/up/symbol/query/all",
                    data: data,
                    headers: {
                        'Content-Type': 'application/json;charset=UTF-8'
                    }
                }).success(function (res) {
                    deferred.resolve(res);
                }).error(function (res) {
                    deferred.reject(res);
                });
                return deferred.promise;
            },
            productPlus: function (upAccount) {
                var deferred = $q.defer();
                $http({
                    method: "POST",
                    url: $rootScope.baseUrl + "c/up/symbol/insert",
                    data: upAccount,
                    headers: {
                        'Content-Type': 'application/json;charset=UTF-8'
                    }
                }).success(function (res) {
                    deferred.resolve(res);
                }).error(function (res) {
                    deferred.reject(res);
                });
                return deferred.promise;
            },
            productModify: function (json) {
                var deferred = $q.defer();
                // var data=new Object();
                $http({
                    method: "POST",
                    url: $rootScope.baseUrl + "c/up/symbol/modify",
                    data: json,
                    headers: {
                        'Content-Type': 'application/json;charset=UTF-8'
                    }
                }).success(function (res) {
                    deferred.resolve(res);
                }).error(function (res) {
                    deferred.reject(res);
                });
                return deferred.promise;
            },
            productDelete: function (removeData) {
                var deferred = $q.defer();
                $http({
                    method: "POST",
                    url: $rootScope.baseUrl + "c/up/symbol/delete",
                    data: removeData,
                    headers: {
                        'Content-Type': 'application/json;charset=UTF-8'
                    }
                }).success(function (res) {
                    deferred.resolve(res);
                }).error(function (res) {
                    deferred.reject(res);
                });
                return deferred.promise;
            },
            protocolSearch: function () {
                var deferred = $q.defer();
                $http({
                    method: "GET",
                    url: $rootScope.baseUrl + "c/up/protocol/query/all"
                }).success(function (res) {
                    deferred.resolve(res);
                }).error(function (res) {
                    deferred.reject(res);
                });
                return deferred.promise;
            }
        }
    }]);