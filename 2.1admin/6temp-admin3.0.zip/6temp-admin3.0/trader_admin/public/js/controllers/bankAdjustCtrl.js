app.controller('bankAdjustCtrl', ['$rootScope', '$scope', 'bankAdjustAll', '$timeout', '$sce', 'getPageNum', 'getBankState', 'getCurrencyType', 'getIoType', 'localStorageService', function ($rootScope, $scope, bankAdjustAll, $timeout, $sce, getPageNum, getBankState, getCurrencyType, getIoType, localStorageService) {
    $scope.toggleTraderSearchState=false;
    $scope.Toggle = function(){
        $scope.toggleTraderSearchState = !$scope.toggleTraderSearchState;
        if($scope.toggleTraderSearchState){
           $('.search_column').css('height','auto');
        }
        else{
           $('.search_column').css('height','36px');
        }
    };

    //机构码匹配
    var saveOrganizeData = localStorageService.get('organizeData');
    // //账户状态
    // $scope.bankState = getBankState;

    // 货币转换
    getCurrencyType.then(function (res) {
        $scope.currencyListData = JSON.parse(res.content);
        console.log($scope.currencyListData);
    });
    //出入金类型
    $scope.IoType = getIoType;

    var processContent,processTotal;
    var source = {
        type: 'POST',
        datatype: "json",
        datafields: [  //数据字段定义
            {name: 'userId', type: 'string'},
            {name: 'orgCode', type: 'string'},
            {name: 'loginName', type: 'string'},
            {name: 'custName', type: 'string'},
            {name: 'custIdentityNo', type: 'string'},

            {name: 'custMobile', type: 'string'},
            {name: 'extract', type: 'string'},
            {name: 'state', type: 'string'}
        ],
        url: $rootScope.baseUrl + 'account/reversal/aiaccount/query/page',
        root: "content",
        pagesize:10,
        processData: function (data) {
            data.page = (data.pagenum + 1)?(data.pagenum + 1):1;
            data.rows =(data.pagesize)?(data.pagesize):10;
            // data.order =($scope.order)?$scope.order:'desc';
            // data.sort =($scope.sort)?$scope.sort:'createTime';
            data.search_A_EQ_userId = ($scope.directiveUserId) ? $scope.directiveUserId : '';

            $scope.orgCode = localStorageService.get('oldOrgCode');
            if ($scope.organizeValue == true && $scope.downOrganizeValue == true) {
                data.search_A_LLIKE_orgCode = ($scope.orgCode) ? $scope.orgCode : '';
            }
            if ($scope.organizeValue == true && $scope.downOrganizeValue == false) {
                data.search_A_EQ_orgCode = ($scope.orgCode) ? $scope.orgCode : '';
            }
            if ($scope.organizeValue == false && $scope.downOrganizeValue == true) {
                data.search_A_LLIKE_orgCode = ($scope.orgCode) ? $scope.orgCode + '-' : '';
            }
        }, //传递参数处理
        beforeLoadComplete: function (records) { //数据完全加载完执行绘制表格
            var start;
            for (var i in records) {
                start = parseInt(i);
                break;
            }
            for (var k = 0, r = processContent.length; k < r; k++) {
                records[start + k].userId = processContent[k].userId;
                records[start + k].orgCode = processContent[k].orgCode;
                records[start + k].loginName = processContent[k].loginName;
                records[start + k].custName = processContent[k].custName;
                records[start + k].custIdentityNo = processContent[k].custIdentityNo;

                records[start + k].custMobile = processContent[k].custMobile;
                records[start + k].extract = processContent[k].extract;
                records[start + k].state = processContent[k].state;
            }
        },
        beforeprocessing: function (data) { //处理总页数
            var processData = JSON.parse(data.content);
            console.log(processData)
            processContent = processData.content;
            source.totalrecords = processData.totalElements == 0 ? 5 : processData.totalElements;
            processTotal = processData.totalElements;
        },
        loadComplete: function (records) {
            $scope.saveResult=JSON.parse(records.content);
            var data =  $scope.saveResult.totalElements;
            if (data == 0) {
                $('#contenttableentrustDetailGrid > div').remove();
            }
        },
        endUpdate: true
    };
    //创建数据适配器
    var dataAdapter = null;
    $scope.searchAjax = function () {
        $scope.featureShow=true;
        $scope.toggleTraderSearchState = false;
        $('.search_column').css('height', '36px');
        if (dataAdapter == null) {
            dataAdapter = new $.jqx.dataAdapter(source);
            //创建表格
            $("#entrustDetailGrid").jqxGrid({
                source: dataAdapter,
                columns: [  //表格数据域
                    {
                        text: '上级机构',
                        datafield: 'orgCode',
                        width: '13%',
                        minwidth: 13 + '%',//设置列min宽
                        align: 'center',//设置表头
                        cellsrenderer: function (row, columnfield, value, defaulthtml, columnproperties) {
                            if (saveOrganizeData) {
                                for (var i = 0; i <saveOrganizeData.length; i++) {
                                    if (value ==saveOrganizeData[i].orgCode) {
                                        return saveOrganizeData[i].orgNum;
                                    }
                                }
                            }
                        }
                    },
                    {
                        text: '用户名',
                        datafield: 'loginName',
                        minwidth: 16 + '%',
                        cellsalign: 'center',
                        align: 'center',
                        width: '16%'
                    },
                    {
                        text: '开户名',
                        datafield: 'custName',
                        width:'13%',
                        minwidth: 13 + '%',
                        align: 'center'
                    },
                    {
                        text: '身份证号',
                        datafield: 'custIdentityNo',
                        width:'16%',
                        minwidth: 16 + '%',
                        align: 'center'
                    },
                    {
                        text: '手机号',
                        datafield: 'custMobile',
                        width:'14%',
                        minwidth: 14 + '%',
                        align: 'center'
                    },
                    {
                        text: '可调余额',
                        datafield: 'extract',
                        width:'15%',
                        minwidth: 15 + '%',
                        align: 'center'
                    },
                    {
                        text: '用户状态',
                        datafield: 'state',
                        width:'13%',
                        minwidth: 13 + '%',
                        align: 'center',
                        cellsrenderer: function (row, columnfield, value, defaulthtml, columnproperties) {
                            if (getBankState) {
                                for (var i = 0; i <getBankState.length; i++) {
                                    if (value ==getBankState[i].id) {
                                        return getBankState[i].name;
                                    }
                                }
                            }
                        }
                    }
                ],
                width: 100 + '%',
                height: 81 + '%',
                theme:'metrodark',
                virtualmode: true,
                rendergridrows: function (params) { //将数据渲染到页面
                    return params.data;
                },
                pageable: true,
                pagesizeoptions: ['10','30','100','200'],
                // sortable: true,
                columnsresize: true,//列间距是否可调整
                clipboard: true
            });
        }else {
            $("#entrustDetailGrid").jqxGrid('updatebounddata', 'cells');
        }
    };
    //分页
    $("#entrustDetailGrid").on("pagechanged", function (event) {
        console.log(event)
    });
    //排序
    $("#entrustDetailGrid").on("sort", function (event) {
        var sortinformation = event.args.sortinformation;
        $scope.sort=sortinformation.sortcolumn;
        $scope.order=($scope.sort)?(sortinformation.sortdirection.ascending)?'asc':'desc':'asc';
        data={
            order:$scope.order,
            sort:$scope.sort
        };
        source.processData(data);
        $("#entrustDetailGrid").jqxGrid('updatebounddata', 'sort');
    });
    //选中
    $('#entrustDetailGrid').on('rowselect', function (event) {
        $scope.userId = event.args.row.userId;
        $scope.userName=event.args.row.loginName;
        console.log(event)
    });
    // 调账
    $scope.searchCurrency = '';
    $scope.balance = '';
    $scope.amount = '';
    $scope.addIoType = null;
    $scope.addNewUser = function () {
        if (!$scope.userId) {
            $rootScope.tipService.setMessage('请先选择用户', 'warning');
        } else {
            $scope.newUserShow = true;
        }
    };
    $scope.remove = function () {
        $scope.ioType = '';
        $scope.amount = '';
        $scope.currencyNum = '';
        $scope.balance = '';
    };
    //币种调账查询
    $scope.tradeAccountCurrency = function () {
        var signUpV = {
            currency: parseFloat($scope.currencyNum),
            userId: $scope.userId
        };
        bankAdjustAll.tradeSearch(signUpV)
            .then(function (res) {
                if (res.code == '000000' && res.content) {
                    var tradeSearchList = JSON.parse(res.content);
                    console.log(tradeSearchList);
                    $scope.extract = tradeSearchList.extract; //结余
                } else {
                    console.log(res)
                    // $rootScope.tipService.setMessage(res.message, 'warning');
                }
            }, function (error) {
                console.log(error)
                // $rootScope.tipService.setMessage(error.message, 'warning');
            });
    };
    $scope.addUserSubmit = function () {
        if ($scope.currencyNum) {
            $scope.addIoTypeNum = parseFloat($scope.addIoType);
            var userInfo = localStorageService.get('userInfo');
            var reversalV = {
                userId: $scope.userId,
                currency: parseFloat($scope.currencyNum),
                amount: $scope.amount,
                ioType: parseFloat($scope.ioType)
            };
            var json = {
                reversalV: reversalV
            };
            bankAdjustAll.unitAdd(json)
                .then(function (response) {
                    if (response.code == '000000') {
                        $scope.newUserShow = false;
                        $rootScope.tipService.setMessage(response.message, 'warning');
                        $scope.searchAjax();
                        $scope.remove();
                    } else {
                        $scope.newUserShow = false;
                        $rootScope.tipService.setMessage(response.message, 'warning');
                        $scope.searchAjax();
                        $scope.remove();
                    }
                }, function (error) {
                    $rootScope.tipService.setMessage(error.message, 'warning');
                })
        } else {
            $rootScope.tipService.setMessage('请先选择币种!', 'warning');
        }
    };

    $scope.cancelUser = function () {
        $scope.newUserShow = false;
        $scope.remove();
    }
}])
// Server 银行调账
    .factory('bankAdjustAll', ['$rootScope', '$http', 'myHttp', '$q', function ($rootScope, $http, myHttp, $q) {
        return {
            unitSearch: function (json) {
                var deferred = $q.defer();
                myHttp.post("account/reversal/aiaccount/query/page", json)
                    .then(function (res) {
                        deferred.resolve(res);
                    }, function (res) {
                        deferred.reject(res);
                    });
                return deferred.promise;
            },
            unitAdd: function (json) {
                var deferred = $q.defer();
                $http({
                    method: "POST",
                    url: $rootScope.baseUrl + "account/reversal",
                    data: json,
                    headers: {
                        'Content-Type': 'application/json;charset=UTF-8'
                    }
                }).success(function (res) {
                    deferred.resolve(res);
                }).error(function (res) {
                    deferred.reject(res);
                });
                return deferred.promise;
            },
            //币种之前查询
            tradeSearch: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'account/get/extra/by/useridcurrency',
                    data: json,
                    headers: {
                        'Content-Type': 'application/json;charset=UTF-8'
                    }
                }).success(function (res) {
                    deferred.resolve(res);
                }).error(function (res) {
                    deferred.reject(res);
                });
                return deferred.promise;
            }
        }
    }]);
