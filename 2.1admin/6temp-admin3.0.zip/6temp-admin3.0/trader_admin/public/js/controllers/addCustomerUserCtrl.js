app.controller("addCustomerUserCtrl", function($scope, $state, $rootScope, tipService, confirmService, dataSer, timestamp, addAllTypeUserCtrlSer, localStorageService, $timeout) {
		$scope.historyInfo = localStorageService.get('allUserAddInfo');
		$scope.step = 1;

		$scope.orgId = null;
		$scope.orgListDisplay = false;
		$scope.extendUserToggle = false;
		$scope.contactUserToggle = false;
		$scope.readRisk = false;

		$scope.step2_email = ''; //邮箱
		$scope.step2_phone = ''; //手机号码
		$scope.step2_orgCode = ''; //机构代码

		dataSer.organizeQuerySer()
			.then(function(res) {
				$scope.orgList = res;
			});

		$scope.goBack = function() {
				if ($scope.historyInfo.type == 4) {
					$state.go('tabs.customerManage');
				}
			}
			//获取机构扩展信息 行业
		dataSer.readIndustry()
			.then(function(res) {
				$scope.getOrgInfoIndustryData = res.industry;
			});
		//获取机构性质
		dataSer.readOccupation()
			.then(function(res) {
				$scope.getReadOccupationData = res.occupation;
			});
		//获取学历数据
		dataSer.readEducation()
			.then(function(res) {
				$scope.getReadEducationData = res.education;
			});
		//投资者性质
		dataSer.readProperty()
			.then(function(res) {
				$scope.getReadPropertyData = res.property;
			});
		//国家 城市 地区 选择
		$scope.isChooseCountry = function() {
			if ($scope.userExtendInfoCountry) {
				dataSer.provinceQuerySer($scope.userExtendInfoCountry)
					.then(function(res) {
						if (res.code == '000000') {
							$scope.provincesData = res.results;
						}
					});
			}
		}
		$scope.isChooseProvinces = function() {
			if ($scope.userExtendInfoProvinces) {
				dataSer.cityQuerySer($scope.userExtendInfoProvinces)
					.then(function(res) {
						if (res.code == '000000') {
							$scope.cityData = res.results;
						}
					});
			}
		}
		$scope.isChooseCity = function() {
				if ($scope.userExtendInfoCity) {
					dataSer.areaQuerySer($scope.userExtendInfoCity)
						.then(function(res) {
							if (res.code == '000000') {
								$scope.areaData = res.results;
							}
						});
				}
			}
			//获取证件类型
		dataSer.readCertificateType()
			.then(function(res) {
				$scope.certificateList = res.certificateType;
			});

		$scope.cStep = function(step) {
				if (step == 1) {
					if ($scope.readRisk) {
						$scope.step = 2;
					}
				} else if (step == 2) {
					if (toValidate('#step2_form')) {
						addAllTypeUserCtrlSer.step2($scope.step2_email, $scope.step2_phone)
							.then(function(res) {
								console.log(res);
								if (res.data.code == '000000') {
									confirmService.set('步骤提示', '邮件已发送，请去邮箱获取验证码', function() {
										$scope.step = 3;
										confirmService.clear();
									});
								} else {
									$rootScope.tipService.setMessage(res.data.message, 'warning');
								}
							}, function(error) {
								$rootScope.tipService.setMessage(error.data.message, 'warning');
							});
					}
				} else if (step == 3) {
					//用户基本信息
					var createUserSecurityV = {
							email: $scope.step2_email,
							loginName: $scope.loginName,
							phone: $scope.step2_phone,
							password: $scope.password
						}
						//用户实名信息
					var userRealInfoV = {
							name: $scope.userRealInfoName,
							certificateType: $scope.userRealInfoCertificateType,
							certificateNo: $scope.userRealInfoCertificateCode,
							cpFId: $scope.userRealInfoCertificateImg1,
							cbFId: $scope.userRealInfoCertificateImg2,
							chFId: $scope.userRealInfoCertificateImg3
						}
						//用户扩展信息
					var userInfoV = {
							country: $scope.userExtendInfoCountry,
							provinces: $scope.userExtendInfoProvinces,
							city: $scope.userExtendInfoCity,
							area: $scope.userExtendInfoArea,
							sex: $scope.userExtendInfoSex,
							birthday: $scope.userExtendInfoBirthday,
							nativePlace: $scope.userExtendInfoNativePlace,
							education: $scope.userExtendInfoEducation,
							occupation: $scope.userExtendInfoOccupation,
							industry: $scope.userExtendInfoIndustry,
							marriage: $scope.userExtendInfoMarriage,
							qq: $scope.userExtendInfoQQ,
							property: $scope.userExtendInfoProperty
						}
						//用户联系人
					var contactsVs = [{
						name: $scope.contactsListName,
						telephone: $scope.contactsListLocalPhone,
						mobileTelephone: $scope.contactsListMobilePhone,
						email: $scope.contactsListEmail,
						address: $scope.contactsListAdress,
						postcode: $scope.contactsListPostCode,
						sex: $scope.contactsListGender,
						fax: $scope.contactsListFax
					}];
					addAllTypeUserCtrlSer.step3($scope.checkMailCode, $scope.step2_orgCode, createUserSecurityV, userRealInfoV, userInfoV, contactsVs)
						.then(function(res) {
							if (res.data.code === '000000') {
								$scope.step = 4;
								$rootScope.tipService.setMessage(res.data.message, 'warning');
							} else {
								$rootScope.tipService.setMessage(res.data.message, 'warning');
							}
						}, function(error) {
							$rootScope.tipService.setMessage(error.data.message, 'warning');
						});
				}
			}
			//图片上传
		uploadImg = function(id, num) {
			var urlUpload = $rootScope.baseUrl + 'file/upload';
			upload_img(urlUpload, id, function(data, status) {
				if (data.code === '000000') {
					var ImgId = data.results[0].id;
					switch (num) {
						case 1:
							$scope.userRealInfoCertificateImg1 = ImgId;
							$('#uploadImg1').attr('src', "" + $rootScope.baseUrl + "/file/download?fileId=" + ImgId + "");
							break;
						case 2:
							$scope.userRealInfoCertificateImg2 = ImgId;
							$('#uploadImg2').attr('src', "" + $rootScope.baseUrl + "/file/download?fileId=" + ImgId + "");
							break;
						case 3:
							$scope.userRealInfoCertificateImg3 = ImgId;
							$('#uploadImg3').attr('src', "" + $rootScope.baseUrl + "/file/download?fileId=" + ImgId + "");
							break;
					}
				}
			});
		}

		// 上传图片
		// url:后台访问路径 fileId:input file按钮id, btn:点击的按钮id, fileInput:接收上传图片的id
		function upload_img(url, fileId, callback) {
			$.ajaxFileUpload({
				url: url,
				type: 'post',
				secureuri: false,
				fileElementId: fileId, // file标签的id
				dataType: 'json', // 返回数据的类型
				data: {
					name: fileId
				},
				success: function(data, status) {
					callback(data, status)
				},
				error: function(data, status, e) {
					console.log(data, status, e)
				}
			});
		};
});