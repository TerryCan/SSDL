app.controller('VarietInmappingCtrl', ['$rootScope', '$scope', 'getPageNum', 'VarietInmappingCtrlSer', 'dataSer', 'localStorageService', 'confirmService','$timeout','VarietiesCtrlSer','getadminState', function ($rootScope, $scope, getPageNum, VarietInmappingCtrlSer , dataSer, localStorageService, confirmService,$timeout,VarietiesCtrlSer,getadminState) {
    $scope.toggleTraderSearchState = false;
    $scope.Toggle = function () {
        $scope.toggleTraderSearchState = !$scope.toggleTraderSearchState;
        if ($scope.toggleTraderSearchState) {
            $('.search_column').css('height', 'auto');
        }
        else {
            $('.search_column').css('height', '36px');
        }
    };
    localStorageService.clear('userIdChecked');
    $scope.tableshow = false;
    $scope.commodityIdlist="";
    $scope.ToState='';

    $scope.allotTypeData=getadminState;
    $scope.allotTypeText = function(val) {
        for (var i = 0, r = $scope.allotTypeData.length; i < r; i++) {
            if (val == $scope.allotTypeData[i].id) {
                return $scope.allotTypeData[i].name;
            }
        }
    }

    $scope.search = function (type) {
        $scope.toggleTraderSearchState = false;
        $('.search_column').css('height', '36px');
        if (type == 'search') {
            pageInitialize()
        };
        var json = {
            page: $scope.currentPage,
            rows: $scope.showNum.showNum,
            orders: 'asc',
            search_EQ_commodityId: $scope.commodityIdlist,
            search_EQ_state: $scope.ToState,

        };
        VarietInmappingCtrlSer.search(json)
            .then(function (res) {
                console.log(res)
                if (res.code == '000000') {
                    $scope.showPage = true;
                    var data = JSON.parse(res.content);
                    $scope.searchResult = data.content;
                    console.log($scope.searchResult);
                    $scope.dataNum = data.totalElements;
                    $scope.PageNum();
                    var checkedUserId=localStorageService.get('userIdChecked'); //获取上一次存储的id
                    $scope.switchUserId(checkedUserId,$scope.searchResult); //执行选中方法
                } else {
                    $rootScope.tipService.setMessage(res.message, 'warning');
                }
            }, function (error) {
                $rootScope.tipService.setMessage(error.message, 'warning');
            });
    }
    $scope.basicData = [{
        name: '是',
        val: true
    }, {
        name: '否',
        val: false
    }];
    $scope.basicText = function (val) {
        for (var i = 0, r = $scope.basicData.length; i < r; i++) {
            if (val == $scope.basicData[i].val) {
                return $scope.basicData[i].name;
            }
        }
    }

    $scope.ormTypes=[{
        name: '外映射',
        val: '1'
    }, {
        name: '内映射',
        val: '2'
    }]
    $scope.ormTypeText = function (ormType) {
        for (var i = 0, r = $scope.ormTypes.length; i < r; i++) {
            if (ormType == $scope.ormTypes[i].val) {
                return $scope.ormTypes[i].name;
            }
        }
    }



    /**
     * 分页功能实现TerryMin
     * **/
    $scope.showDataChoose = getPageNum.pageNum(); //获取分页
    $scope.showNum = $scope.showDataChoose[0]; //初始显示刷具条数
    $scope.showPage = false;
    var pageInitialize = function () {
        $scope.dataNum = 0; //数据总条数
        $scope.dataPage = 0; //分页数
        $scope.currentPage = 1; //当前页数
        $scope.jumpPageNum = '';
    };
    pageInitialize();

    // x/y $scope.dataPage
    $scope.PageNum = function () {
        $scope.showPage = true;
        if ($scope.showNum.showNum < $scope.dataNum) {
            $scope.dataPage =Math.ceil($scope.dataNum / $scope.showNum.showNum);
        } else {
            $scope.dataPage = 0;
        }
    };
    //上页下页 $scope.currentPage
    $scope.pageSlect = function (type) {
        if (type == 'prev') {
            if ($scope.currentPage != 1) {
                $scope.currentPage--;
                $scope.PageNum();
                $scope.search();
            }
        } else {
            if ($scope.currentPage < $scope.dataPage) {
                $scope.currentPage++;
                $scope.PageNum();
                $scope.search();
            }
        }
    };
    // 每页条数单元
    $scope.pageSelect = function (params) {
        $scope.showNum.showNum = params.showNum;
        pageInitialize();
        $scope.search();
    };
    //页数跳转 currentPage
    $scope.jumpPage = function (num) {
        num = parseInt(num);
        if (parseInt(num, 10) === num && num <= ($scope.dataPage + 1) && num > 0) {
            $scope.currentPage = num;
            $scope.PageNum();
            $scope.search();
        }
    };
    $scope.swormType=true;
    $scope.commodtype=function(){
        var words = $scope.commodityId.split('/');
        console.log(words)
        var commodityId = words[0];
        var ormTypeArr = words[1];
        //console.log(ormTypeArr)
       // $scope.commodityId=ormTypeArr[0];
        //console.log($scope.commodityId)
        $scope.ormType=ormTypeArr;
        console.log($scope.ormType)
        if($scope.ormType==1){
            console.log($scope.ormType==1)
            $scope.swormType=false;
        }else if($scope.ormType==2){
            $scope.swormType=true;
        }else{
            $scope.swormType=true;
        }
    //上手品种列表
        var json={
            commodityId:commodityId
        }
        VarietInmappingCtrlSer.uplist(json)
        .then(function (res) {
            console.log(res)
            if (res.data.code == '000000') {
                $scope.updatalist = JSON.parse(res.data.content);
                console.log($scope.updatalist)
            } else {
                $rootScope.tipService.setMessage(res.data.message, 'warning');
            }
        }, function (error) {
            $rootScope.tipService.setMessage(error.data.message, 'warning');
        });

    }
    //品种列表
    VarietiesCtrlSer.searchlist()
        .then(function (res) {
            console.log(res)
            if (res.code == '000000') {
                var data = JSON.parse(res.content);
                $scope.searchdatalist = data;
                console.log($scope.searchdatalist);
            } else {
                $rootScope.tipService.setMessage(res.message, 'warning');
            }
        }, function (error) {
            $rootScope.tipService.setMessage(error.message, 'warning');
        });

    $scope.Varietsearchtty=function(commodityId){
        if($scope.searchdatalist){
        for (var i = 0, r = $scope.searchdatalist.length; i < r; i++) {
            if ($scope.searchdatalist[i].commodityId == commodityId) {
                return $scope.searchdatalist[i].commodityName;
                }
            }
        }
    }

    $scope.tradesearchtty=function(tradeCommodityId){
        if($scope.searchdatalist){

        for (var i = 0, r = $scope.searchdatalist.length; i < r; i++) {
            if ($scope.searchdatalist[i].commodityId == tradeCommodityId) {
                return $scope.searchdatalist[i].commodityName;
                }
            }
        }
    }
    $scope.pricesearchtty=function(priceCommodityId){
        if($scope.searchdatalist){
        for (var i = 0, r = $scope.searchdatalist.length; i < r; i++) {
            if ($scope.searchdatalist[i].commodityId == priceCommodityId) {
                return $scope.searchdatalist[i].commodityName;
                }
            }
        }
    }

    $scope.Datalists=[];
    $scope.addrule = function() {
        /*var words = $scope.commodityId.split('/');
        console.log(words)
        var channelProductId = words[1];
        var accountSymbolId = words[0];*/
        $scope.Datalists.push($scope.Dataorm);
        console.log($scope.Datalists)
    }

    $scope.deletesd = function(index) {
        $scope.Datalists.splice(index, 1);
    }
    $scope.add = function () {
        $scope.tableshow = true;
        $scope.addEditText = '新增';
        $scope.tradeCommodityId='';
        $scope.priceCommodityId='';
        $scope.commodityId='';
        $scope.accurateDigit='';  //精确位数
        $scope.premium='';  //升水贴
        $scope.ratio='';  //行情系数
        $scope.priceFlag=false;  //是否继承行情
    }
    $scope.addSubmit = function () {
        console.log($scope.commodityId)
        var words = $scope.commodityId.split('/');
       console.log(words)
       var commodityId = words[0];
        var configCommodityOrmVIce= {
                tradeCommodityId: $scope.tradeCommodityId,  //交易品种编码
                priceCommodityId: $scope.priceCommodityId,  //行情品种编码
                commodityId:commodityId,  //品种编码
                accurateDigit:parseFloat($scope.accurateDigit),   //精确位数
                premium:parseFloat($scope.premium),  //升水贴
                ratio:parseFloat($scope.ratio),  //行情系数
                priceFlag:$scope.priceFlag,  //是否继承行情
                commodityTradeOrms:$scope.Datalists,
        }

        var json = {
            configCommodityOrmVIce:configCommodityOrmVIce
        }
        VarietInmappingCtrlSer.Addsub(json)
            .then(function (res) {
                if (res.data.code == "000000") {
                    $scope.tableshow = false;
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                    localStorageService.clear('userIdChecked');
                    $scope.search();
                } else {
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                }
            }, function (error) {
                $rootScope.tipService.setMessage(error.data.message, 'warning');
            })
    }

    $scope.hideRoleaut=true;
    $scope.showRoleaut=true;
// 选择
    $scope.checkedTab1 = function (index,commodityId,tradeCommodityId,priceCommodityId,accurateDigit,premium,ratio,priceFlag,state,applyId,commodityOrmId,ormType,commodityTradeOrms){
        $scope.chooseUserData={
            commodityId: commodityId,
            tradeCommodityId: tradeCommodityId,
            priceCommodityId: priceCommodityId,
            accurateDigit: accurateDigit,
            premium: premium,
            ratio: ratio,
            priceFlag: priceFlag,
            state: state,
            applyId: applyId,
            commodityOrmId: commodityOrmId,
            ormType: ormType,
            commodityTradeOrms: commodityTradeOrms,
    };
        console.log($scope.chooseUserData)
        var userIdChecked = localStorageService.get('userIdChecked');
        $('#dataReport input[type=checkbox]').prop('checked', false);
        if (commodityId == userIdChecked) {
            localStorageService.clear('userIdChecked');
            $scope.chooseItemTab1 = '';
            $scope.applyId= '';
            $scope.state= '';

        } else {
            $('#dataReport input[type=checkbox]').eq(index).prop('checked', true);
            localStorageService.update('userIdChecked', commodityId);
            $scope.chooseItemTab1 = commodityId;
            $scope.applyId= applyId;
            $scope.state= state;
        }
        if ($scope.chooseUserData.commodityId != null && $scope.chooseUserData.applyId != null) {
            console.log($scope.chooseUserData.commodityId)
            $scope.hideRoleaut=false;
            $scope.showRoleaut=false;
        }else{
            $scope.hideRoleaut=true;
            $scope.showRoleaut=true;
        };
    };
    // 存储选中
    $scope.switchUserId = function (parameter, responseData) {
        $timeout(function () {
            for (var i = 0; i < responseData.length; i++) {
                if (parameter == responseData[i].commodityId) {
                    $('#dataReport input[type=checkbox]').eq(i).prop('checked', true);
                    return;
                }
            }
        }, 1500)
    };

    $scope.apply = function () {
        if (!$scope.chooseItemTab1) {
            $rootScope.tipService.setMessage('请先选择品种内映射信息', 'warning');
        } else {
            var  json={
                commodityId:$scope.chooseItemTab1
            }
            VarietInmappingCtrlSer.orgget(json)
                .then(function(res){
                    if(res.data.code=="000000"){
                        $scope.comData=JSON.parse(res.data.content)
                        console.log($scope.comData)
                        $scope.auditshow = true;
                        $scope.addEditTexts = "申请变更"
                        $scope.applyId= $scope.comData.applyId;
                        $scope.ormType= $scope.comData.ormType;
                        $scope.commodityId= $scope.comData.commodityId+'/'+$scope.ormType;
                        //console.log($scope.commodityId)
                        $scope.tradeCommodityId= $scope.comData.tradeCommodityId;
                        console.log($scope.tradeCommodityId)
                        $scope.priceCommodityId= $scope.comData.priceCommodityId;
                        console.log($scope.priceCommodityId)
                        $scope.state= $scope.comData.state;
                        $scope.accurateDigit= $scope.comData.accurateDigit;
                        $scope.premium= $scope.comData.premium;
                        $scope.ratio= $scope.comData.ratio;
                        $scope.priceFlag= $scope.comData.priceFlag;
                        $scope.commodityOrmId= $scope.comData.commodityOrmId;
                        console.log($scope.commodityOrmId)
                        if($scope.ormType==1){
                            console.log($scope.ormType==1)
                            $scope.swormType=false;
                        }else if($scope.ormType==2){
                            $scope.swormType=true;
                        }
                        for (var i = 0; i < $scope.comData.commodityTradeOrms.length; i++) {
                            console.log( $scope.comData.commodityTradeOrms.length, $scope.comData.commodityTradeOrms)
                            $scope.Datalists.push($scope.comData.commodityTradeOrms[i]);
                            console.log($scope.Datalists)
                        }
                    }
                })
            /*$scope.auditshow = true;
            $scope.addEditTexts = "申请变更"
            $scope.applyId= $scope.chooseUserData.applyId;
            $scope.commodityId= $scope.chooseUserData.commodityId;
            $scope.tradeCommodityId= $scope.chooseUserData.tradeCommodityId;
            $scope.priceCommodityId= $scope.chooseUserData.priceCommodityId;
            $scope.state= $scope.chooseUserData.state;
            $scope.accurateDigit= $scope.chooseUserData.accurateDigit;
            $scope.premium= $scope.chooseUserData.premium;
            $scope.ratio= $scope.chooseUserData.ratio;
            $scope.priceFlag= $scope.chooseUserData.priceFlag;
            $scope.commodityOrmId= $scope.chooseUserData.commodityOrmId;
            $scope.ormType= $scope.chooseUserData.ormType;
            $scope.commodityTradeOrms= $scope.chooseUserData.commodityTradeOrms;
            console.log($scope.commodityTradeOrms)*/
        }
    }

    $scope.applySubmit=function(){
        console.log($scope.commodityId)
        var words = $scope.commodityId.split('/');
        console.log(words)
        var commodityId = words[0];

        var configCommodityOrmVIce= {
            tradeCommodityId: $scope.tradeCommodityId,  //交易品种编码
            priceCommodityId: $scope.priceCommodityId,  //行情品种编码
            commodityId:commodityId,  //品种编码
            accurateDigit:parseFloat($scope.accurateDigit),   //精确位数
            premium:parseFloat($scope.premium),  //升水贴
            ratio:parseFloat($scope.ratio),  //行情系数
            priceFlag:$scope.priceFlag,  //是否继承行情
            //commodityOrmId:$scope.commodityOrmId,
            ormType:$scope.ormType,
            commodityTradeOrms:$scope.Datalists,
        }

        var json = {
            configCommodityOrmVIce: configCommodityOrmVIce
        }
        VarietInmappingCtrlSer.tradeapply(json)
            .then(function (res) {
                if (res.data.code == "000000") {
                    $scope.auditshow = false;
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                    localStorageService.clear('userIdChecked');
                    $scope.search();
                }else{
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                }
            },function(error){
                $rootScope.tipService.setMessage(error.data.message, 'warning');
            })
    }

    $scope.getaudit=function () {
        if (!$scope.applyId) {
            $rootScope.tipService.setMessage('请先申请交易变更', 'warning');
        } else {
            var json={
                applyId:$scope.applyId
            }
            VarietInmappingCtrlSer.Getaudit(json)
                .then(function(res){
                    console.log(res)
                    if(res.data.code=="000000"){
                        var getData=JSON.parse(res.data.content);
                        $scope.getaduitDatalist=getData.configCommodityInnerMapV;
                        console.log($scope.getaduitDatalist)
                        $scope.auditGetshow = true;
                        $scope.addEditTexts = "审核变更";
                        $scope.applyId= $scope.getaduitDatalist.applyId;
                        $scope.commodityId= $scope.getaduitDatalist.commodityId;
                        $scope.tradeCommodityId= $scope.getaduitDatalist.tradeCommodityId;
                        $scope.priceCommodityId= $scope.getaduitDatalist.priceCommodityId;
                        $scope.state= $scope.getaduitDatalist.state;
                        $scope.accurateDigit= $scope.getaduitDatalist.accurateDigit;
                        $scope.premium= $scope.getaduitDatalist.premium;
                        $scope.ratio= $scope.getaduitDatalist.ratio;
                        $scope.priceFlag= $scope.getaduitDatalist.priceFlag;
                    }
                })
        }
    }

    $scope.auditRoletrueData = function (tmpOpt) {
        var json = {
            applyId: $scope.chooseUserData.applyId,
            auditRs: tmpOpt
        };
        VarietInmappingCtrlSer.auditRoletruetion(json)
            .then(function (res) {
                if (res.data.code == '000000') {
                    $scope.auditGetshow = false;
                    localStorageService.clear('userIdChecked');
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                    $scope.search();
                } else {
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                }
            },function(error) {
                $rootScope.tipService.setMessage(error.data.message, 'warning');
            })
    }
    $scope.auditRolefalseData = function (tmpOpt) {
        var json = {
            applyId: $scope.chooseUserData.applyId,
            auditRs: tmpOpt
        };
        VarietInmappingCtrlSer.auditRoletruetion(json)
            .then(function (res) {
                if (res.data.code == '000000') {
                    $scope.auditGetshow = false;
                    localStorageService.clear('userIdChecked');
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                    $scope.search();
                } else {
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                }
            },function(error) {
                $rootScope.tipService.setMessage(error.data.message, 'warning');
            })
    }

    $scope.pass=function() {
        if (!$scope.chooseItemTab1) {
            $rootScope.tipService.setMessage('请先选择品种内映射信息', 'warning');
        } else {
            var json={
                commodityId:$scope.chooseItemTab1
            }
            VarietInmappingCtrlSer.passCheck(json)
                .then(function (res) {
                    if (res.data.code == '000000') {
                        localStorageService.clear('userIdChecked');
                        $rootScope.tipService.setMessage(res.data.message, 'warning');
                        $scope.search();
                    } else {
                        $rootScope.tipService.setMessage(res.data.message, 'warning');
                    }
                }, function (error) {
                    $rootScope.tipService.setMessage(error.data.message, 'warning');
                });
        }
    }
    $scope.fail=function() {
        if (!$scope.chooseItemTab1) {
            $rootScope.tipService.setMessage('请先选择品种内映射信息', 'warning');
        } else {
            var json={
                commodityId:$scope.chooseItemTab1
            }
            VarietInmappingCtrlSer.failedCheck(json)
                .then(function (res) {
                    if (res.data.code == '000000') {
                        localStorageService.clear('userIdChecked');
                        $rootScope.tipService.setMessage(res.data.message, 'warning');
                        $scope.search();
                    } else {
                        $rootScope.tipService.setMessage(res.data.message, 'warning');
                    }
                }, function (error) {
                    $rootScope.tipService.setMessage(error.data.message, 'warning');
                });
        }
    }
    $scope.open=function() {
        if (!$scope.chooseItemTab1) {
            $rootScope.tipService.setMessage('请先选择品种内映射信息', 'warning');
        } else {
            var json={
                commodityId:$scope.chooseItemTab1
            }
            VarietInmappingCtrlSer.open(json)
                .then(function (res) {
                    if (res.data.code == '000000') {
                        localStorageService.clear('userIdChecked');
                        $rootScope.tipService.setMessage(res.data.message, 'warning');
                        $scope.search();
                    } else {
                        $rootScope.tipService.setMessage(res.data.message, 'warning');
                    }
                }, function (error) {
                    $rootScope.tipService.setMessage(error.data.message, 'warning');
                });
        }
    }

    $scope.close=function() {
        if (!$scope.chooseItemTab1) {
            $rootScope.tipService.setMessage('请先选择品种内映射信息', 'warning');
        } else {
            confirmService.set('确认提示', '确定要注销此品种内映射信息?', function () {
                var json={
                    commodityId:$scope.chooseItemTab1
                }
                VarietInmappingCtrlSer.Close(json)
                    .then(function (res) {
                        if (res.data.code == '000000') {
                            localStorageService.clear('userIdChecked');
                            $rootScope.tipService.setMessage(res.data.message, 'warning');
                            $scope.search();
                        } else {
                            $rootScope.tipService.setMessage(res.data.message, 'warning');
                        }
                    }, function (error) {
                        $rootScope.tipService.setMessage(error.data.message, 'warning');
                    });
                confirmService.clear();
            });
        }
    }

}])
    .factory('VarietInmappingCtrlSer', ['$http', 'localStorageService', 'myHttp', '$q', '$rootScope', function ($http, localStorageService, myHttp, $q, $rootScope) {
        return {
            //查询
            search: function (json) {
                var deferred = $q.defer();
                myHttp.post("admin/config/product/orm/query/page", json)
                    .then(function (res) { // 调用承诺API获取数据 .resolve
                        deferred.resolve(res);
                    }, function (res) { // 处理错误 .reject
                        deferred.reject(res);
                    });
                return deferred.promise;
            },
            searchlist:function(superorgId){
                var json={
                    search_EQ_orgId:superorgId
                }
                var deferred = $q.defer();
                myHttp.post("admin/config/product/category/query/list",json)
                    .then(function (res) { // 调用承诺API获取数据 .resolve
                        deferred.resolve(res);
                    }, function (res) { // 处理错误 .reject
                        deferred.reject(res);
                    });
                return deferred.promise;
            },
            searchlistpz:function(categoryId){
                var json={
                    search_EQ_categoryId:categoryId
                }
                var deferred = $q.defer();
                myHttp.post("admin/config/product/commodity/query/list",json)
                    .then(function (res) { // 调用承诺API获取数据 .resolve
                        deferred.resolve(res);
                    }, function (res) { // 处理错误 .reject
                        deferred.reject(res);
                    });
                return deferred.promise;
            },


            searchlisteg:function(orgId){
                var json={
                    search_EQ_orgId:orgId
                }
                var deferred = $q.defer();
                myHttp.post("admin/config/product/category/query/list",json)
                    .then(function (res) { // 调用承诺API获取数据 .resolve
                        deferred.resolve(res);
                    }, function (res) { // 处理错误 .reject
                        deferred.reject(res);
                    });
                return deferred.promise;
            },
            //下级机构
            AllNOTLIKEQuerySer: function(superorgCode) { //所属下级机构
                var data = {
                    orders: 'asc',
                    search_LLIKE_orgCode: superorgCode + '-',
                    search_NOTLLIKE_orgCode: superorgCode + '-%-'
                };
                var deferred = $q.defer();
                myHttp.post("organize/query/as/list", data)
                    .then(function(res) { // 调用承诺API获取数据 .resolve
                        //console.log(res)
                        var resArr = [];
                        if (res.code == "000000") {
                            var results = JSON.parse(res.content);
                            //console.log(results)
                            var tmpArr = [];
                            for (var i = 0, r = results.length; i < r; i++) {
                                if (results[i].state == 1) {
                                    var tmp = {};
                                    tmp.orgCode = results[i].orgCode;
                                    tmp.orgId = results[i].orgId;
                                    tmp.orgName = results[i].orgName;
                                    tmp.text = results[i].orgName + ' (' + results[i].orgNum + ')';
                                    tmpArr.push(tmp);
                                }
                            }
                            deferred.resolve(tmpArr);
                        } else {
                            deferred.reject(res);
                        }
                    }, function(res) { // 处理错误 .reject
                        deferred.reject(res);
                    });
                return deferred.promise;
            },
            Addsub: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'admin/config/product/orm/create',
                    data: json
                }).then(function successCallback(response) {
                    console.log(response)
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
            tradeapply: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'admin/config/product/orm/apply',
                    data: json
                }).then(function successCallback(response) {
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
            Getaudit: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'admin/config/product/orm/apply/get',
                    data: json
                }).then(function successCallback(response) {
                    console.log(response)
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
            auditRoletruetion: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'admin/config/product/orm/audit',
                    data: json
                }).then(function successCallback(response) {
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
            Close: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'admin/config/product/orm/close',
                    data: json
                }).then(function successCallback(response) {
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
            //通过
            passCheck: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'admin/config/product/orm/pass',
                    data: json
                }).then(function successCallback(response) {
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
            //不通过
            failedCheck: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'admin/config/product/orm/fail',
                    data: json
                }).then(function successCallback(response) {
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
            //重新提交
            open: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'admin/config/product/orm/open',
                    data: json
                }).then(function successCallback(response) {
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
            //上手品种
            uplist: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'admin/config/product/commodity/query/super/list',
                    data: json
                }).then(function successCallback(response) {
                    console.log(response)
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
            orgget: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'admin/config/product/orm/get',
                    data: json
                }).then(function successCallback(response) {
                    console.log(response)
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },

        }
    }])
