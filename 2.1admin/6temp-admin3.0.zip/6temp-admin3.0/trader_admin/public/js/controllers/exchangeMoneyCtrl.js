app.controller("exchangeMoneyCtrl", ["$scope", "$timeout", "$rootScope", "$sce", "exchangeMoneyAll", "getTradeType", "getIoType", 'getAccountStatus', "getPageNum", "tipService", "confirmService", "getCurrencyMethod", 'getBankState', 'timestamp', 'localStorageService', function ($scope, $timeout, $rootScope, $sce, exchangeMoneyAll, getTradeType, getIoType, getAccountStatus, getPageNum, tipService, confirmService, getCurrencyMethod, getBankState, timestamp, localStorageService) {
    $scope.toggleTraderSearchState=false;
    $scope.Toggle = function(){
        $scope.toggleTraderSearchState = !$scope.toggleTraderSearchState;
        if($scope.toggleTraderSearchState){
           $('.search_column').css('height','auto');
        }
        else{
           $('.search_column').css('height','36px');
        }
    };
    //银行状态
    $scope.BankState = getBankState;
    //出入金方向
    $scope.ioTypeNum = getIoType;
    //交易类型
    $scope.tradeType = getTradeType;
    //银行状态
    $scope.BankState = getBankState;
    //审核状态
    $scope.accountStatus = getAccountStatus;
    // 货币转换
    getCurrencyMethod.obtainCurrencyType().then(function (res) {
        if(res.code=='000000'){
            $scope.currencyList = JSON.parse(res.content);
            console.log( $scope.currencyList);
        }
    });

    var processContent,processTotal;
    var source = {
        type: 'POST',
        datatype: "json",
        datafields: [  //数据字段定义
            {name: 'accountIoId', type: 'string'},
            {name: 'userName', type: 'string'},
            {name: 'ioType', type: 'string'},
            {name: 'tradeType', type: 'string'},
            {name: 'currency', type: 'string'},

            {name: 'ioNumber', type: 'string'},
            {name: 'verifyName', type: 'string'},
            {name: 'state', type: 'string'},
            {name: 'createTime', type: 'string'}
        ],
        url: $rootScope.baseUrl + 'account/io/query/foraudit/page',
        root: "content",
        pagesize:10,
        processData: function (data) {
            data.page = (data.pagenum + 1)?(data.pagenum + 1):1;
            data.rows =(data.pagesize)?(data.pagesize):10;
            data.order =($scope.order)?$scope.order:'desc';
            data.sort =($scope.sort)?$scope.sort:'createTime';
            data.search_A_EQ_userId = ($scope.directiveUserId) ? $scope.directiveUserId : '';
            data.search_EQ_state =($scope.bankStatus)?$scope.bankStatus:'';
            data.search_GTE_createTime = ($scope.createTimeStartNum) ? Date.parse(new Date(timestamp.formatTimeKind($scope.createTimeStartNum))) : '';
            data.search_LTE_createTime = ($scope.createTimeEndNum) ? Date.parse(new Date(timestamp.formatTimeKind($scope.createTimeEndNum))) : '';
            data.search_EQ_ioType =($scope.ioType)?$scope.ioType:'';
            data.search_EQ_currency =($scope.currency)?$scope.currency:'';

            $scope.orgCode = localStorageService.get('oldOrgCode');
            if ($scope.organizeValue == true && $scope.downOrganizeValue == true) {
                data.search_A_LLIKE_orgCode = ($scope.orgCode) ? $scope.orgCode : '';
            }
            if ($scope.organizeValue == true && $scope.downOrganizeValue == false) {
                data.search_A_EQ_orgCode = ($scope.orgCode) ? $scope.orgCode : '';
            }
            if ($scope.organizeValue == false && $scope.downOrganizeValue == true) {
                data.search_A_LLIKE_orgCode = ($scope.orgCode) ? $scope.orgCode + '-' : '';
            }
        }, //传递参数处理
        beforeLoadComplete: function (records) { //数据完全加载完执行绘制表格
            var start;
            for (var i in records) {
                start = parseInt(i);
                break;
            }
            for (var k = 0, r = processContent.length; k < r; k++) {
                records[start + k].accountIoId = processContent[k].accountIoId;
                records[start + k].userName = processContent[k].userName;
                records[start + k].ioType = processContent[k].ioType;
                records[start + k].tradeType = processContent[k].tradeType;
                records[start + k].currency = processContent[k].currency;

                records[start + k].ioNumber = processContent[k].ioNumber;
                records[start + k].verifyName = processContent[k].verifyName;
                records[start + k].state = processContent[k].state;
                records[start + k].createTime = processContent[k].createTime;
            }
        },
        beforeprocessing: function (data) { //处理总页数
            var processData = JSON.parse(data.content);
            console.log(processData)
            processContent = processData.content;
            source.totalrecords = processData.totalElements == 0 ? 5 : processData.totalElements;
            processTotal = processData.totalElements;
        },
        loadComplete: function (records) {
            $scope.saveResult=JSON.parse(records.content);
            var data =  $scope.saveResult.totalElements;
            if (data == 0) {
                $('#contenttableentrustDetailGrid > div').remove();
            }
        },
        endUpdate: true
    };
    //创建数据适配器
    var dataAdapter = null;
    $scope.searchAjax = function () {
        $scope.featureShow=true;
        $scope.toggleTraderSearchState = false;
        $('.search_column').css('height', '36px');
        if (dataAdapter == null) {
            dataAdapter = new $.jqx.dataAdapter(source);
            //创建表格
            $("#entrustDetailGrid").jqxGrid({
                source: dataAdapter,
                columns: [  //表格数据域
                    {
                        text: '用户名',
                        datafield: 'userName',
                        width: '12%',
                        minwidth: 12 + '%',//设置列min宽
                        align: 'center'//设置表头
                    },
                    {
                        text: '方向',
                        datafield: 'ioType',
                        minwidth: 12 + '%',
                        cellsalign: 'center',
                        align: 'center',
                        width: '12%',
                        cellsrenderer: function (row, columnfield, value, defaulthtml, columnproperties) {
                            if (getIoType) {
                                for (var i = 0; i <getIoType.length; i++) {
                                    if (value ==getIoType[i].id) {
                                        return getIoType[i].name;
                                    }
                                }
                            }
                        }
                    },
                    {
                        text: '流水类型',
                        datafield: 'tradeType',
                        width:'12%',
                        minwidth: 12 + '%',
                        align: 'center',
                        cellsrenderer: function (row, columnfield, value, defaulthtml, columnproperties) {
                            if (getTradeType) {
                                for (var i = 0; i <getTradeType.length; i++) {
                                    if (value ==getTradeType[i].id) {
                                        return getTradeType[i].name;
                                    }
                                }
                            }
                        }
                    },
                    {
                        text: '币种',
                        datafield: 'currency',
                        width:'12%',
                        minwidth: 12 + '%',
                        align: 'center',
                        cellsrenderer: function (row, columnfield, value, defaulthtml, columnproperties) {
                            if ($scope.currencyList) {
                                for (var i = 0; i <$scope.currencyList.length; i++) {
                                    if (value ==$scope.currencyList[i].currency) {
                                        return $scope.currencyList[i].currencyName;
                                    }
                                }
                            }
                        }
                    },
                    {
                        text: '金额',
                        datafield: 'ioNumber',
                        width:'12%',
                        minwidth: 12 + '%',
                        align: 'center'
                    },
                    {
                        text: '审核人',
                        datafield: 'verifyName',
                        width:'12%',
                        minwidth: 12 + '%',
                        align: 'center'
                    },
                    {
                        text: '审核状态',
                        datafield: 'state',
                        width:'12%',
                        minwidth: 12 + '%',
                        align: 'center',
                        cellsrenderer: function (row, columnfield, value, defaulthtml, columnproperties) {
                            if (getAccountStatus) {
                                for (var i = 0; i <getAccountStatus.length; i++) {
                                    if (value ==getAccountStatus[i].id) {
                                        return getAccountStatus[i].name;
                                    }
                                }
                            }
                        }
                    },
                    {
                        text: '日期',
                        datafield: 'createTime',
                        width:'16%',
                        minwidth: 16 + '%',
                        align: 'center',
                        cellsrenderer: function (row, columnfield, value, defaulthtml, columnproperties) {
                            return timestamp.timestampCoverHms(value, 'all');
                        }
                    },
                ],
                width: 100 + '%',
                height: 81 + '%',
                theme:'metrodark',
                virtualmode: true,
                rendergridrows: function (params) { //将数据渲染到页面
                    return params.data;
                },
                pageable: true,
                pagesizeoptions: ['10','30','100','200'],
                // sortable: true,
                columnsresize: true,//列间距是否可调整
                // selectionmode: 'singlecell',//选择模式
                clipboard: true,
                // selectionmode: 'checkbox',//复选框
            });
        }else {
            $("#entrustDetailGrid").jqxGrid('updatebounddata', 'cells');
        }
    };

    //分页
    $("#entrustDetailGrid").on("pagechanged", function (event) {
        console.log(event)
    });
    //排序
    // $("#entrustDetailGrid").on("sort", function (event) {
    //     var sortinformation = event.args.sortinformation;
    //     $scope.sort=sortinformation.sortcolumn;
    //     $scope.order=($scope.sort)?(sortinformation.sortdirection.ascending)?'asc':'desc':'asc';
    //     data={
    //         order:$scope.order,
    //         sort:$scope.sort
    //     };
    //     source.processData(data);
    //     $("#entrustDetailGrid").jqxGrid('updatebounddata', 'sort');
    // });
    //选中
    $('#entrustDetailGrid').on('rowselect', function (event) {
        $scope.ioId = event.args.row.accountIoId;
        console.log( $scope.ioId)
    });

    //审核
    $scope.audit = function () {
        if (!$scope.ioId) {
            $rootScope.tipService.setMessage('请先选择用户', 'warning');
        } else {
            var json = {
                result: 9999,
                accountIoId: $scope.ioId
            };
            exchangeMoneyAll.review(json)
                .then(function (res) {
                    $rootScope.tipService.setMessage(res.message, 'warning');
                    $scope.searchAjax();
                }, function (error) {
                    $rootScope.tipService.setMessage(error.message, 'warning');
                })
        }
    };
    //驳回
    $scope.reject = function () {
        if (!$scope.ioId) {
            $rootScope.tipService.setMessage('请先选择用户', 'warning');
        } else {
            var json = {
                result: 8888,
                accountIoId: $scope.ioId
            };
            exchangeMoneyAll.review(json)
                .then(function (res) {
                    $rootScope.tipService.setMessage(res.message, 'warning');
                    $scope.searchAjax();
                }, function (error) {
                    $rootScope.tipService.setMessage(error.message, 'warning');
                })
        }
    };
}])
// Server  出入金
    .factory('exchangeMoneyAll', ['$http', 'myHttp', '$q', '$rootScope', function ($http, myHttp, $q, $rootScope) {
        return {
            unitSearch: function (json) {
                var deferred = $q.defer();
                myHttp.post("account/io/query/foraudit/page", json)
                    .then(function (res) {
                        deferred.resolve(res);
                    }, function (res) {
                        deferred.reject(res);
                    });
                return deferred.promise;
            },
            review: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'account/io/audit',
                    data: json,
                    headers: {
                        'Content-Type': 'application/json;charset=UTF-8'
                    }
                }).success(function (res) {
                    deferred.resolve(res);
                }).error(function (res) {
                    deferred.reject(res)
                });
                return deferred.promise;
            }
        }
    }]);