app.controller('CustomerEntrustCtrl', ['$rootScope', '$scope', 'CustomerEntrustData', 'tipService', 'getPageNum', 'getCurrencyType', 'getProductScope', 'getUserStates', 'timestamp', 'getOrderDirect', 'getPriceCondition', 'getOrderState', 'getOrderType', '$state', 'getRequestType', 'getOrderReason', 'localStorageService', function ($rootScope, $scope, CustomerEntrustData, tipService, getPageNum, getCurrencyType, getProductScope, getUserStates, timestamp, getOrderDirect, getPriceCondition, getOrderState, getOrderType, $state, getRequestType, getOrderReason, localStorageService) {
    $scope.toggleTraderSearchState = false;
    $scope.Toggle = function () {
        $scope.toggleTraderSearchState = !$scope.toggleTraderSearchState;
        if ($scope.toggleTraderSearchState) {
            $('.search_column').css('height', 'auto');
        }
        else {
            $('.search_column').css('height', '36px');
        }
    };

    //机构码转换
    $scope.getOrgnizeList = localStorageService.get('organizeData');
    //报单
    $scope.OrderReason = getOrderReason;
    //触发类型
    $scope.OrderRequestType = getRequestType;
    //买卖方向
    $scope.orderDirect = getOrderDirect;
    //委托类型
    $scope.getOrderType = getOrderType; ////获取委托类型
    $scope.priceCondition = getPriceCondition;
    //委托状态
    $scope.orderState = getOrderState;

    var processContent,processTotal;
    var source = {
        type: 'POST',
        datatype: "json",
        datafields: [  //数据字段定义
            {name: 'localOrderId', type: 'string'},
            {name: 'localOrderNo', type: 'string'},
            {name: 'userName', type: 'string'},
            {name: 'orgCode', type: 'string'},
            {name: 'productName', type: 'string'},
            {name: 'productCode', type: 'string'},

            {name: 'priceCondition', type: 'string'},
            {name: 'orderState', type: 'string'},
            {name: 'reason', type: 'string'},
            {name: 'orderDirect', type: 'string'},

            {name: 'orderPrice', type: 'string'},
            {name: 'orderVolume', type: 'string'},
            {name: 'errorMsgExt', type: 'string'},
            {name: 'createTime', type: 'string'}

        ],
        url: $rootScope.baseUrl + 'admin/trade/order/query/as/page',
        root: "content",
        pagesize:10,
        processData: function (data) {
            data.page = (data.pagenum + 1)?(data.pagenum + 1):1;
            data.rows =(data.pagesize)?(data.pagesize):10;
            data.order =($scope.order)?$scope.order:'desc';
            data.sort =($scope.sort)?$scope.sort:'createTime';
            data.search_A_EQ_userId = ($scope.directiveUserId) ? $scope.directiveUserId : '';
            data.search_A_EQ_orderDirect = ($scope.SearchOrderDirect) ? $scope.SearchOrderDirect : '';
            data.search_A_GTE_createTime = ($scope.createTimeStart) ? $scope.createTimeStart : '';
            data.search_A_LTE_createTime = ($scope.createTimeEnd) ? $scope.createTimeEnd : '';
            data.search_A_EQ_orderState = ($scope.SearchOrderState) ? $scope.SearchOrderState : '';
            data.search_A_EQ_priceCondition = ($scope.orderType) ? $scope.orderType : '';
            data.search_A_EQ_reason = ($scope.orderReason) ? $scope.orderReason : '';

            $scope.orgCode = localStorageService.get('oldOrgCode');
            if ($scope.organizeValue == true && $scope.downOrganizeValue == true) {
                data.search_A_LLIKE_orgCode = ($scope.orgCode) ? $scope.orgCode : '';
            }
            if ($scope.organizeValue == true && $scope.downOrganizeValue == false) {
                data.search_A_EQ_orgCode = ($scope.orgCode) ? $scope.orgCode : '';
            }
            if ($scope.organizeValue == false && $scope.downOrganizeValue == true) {
                data.search_A_LLIKE_orgCode = ($scope.orgCode) ? $scope.orgCode + '-' : '';
            }
        }, //传递参数处理
        beforeLoadComplete: function (records) { //数据完全加载完执行绘制表格
            console.log(records)
            var start;
            for (var i in records) {
                start = parseInt(i);
                break;
            }
            for (var k = 0, r = processContent.length; k < r; k++) {
                records[start + k].localOrderId = processContent[k].localOrderId;
                records[start + k].localOrderNo = processContent[k].localOrderNo;
                records[start + k].userName = processContent[k].userName;
                records[start + k].orgCode = processContent[k].orgCode;
                records[start + k].productName = processContent[k].productName;
                records[start + k].productCode = processContent[k].productCode;

                records[start + k].priceCondition = processContent[k].priceCondition;
                records[start + k].orderState = processContent[k].orderState;
                records[start + k].reason = processContent[k].reason;
                records[start + k].orderDirect = processContent[k].orderDirect;

                records[start + k].orderPrice = processContent[k].orderPrice;
                records[start + k].orderVolume = processContent[k].orderVolume;
                records[start + k].errorMsgExt = processContent[k].errorMsgExt;
                records[start + k].createTime = processContent[k].createTime;
            }
        },
        beforeprocessing: function (data) { //处理总页数
            var processData = JSON.parse(data.content);
            processContent = processData.content;
            source.totalrecords = processData.totalElements == 0 ? 1 : processData.totalElements;
            processTotal = processData.totalElements;
        },
        loadComplete: function (records) {
            $scope.saveResult=JSON.parse(records.content);
            var data =  $scope.saveResult.totalElements;
            if (data == 0) {
                $('#contenttableentrustDetailGrid > div').remove();
            }
        },
        endUpdate: true
    };
    //创建数据适配器
    var dataAdapter = null;
    $scope.searchAjax = function () {
        $scope.toggleTraderSearchState = false;
        $('.search_column').css('height', '36px');
        if (dataAdapter == null) {
            dataAdapter = new $.jqx.dataAdapter(source);
            //创建表格
            $("#entrustDetailGrid").jqxGrid({
                source: dataAdapter,
                width: 100 + '%',
                height: 87 + '%',
                rowsheight:30,
                theme:'metrodark',
                virtualmode: true,
                rendergridrows: function (params) { //将数据渲染到页面
                    return params.data;
                },
                pageable: true,
                sortable: true,
                pagesizeoptions: ['10','30','100','200'],
                columnsresize: true,//列间距是否可调整
                selectionmode: 'singlecell',//选择模式
                clipboard: true,
                columns: [  //表格数据域
                    {
                        text: '委托单号',
                        datafield: 'localOrderNo',
                        sortable:false,
                        align: 'center',//设置表头
                        width: '10%',
                    },
                    {
                        text: '用户名',
                        datafield: 'userName',
                        sortable:false,
                        cellsalign: 'center',
                        align: 'center',
                        width: '7%'
                    },
                    {
                        text: '机构编码',
                        datafield: 'orgCode',
                        sortable:false,
                        width:'8%',
                        align: 'center',
                        cellsrenderer: function (row, columnfield, value, defaulthtml, columnproperties) {
                            if ($scope.getOrgnizeList) {
                                for (var i = 0; i < $scope.getOrgnizeList.length; i++) {
                                    if (value == $scope.getOrgnizeList[i].orgCode) {
                                        return $scope.getOrgnizeList[i].orgNum;
                                    }
                                }
                            }
                        }
                    },
                    {
                        text: '商品名',
                        datafield: 'productName',
                        sortable:false,
                        cellsalign: 'center',
                        align: 'center',
                        width:'7%'
                    },
                    {
                        text: '商品代码',
                        datafield: 'productCode',
                        sortable:false,
                        align: 'center',
                        width:'7%'
                    },
                    {
                        text: '委托类型',
                        datafield: 'priceCondition',
                        sortable:false,
                        cellsalign: 'center',
                        align: 'center',
                        width:'6%',
                        cellsrenderer: function (row, columnfield, value, defaulthtml, columnproperties) {
                            if ($scope.priceCondition) {
                                for (var i = 0; i < $scope.priceCondition.length; i++) {
                                    if (value == $scope.priceCondition[i].id) {
                                        return $scope.priceCondition[i].name;
                                    }
                                }
                            }
                        }
                    },
                    {
                        text: '委托状态',
                        datafield: 'orderState',
                        sortable:false,
                        width:'7%',
                        align: 'center',
                        cellsrenderer: function (row, columnfield, value, defaulthtml, columnproperties) {
                            if ($scope.orderState) {
                                for (var i = 0; i < $scope.orderState.length; i++) {
                                    if (value == $scope.orderState[i].id) {
                                        return $scope.orderState[i].name;
                                    }
                                }
                            }
                        }
                    },
                    {
                        text: '触发类型',
                        datafield: 'reason',
                        sortable:false,
                        cellsalign: 'center',
                        align: 'center',
                        width:'7%',
                        cellsrenderer: function (row, columnfield, value, defaulthtml, columnproperties) {
                            if ($scope.OrderReason) {
                                for (var i = 0; i < $scope.OrderReason.length; i++) {
                                    if (value == $scope.OrderReason[i].id) {
                                        return $scope.OrderReason[i].name;
                                    }
                                }
                            }
                        }
                    },
                    {
                        text: '买卖方向',
                        datafield: 'orderDirect',
                        sortable:false,
                        align: 'center',
                        width:'6%',
                        cellsrenderer: function (row, columnfield, value, defaulthtml, columnproperties) {
                            if ($scope.orderDirect) {
                                for (var i = 0; i < $scope.orderDirect.length; i++) {
                                    if (value == $scope.orderDirect[i].id) {
                                        return $scope.orderDirect[i].name;
                                    }
                                }
                            }
                        },
                        cellsalign: 'right',
                    },
                    {
                        text: '订单价格',
                        datafield: 'orderPrice',
                        align: 'center',
                        cellsalign: 'center',
                        width:'7%'
                    },
                    {
                        text: '下单数量',
                        datafield: 'orderVolume',
                        minwidth: 7 + '%',
                        cellsalign: 'center',
                        align: 'center',
                        width:'7%'
                    },
                    {
                        text: '下单失败',
                        datafield: 'errorMsg',
                        sortable:false,
                        cellsalign: 'center',
                        align: 'center',
                        width:'10%'
                    },
                    {
                        text: '委托时间',
                        datafield: 'createTime',
                        cellsalign: 'center',
                        align: 'center',
                        width:'11%',
                        cellsrenderer: function (row, columnfield, value, defaulthtml, columnproperties) {
                            return timestamp.timestampCoverHms(value, 'all');
                        }
                    }
                ]
            });
        }else {
            $("#entrustDetailGrid").jqxGrid('updatebounddata', 'cells');
        }
    };
         $("#entrustDetailGrid").on("pagechanged", function (event) {
         console.log(event)
     });
    //排序
    $("#entrustDetailGrid").on("sort", function (event){
        var sortinformation = event.args.sortinformation;
        $scope.sort=sortinformation.sortcolumn;
        $scope.order=($scope.sort)?(sortinformation.sortdirection.ascending)?'asc':'desc':'asc';
        data={
            order:$scope.order,
            sort:$scope.sort
        };
        source.processData(data);
        $("#entrustDetailGrid").jqxGrid('updatebounddata', 'sort');
    });
}])
    .factory('CustomerEntrustData', ['$http', 'myHttp', '$q', function ($http, myHttp, $q) {
    return {
        search: function (json) {
            var deferred = $q.defer();
            myHttp.post("admin/trade/order/query/as/page", json)
                .then(function (res) {  // 调用承诺API获取数据 .resolve
                    deferred.resolve(res);
                }, function (res) {  // 处理错误 .reject
                    deferred.reject(res);
                });
            return deferred.promise;
        }
    };
}]);