app.controller('runSearchCtrl', ['$rootScope', '$scope', 'runSearchAll', '$timeout', '$sce', 'getPageNum', 'getIoType', 'getTradeType', 'getCurrencyType', 'timestamp', 'getAccountStatus', 'localStorageService', function ($rootScope, $scope, runSearchAll, $timeout, $sce, getPageNum, getIoType, getTradeType, getCurrencyType, timestamp, getAccountStatus, localStorageService) {
    $scope.toggleTraderSearchState = false;
    $scope.Toggle = function () {
        $scope.toggleTraderSearchState = !$scope.toggleTraderSearchState;
        if ($scope.toggleTraderSearchState) {
            $('.search_column').css('height', 'auto');
        }
        else {
            $('.search_column').css('height', '36px');
        }
    };
    //流水类型
    $scope.tradeType = getTradeType;
    //出入金方向
    $scope.ioTypeNum = getIoType;
    // 货币转换
    getCurrencyType.then(function (res) {
        $scope.currencyList = JSON.parse(res.content);
    });
    // 查询
    $scope.tradeTypeNum = '';
    $scope.createTimeStartNum = '';
    $scope.createTimeEndNum = '';
    $scope.ioType = '';
    $scope.currency = '';
    var processContent, processTotal;
    var source = {
        type: 'POST',
        datatype: "json",
        datafields: [  //数据字段定义
            {name: 'userName', type: 'string'},
            {name: 'tradeType', type: 'string'},
            {name: 'state', type: 'string'},
            {name: 'ioType', type: 'string'},
            {name: 'currency', type: 'string'},

            {name: 'ioNumber', type: 'string'},
            {name: 'comment', type: 'string'},
            {name: 'createTime', type: 'string'}
        ],
        url: $rootScope.baseUrl + 'account/io/query/page',
        root: "content",
        pagesize: 10,
        processData: function (data) {
            data.page = (data.pagenum + 1) ? (data.pagenum + 1) : 1;
            data.rows = (data.pagesize) ? (data.pagesize) : 10;
            data.order = ($scope.order) ? $scope.order : 'desc';
            data.sort = ($scope.sort) ? $scope.sort : 'createTime';
            data.search_A_EQ_userId = ($scope.directiveUserId) ? $scope.directiveUserId : '';
            data.search_EQ_tradeType =($scope.tradeTypeNum)?$scope.tradeTypeNum:'';
            data.search_GTE_createTime = ($scope.createTimeStartNum) ? Date.parse(new Date(timestamp.formatTimeKind($scope.createTimeStartNum))) : '';
            data.search_LTE_createTime = ($scope.createTimeEndNum) ? Date.parse(new Date(timestamp.formatTimeKind($scope.createTimeEndNum))) : '';
            data.search_EQ_ioType =($scope.ioType)?$scope.ioType:'';
            data.search_EQ_currency =($scope.currency)?$scope.currency:''

            $scope.orgCode = localStorageService.get('oldOrgCode');
            if ($scope.organizeValue == true && $scope.downOrganizeValue == true) {
                data.search_A_LLIKE_orgCode = ($scope.orgCode) ? $scope.orgCode : '';
            }
            if ($scope.organizeValue == true && $scope.downOrganizeValue == false) {
                data.search_A_EQ_orgCode = ($scope.orgCode) ? $scope.orgCode : '';
            }
            if ($scope.organizeValue == false && $scope.downOrganizeValue == true) {
                data.search_A_LLIKE_orgCode = ($scope.orgCode) ? $scope.orgCode + '-' : '';
            }
        }, //传递参数处理
        beforeLoadComplete: function (records) { //数据完全加载完执行绘制表格
            var start;
            for (var i in records) {
                start = parseInt(i);
                break;
            }
            for (var k = 0, r = processContent.length; k < r; k++) {
                records[start + k].userName = processContent[k].userName;
                records[start + k].tradeType = processContent[k].tradeType;
                records[start + k].state = processContent[k].state;
                records[start + k].ioType = processContent[k].ioType;
                records[start + k].currency = processContent[k].currency;

                records[start + k].ioNumber = processContent[k].ioNumber;
                records[start + k].comment = processContent[k].comment;
                records[start + k].createTime = processContent[k].createTime;
            }
        },
        beforeprocessing: function (data) { //处理总页数
            if(data.code==='000000'){
                var processData = JSON.parse(data.content);
                console.log(processData)
                processContent = processData.content;
                source.totalrecords = processData.totalElements == 0 ? 5 : processData.totalElements;
                processTotal = processData.totalElements;
            }else{
                $rootScope.tipService.setMessage(data.message, 'warning');
            }
        },
        loadComplete: function (records) {
            $scope.saveResult = JSON.parse(records.content);
            var data = $scope.saveResult.totalElements;
            if (data == 0) {
                $('#contenttableentrustDetailGrid > div').remove();
            }
        },
        endUpdate: true
    };
    //创建数据适配器
    var dataAdapter = null;
    $scope.searchAjax = function () {
        $scope.toggleTraderSearchState = false;
        $('.search_column').css('height', '36px');
        if (dataAdapter == null) {
            dataAdapter = new $.jqx.dataAdapter(source);
            //创建表格
            $("#entrustDetailGrid").jqxGrid({
                source: dataAdapter,
                columns: [  //表格数据域
                    {
                        text: '用户名',
                        datafield: 'userName',
                        width: '12%',
                        minwidth: 12 + '%',
                        align: 'center'
                    },
                    {
                        text: '流水类型',
                        datafield: 'tradeType',
                        minwidth: 12 + '%',
                        cellsalign: 'center',
                        align: 'center',
                        width: '12%',
                        cellsrenderer: function (row, columnfield, value, defaulthtml, columnproperties) {
                            if (getTradeType) {
                                for (var i = 0; i < getTradeType.length; i++) {
                                    if (value == getTradeType[i].id) {
                                        return getTradeType[i].name;
                                    }
                                }
                            }
                        }
                    },
                    {
                        text: '状态',
                        datafield: 'state',
                        width: '12%',
                        minwidth: 12 + '%',
                        align: 'center',
                        cellsrenderer: function (row, columnfield, value, defaulthtml, columnproperties) {
                            if (getAccountStatus) {
                                for (var i = 0; i < getAccountStatus.length; i++) {
                                    if (value == getAccountStatus[i].id) {
                                        return getAccountStatus[i].name;
                                    }
                                }
                            }
                        }
                    },
                    {
                        text: '方向',
                        datafield: 'ioType',
                        minwidth: 8 + '%',
                        cellsalign: 'center',
                        align: 'center',
                        width: '8%',
                        cellsrenderer: function (row, columnfield, value, defaulthtml, columnproperties) {
                            if (getIoType) {
                                for (var i = 0; i < getIoType.length; i++) {
                                    if (value == getIoType[i].id) {
                                        return getIoType[i].name;
                                    }
                                }
                            }
                        }
                    },
                    {
                        text: '币种',
                        datafield: 'currency',
                        minwidth: 8 + '%',
                        align: 'center',
                        width: '8%',
                        cellsrenderer: function (row, columnfield, value, defaulthtml, columnproperties) {
                            if ($scope.currencyList) {
                                for (var i = 0; i < $scope.currencyList.length; i++) {
                                    if (value == $scope.currencyList[i].currency) {
                                        return $scope.currencyList[i].currencyName;
                                    }
                                }
                            }
                        }
                    },
                    {
                        text: '金额',
                        datafield: 'ioNumber',
                        minwidth: 12 + '%',
                        cellsalign: 'center',
                        align: 'center',
                        width: '12%'
                    },
                    {
                        text: '备注',
                        datafield: 'comment',
                        minwidth: 20 + '%',
                        width: '20%',
                        align: 'center'
                    },
                    {
                        text: '日期',
                        datafield: 'createTime',
                        minwidth: 16 + '%',
                        cellsalign: 'center',
                        align: 'center',
                        width: '16%',
                        cellsrenderer: function (row, columnfield, value, defaulthtml, columnproperties) {
                            return timestamp.timestampCoverHms(value, 'all');
                        }
                    }
                ],
                width: 100 + '%',
                height: 87 + '%',
                theme: 'metrodark',
                virtualmode: true,
                rendergridrows: function (params) { //将数据渲染到页面
                    return params.data;
                },
                pageable: true,
                pagesizeoptions: ['10', '30', '100', '200'],
                // sortable: true,
                columnsresize: true,//列间距是否可调整
                selectionmode: 'singlecell',//选择模式
                clipboard: true,
            });
        } else {
            $("#entrustDetailGrid").jqxGrid('updatebounddata', 'cells');
        }
    };
    //分页
    $("#entrustDetailGrid").on("pagechanged", function (event) {
        console.log(event)
    });
    //排序
    $("#entrustDetailGrid").on("sort", function (event) {
        var sortinformation = event.args.sortinformation;
        $scope.sort = sortinformation.sortcolumn;
        $scope.order = ($scope.sort) ? (sortinformation.sortdirection.ascending) ? 'asc' : 'desc' : 'asc';
        data = {
            order: $scope.order,
            sort: $scope.sort
        };
        source.processData(data);
        $("#entrustDetailGrid").jqxGrid('updatebounddata', 'sort');
    });

}])
// Server  流水查询
    .factory('runSearchAll', ['$http', 'localStorageService', 'myHttp', '$q', '$rootScope', function ($http, localStorageService, myHttp, $q, $rootScope) {
        return {
            unitSearch: function (json) {
                var deferred = $q.defer();
                myHttp.post("account/io/query/page", json)
                    .then(function (res) {
                        deferred.resolve(res);
                    }, function (res) {
                        deferred.reject(res);
                    });
                return deferred.promise;

            }
        }
    }]);