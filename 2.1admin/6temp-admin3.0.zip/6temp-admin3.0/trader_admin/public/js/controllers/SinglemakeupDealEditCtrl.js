app.controller('SinglemakeupDealEditCtrl', ['$scope', 'SinglemakeupDealEditCtrlSel', 'getPageNum', 'localStorageService', '$state','$rootScope','SinglemakeupdetailsCtrlSel', function($scope, SinglemakeupDealEditCtrlSel, getPageNum, localStorageService, $state,$rootScope,SinglemakeupdetailsCtrlSel) {
		//成交修改
		$scope.goBack = function() {
			$state.go('tabs.Singlemakeupdetails');
		}
		function add0(m) {
			return m < 10 ? '0' + m : m
		}

		function format(datatime) {
			//shijianchuo是整数，否则要parseInt转换
			var time = new Date(datatime);
			var y = time.getFullYear();
			var m = time.getMonth() + 1;
			var d = time.getDate();
			var h = time.getHours();
			var mm = time.getMinutes();
			var s = time.getSeconds();
			return y + '-' + add0(m) + '-' + add0(d) + ' ' + add0(h) + ':' + add0(mm) + ':' + add0(s);
		}
		var chooseNoticeId = localStorageService.get('EDNoticeId');
		console.log(chooseNoticeId)
		SinglemakeupdetailsCtrlSel.getCJNTInfo(chooseNoticeId)
			.then(function(res) {
				console.log(res)
				if (res.data.code == '000000') {
					var dataVal = JSON.parse(res.data.content);
					console.log(dataVal);
						$scope.recoverMatchId=dataVal.recoverMatchId;
						$scope.recoverId=dataVal.recoverId;// 主表主键
						$scope.matchStreamId=parseInt(dataVal.matchStreamId);// 成交流号
						$scope.clientNo=dataVal.clientNo;// 客户账号
						console.log($scope.clinetNo)
						$scope.upNo=dataVal.upNo;// 上手编号
						$scope.systemNo=dataVal.systemNo;// 系统号
						$scope.matchNo=dataVal.matchNo;// 成交编号
						$scope.matchPatterns=dataVal.matchPatterns;// 成交模式
						$scope.orderSource=dataVal.orderSource;// 委托来源
						$scope.matchPrice=dataVal.matchPrice;// 成交价格
						$scope.matchVolume=parseInt(dataVal.matchVolume);// 成交数量
						$scope.matchTime=format(dataVal.matchTime); // 成交时间(64)
						$scope.upMatchTime=format(dataVal.upMatchTime);// 上手成交时间
						$scope.matchFee=parseFloat(dataVal.matchFee); // 手续费
						$scope.currencySymbol=dataVal.currencySymbol; // 手续费币种(32)
						$scope.marketNo=dataVal.marketNo;// 市场编号
						$scope.commodityType=dataVal.commodityType;// 品种类型
						$scope.commodityNo=dataVal.commodityNo;// 品种编号
						$scope.contractNo=dataVal.contractNo;// 合约编号
						$scope.orderDirect=dataVal.orderDirect;// 买卖
						$scope.orderOffset=dataVal.orderOffset;// 开平
						$scope.t1Flag=dataVal.t1Flag;// T+1标志
						$scope.feeHandwork=dataVal.feeHandwork;// 是否手工手续费
						$scope.deleteFlag=dataVal.deleteFlag;// 删除标记
						$scope.orderId=parseInt(dataVal.orderId);// 委托ID
						$scope.matchId=parseInt(dataVal.matchId);// 成交ID
						// 用户信息
						$scope.userName=dataVal.userName; // 用户账户
						// 资产信息
						$scope.productCode=dataVal.productCode; // 资产代码
				}
			});
		$scope.NewSubmit= function() {
					var recoverMatchVIce={
						recoverMatchId:$scope.recoverMatchId,
						//recoverId:$scope.recoverId,// 主表主键
						matchStreamId:parseInt($scope.matchStreamId),// 成交流号
						clientNo:$scope.clientNo,// 客户账号
						upNo:$scope.upNo,// 上手编号
						systemNo:$scope.systemNo,// 系统号
						matchNo:$scope.matchNo,// 成交编号
						matchPatterns:$scope.matchPatterns,// 成交模式
						orderSource:$scope.orderSource,// 委托来源
						matchPrice:$scope.matchPrice,// 成交价格
						matchVolume:parseInt($scope.matchVolume),// 成交数量
						matchTime:Date.parse(new Date($scope.matchTime)), // 成交时间(64)
						upMatchTime:Date.parse(new Date($scope.upMatchTime)),// 上手成交时间
						matchFee:parseFloat($scope.matchFee), // 手续费
						currencySymbol:$scope.currencySymbol, // 手续费币种(32)
						marketNo:$scope.marketNo,// 市场编号
						commodityType:$scope.commodityType,// 品种类型
						commodityNo:$scope.commodityNo,// 品种编号
						contractNo:$scope.contractNo,// 合约编号
						orderDirect:$scope.orderDirect,// 买卖
						orderOffset:$scope.orderOffset,// 开平
						t1Flag:$scope.t1Flag,// T+1标志
						feeHandwork:$scope.feeHandwork,// 是否手工手续费
						deleteFlag:$scope.deleteFlag,// 删除标记
						orderId:parseInt($scope.orderId),// 委托ID
						matchId:parseInt($scope.matchId),// 成交ID
						// 用户信息
						//userName:$scope.userName, // 用户账户
						// 资产信息
						//productCode:$scope.productCode, // 资产代码
					}
					var json = {
					recoverMatchVIce: recoverMatchVIce
					}
				SinglemakeupDealEditCtrlSel.addSinglemake(json)
					.then(function(res){
						if(res.data.code=="000000"){
							$rootScope.tipService.setMessage(res.data.message, 'warning');
							$state.go('tabs.Singlemakeupdetails');
						}else{
							$rootScope.tipService.setMessage(res.data.message, 'warning');
						}
					},function(error){
						$rootScope.tipService.setMessage(error.data.message, 'warning');
					})
				}
}])
.factory('SinglemakeupDealEditCtrlSel', ['$http', 'localStorageService', 'myHttp', '$q', '$rootScope', function($http, localStorageService, myHttp, $q, $rootScope) {
		return {
				//委托新增
				addSinglemake: function(json) {
				var deferred = $q.defer();
				$http({
						method: 'POST',
						url: $rootScope.baseUrl + 'admin/trade/recover/save/match',
						data: json
					})
					.then(function(res) { // 调用承诺API获取数据 .resolve
						deferred.resolve(res);
					}, function(res) { // 处理错误 .reject
						deferred.reject(res);
					});
				return deferred.promise;
			}
		}
	}])
