app.controller('CommissionallocationAddCtrl', ['$rootScope', '$scope', 'CommissionallocationAddCtrlSer', 'getPageNum', 'dataSer', '$state', 'memberMangerCtrlSer', function($rootScope, $scope, CommissionallocationAddCtrlSer, getPageNum, dataSer, $state, memberMangerCtrlSer) {
		$scope.goBack = function() {
			$state.go('tabs.commissionSplit');
		}
		dataSer.organizeQuerySer()
			.then(function(res) {
				$scope.orgList = res;
				//console.log($scope.orgList);
			});

		$scope.addOrgValFTC = function(data) {
			//console.log(data);
			$scope.allotOrgId = data.orgId;
			$scope.superorgCode = data.orgCode;
			$scope.addOrgVal = data.text;
			CommissionallocationAddCtrlSer.AllNOTLIKEQuerySer($scope.superorgCode)
				.then(function(res) {
					$scope.allnotlickList = res;
					console.log($scope.allnotlickList);
				})
			$scope.singleRuleVs = [];

		}
		$scope.addOrgValcler = function() {
			$scope.addOrgVal = "";
			$scope.allnotOrgVal = "";
			$scope.allnotlickList = "";
			$scope.singleRuleVs = [];
		}
		$scope.AllNOTLIKE = function(data) {
			//console.log(data);
			$scope.allottoOrgIdNum = data.orgId;
			$scope.allnotorgCodeNum = data.orgCode;
			$scope.allnotOrgVal = data.text;
			//产品ID
			CommissionallocationAddCtrlSer.productListdata($scope.allottoOrgIdNum)
				.then(function(res) {
					console.log(res)
					if (res.code == "000000") {
						var prolistdt = JSON.parse(res.content);
						$scope.prolist = [];
						for (var i = 0, r = prolistdt.length; i < r; i++) {
							$scope.prolist.push(prolistdt[i]);
						}
						console.log(prolistdt)
					} else {
						$rootScope.tipService.setMessage(res.message, 'warning')
					}
				}),
				function(error) {
					$rootScope.tipService.setMessage(error.message, 'warning')
				}
		}
		memberMangerCtrlSer.search(9999, 1, '', '', '')
			.then(function(res) {
				$scope.meborgList = JSON.parse(res.content).content;
				console.log($scope.meborgList)
			})
		$scope.getOrgVal = function(orgCode) {
			if ($scope.meborgList) {
				for (var i = 0; i < $scope.meborgList.length; i++) {
					if (orgCode == $scope.meborgList[i].orgCode) {
						return $scope.meborgList[i].orgNum;
					}
				}
			}
		}

		$scope.allotText = function(allotOrgId) {
			//console.log(allotOrgId)
			for (var i = 0, r = $scope.allnotlickList.length; i < r; i++) {
				//console.log($scope.allnotlickList[i])
				if (allotOrgId == $scope.allnotlickList[i].orgId) {
					return $scope.allnotlickList[i].orgName;
				}
			}
		}

		$scope.PtText = function(productId) {
			if ($scope.prolist) {
				for (var i = 0, r = $scope.prolist.length; i < r; i++) {
					if ($scope.prolist[i].productId == productId) {
						return $scope.prolist[i].productName;
					}
				}
			}
		}
		$scope.allotTypeData = [{
			name: '仓息',
			val: '6'
		}, {
			name: '手续费',
			val: '7'
		}];
		$scope.allotTypeText = function(val) {
			for (var i = 0, r = $scope.allotTypeData.length; i < r; i++) {
				if (val == $scope.allotTypeData[i].val) {
					return $scope.allotTypeData[i].name;
				}
			}
		}
		$scope.allotValData = [{
			name: '百分比',
			val: '1'
		}, {
			name: '固定金额',
			val: '2'
		}];

		//$scope.allotVooType=true;
		$scope.changeVooType=function(){
			if($scope.allotVooType==1){
				$scope.valtype=false;
				$scope.nextNum = "";
				$scope.taxesNum = "";
				$scope.channelNum = "";
				$scope.selfNum ="";
			}else if($scope.allotVooType==2){
				$scope.valtype=true;
				$scope.nextNum = "";
				$scope.taxesNum = "";
				$scope.channelNum = "";
				$scope.selfNum ="";
			}else{
				$scope.valtype=false;
			}
		}


		$scope.singleRuleVs = [];
		//动态添加减少数据
		$scope.addrule = function() {
			console.log($scope.allotVooType)
			if ($scope.addOrgVal == undefined || $scope.addOrgVal == '') {
				$rootScope.tipService.setMessage('请选择所属机构编号', 'warning');
			} else if ($scope.productId == undefined || $scope.productId == '') {
				$rootScope.tipService.setMessage('请先填写分配产品', 'warning');
			} else if ($scope.allnotOrgVal == undefined || $scope.allnotOrgVal == '') {
				$rootScope.tipService.setMessage('请选择分配机构', 'warning');
			} else if ($scope.allotType == undefined || $scope.allotType == '') {
				$rootScope.tipService.setMessage('请选择分配佣金类型', 'warning');
			} else if ($scope.allotVooType == undefined || $scope.allotVooType == '') {
				$rootScope.tipService.setMessage('请选择分配类型', 'warning');
			} else if ($scope.nextNum == undefined || $scope.nextNum === '') {
				$rootScope.tipService.setMessage('请填写下级百分比', 'warning');
			} else if ($scope.taxesNum == undefined || $scope.taxesNum === '') {
				$rootScope.tipService.setMessage('请填写税费百分比', 'warning');
			} else if ($scope.channelNum == undefined || $scope.channelNum === '') {
				$rootScope.tipService.setMessage('请填写通道百分比', 'warning');
			} else if($scope.allotVooType==1){
				$scope.allotType = parseFloat($scope.allotType);
				$scope.allotVooType= parseInt($scope.allotVooType);
				$scope.nextNum = parseFloat($scope.nextNum);
				$scope.taxesNum = parseFloat($scope.taxesNum);
				$scope.channelNum = parseFloat($scope.channelNum);
				$scope.selfNum = 100 - $scope.nextNum - $scope.taxesNum - $scope.channelNum;
				var allNum = $scope.nextNum + $scope.taxesNum + $scope.channelNum;
				console.log(allNum, typeof(allNum))
				if (allNum > 100) {
					console.log('y')
					$rootScope.tipService.setMessage('四项百分比之和不能超过100', 'warning');
				} else {
					console.log('x')
					var SingleRuleData = {
						"productId": $scope.productId,
						"allotType": $scope.allotType,
						"allotToOrgCode": $scope.allnotorgCodeNum,
						"allotToOrgId": $scope.allottoOrgIdNum,
						"allotValueType": $scope.allotVooType,
						"selfNum": $scope.selfNum,
						"nextNum": $scope.nextNum,
						"taxesNum": $scope.taxesNum,
						"channelNum": $scope.channelNum
					}
					$scope.singleRuleVs.push(SingleRuleData);
					console.log(SingleRuleData)
				}
			} else if($scope.allotVooType==2){
				if ($scope.selfNum == undefined || $scope.selfNum === '') {
				$rootScope.tipService.setMessage('请填写本级百分比', 'warning');
				}else{
				$scope.allotType = parseFloat($scope.allotType);
				$scope.allotVooType= parseInt($scope.allotVooType);
				$scope.nextNum = parseFloat($scope.nextNum);
				$scope.taxesNum = parseFloat($scope.taxesNum);
				$scope.channelNum = parseFloat($scope.channelNum);
				$scope.selfNum = parseFloat($scope.selfNum);
					console.log('x')
					var SingleRuleData = {
						"productId": $scope.productId,
						"allotType": $scope.allotType,
						"allotToOrgCode": $scope.allnotorgCodeNum,
						"allotToOrgId": $scope.allottoOrgIdNum,
						"allotValueType": $scope.allotVooType,
						"selfNum": $scope.selfNum,
						"nextNum": $scope.nextNum,
						"taxesNum": $scope.taxesNum,
						"channelNum": $scope.channelNum
					}
					$scope.singleRuleVs.push(SingleRuleData);
					console.log(SingleRuleData)
				}
				}
			}

		$scope.delete = function(index) {
			$scope.singleRuleVs.splice(index, 1);
		}

		//保存数据
		$scope.addsaveInfo = function() {
			if (toValidate('#allocationAdd')) {
				//var fizeNum = $scope.selfNum + $scope.nextNum + $scope.taxesNum + $scope.channelNum;
				//if ( fizeNum >=0 ||fizeNum <= 100){
				CommissionallocationAddCtrlSer.save($scope.superorgCode, $scope.allotOrgId, $scope.singleRuleVs)
					.then(function(res) {
						//console.log(res)
						if (res.data.code == '000000') {
							$rootScope.tipService.setMessage(res.data.message, 'warning');
							$state.go('tabs.commissionSplit');
						} else {
							$rootScope.tipService.setMessage(res.data.message, 'warning');
						}
					});
				/*			} else {
						$rootScope.tipService.setMessage('百分比之和不能超过100', 'warning');
					}*/
			}
		}

		function changeV(val) {
			val = val.replace(/[^\d.]/g, ""); //清除“数字”和“.”以外的字符
			val = val.replace(/^\./g, ""); //验证第一个字符是数字而不是.
			val = val.replace(/\.{2,}/g, "."); //只保留第一个. 清除多余的
			val = val.replace(".", "$#$").replace(/\./g, "").replace("$#$", ".");
			val = val.replace(/^(\-)*(\d+)\.(\d\d).*$/, '$1$2.$3'); //只能输入两个小数
			console.log(val)
			return val;
		};
		$scope.clearNoNum = function(obj) {
			$scope.nextNum = changeV($scope.nextNum);
			$scope.taxesNum = changeV($scope.taxesNum);
			$scope.channelNum = changeV($scope.channelNum);
			$scope.selfNum = changeV($scope.selfNum);
		};
	}])
	.factory('CommissionallocationAddCtrlSer', ['$http', 'localStorageService', 'myHttp', '$q', '$rootScope', function($http, localStorageService, myHttp, $q, $rootScope) {
		return {
			AllNOTLIKEQuerySer: function(superorgCode) { //所属下级机构
				var data = {
					orders: 'asc',
					search_LLIKE_orgCode: superorgCode + '-',
					search_NOTLLIKE_orgCode: superorgCode + '-%-'
				};
				var deferred = $q.defer();
				myHttp.post("organize/query/as/list", data)
					.then(function(res) { // 调用承诺API获取数据 .resolve
						//console.log(res)
						var resArr = [];
						if (res.code == "000000") {
							var results = JSON.parse(res.content);
							//console.log(results)
							var tmpArr = [];
							for (var i = 0, r = results.length; i < r; i++) {
								if (results[i].state == 1) {
									var tmp = {};
									tmp.orgCode = results[i].orgCode;
									tmp.orgId = results[i].orgId;
									tmp.orgName = results[i].orgName;
									tmp.text = results[i].orgName + ' (' + results[i].orgNum + ')';
									tmpArr.push(tmp);
								}
							}
							deferred.resolve(tmpArr);
						} else {
							deferred.reject(res);
						}
					}, function(res) { // 处理错误 .reject
						deferred.reject(res);
					});
				return deferred.promise;
			},
			save: function(superorgCode, allotOrgId, singleRuleVs) {
				var json = {
					"allotRule": {
						"allotOrgCode": superorgCode,
						"allotOrgId": allotOrgId,
						"singleRuleVs": singleRuleVs
					}
				}
				var deferred = $q.defer();
				$http({
					method: 'POST',
					url: $rootScope.baseUrl + 'config/allotrule/save',
					data: json
				}).then(function successCallback(response) {
					deferred.resolve(response);
				}, function errorCallback(response) {
					deferred.reject(response);
				});
				return deferred.promise;
			},

			productListdata: function(allottoOrgIdNum) {
				var deferred = $q.defer();
				var json = {
					orgId: allottoOrgIdNum
				}
				$http({
					method: "POST",
					url: $rootScope.baseUrl + "config/product/query/as/list/with/enable",
					data: json
				}).success(function(res) {
					deferred.resolve(res);
				}).error(function(res) {
					deferred.reject(res);
				});
				return deferred.promise;
			},
			productListadmin: function(json) {
				var deferred = $q.defer();
				$http({
					method: "POST",
					url: $rootScope.baseUrl + "config/product/query/as/list/with/enable",
					data: json
				}).success(function(res) {
					deferred.resolve(res);
				}).error(function(res) {
					deferred.reject(res);
				});
				return deferred.promise;
			}
		}
	}])