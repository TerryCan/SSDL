app.controller('QuotaManagementCtrl', ['$scope', '$rootScope', 'QuotaManagementData', 'dataSer', 'getCurrencyType', 'localStorageService', "tipService", "confirmService", function($scope, $rootScope, QuotaManagementData, dataSer, getCurrencyType, localStorageService, tipService, confirmService) {
			$scope.tableshow = false;
			$scope.orgCode = '';
			$scope.enable = false;
			$scope.CurrencySymbol = '';
			$scope.CalcMethod = '';
			$scope.Balance = '';

			$scope.titleName = '';
			$scope.submitBtnName = '';
			$scope.CurrencyType = getCurrencyType;
			dataSer.organizeQuerySer()
				.then(function(res) {
					$scope.orgList = res;
				});
			var baseUserInfo = localStorageService.get("userInfo");
			$scope.loginName = baseUserInfo.loginName;

			//币种文字转换
			$scope.changeCurrencyText = function(val) {
				for (var i = 0, r = getCurrencyType.length; i < r; i++) {
					if (getCurrencyType[i].id == val) {
						return getCurrencyType[i].name;
					}
				}
			}
			$scope.addQuota = function(type, OrgCode) {
				$scope.tableshow = true;
				$scope.nowAEtype = type;
				if ($scope.nowAEtype == 'add') {
					$scope.titleName = '新增额度管理';
					$scope.submitBtnName = '新 增';
				} else {
					$scope.titleName = '编辑额度管理';
					$scope.submitBtnName = '保 存';
					QuotaManagementData.getSingleData(OrgCode)
						.then(function(res) {
							console.log(res);
							$scope.orgCode = res.data.list[0].OrgCode;
							$scope.orgId = res.data.list[0].OrgId;
							$scope.orgName = res.data.list[0].OrgName;
							$scope.enable = res.data.list[0].Enable;
							$scope.CurrencySymbol = res.data.list[0].CurrencySymbol;
							$scope.CalcMethod = res.data.list[0].CalcMethod;
							$scope.Balance = res.data.list[0].Balance;
							$scope.loginName = res.data.list[0].Operator;
						});
				}
			}

			var add = function() {
				var obj = {
					orgId: $scope.orgId,
					orgCode: $scope.orgCode,
					orgName: $scope.orgName,
					enable: $scope.enable,
					CurrencySymbol: $scope.CurrencySymbol,
					CalcMethod: $scope.CalcMethod,
					Balance: $scope.Balance,
					loginName: $scope.loginName
				}
				QuotaManagementData.add(obj)
					.then(function(res) {
						if (res.data.code == '000000') {
							$rootScope.tipService.setMessage(res.data.message, 'warning');
							$scope.search();
							$scope.tableshow = false;
						} else {
							$rootScope.tipService.setMessage(res.data.message, 'warning');
						}
					});
			}
			var edit = function() {
				var obj = {
					orgId: $scope.orgId,
					orgCode: $scope.orgCode,
					orgName: $scope.orgName,
					enable: $scope.enable,
					CurrencySymbol: $scope.CurrencySymbol,
					CalcMethod: $scope.CalcMethod,
					Balance: $scope.Balance,
					loginName: $scope.loginName
				}
				QuotaManagementData.edit(obj)
					.then(function(res) {
						if (res.data.code == '000000') {
							$rootScope.tipService.setMessage(res.data.message, 'warning');
							$scope.search();
							$scope.tableshow = false;
						} else {
							$rootScope.tipService.setMessage(res.data.message, 'warning');
						}
					});
			}
			$scope.submit = function() {
				if ($scope.nowAEtype == 'add') {
					add();
				} else {
					edit();
				}
			}
			$scope.search = function() {
				QuotaManagementData.search($scope.OrgCode)
					.then(function(res) {
						console.log(res);
						if (res.data.retMsg.code == '000000') {
							$scope.searchResult = res.data.list;
						} else {
							$rootScope.tipService.setMessage('找不到对应的机构编码', 'warning');
						}
					});
			}
			$scope.search();
			$scope.addOrgValFTC = function(d) {
				$scope.orgCode = d.orgCode;
				$scope.orgId = d.orgId;
				$scope.orgName = d.orgName;
			}
			$scope.delete = function(orgCode) {
				confirmService.set('确认提示', '确定要删除此条记录?', function() {
					QuotaManagementData.delete(orgCode)
						.then(function(res) {
							$rootScope.tipService.setMessage(res.data.message, 'warning');
							$scope.search();
						}, function(error) {
							$rootScope.tipService.setMessage(error.data.message, 'warning');
						});
					confirmService.clear();
				});
			}
	}])
	.factory('QuotaManagementData', ['$http', 'localStorageService', 'myHttp', '$q', '$rootScope', function($http, localStorageService, myHttp, $q, $rootScope) {
		return {
			search: function(OrgCode) {
				var deferred = $q.defer();
				if (OrgCode == '' || OrgCode == undefined) {
					$http({
						method: 'POST',
						url: $rootScope.baseUrl + 'c/credit/query/all'
					}).then(function successCallback(response) {
						deferred.resolve(response);
					}, function errorCallback(response) {
						deferred.reject(response);
					});
				} else {
					$http({
						method: 'POST',
						url: $rootScope.baseUrl + 'c/credit/query/key',
						data: {
							key: OrgCode
						}
					}).then(function successCallback(response) {
						deferred.resolve(response);
					}, function errorCallback(response) {
						deferred.reject(response);
					});
				}
				return deferred.promise;
			},
			getSingleData: function(OrgCode) {
				var deferred = $q.defer();
				$http({
					method: 'POST',
					url: $rootScope.baseUrl + 'c/credit/query/key',
					data: {
						key: OrgCode
					}
				}).then(function successCallback(response) {
					deferred.resolve(response);
				}, function errorCallback(response) {
					deferred.reject(response);
				});
				return deferred.promise;
			},
			delete: function(OrgCode) {
				var deferred = $q.defer();
				$http({
					method: 'POST',
					url: $rootScope.baseUrl + 'c/credit/delete',
					data: {
						key: OrgCode
					}
				}).then(function successCallback(response) {
					deferred.resolve(response);
				}, function errorCallback(response) {
					deferred.reject(response);
				});
				return deferred.promise;
			},
			add: function(data) {
				var deferred = $q.defer();
				$http({
					method: 'POST',
					url: $rootScope.baseUrl + 'c/credit/insert',
					data: {
						creditInfo: {
							OrgCode: data.orgCode,
							OrgId: data.orgId,
							OrgName: data.orgName,
							CurrencySymbol: data.CurrencySymbol,
							Enable: data.enable,
							CalcMethod: data.CalcMethod,
							Balance: data.Balance,
							Operator: data.loginName
						}
					}
				}).then(function successCallback(response) {
					deferred.resolve(response);
				}, function errorCallback(response) {
					deferred.reject(response);
				});
				return deferred.promise;
			},
			edit: function(data) {
				var deferred = $q.defer();
				$http({
					method: 'POST',
					url: $rootScope.baseUrl + 'c/credit/modify',
					data: {
						creditInfo: {
							OrgCode: data.orgCode,
							OrgId: data.orgId,
							OrgName: data.orgName,
							CurrencySymbol: data.CurrencySymbol,
							Enable: data.enable,
							CalcMethod: data.CalcMethod,
							Balance: data.Balance,
							Operator: data.loginName
						}
					}
				}).then(function successCallback(response) {
					deferred.resolve(response);
				}, function errorCallback(response) {
					deferred.reject(response);
				});
				return deferred.promise;
			}
		}
	}])