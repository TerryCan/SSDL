app.controller("userManageCtrl", ["$scope", "userJurisdictionCtrlSer", "getUserType", "getUserStates", "getPageNum", "tipService", "confirmService", "dataSer", "$timeout", "$rootScope", "$sce", "getGroupType", "localStorageService", "timestamp", function ($scope, userJurisdictionCtrlSer, getUserType, getUserStates, getPageNum, tipService, confirmService, dataSer, $timeout, $rootScope, $sce, getGroupType, localStorageService, timestamp) {
    $scope.toggleTraderSearchState = false;
    $scope.Toggle = function () {
        $scope.toggleTraderSearchState = !$scope.toggleTraderSearchState;
        if ($scope.toggleTraderSearchState) {
            $('.search_column').css('height', 'auto');
        } else {
            $('.search_column').css('height', '36px');
        }
    };
    $scope.userManageTab = 1;
    $scope.jurisdiction = false;
    $scope.userType = getUserType;

    //状态
    getUserStates.userState().then(function (res) {
        $scope.customerStateList = res;
    });

    var processContent, processTotal;
    var source = {
        type: 'POST',
        datatype: "json",
        datafields: [  //数据字段定义
            {name: 'userType', type: 'string'},
            {name: 'orgName', type: 'string'},
            {name: 'orgCode', type: 'string'},
            {name: 'orgNum', type: 'string'},
            {name: 'inherited', type: 'string'},

            {name: 'authApplyId', type: 'string'},
            {name: 'roleId', type: 'string'},
            {name: 'roleName', type: 'string'},
            {name: 'state', type: 'string'},
            {name: 'type', type: 'string'},

            {name: 'organize', type: 'string'},
            {name: 'roleAuthoriseds', type: 'object'},
            {name: 'userAuthoriseds', type: 'string'},
            {name: 'defaultTag', type: 'string'}
        ],
        url: $rootScope.baseUrl + 'role/query/as/page',
        root: "content",
        pagesize: 10,
        processData: function (data) {
            data.page = (data.pagenum + 1) ? (data.pagenum + 1) : 1;
            data.rows = (data.pagesize) ? (data.pagesize) : 10;
            // data.order = ($scope.order) ? $scope.order : 'desc';
            // data.sort = ($scope.sort) ? $scope.sort : 'registerTime';
            data.search_A_EQ_type = ($scope.searchUserTypeTab1) ? $scope.searchUserTypeTab1 : '';
            data.search_A_EQ_state = ($scope.searchUserStatesTab1) ? $scope.searchUserStatesTab1 : '';
            data.search_A_LIKE_roleName = ($scope.searchUserNameTab1) ? $scope.searchUserNameTab1 : '';

            data.search_A_EQ_orgId = ($scope.upOrgId) ? $scope.upOrgId : '';
            data['search_A_LIKE_sysUserRealInfo.name'] = ($scope.realName) ? $scope.realName : '';
            data.search_A_GTE_createTime = ($scope.registerTimeStart) ?$scope.registerTimeStart: '';
            data.search_A_LTE_createTime = ($scope.registerTimeEnd) ?$scope.registerTimeEnd: '';

        }, //传递参数处理
        beforeLoadComplete: function (records) { //数据完全加载完执行绘制表格
            var start;
            for (var i in records) {
                start = parseInt(i);
                break;
            }
            for (var k = 0, r = processContent.length; k < r; k++) {
                records[start + k].userType = processContent[k].userType;
                records[start + k].orgName = processContent[k].orgName;
                records[start + k].orgCode = processContent[k].orgCode;
                records[start + k].orgNum = processContent[k].orgNum;
                records[start + k].inherited = processContent[k].inherited;

                records[start + k].authApplyId = processContent[k].authApplyId;
                records[start + k].roleId = processContent[k].roleId;
                records[start + k].roleName = processContent[k].roleName;
                records[start + k].state = processContent[k].state;
                records[start + k].type = processContent[k].type;

                records[start + k].organize = processContent[k].organize;
                records[start + k].roleAuthoriseds = processContent[k].roleAuthoriseds;
                records[start + k].userAuthoriseds = processContent[k].userAuthoriseds;
                records[start + k].defaultTag = processContent[k].defaultTag;
            }
        },
        beforeprocessing: function (data) { //处理总页数
            var processData = JSON.parse(data.content);
            console.log(processData);
            processContent = processData.content;
            source.totalrecords = processData.totalElements == 0 ? 5 : processData.totalElements;
            // source.totalrecords =processData.totalElements;
            processTotal = processData.totalElements;
        },
        loadComplete: function (records) {
            $scope.saveResult = JSON.parse(records.content);
            var data = $scope.saveResult.totalElements;
            if (data == 0) {
                $('#contenttableentrustDetailGrid > div').remove();
            }
        },
        endUpdate: true
    };
    //创建数据适配器
    var dataAdapter = null;
    $scope.searchAjax = function () {
        $scope.featureShow = true;
        $scope.toggleTraderSearchState = false;
        $('.search_column').css('height', '36px');
        if (dataAdapter == null) {
            dataAdapter = new $.jqx.dataAdapter(source);
            //创建表格
            $("#entrustDetailGrid").jqxGrid({
                source: dataAdapter,
                columns: [  //表格数据域
                    {
                        text: '角色名称',
                        datafield: 'roleName',
                        width: '14%',
                        minwidth: 14 + '%',//设置列min宽
                        align: 'center'//设置表头
                    },
                    {
                        text: '状态',
                        datafield: 'state',
                        minwidth: 14 + '%',
                        cellsalign: 'center',
                        align: 'center',
                        width: '14%',
                        cellsrenderer: function (row, columnfield, value, defaulthtml, columnproperties) {
                            if ($scope.customerStateList) {
                                for (var i in $scope.customerStateList) {
                                    if (value == i) {
                                        return $scope.customerStateList[i];
                                    }
                                }
                            }
                        }
                    },
                    {
                        text: '类型',
                        datafield: 'type',
                        width: '14%',
                        minwidth: 14 + '%',
                        align: 'center',
                        cellsrenderer: function (row, columnfield, value, defaulthtml, columnproperties) {
                            if ($scope.userType) {
                                for (var i = 0, r = $scope.userType.length; i < r; i++) {
                                    if (value == $scope.userType[i].id) {
                                        return $scope.userType[i].name;
                                    }
                                }
                            }
                        }
                    },
                    {
                        text: '机构信息',
                        datafield: 'organize',
                        width: '14%',
                        minwidth: 14 + '%',
                        align: 'center',
                        cellsrenderer: function (row, columnfield, value, defaulthtml, columnproperties) {
                            if (value) {
                                return value.orgName+"("+value.orgNum+")"
                            }
                        }
                    },
                    {
                        text: '授权数',
                        datafield: 'roleAuthoriseds',
                        width: '14%',
                        minwidth: 14 + '%',
                        align: 'center'
                    },
                    {
                        text: '授予用户数',
                        datafield: 'userAuthoriseds',
                        width: '14%',
                        align: 'center'
                    },
                    {
                        text: '默认',
                        datafield: 'defaultTag',
                        width: '16%',
                        minwidth: 16 + '%',
                        align: 'center',
                        cellsrenderer: function (row, columnfield, value, defaulthtml, columnproperties) {
                            if (value==true) {
                                return '是'
                            }else{
                                return '否'
                            }
                        }
                    }
                ],
                width:100+'%',
                // shrinkToFit: true,
                height: 81 + '%',
                theme: 'metrodark',
                virtualmode: true,
                rendergridrows: function (params) { //将数据渲染到页面
                    return params.data;
                },
                pageable: true,
                pagesizeoptions: ['10', '30', '100', '200'],
                // sortable: true,
                columnsresize: true,//列间距是否可调整
                clipboard: true
            });
        } else {
            $("#entrustDetailGrid").jqxGrid('updatebounddata', 'cells');
        }
    };

    //分页
    $("#entrustDetailGrid").on("pagechanged", function (event) {
        console.log(event)
    });
    //排序
    $("#entrustDetailGrid").on("sort", function (event) {
        var sortinformation = event.args.sortinformation;
        $scope.sort = sortinformation.sortcolumn;
        $scope.order = ($scope.sort) ? (sortinformation.sortdirection.ascending) ? 'asc' : 'desc' : 'asc';
        data = {
            order: $scope.order,
            sort: $scope.sort
        };
        source.processData(data);
        $("#entrustDetailGrid").jqxGrid('updatebounddata', 'sort');
    });
    //选中
    $scope.chooseUserData = {
        roleId:'',
        roleName: '',
        state:'',
        userType:'',
        orgName: '',
        orgCode:'',
        orgNum:'',
        inherited:'',
        authApplyId:''
    };
    $('#entrustDetailGrid').on('rowselect', function (event) {
        if (event.args.row.authApplyId != null) {
            $scope.Roleaudit = false;
            $scope.Roleauthority = true;
        } else {
            $scope.Roleauthority = false;
            $scope.Roleaudit = true;
        }
        $scope.chooseItemTab1 = event.args.row.roleId;
        $scope.state = event.args.row.state;
        $scope.chooseDefaultTag = event.args.row.defaultTag;
        $scope.chooseUserData = {
            roleId: event.args.row.roleId,
            roleName: event.args.row.roleName,
            state: event.args.row.state,
            userType: event.args.row.userType,
            orgName: event.args.row.orgName,
            orgCode: event.args.row.orgCode,
            orgNum: event.args.row.orgNum,
            inherited: event.args.row.inherited,
            authApplyId: event.args.row.authApplyId
        };
        $scope.$apply()
    });

    $scope.orgNum = '';
    $scope.searchUserNameTab1 = '';
    $scope.searchUserTypeTab1 = '';
    $scope.searchUserStatesTab1 = '';
    $scope.searchOrgName = '';
    $scope.chooseItemTab1 = null;
    $scope.registerTimeStart = '';
    $scope.registerTimeEnd = '';
    //机构列表
    $scope.addOrgVal = ''; //显示值
    $scope.addOrgChooseVal = ''; //选择值
    dataSer.organizeQuerySer()
        .then(function (res) {
            $scope.orgList = res;
        });
    $scope.addOrgValFTC = function (val, showval) {
        $scope.addOrgChooseVal = val;
        $scope.addOrgVal = showval;
    };
    $scope.hideOrgList = function () {
        $scope.isShowOrgList = false;
        $(".OrgList").blur();
    };
    // //重提审核
    // $scope.rePassCheck = function () {
    //     if ($scope.chooseItemTab1) {
    //             userJurisdictionCtrlSer.rePassCheck($scope.chooseItemTab1)
    //                 .then(function (res) {
    //                     $rootScope.tipService.setMessage(res.data.message, 'warning');
    //                     $scope.searchAjax();
    //                 }, function (error) {
    //                     $rootScope.tipService.setMessage(error.data.message, 'warning');
    //                 });
    //
    //     } else {
    //         $rootScope.tipService.setMessage('请先选择用户!', 'warning');
    //     }
    // };
    //审核通过
    $scope.passCheck = function () {
        if ($scope.chooseItemTab1) {
            confirmService.set('确认提示', '确定审核通过此用户?', function () {
                userJurisdictionCtrlSer.passCheck($scope.chooseItemTab1)
                    .then(function (res) {
                        $rootScope.tipService.setMessage(res.data.message, 'warning');
                        $scope.searchAjax();
                    }, function (error) {
                        $rootScope.tipService.setMessage(error.data.message, 'warning');
                    });
                confirmService.clear();
            });
        } else {
            $rootScope.tipService.setMessage('请先选择用户!', 'warning');
        }
    };
    //审核驳回
    $scope.failedCheck = function () {
        if ($scope.chooseItemTab1) {
            confirmService.set('确认提示', '确定审核驳回此用户?', function () {
                userJurisdictionCtrlSer.failedCheck($scope.chooseItemTab1)
                    .then(function (res) {
                        $rootScope.tipService.setMessage(res.data.message, 'warning');
                        $scope.searchAjax();
                    }, function (error) {
                        $rootScope.tipService.setMessage(error.data.message, 'warning');
                    });
                confirmService.clear();
            });
        } else {
            $rootScope.tipService.setMessage('请先选择用户!', 'warning');
        }
    };
    //冻结
    $scope.freeze = function () {
        if ($scope.chooseItemTab1) {
            confirmService.set('确认提示', '确定要冻结此用户?', function () {
                userJurisdictionCtrlSer.Freezen($scope.chooseItemTab1)
                    .then(function (res) {
                        $rootScope.tipService.setMessage(res.data.message, 'warning');
                        $scope.searchAjax();
                    }, function (error) {
                        $rootScope.tipService.setMessage(error.data.message, 'warning');
                    });
                confirmService.clear();
            });
        } else {
            $rootScope.tipService.setMessage('请先选择用户!', 'warning');
        }
    };
    //解冻
    $scope.unfreeze = function () {
        if ($scope.chooseItemTab1) {
            confirmService.set('确认提示', '确定要解冻此用户?', function () {
                userJurisdictionCtrlSer.unFreezen($scope.chooseItemTab1)
                    .then(function (res) {
                        $rootScope.tipService.setMessage(res.data.message, 'warning');
                        $scope.searchAjax();
                    }, function (error) {
                        $rootScope.tipService.setMessage(error.data.message, 'warning');
                    });
                confirmService.clear();
            });

        } else {
            $rootScope.tipService.setMessage('请先选择用户!', 'warning');
        }
    };
    //注销
    $scope.cancel = function () {
        if (!$scope.chooseItemTab1) {
            $rootScope.tipService.setMessage('请先选择用户', 'warning');
        } else {
            confirmService.set('确认提示', '确定要注销此用户?', function () {
                userJurisdictionCtrlSer.cancel($scope.chooseItemTab1)
                    .then(function (res) {
                        $rootScope.tipService.setMessage(res.data.message, 'warning');
                        $scope.searchAjax();
                    }, function (error) {
                        $rootScope.tipService.setMessage(error.data.message, 'warning');
                    });
                confirmService.clear();
            });
        }
    };
    //设为默认
    $scope.setDefault = function () {
        if ($scope.chooseItemTab1) {
            if ($scope.chooseDefaultTag == false) {
                userJurisdictionCtrlSer.setUserDefault($scope.chooseItemTab1)
                    .then(function (res) {
                        console.log(res);
                        if (res.data.code == '000000') {
                            $rootScope.tipService.setMessage(res.data.message, 'warning');
                            $scope.searchAjax();
                        } else {
                            $rootScope.tipService.setMessage(res.data.message, 'warning');
                        }
                    }, function (error) {
                        $rootScope.tipService.setMessage(error.data.message, 'warning');
                    });
            } else {
                $rootScope.tipService.setMessage('该用户不能执行此操作!', 'warning');
            }
        } else {
            $rootScope.tipService.setMessage('请先选择用户!', 'warning');
        }

    };
    $scope.Roleaudit = true;
    $scope.Roleauthority = true;

    //新增角色
    $scope.addEditText = '';
    $scope.addFctUserType = null;
    $scope.inherited = false;
    $scope.newUserShow = false;
    $scope.addNewUser = function () {
        $scope.newUserShow = true;
        $scope.addEditText = '新增';
        $scope.addFctUserType = null;
        $scope.addOrgVal = '';
        $scope.canInherit = '';
        $scope.editUserLocked = false;
        $scope.addUserName = '';
        $('.addFctUserType').val('');
    };
    //修改角色
    $scope.editUserLocked = false;
    $scope.editUser = function () {
        console.log($scope.chooseItemTab1)
        if (!$scope.chooseItemTab1) {
            $rootScope.tipService.setMessage('请先选择用户', 'warning');
        } else {
            $scope.addEditText = '修改';
            $scope.editUserLocked = true;
            $scope.newUserShow = true;
            $scope.chooseUserData.roleId = $scope.chooseItemTab1;
            $scope.addOrgVal = $scope.chooseUserData.orgNum;
            $scope.addUserName = $scope.chooseUserData.roleName;
            $scope.inherited = $scope.chooseUserData.inherited;
            $('.addFctUserType').val($scope.chooseUserData.userType);
        }
    };
    $scope.addEditUserSubmit = function () {
        if ($scope.addEditText == '新增') {
            if ($scope.addFctUserType == null) {
                $rootScope.tipService.setMessage('请选择角色类型', 'warning');
            } else if ($scope.addUserName == '') {
                $rootScope.tipService.setMessage('请填写角色名', 'warning');
            } else {
                if (toValidate('#userManageAdd')) {
                    userJurisdictionCtrlSer.add($scope.addOrgChooseVal, $scope.addUserName, $scope.addFctUserType, $scope.inherited)
                        .then(function (res) {
                            console.log(res);
                            $scope.newUserShow = false;
                            $rootScope.tipService.setMessage(res.data.message, 'warning');
                            $scope.searchAjax();
                        }, function (error) {
                            $rootScope.tipService.setMessage(error.data.message, 'warning');
                        });
                }
            }
        } else if ($scope.addEditText == '修改') {
            if ($scope.addUserName == '') {
                $rootScope.tipService.setMessage('请填写角色名', 'warning');
            } else {
                if (toValidate('#userManageAdd')) {
                    userJurisdictionCtrlSer.edit($scope.chooseUserData.roleId, $scope.addUserName, $scope.inherited)
                        .then(function (res) {
                            $scope.newUserShow = false;
                            $rootScope.tipService.setMessage(res.data.message, 'warning');
                            $scope.searchAjax();
                        }, function (error) {
                            $rootScope.tipService.setMessage(error.data.message, 'warning');
                        });
                }
            }
        }
    };

    //授权
    $scope.authorization = function () {
        $scope.baseAuthorizationList = [];
        for (var i = 0, r = $scope.userManageMultiple.length; i < r; i++) {
            var tmp = parseInt($scope.userManageMultiple[i]);
            $scope.baseAuthorizationList.push($scope.canJurisdictionData[tmp]);
        }
    };


    $scope.toAuthorization = function () {
        console.log($scope.baseAuthorizationList)
        for (var i = 0, r = $scope.baseAuthorizationList.length; i < r; i++) {
            $scope.baseAuthorizationList[i].freezingValid = false; //冻结默认关闭
            $scope.isJurisdictionData.push($scope.baseAuthorizationList[i]);
        }
        console.log($scope.isJurisdictionData)  //已授权数据
        //$scope.postJurisdiction();
        $scope.baseAuthorizationList = [];
    };
    //权限修改
    $scope.jurisdictionShow = false;
    $scope.editJurisdiction = function () {
        if (!$scope.chooseItemTab1) {
            $rootScope.tipService.setMessage('请先选择用户', 'warning');
        } else {
            $scope.jurisdictionShow = true;
            $scope.getCanJurisdiction($scope.chooseItemTab1);
            $scope.getIsJurisdiction($scope.chooseItemTab1);
            //$scope.adqd();
            }
    };

    //权限审核
    $scope.RoleauditdictionShow = false;
    $scope.RoleJurisdiction = function () {
        if (!$scope.chooseItemTab1) {
            $rootScope.tipService.setMessage('请先选择用户', 'warning');
        } else {
            $scope.RoleauditdictionShow = true;
            $scope.RoleCanJurisdiction($scope.chooseUserData.authApplyId);
            //.RolegetJurisdiction($scope.chooseUserData.authApplyId);
        }
    };

    //读取可授权列表
    $scope.getCanJurisdiction = function (roleId) {
        console.log(roleId)
        userJurisdictionCtrlSer.canJurisdiction(roleId)
            .then(function (res) {
                if (res.data.code == '000000') {
                    $scope.canJurisdictionData = [];
                    var data = JSON.parse(res.data.content);
                    //console.log(data);  //可授权数据
                    for (var i = 0, r = data.length; i < r; i++) {
                        data[i].filterId = i;
                        $scope.canJurisdictionData.push(data[i]);
                       //console.log( $scope.canJurisdictionData)
                        //return $scope.canJurisdictionData;
                        //console.log(typeof($scope.canJurisdictionData))
                    }
                }else{
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                }},function(error) {
                    $rootScope.tipService.setMessage(error.data.message, 'warning');
            });
    }

    //读取已授权列表
    $scope.getIsJurisdiction = function (roleId) {
        userJurisdictionCtrlSer.isJurisdiction(roleId)
            .then(function (res) {
                if (res.data.code === '000000') {
                    $scope.isJurisdictionData = JSON.parse(res.data.content);
                    //console.log(typeof($scope.isJurisdictionData))
                    //return $scope.isJurisdictionData;
                    console.log($scope.isJurisdictionData)  //已授权数据
                    /*for(var j = 0, k =$scope.isJurisdictionData.length; j < k; j++){
                        for(var n = 0, m =$scope.canJurisdictionData.length; n < m; n++){
                            console.log($scope.isJurisdictionData[j].permissionCode)
                            if ($scope.isJurisdictionData[j].permissionCode == $scope.canJurisdictionData[n].permissionCode && $scope.isJurisdictionData[j].appId == $scope.canJurisdictionData[n].appId) {
                                console.log($scope.isJurisdictionData[j].permissionCode == $scope.canJurisdictionData[n].permissionCode)
                                //console.log($scope.RoleJurisdictionData[j])
                                console.log($scope.canJurisdictionData)
                                $scope.canJurisdictionData.push($scope.canJurisdictionData.splice(n, 1))
                            }
                        }
                    }*/
                }else{
                        $rootScope.tipService.setMessage(res.data.message, 'warning');
                    }},function(error) {
                    $rootScope.tipService.setMessage(error.data.message, 'warning');
                });
    };

   /* $scope.adqd=function(){
    if($scope.isJurisdictionData&&$scope.canJurisdictionData){
        console.log($scope.isJurisdictionData,$scope.canJurisdictionData);
        for(var j = 0, k =$scope.isJurisdictionData.length; j < k; j++) {
            for (var n = 0, m = $scope.canJurisdictionData.length; n < m; n++) {
                console.log($scope.canJurisdictionData[n])
                if ($scope.isJurisdictionData[j].permissionCode == $scope.canJurisdictionData[n].permissionCode && $scope.isJurisdictionData[j].appId == $scope.canJurisdictionData[n].appId) {
                    console.log($scope.isJurisdictionData[j].permissionCode == $scope.canJurisdictionData[n].permissionCode)
                    //console.log($scope.RoleJurisdictionData[j])
                    console.log($scope.canJurisdictionData)
                    $scope.canJurisdictionData.push($scope.canJurisdictionData.splice(n, 1))
                }}
            }
        }
    }*/



    //读取可前审核列表
    /*$scope.RolegetJurisdiction = function (authApplyId) {
        console.log(authApplyId)
        userJurisdictionCtrlSer.RoleJurisdiction(authApplyId)
            .then(function (res) {
                console.log(res)
                if (res.data.code == '000000') {
                    $scope.originalsData = [];
                    var data = JSON.parse(res.data.content);
                    console.log(data);  //可授权数据
                    for (var i = 0, r = data.originals.length; i < r; i++) {
                        $scope.originalsData.push(data.originals[i]);
                        //console.log($scope.originalsData)
                    }
                } else {
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                }
            });
    };*/
    //读取可审核列表
    $scope.RoleCanJurisdiction = function (authApplyId) {
        //$scope.RolegetJurisdiction();
        userJurisdictionCtrlSer.RoleJurisdiction(authApplyId)
            .then(function (res) {
                console.log(res)
                if (res.data.code == '000000') {
                    $scope.RoleJurisdictionData = [];
                    $scope.originalsData = [];
                    $scope.Rdata = JSON.parse(res.data.content);
                    var data = $scope.Rdata;
                    console.log(data);  //可授权数据
                    for (var i = 0, r = data.changes.length; i < r; i++) {
                        $scope.RoleJurisdictionData.push(data.changes[i]);
                        //console.log($scope.RoleJurisdictionData);
                    }

                    var data2 = JSON.parse(res.data.content);
                    //console.log(data2);  //可授权数据
                    for (var i = 0, r = data2.originals.length; i < r; i++) {
                        $scope.originalsData.push(data2.originals[i]);
                        //console.log($scope.originalsData)
                    }

                } else {
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                }
            });
    };
    //删除所有已授权
    $scope.deleteAauthorization = function () {
        console.log($scope.isJurisdictionData)
        for (var i = 0, r = $scope.isJurisdictionData.length; i < r; i++) {
            $scope.isJurisdictionData[i].delete = true;
        }
        $scope.isJurisdictionData =[];
        //$scope.postJurisdiction();
    };
    //提交授权
    $scope.postJurisdiction = function (tmpOpt) {
        console.log(tmpOpt)
        userJurisdictionCtrlSer.postJurisdiction($scope.chooseUserData.roleId, $scope.isJurisdictionData)
            .then(function (res) {
                console.log(res)
                if (res.data.code === '000000') {
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                    localStorageService.clear('userIdChecked');
                    $scope.searchAjax();
                    $scope.getIsJurisdiction($scope.chooseUserData.roleId);
                } else {
                    $scope.getIsJurisdiction($scope.chooseUserData.roleId);
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                }
            }, function (error) {
                $rootScope.tipService.setMessage(error.data.message, 'warning');
            });
        if (tmpOpt) {
            $scope.jurisdictionShow = false;
            $scope.searchAjax();
        }
    };
    //删除单条授权记录
    /*$scope.delJurisdictionData = function (roleAuthorisedId) {
        console.log(roleAuthorisedId)
        userJurisdictionCtrlSer.delJurisdictionData(roleAuthorisedId)
            .then(function (res) {
                if (res.data.code != '000000') {
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                }
                $scope.getIsJurisdiction($scope.chooseUserData.roleId);
            }, function (error) {
                $rootScope.tipService.setMessage(error.data.message, 'warning');
                $scope.getIsJurisdiction($scope.chooseUserData.roleId);
            });
    };*/

    $scope.delData = function (index) {
        console.log(index)
        $scope.isJurisdictionData.splice(index,1)
        //$scope.getIsJurisdiction();
    };

    $scope.getState = function (params) {
        for (var i in $scope.customerStateList) {
            if (params == i) {
                return $scope.customerStateList[i];
            }
        }
    };

/*    //单选
    $scope.checked = function (index, orgId) {
        $scope.chooseOrgData.orgId = orgId;
        localStorageService.update('memberEditOrgId', $scope.chooseOrgData.orgId);

        $('#dataReport input[type=checkbox]').prop('checked', false);
        $('#dataReport input[type=checkbox]').eq(index).prop('checked', true);
    };*/

    $scope.RoletrueData = function (tmpOpt) {
        var json = {
            applyId: $scope.Rdata.applyId,
            auditRs: tmpOpt
        };
        userJurisdictionCtrlSer.Roletruetion(json)
            .then(function (res) {
                if (res.data.code === '000000') {
                    $scope.RoleauditdictionShow = false;
                    localStorageService.clear('userIdChecked');
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                    $scope.searchAjax();
                } else {
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                    }
                },function(error) {
                    $rootScope.tipService.setMessage(error.data.message, 'warning');
                })
    }
    $scope.RolefalseData = function (tmpOpt) {
        var json = {
            applyId: $scope.Rdata.applyId,
            auditRs: tmpOpt
        };
        userJurisdictionCtrlSer.Roletruetion(json)
            .then(function (res) {
                if (res.data.code === '000000') {
                    $scope.RoleauditdictionShow = false;
                    localStorageService.clear('userIdChecked');
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                    $scope.searchAjax();
                } else {
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                }
            },function(error) {
                $rootScope.tipService.setMessage(error.data.message, 'warning');
            })
    };
}])
//角色管理
    .factory('userJurisdictionCtrlSer', ['$http', 'localStorageService', 'myHttp', '$q', '$rootScope', function ($http, localStorageService, myHttp, $q, $rootScope) {
        return {
            search: function (json) {
                var deferred = $q.defer();
                myHttp.post("role/query/as/page", json)
                    .then(function (res) { // 调用承诺API获取数据 .resolve
                        deferred.resolve(res);
                    }, function (res) { // 处理错误 .reject
                        deferred.reject(res);
                    });
                return deferred.promise;
            },
            checkedSearch: function (showNum, nowPage, searchUserNameTab1, searchUserTypeTab1, searchUserStatesTab1) {
                var json = {
                    page: nowPage,
                    rows: showNum,
                    orders: 'asc',
                    search_A_EQ_type: searchUserTypeTab1,
                    search_A_EQ_state: searchUserStatesTab1,
                    search_A_LIKE_roleName: searchUserNameTab1
                };
                var deferred = $q.defer();
                myHttp.post("role/query/as/page", json)
                    .then(function (res) { // 调用承诺API获取数据 .resolve
                        deferred.resolve(res);
                    }, function (res) { // 处理错误 .reject
                        deferred.reject(res);
                    });
                return deferred.promise;
            },
            Freezen: function (roleId) {
                var json = {
                    roleId: roleId
                };
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'role/freeze',
                    data: json
                }).then(function successCallback(response) {
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
            passCheck: function (roleId) {
                var json = {
                    roleId: roleId
                };
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'role/pass',
                    data: json
                }).then(function successCallback(response) {
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
            failedCheck: function (roleId) {
                var json = {
                    roleId: roleId
                };
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'role/fail',
                    data: json
                }).then(function successCallback(response) {
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
            rePassCheck: function (roleId) {
                var json = {
                    roleId: roleId
                };
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'role/open',
                    data: json
                }).then(function successCallback(response) {
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
            unFreezen: function (roleId) {
                var json = {
                    roleId: roleId
                };
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'role/unfreeze',
                    data: json
                }).then(function successCallback(response) {
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
            cancel: function (roleId) {
                var json = {
                    roleId: roleId
                };
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'role/close',
                    data: json
                }).then(function successCallback(response) {
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
            add: function (orgId, roleName, type, inherited) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'role/create',
                    data: {
                        "createRoleV": {
                            "orgId": orgId,
                            "roleName": roleName,
                            "type": type,
                            "inherited": inherited
                        }
                    }
                }).then(function successCallback(response) {
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
            edit: function (roleId, roleName, inherited) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'role/update',
                    data: {
                        "updateRoleV": {
                            "roleId": roleId,
                            "roleName": roleName,
                            "inherited": inherited
                        }
                    }
                }).then(function successCallback(response) {
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
            canJurisdiction: function (roleId) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'role/query/may/authorised/as/list',
                    data: {
                        "roleId": roleId
                    }
                }).then(function successCallback(response) {
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
            isJurisdiction: function (roleId) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'role/query/has/authorised/as/list',
                    data: {
                        "roleId": roleId
                    }
                }).then(function successCallback(response) {
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
            postJurisdiction: function (roleId, data) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'role/auth/apply',
                    data: {
                        "roleId": roleId,
                        "roleAuthorisedVs": data
                    }
                }).then(function successCallback(response) {
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
            RoleJurisdiction: function (applyId) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'role/get/auth/apply',
                    data: {
                        "applyId": applyId
                    }
                }).then(function successCallback(response) {
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
            Roletruetion: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'role/auth/audit',
                    data: json
                }).then(function successCallback(response) {
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
            setUserDefault: function (roleId) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'role/change/default',
                    data: {
                        "roleId": roleId
                    }
                }).then(function successCallback(response) {
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
        }
    }])