app.controller('currentCapitalCtrl', ['$rootScope', '$scope', 'currentCapitalAll','$timeout', '$sce','tipService', 'confirmService', 'getCurrencyType', 'getAccountState','localStorageService','getProcessType', function ($rootScope, $scope, currentCapitalAll,$timeout, $sce,tipService, confirmService, getCurrencyType, getAccountState,localStorageService,getProcessType) {
    $scope.toggleTraderSearchState=false;
    $scope.Toggle = function(){
        $scope.toggleTraderSearchState = !$scope.toggleTraderSearchState;
        if($scope.toggleTraderSearchState){
           $('.search_column').css('height','auto');
        }
        else{
           $('.search_column').css('height','36px');
        }
    };
    //获取币种
    getCurrencyType.then(function (res) {
        $scope.currencyList = JSON.parse(res.content);
    });
    $scope.processType=getProcessType;
    var processContent,processTotal;
    var source = {
        type: 'POST',
        datatype: "json",
        datafields: [  //数据字段定义
            {name: 'userId', type: 'string'},
            {name: 'loginName', type: 'string'},
            {name: 'netWorth', type: 'string'},
            {name: 'deposit', type: 'string'},
            {name: 'floatProfit', type: 'string'},

            {name: 'balance', type: 'string'},
            {name: 'khfFloatProfit', type: 'string'},
            {name: 'freeze', type: 'string'},
            {name: 'extract', type: 'string'},
            {name: 'state', type: 'string'}
        ],
        url: $rootScope.baseUrl + 'account/aiaccount/query/page',
        root: "content",
        pagesize:10,
        processData: function (data) {
            data.page = (data.pagenum + 1)?(data.pagenum + 1):1;
            data.rows =(data.pagesize)?(data.pagesize):10;
            // data.order =($scope.order)?$scope.order:'desc';
            // data.sort =($scope.sort)?$scope.sort:'createTime';
            data.search_A_EQ_userId = ($scope.directiveUserId) ? $scope.directiveUserId : '';
        }, //传递参数处理
        beforeLoadComplete: function (records) { //数据完全加载完执行绘制表格
            var start;
            for (var i in records) {
                start = parseInt(i);
                break;
            }
            for (var k = 0, r = processContent.length; k < r; k++) {
                records[start + k].userId = processContent[k].userId;
                records[start + k].loginName = processContent[k].loginName;
                records[start + k].netWorth = processContent[k].netWorth;
                records[start + k].deposit = processContent[k].deposit;
                records[start + k].floatProfit = processContent[k].floatProfit;

                records[start + k].balance = processContent[k].balance;
                records[start + k].khfFloatProfit = processContent[k].khfFloatProfit;
                records[start + k].freeze = processContent[k].freeze;
                records[start + k].extract = processContent[k].extract;
                records[start + k].state = processContent[k].state;
            }
        },
        beforeprocessing: function (data) { //处理总页数
            var processData = JSON.parse(data.content);
            console.log(processData)
            processContent = processData.content;
            source.totalrecords = processData.totalElements == 0 ? 5 : processData.totalElements;
            processTotal = processData.totalElements;
        },
        loadComplete: function (records) {
            $scope.saveResult=JSON.parse(records.content);
            var data =  $scope.saveResult.totalElements;
            if (data == 0) {
                $('#contenttableentrustDetailGrid > div').remove();
            }
        },
        endUpdate: true
    };
    //创建数据适配器
    var dataAdapter = null;
    $scope.searchAjax = function () {
        $scope.toggleTraderSearchState = false;
        $('.search_column').css('height', '36px');
        if (dataAdapter == null) {
            dataAdapter = new $.jqx.dataAdapter(source);
            //创建表格
            $("#entrustDetailGrid").jqxGrid({
                source: dataAdapter,
                columns: [  //表格数据域
                    {
                        text: '用户名',
                        datafield: 'loginName',
                        width: '11%',
                        minwidth: 11 + '%',//设置列min宽
                        align: 'center'//设置表头
                    },
                    {
                        text: '净值',
                        datafield: 'netWorth',
                        minwidth: 11 + '%',
                        cellsalign: 'center',
                        align: 'center',
                        width: '11%'
                    },
                    {
                        text: '占用保证金',
                        datafield: 'deposit',
                        width:'11%',
                        minwidth: 11 + '%',
                        align: 'center'
                    },
                    {
                        text: '浮动盈亏',
                        datafield: 'floatProfit',
                        width:'11%',
                        minwidth: 11 + '%',
                        align: 'center'
                    },
                    {
                        text: '结余',
                        datafield: 'balance',
                        width:'12%',
                        minwidth: 12 + '%',
                        align: 'center'
                    },
                    {
                        text: '客户浮盈',
                        datafield: 'khfFloatProfit',
                        width:'11%',
                        minwidth: 11 + '%',
                        align: 'center'
                    },
                    {
                        text: '出金阀值',
                        datafield: 'freeze',
                        width:'11%',
                        minwidth: 11 + '%',
                        align: 'center',
                        cellsrenderer: function (row, columnfield, value, defaulthtml, columnproperties) {
                            if (value<0) {
                                return -value;
                            }else{
                                return value;
                            }
                        }
                    },
                    {
                        text: '可出金额',
                        datafield: 'extract',
                        width:'11%',
                        minwidth: 11 + '%',
                        align: 'center'
                    },
                    {
                        text: '状态',
                        datafield: 'state',
                        width:'11%',
                        minwidth: 11 + '%',
                        align: 'center',
                        cellsrenderer: function (row, columnfield, value, defaulthtml, columnproperties) {
                            if (getAccountState) {
                                for (var i = 0; i <getAccountState.length; i++) {
                                    if (value ==getAccountState[i].id) {
                                        return getAccountState[i].name;
                                    }
                                }
                            }
                        }
                    },
                ],
                width: 100 + '%',
                height: 81 + '%',
                theme:'metrodark',
                virtualmode: true,
                rendergridrows: function (params) { //将数据渲染到页面
                    return params.data;
                },
                pageable: true,
                pagesizeoptions: ['10','30','100','200'],
                columnsresize: true,//列间距是否可调整
                clipboard: true
            });
        }else {
            $("#entrustDetailGrid").jqxGrid('updatebounddata', 'cells');
        }
    };

    //分页
    $("#entrustDetailGrid").on("pagechanged", function (event) {
        console.log(event)
    });
    //排序
    $("#entrustDetailGrid").on("sort", function (event) {
        var sortinformation = event.args.sortinformation;
        $scope.sort=sortinformation.sortcolumn;
        $scope.order=($scope.sort)?(sortinformation.sortdirection.ascending)?'asc':'desc':'asc';
        data={
            order:$scope.order,
            sort:$scope.sort
        };
        source.processData(data);
        $("#entrustDetailGrid").jqxGrid('updatebounddata', 'sort');
    });
    //选中
    $('#entrustDetailGrid').on('rowselect', function (event) {
        $scope.userId = event.args.row.userId;
    });

    //新增
    $scope.add = function () {
        if (!$scope.userId) {
            $rootScope.tipService.setMessage('请先选择用户', 'warning');
        } else {
            $scope.FundColumn = true;
        }
    };
    $scope.submitAdd = function () {
        var accountProcessCreateV = {
            userId: $scope.userId,
            currency: ($scope.currency)?parseInt($scope.currency):'',
            processType:($scope.flowType)?parseInt($scope.flowType):'',
            amount: $scope.amount
        };
        var json = {
            accountProcessCreateV: accountProcessCreateV
        };
        currentCapitalAll.unitAdd(json)
            .then(function (res) {
                if (res.code == '000000') {
                    $scope.FundColumn = false;
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                    $scope.searchAjax();
                } else {
                    $scope.FundColumn = false;
                    $rootScope.tipService.setMessage(res.data.message, 'warning');
                    $scope.searchAjax();
                }
            }, function (error) {
                $rootScope.tipService.setMessage(error.data.message, 'warning');
            });
        confirmService.clear();
    };

    //明细
    $scope.searchDetail=function(){
        if (!$scope.userId) {
            $rootScope.tipService.setMessage('请先选择用户', 'warning');
        } else {
            $scope.accountDetailDisplay = true;
            var signUpV = {
                userId: $scope.userId
            };
            currentCapitalAll.searchAccountDetail(signUpV)
                .then(function (res) {
                    if (res.code == '000000' && res.content) {
                        var tradeSearchList = JSON.parse(res.content);
                        console.log(tradeSearchList);
                        $scope.marketValue = tradeSearchList.inOut + tradeSearchList.floatProfit;
                        $scope.netWorth = tradeSearchList.netWorth;
                        $scope.balance = tradeSearchList.balance; //结余
                        $scope.freeze = tradeSearchList.freeze;
                        $scope.extract = tradeSearchList.extract;
                        $scope.outing = tradeSearchList.outing;
                        $scope.ining = tradeSearchList.ining;
                        $scope.floatProfit = tradeSearchList.floatProfit / tradeSearchList.tradeRate;
                        $scope.deposit = tradeSearchList.deposit / tradeSearchList.tradeRate;
                        $scope.riskRate = tradeSearchList.riskRate;
                    } else {
                        $rootScope.tipService.setMessage(res.message, 'warning');
                    }
                }, function (error) {
                    $rootScope.tipService.setMessage(error.message, 'warning');
                });
        }
    };
}])
//实时资金
    .factory('currentCapitalAll', ['$http', 'localStorageService', 'myHttp', '$q', '$rootScope', function ($http, localStorageService, myHttp, $q, $rootScope) {
        return {
            unitAdd: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'account/create/accountprocess',
                    data: json
                }).then(function successCallback(response) {
                    deferred.resolve(response);
                }, function errorCallback(response) {
                    deferred.reject(response);
                });
                return deferred.promise;
            },
            searchAccountDetail: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'account/query/user/aiaccountm',
                    data: json,
                    headers: {
                        'Content-Type': 'application/json;charset=UTF-8'
                    }
                }).success(function (res) {
                    deferred.resolve(res);
                }).error(function (res) {
                    deferred.reject(res);
                });
                return deferred.promise;
            }
        }
    }]);