app.controller("prevSourcePipelinequeryCtrl", ['$scope', '$timeout', 'prevSourcePipelinequeryCtrlSel', 'getPageNum', 'plateType', 'memberMangerCtrlSer', '$rootScope', 'dataSer', 'accountManagementSer', 'timestamp', 'waterType', function($scope, $timeout, prevSourcePipelinequeryCtrlSel, getPageNum, plateType, memberMangerCtrlSer, $rootScope, dataSer, accountManagementSer, timestamp, waterType) {
			$scope.toggleTraderSearchState = false;
			$scope.Toggle = function() {
				$scope.toggleTraderSearchState = !$scope.toggleTraderSearchState;
				if ($scope.toggleTraderSearchState) {
					$('.search_column').css('height', 'auto');
				} else {
					$('.search_column').css('height', '36px');
				}
			};
			$scope.account = "";
			$scope.Direct = "";
			/*$scope.types="";*/
			$scope.startTime = "";
			$scope.endTime = "";
			accountManagementSer.accountSearch()
				.then(function(response) {
					var accountList = response.list;
					$scope.accountList = accountList;
					console.log($scope.accountList);
				})
			$scope.accountType = function(key) {
					for (var i = 0, r = $scope.accountList.length; i < r; i++) {
						if (key == $scope.accountList[i].key) {
							return $scope.accountList[i].name
						}

					}
				}
				//数据转换
			$scope.ioType = [{
				id: '0',
				name: '入金'
			}, {
				id: '1',
				name: '出金'
			}];
			$scope.getIoType = function(params) {
				for (var i = 0, r = $scope.ioType.length; i < r; i++) {
					if (params == $scope.ioType[i].id) {
						return $scope.ioType[i].name;
					}
				}
			}
			$scope.waterTypelist = waterType;
			console.log($scope.waterTypelist)
			$scope.getIwateroType = function(Type) {
					for (var i = 0, r = $scope.waterTypelist.length; i < r; i++) {
						if (Type == $scope.waterTypelist[i].val) {
							return $scope.waterTypelist[i].name;
						}
					}
				}
				//时间戳
			$scope.timestamp = function(stamp) {
					return timestamp.timestampCoverHms(stamp * 1000, 'all')
				}
				//统计查询
			$scope.search = function() {
				 	$scope.toggleTraderSearchState=false;
					$('.search_column').css('height', '36px');
					var startTime = $scope.startTime;
					var endTime = $scope.endTime;
					var startTimeNum = Date.parse(new Date(startTime)) / 1000;
					console.log(startTimeNum)
					var endTimeNum = Date.parse(new Date(endTime)) / 1000;
					prevSourcePipelinequeryCtrlSel.search($scope.showNum.showNum, $scope.currentPage, $scope.account, $scope.Direct, startTimeNum, endTimeNum)
						.then(function(res) {
							//console.log(res)
							if (res.data.code = "000000") {
								$scope.currentlsit = res.data.list;
								$scope.showPage = true;
								$scope.dataNum = res.data.TotalCount;
								$scope.PageNum();
							} else {
								$rootScope.tipService.setMessage(res.data.message, 'warning');
							}
						}, function(error) {
							$rootScope.tipService.setMessage(error.data.message, 'warning');
						});
				}
				/* 分页功能实现 */
			var pageInitialize = function() {
				$scope.dataNum = 0; //数据总条数
				$scope.dataPage = 0; //分页数
				$scope.currentPage = 1; //当前页数
				$scope.jumpPageNum = '';
			}
			$scope.showDataChoose = getPageNum.pageNum(); //获取分页
			$scope.showNum = $scope.showDataChoose[0]; //初始显示刷具条数
			$scope.dataPageNumber = []; //生成页面数
			$scope.showPage = false;
			$scope.pageSelect = function(params) {
				console.log(params);
				$scope.showNum.showNum = params.showNum;
				pageInitialize();
				$scope.search();
			}
			$scope.changePageNumber = function(params) {
				$scope.currentPage = params;
				$scope.search();
				$scope.PageNum();
			}
			$scope.PageNum = function() {
				if ($scope.showNum.showNum < $scope.dataNum) {
					$scope.dataPage = parseInt($scope.dataNum / $scope.showNum.showNum) + 1;
				} else {
					$scope.dataPage = 0;
				}
				$scope.dataPageNumber = [];
				for (var i = 0; i < $scope.dataPage; i++) {
					$scope.dataPageNumber.push(i + 1);
				}
			}
			$scope.jumpPage = function(num) {
				num = parseInt(num);
				if (parseInt(num, 10) === num && num <= ($scope.dataPage + 1) && num > 0) {
					$scope.currentPage = num;
					$scope.PageNum();
					$scope.search();
				}
			}
			$scope.pageSlect = function(type) {
				if (type == 'prev') {
					if ($scope.currentPage != 1) {
						$scope.currentPage--;
						$scope.PageNum();
						$scope.search();
					}
				} else {
					if ($scope.currentPage < $scope.dataPage) {
						$scope.currentPage++;
						$scope.PageNum();
						$scope.search();
					}
				}
			}
			pageInitialize();
	}])
	.factory('prevSourcePipelinequeryCtrlSel', ['$http', 'localStorageService', 'myHttp', '$q', '$rootScope', function($http, localStorageService, myHttp, $q, $rootScope) {
		return {
			search: function(showNum,nowPage, account, Direct, startTimeNum, endTimeNum) {
				var deferred = $q.defer();
				$http({
						method: 'POST',
						url: $rootScope.baseUrl + 'c/up/capital/history/query',
						data: {
							"condlist": [{
									"field": "Account",
									"value": account,
									"condition": 0
								}, {
									"field": "Direct",
									"value": Direct,
									"condition": 0
								},
								/*{
																	"field": "Type",
																	"value": types,
																	"condition": 0
																},*/
								{
									"field": "Time",
									"value": startTimeNum,
									"condition": 3
								}, {
									"field": "Time",
									"value": endTimeNum,
									"condition": 4
								}


							],
							"page":nowPage,
    						"rows":showNum,
						}
					})
					.then(function(res) { // 调用承诺API获取数据 .resolve
						deferred.resolve(res);
					}, function(res) { // 处理错误 .reject
						deferred.reject(res);
					});
				return deferred.promise;
			}

		}
	}])