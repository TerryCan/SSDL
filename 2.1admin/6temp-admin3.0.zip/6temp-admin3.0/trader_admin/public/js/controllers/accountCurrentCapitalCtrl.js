app.controller('accountCurrentCapitalCtrl', ['$rootScope', '$scope', 'accountCurrentCapitalAll', '$timeout', '$sce', 'getPageNum', 'getCurrencyType', 'getBankAccount','localStorageService', function ($rootScope, $scope, accountCurrentCapitalAll,$timeout, $sce, getPageNum, getCurrencyType, getBankAccount,localStorageService) {
    $scope.toggleTraderSearchState=false;
    $scope.Toggle = function(){
        $scope.toggleTraderSearchState = !$scope.toggleTraderSearchState;
        if($scope.toggleTraderSearchState){
           $('.search_column').css('height','auto');
        }
        else{
           $('.search_column').css('height','36px');
        }
    };
    // 货币转换
    getCurrencyType.then(function (res) {
        $scope.currencyList = JSON.parse(res.content);
    });
    //签约状态
    $scope.bankAccount = getBankAccount;


    var processContent, processTotal;
    var source = {
        type: 'POST',
        datatype: "json",
        datafields: [  //数据字段定义
            {name: 'channelName', type: 'string'},
            {name: 'userName', type: 'string'},
            {name: 'cardName', type: 'string'},
            {name: 'custNo', type: 'string'},
            {name: 'custName', type: 'string'},
            {name: 'signupState', type: 'string'},

            {name: 'currency', type: 'string'},
            {name: 'balance', type: 'string'}
        ],
        url: $rootScope.baseUrl + 'exbank/bank/signup/query/page',
        root: "content",
        pagesize: 10,
        processData: function (data) {
            console.log(data)
            data.page = (data.pagenum + 1) ? (data.pagenum + 1) : 1;
            data.rows = (data.pagesize) ? (data.pagesize) : 10;
            data.order = ($scope.order) ? $scope.order : 'desc';
            data.sort = ($scope.sort) ? $scope.sort : 'createTime';
            data.search_A_EQ_userId = ($scope.directiveUserId) ? $scope.directiveUserId : '';

            $scope.orgCode = localStorageService.get('oldOrgCode');
            if ($scope.organizeValue == true && $scope.downOrganizeValue == true) {
                data.search_A_LLIKE_orgCode = ($scope.orgCode) ? $scope.orgCode : '';
            }
            if ($scope.organizeValue == true && $scope.downOrganizeValue == false) {
                data.search_A_EQ_orgCode = ($scope.orgCode) ? $scope.orgCode : '';
            }
            if ($scope.organizeValue == false && $scope.downOrganizeValue == true) {
                data.search_A_LLIKE_orgCode = ($scope.orgCode) ? $scope.orgCode + '-' : '';
            }
        }, //传递参数处理
        beforeLoadComplete: function (records) { //数据完全加载完执行绘制表格
            console.log(records)
            var start;
            for (var i in records) {
                start = parseInt(i);
                break;
            }
            for (var k = 0, r = processContent.length; k < r; k++) {
                records[start + k].channelName = processContent[k].channelName;
                records[start + k].userName = processContent[k].userName;
                records[start + k].cardName = processContent[k].cardName;
                records[start + k].custNo = processContent[k].custNo;
                records[start + k].custName = processContent[k].custName;
                records[start + k].signupState = processContent[k].signupState;

                records[start + k].currency = processContent[k].currency;
                records[start + k].balance = processContent[k].balance;
            }
        },
        beforeprocessing: function (data) { //处理总页数
            var processData = JSON.parse(data.content);
            processContent = processData.content;
            source.totalrecords = processData.totalElements == 0 ? 5 : processData.totalElements;
            processTotal = processData.totalElements;
        },
        loadComplete: function (records) {
            $scope.saveResult = JSON.parse(records.content);
            var data = $scope.saveResult.totalElements;
            if (data == 0) {
                $('#contenttableentrustDetailGrid > div').remove();
            }
        },
        endUpdate: true
    };
    //创建数据适配器
    var dataAdapter = null;
    $scope.searchAjax = function () {
        $scope.toggleTraderSearchState = false;
        $('.search_column').css('height', '36px');
        if (dataAdapter == null) {
            dataAdapter = new $.jqx.dataAdapter(source);
            //创建表格
            $("#entrustDetailGrid").jqxGrid({
                source: dataAdapter,
                columns: [  //表格数据域
                    {
                        text: '商户号',
                        datafield: 'channelName',
                        width: '12%',
                        minwidth: 12 + '%',
                        align: 'center'
                    },
                    {
                        text: '用户名',
                        datafield: 'userName',
                        minwidth: 12 + '%',
                        cellsalign: 'center',
                        align: 'center',
                        width: '12%'
                    },
                    {
                        text: '开户名',
                        datafield: 'cardName',
                        width: '12%',
                        minwidth: 12 + '%',
                        align: 'center'
                    },
                    {
                        text: '签约编号',
                        datafield: 'custNo',
                        minwidth: 20 + '%',
                        cellsalign: 'center',
                        align: 'center',
                        width: '20%'
                    },
                    {
                        text: '签约名',
                        datafield: 'custName',
                        minwidth: 16 + '%',
                        align: 'center',
                        width: '16%'
                    },
                    {
                        text: '签约状态',
                        datafield: 'signupState',
                        minwidth: 12 + '%',
                        cellsalign: 'center',
                        align: 'center',
                        width: '12%',
                        cellsrenderer: function (row, columnfield, value, defaulthtml, columnproperties) {
                            if (getBankAccount) {
                                for (var i = 0; i < getBankAccount.length; i++) {
                                    if (value == getBankAccount[i].id) {
                                        return getBankAccount[i].name;
                                    }
                                }
                            }
                        }
                    },
                    {
                        text: '币种',
                        datafield: 'currency',
                        minwidth: 8 + '%',
                        width: '8%',
                        align: 'center',
                        cellsrenderer: function (row, columnfield, value, defaulthtml, columnproperties) {
                            if ($scope.currencyList) {
                                for (var i = 0; i < $scope.currencyList.length; i++) {
                                    if (value == $scope.currencyList[i].currency) {
                                        return $scope.currencyList[i].currencyName;
                                    }
                                }
                            }
                        }
                    },
                    {
                        text: '可用余额',
                        datafield: 'balance',
                        minwidth: 8 + '%',
                        cellsalign: 'center',
                        align: 'center',
                        width: '8%'
                    }
                ],
                width: 100 + '%',
                height: 87 + '%',
                theme: 'metrodark',
                virtualmode: true,
                rendergridrows: function (params) { //将数据渲染到页面
                    return params.data;
                },
                pageable: true,
                pagesizeoptions: ['10', '30', '100', '200'],
                // sortable: true,
                columnsresize: true,//列间距是否可调整
                selectionmode: 'singlecell',//选择模式
                clipboard: true,
            });
        } else {
            $("#entrustDetailGrid").jqxGrid('updatebounddata', 'cells');
        }
    };
    //分页
    $("#entrustDetailGrid").on("pagechanged", function (event) {
        console.log(event)
    });
    //排序
    $("#entrustDetailGrid").on("sort", function (event) {
        var sortinformation = event.args.sortinformation;
        $scope.sort = sortinformation.sortcolumn;
        $scope.order = ($scope.sort) ? (sortinformation.sortdirection.ascending) ? 'asc' : 'desc' : 'asc';
        data = {
            order: $scope.order,
            sort: $scope.sort
        };
        source.processData(data);
        $("#entrustDetailGrid").jqxGrid('updatebounddata', 'sort');
    });

}])

// Server  实时资金
    .factory('accountCurrentCapitalAll', ['$http', 'localStorageService', 'myHttp', '$q', function ($http, localStorageService, myHttp, $q) {
        return {
            unitSearch: function (json) {
                var deferred = $q.defer();
                myHttp.post('exbank/bank/signup/query/page', json)
                    .then(function (res) {
                        deferred.resolve(res)
                    }, function (res) {
                        deferred.reject(res)
                    })
                return deferred.promise;
            }
        }
    }]);