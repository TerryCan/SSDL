app.controller('productClassificationEditCtrl', ['$scope', '$rootScope', '$state', 'productClassificationCtrlSer', 'localStorageService', 'dataSer', 'getCurrencyType', 'getPageNum', 'tipService', 'confirmService', 'getProductScope', 'productClassificationEditCtrlSer','memberMangerCtrlSer', function($scope, $rootScope, $state, productClassificationCtrlSer, localStorageService, dataSer, getCurrencyType, getPageNum, tipService, confirmService, getProductScope, productClassificationEditCtrlSer,memberMangerCtrlSer) {
			//机构列表
			$scope.addOrgVal = ''; //显示值
			$scope.addOptOrgVal = '';
			$scope.orgCode = '';
			$scope.orgOptCode = '';
			$scope.orgId = ''; //选择值
			$scope.orgOptId = '';
			dataSer.organizeQuerySer()
				.then(function(res) {
					$scope.orgList = res;
					console.log($scope.orgList)
				});
			$scope.addOrgValFTC = function(d) {
				$scope.addOrgVal = d.text;
				$scope.orgId = d.orgId;
				$scope.orgCode = d.orgCode;
			}
			$scope.addOrgOptValFTC = function(d) {
					$scope.addOptOrgVal = d.text;
					$scope.orgOptId = d.orgId;
					$scope.orgOptCode = d.orgCode;
				}
				//获取币种
			getCurrencyType
				.then(function(res) {
					$scope.getCurrencybz = JSON.parse(res.content);
					console.log($scope.getCurrencybz)
				});
			$scope.getCurrency = function(parameter) {
				for (var i = 0; i < $scope.getCurrencybz.length; i++) {
					if (parameter == $scope.getCurrencybz[i].id) {
						return $scope.getCurrencybz[i].name;
					}
				}
			}

			memberMangerCtrlSer.search(9999,1,'','','')
			.then(function(res){
				//console.log(res)
				$scope.memberNum=JSON.parse(res.content).content;
				console.log($scope.memberNum)
			})

			$scope.memberNumText = function(orgCode){
					if($scope.memberNum !== null && $scope.memberNum !== undefined){
						console.log($scope.memberNum)
				 	for (var i = 0,r = $scope.memberNum.length; i < r; i++) {
				 		if (orgCode == $scope.memberNum[i].orgCode) {
				 			return $scope.memberNum[i].orgNum;
				 			console.log($scope.memberNum[i].orgNum)
				 		}
				 	}
					}
				}

			$scope.memberTexttype = function(orgCode){
				console.log($scope.memberNum)
				if($scope.memberNum){
					console.log($scope.memberNum)
				 	for (var i = 0,r = $scope.memberNum.length; i < r; i++) {
				 		if (orgCode == $scope.memberNum[i].orgCode) {
				 			return $scope.memberNum[i].orgName;
				 		}
				 	}
				 }
			}



			$scope.ProductScope = getProductScope; //获取产品作用域
			//绑定参数
			$scope.productId = ''; //产品ID
			$scope.productName = ''; //产品名
			$scope.productCode = ''; //产品代码
			$scope.contractNum = ''; //合约大小
			$scope.productCurrency = ''; //产品币种
			$scope.effectType = ''; //作用类型
			$scope.unionMinPrices = ''; //最小跳动价格
			interestMin= '';	//仓息最小值
			interestMax= '';	//仓息最大值
			keepDepositMin= '';	//维持保证金最小值
			keepDepositMax= '';	//维持保证金最大值
			poundageMin= '';	//手续费最小值
			poundageMax= '';	//手续费最大值



			//获取产品信息
			var productId = localStorageService.get('productMmanageChooseProId');
			productClassificationCtrlSer.getProInfo(productId)
				.then(function(res) {
					if (res.data.code == '000000') {
						var data = JSON.parse(res.data.content);
						$scope.datacom = JSON.parse(res.data.content);
						console.log(data);
						$scope.productId = data.productId;
						$scope.productName = data.productName;
						$scope.productCode = data.productCode;
						$scope.contractNum = data.contractNum;
						$scope.productCurrency = data.productCurrency;
						$scope.effectType = data.effectType;
						$scope.orgCodeVal = data.orgCode;
						//$scope.addOrgVal =data.orgCode;
						console.log($scope.addOrgVal)
						$scope.orgId = data.orgId;
						$scope.unionMinPrices = data.unionMinPrices;
						$scope.interestMin=data.interestMin;	//仓息最小值
						$scope.interestMax=data.interestMax;	//仓息最大值
						$scope.keepDepositMin=data.keepDepositMin;	//维持保证金最小值
						$scope.keepDepositMax=data.keepDepositMax;	//维持保证金最大值
						$scope.poundageMin=data.poundageMin;	//手续费最小值
						$scope.poundageMax=data.poundageMax;
                        $scope.considerationNum=data.considerationNum;
					}
				});


					 //匹配机构代码
		    var json = {
		        page: 1,
		        rows: 999,
		        search_A_EQ_state: 1
		    };
		    dataSer.getOrganize(json).then(function (res) {
		        if (res.code == '000000') {
		            $scope.equalOrgCode = JSON.parse(res.content).content;
		            for (var i = 0; i < $scope.equalOrgCode.length; i++) {
		                if ($scope.datacom.orgCode == $scope.equalOrgCode[i].orgCode) {
		                   $scope.addOrgVal =$scope.equalOrgCode[i].orgName +'('+$scope.equalOrgCode[i].orgNum+')';
		                }
		                 if ($scope.datacom.orgCode == $scope.equalOrgCode[i].orgCode) {
		                   $scope.orgCode = $scope.equalOrgCode[i].orgNum;
		                }
		            }
		        } else {
		            console.log(res);
		        }
		    });

			$scope.editProduct = function() {
				var product = {
						productId: $scope.productId,
						productName: $scope.productName,
						productCode: $scope.productCode,
						orgId: $scope.orgId,
						orgCode: $scope.orgCodeVal,
						contractNum: $scope.contractNum,
						productCurrency: $scope.productCurrency,
						effectType: $scope.effectType,
						interestMin:$scope.interestMin,//仓息最小值
						interestMax:$scope.interestMax,//仓息最大值
						keepDepositMin:$scope.keepDepositMin,//维持保证金最小值
						keepDepositMax:$scope.keepDepositMax,//维持保证金最大值
						poundageMin:$scope.poundageMin,//手续费最小值
						poundageMax:$scope.poundageMax,//手续费最大值
                    	considerationNum:parseInt($scope.considerationNum),
					}
				productClassificationEditCtrlSer.edit(product)
					.then(function(res) {
						console.log(res);
						if (res.data.code == '000000') {
							$rootScope.tipService.setMessage(res.data.message, 'warning');
							$state.go('tabs.productClassification');
						} else {
							$rootScope.tipService.setMessage(res.data.message, 'warning');
						}
					});
			}
			$scope.goBack = function() {
				$state.go('tabs.productClassification');
			}
	}])
	.factory('productClassificationEditCtrlSer', ['$http', 'localStorageService', 'myHttp', '$q', '$rootScope', function($http, localStorageService, myHttp, $q, $rootScope) {
		return {
			edit: function(product) {
				var deferred = $q.defer();
				$http({
					method: 'POST',
					url: $rootScope.baseUrl + 'config/product/update',
					data: {
						"product": product
					}
				}).then(function successCallback(response) {
					deferred.resolve(response);
				}, function errorCallback(response) {
					deferred.reject(response);
				});
				return deferred.promise;
			}
		}
	}])