app.controller('accountUnusualManageCtrl', ['$rootScope', '$scope', 'accountUnusualManageSer', '$timeout', '$sce', 'getPageNum', 'getBankOpState', 'timestamp', 'getTradeType','localStorageService', function ($rootScope, $scope, accountUnusualManageSer, $timeout, $sce, getPageNum, getBankOpState, timestamp, getTradeType,localStorageService) {
    $scope.toggleTraderSearchState=false;
    $scope.Toggle = function(){
        $scope.toggleTraderSearchState = !$scope.toggleTraderSearchState;
        if($scope.toggleTraderSearchState){
           $('.search_column').css('height','auto');
        }
        else{
           $('.search_column').css('height','36px');
        }
    };
    localStorageService.clear('userIdChecked');
    // 数据转换
    $scope.timeSwitch = function (stamp) {
        return timestamp.timestampCoverHms(stamp, 'all')
    };
    // 银行反馈
    $scope.BankOpState = getBankOpState;
    $scope.getBankState = function (parameter) {
        for (var i = 0; i < $scope.BankOpState.length; i++) {
            if (parameter == $scope.BankOpState[i].id) {
                return $scope.BankOpState[i].name;
            }
        }
    };
    // 流水类型
    $scope.switchTradeType = function (parameter) {
        for (var i = 0; i < getTradeType.length; i++) {
            if (parameter == getTradeType[i].id) {
                return getTradeType[i].name;
            }
        }

    };

    var processContent,processTotal;
    var source = {
        type: 'POST',
        datatype: "json",
        datafields: [  //数据字段定义
            {name: 'accountIoId', type: 'string'},
            {name: 'userName', type: 'string'},
            {name: 'bankOpState', type: 'string'},
            {name: 'tradeType', type: 'string'},
            {name: 'createTime', type: 'string'}
        ],
        url: $rootScope.baseUrl + 'account/io/query/page',
        root: "content",
        pagesize:10,
        processData: function (data) {
            data.page = (data.pagenum + 1)?(data.pagenum + 1):1;
            data.rows =(data.pagesize)?(data.pagesize):10;
            // data.order =($scope.order)?$scope.order:'desc';
            // data.sort =($scope.sort)?$scope.sort:'createTime';
            data.search_A_EQ_userId = ($scope.directiveUserId) ? $scope.directiveUserId : '';
            data.search_A_EQ_bankOpState =-1;
            data.search_A_LIKE_orgCode = ($scope.orgCode)?$scope.orgCode:'';
        }, //传递参数处理
        beforeLoadComplete: function (records) { //数据完全加载完执行绘制表格
            var start;
            for (var i in records) {
                start = parseInt(i);
                break;
            }
            for (var k = 0, r = processContent.length; k < r; k++) {
                records[start + k].accountIoId = processContent[k].accountIoId;
                records[start + k].userName = processContent[k].userName;
                records[start + k].bankOpState = processContent[k].bankOpState;
                records[start + k].tradeType = processContent[k].tradeType;
                records[start + k].createTime = processContent[k].createTime;
            }
        },
        beforeprocessing: function (data) { //处理总页数
            var processData = JSON.parse(data.content);
            console.log(processData)
            processContent = processData.content;
            source.totalrecords = processData.totalElements == 0 ? 5 : processData.totalElements;
            processTotal = processData.totalElements;
        },
        loadComplete: function (records) {
            $scope.saveResult=JSON.parse(records.content);
            var data =  $scope.saveResult.totalElements;
            if (data == 0) {
                $('#contenttableentrustDetailGrid > div').remove();
            }
        },
        endUpdate: true
    };
    //创建数据适配器
    var dataAdapter = null;
    $scope.searchAjax = function () {
        $scope.featureShow=true;
        $scope.toggleTraderSearchState = false;
        $('.search_column').css('height', '36px');
        if (dataAdapter == null) {
            dataAdapter = new $.jqx.dataAdapter(source);
            //创建表格
            $("#entrustDetailGrid").jqxGrid({
                source: dataAdapter,
                columns: [  //表格数据域
                    {
                        text: '用户名',
                        datafield: 'userName',
                        width: '25%',
                        align: 'center'//设置表头
                    },
                    {
                        text: '银行反馈',
                        datafield: 'bankOpState',
                        cellsalign: 'center',
                        align: 'center',
                        width: '25%',
                        cellsrenderer: function (row, columnfield, value, defaulthtml, columnproperties) {
                            if (getBankOpState) {
                                for (var i = 0; i <getBankOpState.length; i++) {
                                    if (value ==getBankOpState[i].id) {
                                        return getBankOpState[i].name;
                                    }
                                }
                            }
                        }
                    },
                    {
                        text: '流水类型',
                        datafield: 'tradeType',
                        width:'25%',
                        align: 'center',
                        cellsrenderer: function (row, columnfield, value, defaulthtml, columnproperties) {
                            if (getTradeType) {
                                for (var i = 0; i <getTradeType.length; i++) {
                                    if (value ==getTradeType[i].id) {
                                        return getTradeType[i].name;
                                    }
                                }
                            }
                        }
                    },
                    {
                        text: '日期',
                        datafield: 'createTime',
                        width:'25%',
                        align: 'center',
                        cellsrenderer: function (row, columnfield, value, defaulthtml, columnproperties) {
                            return timestamp.timestampCoverHms(value, 'all');
                        }
                    },
                ],
                width: 100 + '%',
                height: 81 + '%',
                theme:'metrodark',
                virtualmode: true,
                rendergridrows: function (params) { //将数据渲染到页面
                    return params.data;
                },
                pageable: true,
                pagesizeoptions: ['10','30','100','200'],
                // sortable: true,
                columnsresize: true,//列间距是否可调整
                // selectionmode: 'singlecell',//选择模式
                clipboard: true,
                // selectionmode: 'checkbox',//复选框
            });
        }else {
            $("#entrustDetailGrid").jqxGrid('updatebounddata', 'cells');
        }
    };

    //分页
    $("#entrustDetailGrid").on("pagechanged", function (event) {
        console.log(event)
    });
    //排序
    // $("#entrustDetailGrid").on("sort", function (event) {
    //     var sortinformation = event.args.sortinformation;
    //     $scope.sort=sortinformation.sortcolumn;
    //     $scope.order=($scope.sort)?(sortinformation.sortdirection.ascending)?'asc':'desc':'asc';
    //     data={
    //         order:$scope.order,
    //         sort:$scope.sort
    //     };
    //     source.processData(data);
    //     $("#entrustDetailGrid").jqxGrid('updatebounddata', 'sort');
    // });
    //选中
    $('#entrustDetailGrid').on('rowselect', function (event) {
        $scope.ioId = event.args.row.accountIoId;
        console.log( $scope.ioId)
    });

    //重发
    $scope.retry = function () {
        if (!$scope.ioId) {
            $rootScope.tipService.setMessage('请先选择用户', 'warning');
        } else {
            var json = {
                accountIoId: $scope.ioId
            };
            accountUnusualManageSer.unitRetry(json)
                .then(function (res) {
                    $rootScope.tipService.setMessage(res.message, 'warning');
                    $scope.searchAjax();
                }, function (error) {
                    $rootScope.tipService.setMessage(error.message, 'warning');
                })
        }
    };
    //修复
    $scope.repair = function () {
        if (!$scope.ioId) {
            $rootScope.tipService.setMessage('请先选择用户', 'warning');
        } else {
            var json = {
                accountIoId: $scope.ioId
            }
            accountUnusualManageSer.unitRepaire(json)
                .then(function (res) {
                    $rootScope.tipService.setMessage(res.message, 'warning');
                    $scope.searchAjax();
                }, function (error) {
                    $rootScope.tipService.setMessage(error.message, 'warning');
                })
        }
    }
}])

// Server
    .factory('accountUnusualManageSer', ['$http', 'localStorageService', 'myHttp', '$q', '$rootScope', function ($http, localStorageService, myHttp, $q, $rootScope) {
        return {
            unitSearch: function (json) {
                var deferred = $q.defer();
                myHttp.post("account/io/query/page", json)
                    .then(function (res) {
                        deferred.resolve(res);
                    }, function (res) {
                        deferred.reject(res);
                    });
                return deferred.promise;
            },
            unitRetry: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'account/io/audit/repaire',
                    data: json,
                    headers: {
                        'Content-Type': 'application/json;charset=UTF-8'
                    }
                }).success(function (res) {
                    deferred.resolve(res);
                }).error(function (res) {
                    deferred.reject(res)
                });
                return deferred.promise;
            },
            unitRepaire: function (json) {
                var deferred = $q.defer();
                $http({
                    method: 'POST',
                    url: $rootScope.baseUrl + 'account/io/audit/fix',
                    data: json,
                    headers: {
                        'Content-Type': 'application/json;charset=UTF-8'
                    }
                }).success(function (res) {
                    deferred.resolve(res);
                }).error(function (res) {
                    deferred.reject(res)
                });
                return deferred.promise;
            }
        }
    }])