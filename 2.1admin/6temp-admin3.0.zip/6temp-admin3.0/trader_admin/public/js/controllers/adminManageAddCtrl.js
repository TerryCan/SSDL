app.controller("adminManageAddCtrl", function($scope, $state, $rootScope, tipService, confirmService, getUserStates, dataSer, timestamp, addAllTypeUserCtrlSer, localStorageService, $timeout, memberMangerCtrlSer) {
        var getUserInfo = localStorageService.get("userInfo");

        getUserStates.userState()
            .then(function(res) {
                $scope.userState = res;
                if (getUserInfo)
                    $scope.userState = $scope.userState[getUserInfo.state];
            });
        //机构列表
        $scope.addOrgVal = ''; //显示值
        $scope.orgId = ''; //选择值
        dataSer.organizeQuerySer()
            .then(function(res) {
                $scope.orgList = res;
                console.log(res);
            });
        $scope.addOrgValFTC = function(orgId, text) {
            $scope.addOrgVal = text;
            $scope.orgId = orgId;
            var json = {
                orgId: $scope.orgId,
                roleType: 3
            };
            memberMangerCtrlSer.getRoleType(json)
                .then(function(res) {
                    if (res.data.code == '000000') {
                        $scope.userList = JSON.parse(res.data.content);
                        console.log($scope.userList);
                    } else {
                        $rootScope.tipService.setMessage(res.data.message, 'warning');
                    }
                }, function(error) {
                    $rootScope.tipService.setMessage(error.data.message, 'warning');
                })
        };

        $scope.typeName = '管理员角色';
        $scope.type = 3;
        $scope.orgListDisplay = false;
        $scope.extendUserToggle = false;
        $scope.contactUserToggle = false;
        $scope.readRisk = false;

        $scope.email = ''; //邮箱
        $scope.phone = ''; //手机号码
        $scope.orgCode = ''; //机构代码

        dataSer.organizeQuerySer()
            .then(function(res) {
                $scope.orgList = res;
            });

        $scope.goBack = function() {
            $state.go('tabs.adminManage');
        };
        //获取机构扩展信息 行业
        dataSer.readIndustry()
            .then(function(res) {
                $scope.getOrgInfoIndustryData = res.industry;
            });
        //获取机构性质
        dataSer.readOccupation()
            .then(function(res) {
                $scope.getReadOccupationData = res.occupation;
            });
        //获取学历数据
        dataSer.readEducation()
            .then(function(res) {
                $scope.getReadEducationData = res.education;
            });
        //投资者性质
        dataSer.readProperty()
            .then(function(res) {
                $scope.getReadPropertyData = res.property;
            });
        //国家 城市 地区 选择
        $scope.isChooseCountry = function() {
            if ($scope.userExtendInfoCountry) {
                dataSer.provinceQuerySer($scope.userExtendInfoCountry)
                    .then(function(res) {
                        if (res.code == '000000') {
                            $scope.provincesData = res.results;
                        }
                    });
            }

        };
        $scope.isChooseProvinces = function() {
            if ($scope.userExtendInfoProvinces) {
                dataSer.cityQuerySer($scope.userExtendInfoProvinces)
                    .then(function(res) {
                        if (res.code == '000000') {
                            $scope.cityData = res.results;
                        }
                    });
            }

        };
        $scope.isChooseCity = function() {
            if ($scope.userExtendInfoCity) {
                dataSer.areaQuerySer($scope.userExtendInfoCity)
                    .then(function(res) {
                        if (res.code == '000000') {
                            $scope.areaData = res.results;
                        }
                    });
            }

        };
        //获取证件类型
        dataSer.readCertificateType()
            .then(function(res) {
                $scope.certificateList = res.certificateType;
            });

        $scope.cStep = function() {
            //用户基本信息
            var createUserSecurityV = {
                email: $scope.email,
                loginName: $scope.loginName,
                phone: $scope.phone,
                password: $scope.password,
                roleId: $scope.roleId
            };
            //用户实名信息
            var userRealInfoV = {
                name: $scope.userRealInfoName,
                certificateType: $scope.userRealInfoCertificateType,
                certificateNo: $scope.userRealInfoCertificateCode,
                cpFId: $scope.userRealInfoCertificateImg1,
                cbFId: $scope.userRealInfoCertificateImg2,
                chFId: $scope.userRealInfoCertificateImg3

            };
            //用户扩展信息
            var userInfoV = {
                country: $scope.userExtendInfoCountry,
                provinces: $scope.userExtendInfoProvinces,
                city: $scope.userExtendInfoCity,
                area: $scope.userExtendInfoArea,
                sex: $scope.userExtendInfoSex,
                birthday: $scope.userExtendInfoBirthday,
                nativePlace: $scope.userExtendInfoNativePlace,
                education: $scope.userExtendInfoEducation,
                occupation: $scope.userExtendInfoOccupation,
                industry: $scope.userExtendInfoIndustry,
                marriage: $scope.userExtendInfoMarriage,
                qq: $scope.userExtendInfoQQ,
                property: $scope.userExtendInfoProperty

            };
            //用户联系人
            var contactsVs = [{
                name: $scope.contactsListName,
                telephone: $scope.contactsListLocalPhone,
                mobileTelephone: $scope.contactsListMobilePhone,
                email: $scope.contactsListEmail,
                address: $scope.contactsListAdress,
                postcode: $scope.contactsListPostCode,
                sex: $scope.contactsListGender,
                fax: $scope.contactsListFax
            }];
            if (toValidate('#adminAdd')) {
                addAllTypeUserCtrlSer.addAdminManage($scope.orgId, $scope.type, createUserSecurityV, userRealInfoV, userInfoV, contactsVs)
                    .then(function(res) {
                        if (res.data.code === '000000') {
                            $rootScope.tipService.setMessage(res.data.message, 'warning');
                            $state.go('tabs.adminManage');
                        } else {
                            $rootScope.tipService.setMessage(res.data.message, 'warning');
                        }
                    }, function(error) {
                        $rootScope.tipService.setMessage(error.data.message, 'warning');
                    });

            }
        };
        //图片上传
        uploadImg = function(id, num) {
            console.log(id);
            var urlUpload = $rootScope.baseUrl + 'file/upload';
            upload_img(urlUpload, id, function(res, status) {
                if (res.code === '000000') {
                    var data = JSON.parse(res.content);
                    console.log(data);
                    var ImgId = data[0].fileId;
                    switch (num) {
                        case 1:
                            $scope.userRealInfoCertificateImg1 = ImgId;
                            $('#uploadImg1').attr('src', "" + $rootScope.baseUrl + "/file/download?fileId=" + ImgId + "");
                            break;
                        case 2:
                            $scope.userRealInfoCertificateImg2 = ImgId;
                            $('#uploadImg2').attr('src', "" + $rootScope.baseUrl + "/file/download?fileId=" + ImgId + "");
                            break;
                        case 3:
                            $scope.userRealInfoCertificateImg3 = ImgId;
                            $('#uploadImg3').attr('src', "" + $rootScope.baseUrl + "/file/download?fileId=" + ImgId + "");
                            break;
                    }
                }
            });
        };

        // 上传图片
        // url:后台访问路径 fileId:input file按钮id, btn:点击的按钮id, fileInput:接收上传图片的id
        function upload_img(url, fileId, callback) {
            $.ajaxFileUpload({
                url: url,
                type: 'post',
                secureuri: false,
                fileElementId: fileId, // file标签的id
                dataType: 'json', // 返回数据的类型
                data: {
                    name: fileId
                },
                success: function(data, status) {
                    callback(data, status);
                },
                error: function(data, status, e) {
                    console.log(data, status, e);
                }
            });
        }
		 //放大图片
    $('.example img').zoomify();
   /* var imgs = document.getElementsByTagName("img");
    var lens = imgs.length;
    var popup = document.getElementById("popup");

    for (var i = 0; i < lens; i++) {
        imgs[i].onclick = function (event) {
            event = event || window.event;
            var target = document.elementFromPoint(event.clientX, event.clientY);
            showBig(target.src);
        }
    }
    popup.onclick = function () {
        popup.style.display = "none";
    };

    function showBig(src) {
        popup.getElementsByTagName("img")[0].src = src;
        popup.style.display = "block";
    }*/
});