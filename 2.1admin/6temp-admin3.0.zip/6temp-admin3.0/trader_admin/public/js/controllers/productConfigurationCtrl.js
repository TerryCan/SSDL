app.controller('productConfigurationCtrl', ['$scope', '$rootScope', 'productConfigurationCtrlSer', 'tipService', 'getPageNum', 'CommissionallocationAddCtrlSer', 'dataSer', 'getCurrencyType', '$state', 'localStorageService', 'getClassificationState','confirmService', function($scope, $rootScope, productConfigurationCtrlSer, tipService, getPageNum, CommissionallocationAddCtrlSer, dataSer, getCurrencyType, $state, localStorageService, getClassificationState,confirmService) {
	$scope.tableshow = false;
	$scope.entrynum = false;
	$scope.search_productId = '';
	$scope.addConfiguration = function() {
		$scope.tableshow = true;
		$scope.entrynum = false;
	}

	$scope.editConfiguration = function() {
		$scope.tableshow = true;
		$scope.entrynum = true;
	}

	$scope.search = function(type) {
		if (type == 'search') {
			pageInitialize()
		};
		productConfigurationCtrlSer.search($scope.showNum.showNum, $scope.currentPage, $scope.search_productId)
			.then(function(res) {
				console.log(res)
				if (res.code == '000000'){
					$scope.showPage = true;
					$scope.searchResult = JSON.parse(res.content).content;
					$scope.dataNum = JSON.parse(res.content).totalElements;
					$scope.PageNum();
					console.log($scope.searchResult)
				} else {
					$rootScope.tipService.setMessage(res.message, 'warning');
				}
			}, function(error) {
				$rootScope.tipService.setMessage(error.message, 'warning');
			});
	}

	$scope.turnPage = function(url, index, productCustomizedId) {
		$state.go(url, index, productCustomizedId);
	}


		//产品ID
		$scope.userInfo = localStorageService.get('selfInfo');
				console.log($scope.userInfo)
				var json ={
					orgId:$scope.userInfo.orgId,
				};
				console.log(json)
				//产品ID
				CommissionallocationAddCtrlSer.productListadmin(json)
				.then(function(res) {
					console.log(res)
					if(res.code=="000000"){
					var proadminlistdt = JSON.parse(res.content);
					$scope.proadminlist = [];
					for (var i = 0, r = proadminlistdt.length; i < r; i++) {
							$scope.proadminlist.push(proadminlistdt[i]);
					}
					console.log($scope.proadminlist)
				}else{
						$rootScope.tipService.setMessage(res.message, 'warning')
					}
				}),function(error){
						$rootScope.tipService.setMessage(error.message, 'warning')
					}

	$scope.PtText = function(productId) {
		if ($scope.prolist) {
			for (var i = 0, r = $scope.prolist.length; i < r; i++) {
				//console.log($scope.prolist[i])
				if ($scope.prolist[i].productId == productId) {
					return $scope.prolist[i].productName;
				}
			}
		}
	}

	//全部状态下所属机构
	dataSer.organizeQuerylistSer()
		.then(function(res) {
				$scope.orgAllList = res;
		});

	$scope.adjustText = function(OrgCode) {
		if ($scope.orgAllList) {
			for (var i = 0, r = $scope.orgAllList.length; i < r; i++) {
				if ($scope.orgAllList[i].orgCode == OrgCode) {
					return $scope.orgAllList[i].text;
				}
			}
		}
	}

	//单选
	$scope.chooseProId = null;
	$scope.checked = function(index, productCustomizedId) {
		$scope.chooseProId = productCustomizedId;

		//console.log($scope.chooseProId)
		$('#dataReport input[type=checkbox]').prop('checked', false);
		$('#dataReport input[type=checkbox]').eq(index).prop('checked', true);

	}

	//修改
	$scope.edit = function(url) {
		if ($scope.chooseProId == null) {
			$rootScope.tipService.setMessage('请先选择客户', 'warning');
		} else {
			localStorageService.update('PMChooseProlist', $scope.chooseProId);
			$state.go(url);
		}
	}
	$scope.ProStateList = getClassificationState;
	$scope.getProStateList = function(params) {
		for (var i = 0, r = $scope.ProStateList.length; i < r; i++) {
			if (params == $scope.ProStateList[i].id) {
				return $scope.ProStateList[i].name;
			}
		}
	}

	//审核通过
	$scope.pass = function(productCustomizedId) {
			productConfigurationCtrlSer.pass(productCustomizedId)
				.then(function(res) {
					console.log(res);
					if (res.data.code == '000000') {
						$rootScope.tipService.setMessage(res.data.message, 'warning');
						$scope.search();
					} else {
						$rootScope.tipService.setMessage(res.data.message, 'warning');
					}
				});
		}
		//驳回
	$scope.fail = function(productCustomizedId) {
			productConfigurationCtrlSer.fail(productCustomizedId)
				.then(function(res) {
					console.log(res);
					if (res.data.code == '000000') {
						$rootScope.tipService.setMessage(res.data.message, 'warning');
						$scope.search();
					}else {
						$rootScope.tipService.setMessage(res.data.message, 'warning');
					}
				});
		}
		//启用
	$scope.open = function(productCustomizedId) {
			productConfigurationCtrlSer.open(productCustomizedId)
				.then(function(res) {
					console.log(res);
					if (res.data.code == '000000') {
						$rootScope.tipService.setMessage(res.data.message, 'warning');
						$scope.search();
					}else {
						$rootScope.tipService.setMessage(res.data.message, 'warning');
					}
				});
		}
		//禁用
	$scope.close = function(productCustomizedId) {
			productConfigurationCtrlSer.close(productCustomizedId)
				.then(function(res) {
					console.log(res);
					if (res.data.code == '000000') {
						$rootScope.tipService.setMessage(res.data.message, 'warning');
						$scope.search();
					}else {
						$rootScope.tipService.setMessage(res.data.message, 'warning');
					}
				});
		}
		//冻结
	$scope.freeze = function(productCustomizedId) {
			productConfigurationCtrlSer.freeze(productCustomizedId)
				.then(function(res) {
					console.log(res);
					if (res.data.code == '000000') {
						$rootScope.tipService.setMessage(res.data.message, 'warning');
						$scope.search();
					}else {
						$rootScope.tipService.setMessage(res.data.message, 'warning');
					}
				});
		}
		//解冻
	$scope.unfreeze = function(productCustomizedId) {
		productConfigurationCtrlSer.unfreeze(productCustomizedId)
			.then(function(res) {
				console.log(res);
				if (res.data.code == '000000') {
					$rootScope.tipService.setMessage(res.data.message, 'warning');
					$scope.search();
				}else {
						$rootScope.tipService.setMessage(res.data.message, 'warning');
					}
			});
	}

		//删除
	$scope.delete = function() {
			if (!$scope.chooseProId) {
				$rootScope.tipService.setMessage('请先选择个性化配置信息', 'warning');
			} else {
				confirmService.set('确认提示', '确定要删除此个性化配置信息?', function() {
					productConfigurationCtrlSer.Delete($scope.chooseProId)
						.then(function(res) {
							if (res.data.code == "000000") {
							$rootScope.tipService.setMessage(res.data.message, 'warning');
							$scope.search();
							} else {
								$rootScope.tipService.setMessage(res.data.message, 'warning');
							}
						}, function(error) {
							$rootScope.tipService.setMessage(error.data.message, 'warning');
						});
					confirmService.clear();
				});
			}
		}



	/* 分页功能实现 */
	var pageInitialize = function() {
		$scope.dataNum = 0; //数据总条数
		$scope.dataPage = 0; //分页数
		$scope.currentPage = 1; //当前页数
		$scope.jumpPageNum = '';
	}
	$scope.showDataChoose = getPageNum.pageNum(); //获取分页
	$scope.showNum = $scope.showDataChoose[0]; //初始显示刷具条数
	$scope.dataPageNumber = []; //生成页面数
	$scope.showPage = false;
	$scope.pageSelect = function(params) {
		$scope.showNum.showNum = params.showNum;
		pageInitialize();
		$scope.search();
	}
	$scope.changePageNumber = function(params) {
		$scope.currentPage = params;
		$scope.search();
		$scope.PageNum();
	}
	$scope.PageNum = function() {
		if ($scope.showNum.showNum < $scope.dataNum) {
			$scope.dataPage = parseInt($scope.dataNum / $scope.showNum.showNum) + 1;
		} else {
			$scope.dataPage = 0;
		}
		$scope.dataPageNumber = [];
		for (var i = 0; i < $scope.dataPage; i++) {
			$scope.dataPageNumber.push(i + 1);
		}
	}
	$scope.jumpPage = function(num) {
		num = parseInt(num);
		if (parseInt(num, 10) === num && num <= ($scope.dataPage + 1) && num > 0) {
			$scope.currentPage = num;
			$scope.PageNum();
			$scope.search();
		}
	}
	$scope.pageSlect = function(type) {
		if (type == 'prev') {
			if ($scope.currentPage != 1) {
				$scope.currentPage--;
				$scope.PageNum();
				$scope.search();
			}
		} else {
			if ($scope.currentPage < $scope.dataPage) {
				$scope.currentPage++;
				$scope.PageNum();
				$scope.search();
			}
		}
	}
	pageInitialize();
	//$scope.search();
}])

.factory('productConfigurationCtrlSer', ['$http', 'localStorageService', 'myHttp', '$q', '$rootScope', function($http, localStorageService, myHttp, $q, $rootScope) {
	return {
		//查询
		search: function(showNum, nowPage, search_productId) {
			var json = {
				page: nowPage,
				rows: showNum,
				orders: 'asc',
				search_LIKE_productId: search_productId
			}
			var deferred = $q.defer();
			myHttp.post("config/product/query/productCustomized/as/page", json)
				.then(function(res) { // 调用承诺API获取数据 .resolve
					deferred.resolve(res);
				}, function(res) { // 处理错误 .reject
					deferred.reject(res);
				});
			return deferred.promise;
		},
		getlistInfo: function(productCustomizedId) {
			var deferred = $q.defer();
			$http({
				method: 'POST',
				url: $rootScope.baseUrl + 'config/product/get/productCustomized/by/productCustomizedid',
				data: {
					"productCustomizedId": productCustomizedId
				}
			}).then(function successCallback(response) {
				//console.log(response)
				deferred.resolve(response);
			}, function errorCallback(response) {
				deferred.reject(response);
			});
			return deferred.promise;
		},
		getProInfo: function(productCustomizedId) {
			var deferred = $q.defer();
			$http({
				method: 'POST',
				url: $rootScope.baseUrl + 'config/product/get/productCustomized/by/productCustomizedid',
				data: {
					"productCustomizedId": productCustomizedId
				}
			}).then(function successCallback(response) {
				//console.log(response)
				deferred.resolve(response);
			}, function errorCallback(response) {
				deferred.reject(response);
			});
			return deferred.promise;
		},
		addData: function(product, productCustomized) {
			var deferred = $q.defer();
			$http({
				method: 'POST',
				url: $rootScope.baseUrl + 'config/product/save/productCustomizeds',
				data: {
					"product": product,
					"productCustomized": productCustomized
				}
			}).then(function successCallback(response) {
				deferred.resolve(response);
			}, function errorCallback(response) {
				deferred.reject(response);
			});
			return deferred.promise;
		},
		pass: function(productCustomizedId) {
			var deferred = $q.defer();
			$http({
				method: 'POST',
				url: $rootScope.baseUrl + 'config/product/pass/customize',
				data: {
					"productCustomizedId": productCustomizedId
				}
			}).then(function successCallback(response) {
				deferred.resolve(response);
			}, function errorCallback(response) {
				deferred.reject(response);
			});
			return deferred.promise;
		},
		fail: function(productCustomizedId) {
			var deferred = $q.defer();
			$http({
				method: 'POST',
				url: $rootScope.baseUrl + 'config/product/fail/customize',
				data: {
					"productCustomizedId": productCustomizedId
				}
			}).then(function successCallback(response) {
				deferred.resolve(response);
			}, function errorCallback(response) {
				deferred.reject(response);
			});
			return deferred.promise;
		},
		open: function(productCustomizedId) {
			var deferred = $q.defer();
			$http({
				method: 'POST',
				url: $rootScope.baseUrl + 'config/product/open/customize',
				data: {
					"productCustomizedId": productCustomizedId
				}
			}).then(function successCallback(response) {
				deferred.resolve(response);
			}, function errorCallback(response) {
				deferred.reject(response);
			});
			return deferred.promise;
		},
		close: function(productCustomizedId) {
			var deferred = $q.defer();
			$http({
				method: 'POST',
				url: $rootScope.baseUrl + 'config/product/close/customize',
				data: {
					"productCustomizedId": productCustomizedId
				}
			}).then(function successCallback(response) {
				deferred.resolve(response);
			}, function errorCallback(response) {
				deferred.reject(response);
			});
			return deferred.promise;
		},
		freeze: function(productCustomizedId) {
			var deferred = $q.defer();
			$http({
				method: 'POST',
				url: $rootScope.baseUrl + 'config/product/freeze/customize',
				data: {
					"productCustomizedId": productCustomizedId
				}
			}).then(function successCallback(response) {
				deferred.resolve(response);
			}, function errorCallback(response) {
				deferred.reject(response);
			});
			return deferred.promise;
		},
		unfreeze: function(productCustomizedId) {
			var deferred = $q.defer();
			$http({
				method: 'POST',
				url: $rootScope.baseUrl + 'config/product/unfreeze/customize',
				data: {
					"productCustomizedId": productCustomizedId
				}
			}).then(function successCallback(response) {
				deferred.resolve(response);
			}, function errorCallback(response) {
				deferred.reject(response);
			});
			return deferred.promise;
		},
		Delete: function(chooseProId) {
			var deferred = $q.defer();
			$http({
				method: 'POST',
				url: $rootScope.baseUrl + 'config/product/delete/productCustomized',
				data: {
					"productCustomizedId": chooseProId
				}
			}).then(function successCallback(response) {
				deferred.resolve(response);
			}, function errorCallback(response) {
				deferred.reject(response);
			});
			return deferred.promise;
		}
	}
}])